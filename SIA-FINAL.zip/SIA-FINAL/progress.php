<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'] ?? 'Learner';
$user_email = $_SESSION['user_email'] ?? '';

$upload_dir = 'uploads/profiles/';
$profile_picture_path = null;

$stmt = $conn->prepare("SELECT profile_picture FROM profiles WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    $profile_filename = $row['profile_picture'] ?? null;
    if (!empty($profile_filename)) {
        $candidate_path = $upload_dir . $profile_filename;
        $filesystem_path = __DIR__ . '/' . $candidate_path;
        if (file_exists($filesystem_path)) {
            $profile_picture_path = $candidate_path;
        }
    }
}
$stmt->close();

$user_theme_color = '#dc2626';
$stmt = $conn->prepare("SELECT theme_color FROM themes WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    $user_theme_color = $row['theme_color'];
}
$stmt->close();

function hexToRgb($hex) {
    $hex = str_replace('#', '', $hex);
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    return [$r, $g, $b];
}

function darkenColor($hex, $percent = 20) {
    $rgb = hexToRgb($hex);
    $r = max(0, min(255, $rgb[0] - ($rgb[0] * $percent / 100)));
    $g = max(0, min(255, $rgb[1] - ($rgb[1] * $percent / 100)));
    $b = max(0, min(255, $rgb[2] - ($rgb[2] * $percent / 100)));
    return sprintf("#%02x%02x%02x", round($r), round($g), round($b));
}

$theme_rgb = hexToRgb($user_theme_color);
$theme_rgba_15 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.15)";
$theme_rgba_10 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.1)";
$theme_rgba_05 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.05)";
$theme_rgba_20 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.2)";
$theme_rgba_25 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.25)";
$theme_rgba_30 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.3)";
$theme_darker = darkenColor($user_theme_color, 15);

function getInitials($name) {
    $words = preg_split('/\s+/', trim($name));
    if (!$words || count($words) === 0) {
        return '??';
    }
    if (count($words) >= 2) {
        return strtoupper(substr($words[0], 0, 1) . substr($words[count($words) - 1], 0, 1));
    }
    return strtoupper(substr($words[0], 0, 2));
}
$user_initials = getInitials($user_name);

// Helper functions
function tableExists(mysqli $conn, $table) {
    $table = $conn->real_escape_string($table);
    $res = $conn->query("SHOW TABLES LIKE '{$table}'");
    return $res && $res->num_rows > 0;
}

function columnExists(mysqli $conn, $table, $column) {
    $table = $conn->real_escape_string($table);
    $column = $conn->real_escape_string($column);
    $res = $conn->query("SHOW COLUMNS FROM `{$table}` LIKE '{$column}'");
    return $res && $res->num_rows > 0;
}

// Learning levels definition
$level_definitions = [
    ['label' => 'Novice', 'start' => 0, 'end' => 100, 'color' => '#93c5fd'],
    ['label' => 'Intermediate', 'start' => 101, 'end' => 300, 'color' => '#fbbf24'],
    ['label' => 'Advanced', 'start' => 301, 'end' => 600, 'color' => '#34d399'],
    ['label' => 'Expert', 'start' => 601, 'end' => 1000, 'color' => '#f472b6'],
];

// Calculate user points/experience
$user_points = 0;
$total_cards_studied = 0;

// Try to get cards studied from review logs
$logsTable = null;
foreach (['card_reviews', 'reviews', 'study_logs'] as $candidate) {
    if (tableExists($conn, $candidate)) { 
        $logsTable = $candidate; 
        break; 
    }
}

if ($logsTable) {
    $dateCol = columnExists($conn, $logsTable, 'created_at') ? 'created_at' : (columnExists($conn, $logsTable, 'reviewed_at') ? 'reviewed_at' : null);
    if ($dateCol) {
        $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM `{$logsTable}` WHERE user_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_assoc();
        $total_cards_studied = (int)($res['c'] ?? 0);
        $stmt->close();
    }
}

// Fallback to total cards if no logs table
if ($total_cards_studied === 0 && tableExists($conn, 'cards')) {
    $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM cards WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $total_cards_studied = (int)($res['c'] ?? 0);
    $stmt->close();
}

// Calculate points (1 point per card studied, or use mastery if available)
$user_points = $total_cards_studied;
if (tableExists($conn, 'cards') && columnExists($conn, 'cards', 'mastery')) {
    // Add bonus points for mastery (cards with mastery > 80 get extra points)
    $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM cards WHERE user_id = ? AND (CASE WHEN mastery <= 1 THEN mastery*100 ELSE mastery END) >= 80");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $mastered_cards = (int)($res['c'] ?? 0);
    $user_points = $total_cards_studied + ($mastered_cards * 0.5); // Bonus for mastered cards
    $stmt->close();
}

// Determine current level and progress
$current_level = null;
$level_progress = 0;
$overall_progress = 0;

foreach ($level_definitions as $level) {
    if ($user_points >= $level['start'] && $user_points <= $level['end']) {
        $current_level = $level;
        $level_range = $level['end'] - $level['start'];
        $progress_in_level = $user_points - $level['start'];
        $level_progress = $level_range > 0 ? ($progress_in_level / $level_range) * 100 : 0;
        break;
    }
}

// If user exceeds all levels, set to highest level
if (!$current_level) {
    $current_level = end($level_definitions);
    $level_progress = 100;
}

// Calculate overall progress (0-1000 points = 0-100%)
$overall_progress = min(100, ($user_points / 1000) * 100);

// Calculate study streak
$study_streak = 0;
if ($logsTable) {
    $dateCol = columnExists($conn, $logsTable, 'created_at') ? 'created_at' : (columnExists($conn, $logsTable, 'reviewed_at') ? 'reviewed_at' : null);
    if ($dateCol) {
        $stmt = $conn->prepare("SELECT DATE(`{$dateCol}`) AS d FROM `{$logsTable}` WHERE user_id = ? AND `{$dateCol}` >= DATE_SUB(CURDATE(), INTERVAL 60 DAY) GROUP BY DATE(`{$dateCol}`) ORDER BY d DESC");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $days = [];
        $r = $stmt->get_result();
        while ($row = $r->fetch_assoc()) { 
            $days[] = $row['d']; 
        }
        $stmt->close();
        
        $cursor = new DateTime();
        $streak = 0;
        foreach ($days as $day) {
            if ($day === $cursor->format('Y-m-d')) {
                $streak++;
                $cursor->modify('-1 day');
            } else {
                if ($streak === 0) {
                    $yesterday = (new DateTime())->modify('-1 day')->format('Y-m-d');
                    if ($day === $yesterday) {
                        $streak = 1;
                        $cursor = new DateTime($yesterday);
                        $cursor->modify('-1 day');
                        continue;
                    }
                }
                break;
            }
        }
        $study_streak = $streak;
    }
}

// Calculate milestones
$milestones = [];

// Milestone 1: Completed X cards
$milestone_100_cards = ['title' => 'Completed 100 cards', 'status' => 'pending', 'progress' => 0];
if ($total_cards_studied >= 100) {
    // Find when 100th card was completed
    $completion_date = null;
    if ($logsTable) {
        $dateCol = columnExists($conn, $logsTable, 'created_at') ? 'created_at' : (columnExists($conn, $logsTable, 'reviewed_at') ? 'reviewed_at' : null);
        if ($dateCol) {
            $stmt = $conn->prepare("SELECT DATE(`{$dateCol}`) AS d FROM `{$logsTable}` WHERE user_id = ? ORDER BY `{$dateCol}` ASC LIMIT 1 OFFSET 99");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $res = $stmt->get_result()->fetch_assoc();
            if ($res) {
                $completion_date = $res['d'];
            }
            $stmt->close();
        }
    }
    $milestone_100_cards = [
        'title' => 'Completed 100 cards',
        'status' => 'completed',
        'date' => $completion_date ? date('M j', strtotime($completion_date)) : null
    ];
} else {
    $milestone_100_cards['progress'] = min(100, ($total_cards_studied / 100) * 100);
    $milestone_100_cards['status'] = $total_cards_studied > 0 ? 'in-progress' : 'pending';
}
$milestones[] = $milestone_100_cards;

// Milestone 2: Studied 7 days streak
$milestone_7_streak = ['title' => 'Studied 7 days streak', 'status' => 'pending', 'progress' => 0];
if ($study_streak >= 7) {
    $milestone_7_streak = [
        'title' => 'Studied 7 days streak',
        'status' => 'completed',
        'date' => date('M j')
    ];
} else {
    $milestone_7_streak['progress'] = min(100, ($study_streak / 7) * 100);
    $milestone_7_streak['status'] = $study_streak > 0 ? 'in-progress' : 'pending';
}
$milestones[] = $milestone_7_streak;

// Milestone 3: Mastered 5 decks
$mastered_decks_count = 0;
if (tableExists($conn, 'decks') && tableExists($conn, 'cards') && columnExists($conn, 'cards', 'mastery')) {
    $stmt = $conn->prepare("
        SELECT d.id, AVG(CASE WHEN c.mastery <= 1 THEN c.mastery*100 ELSE c.mastery END) AS avg_mastery
        FROM decks d
        INNER JOIN cards c ON d.id = c.deck_id AND c.user_id = ?
        WHERE d.user_id = ?
        GROUP BY d.id
        HAVING avg_mastery >= 80
    ");
    $stmt->bind_param("ii", $user_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $mastered_decks_count = $result->num_rows;
    $stmt->close();
}

$milestone_5_decks = ['title' => 'Mastered 5 decks', 'status' => 'pending', 'progress' => 0];
if ($mastered_decks_count >= 5) {
    $milestone_5_decks = [
        'title' => 'Mastered 5 decks',
        'status' => 'completed',
        'date' => date('M j')
    ];
} else {
    $milestone_5_decks['progress'] = min(100, ($mastered_decks_count / 5) * 100);
    $milestone_5_decks['status'] = $mastered_decks_count > 0 ? 'in-progress' : 'pending';
}
$milestones[] = $milestone_5_decks;

// Milestone 4: Create collaborative deck (check if user has shared decks)
$has_collaborative_deck = false;
if (tableExists($conn, 'deck_shares')) {
    $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM deck_shares WHERE sender_id = ? OR recipient_id = ?");
    $stmt->bind_param("ii", $user_id, $user_id);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $has_collaborative_deck = (int)($res['c'] ?? 0) > 0;
    $stmt->close();
}

$milestone_collab = [
    'title' => 'Create collaborative deck',
    'status' => $has_collaborative_deck ? 'completed' : 'pending'
];
if ($has_collaborative_deck) {
    $milestone_collab['date'] = date('M j');
}
$milestones[] = $milestone_collab;

// Calculate recent deck progress
$recent_progress = [];
if (tableExists($conn, 'decks') && tableExists($conn, 'cards')) {
    // Get decks with mastery scores
    $mastery_query = "";
    $mastery_select = "0 AS mastery_score";
    if (columnExists($conn, 'cards', 'mastery')) {
        $mastery_select = "AVG(CASE WHEN c.mastery <= 1 THEN c.mastery*100 ELSE c.mastery END) AS mastery_score";
    }
    
    $stmt = $conn->prepare("
        SELECT d.id, d.title, d.color, 
               COUNT(c.id) AS card_count,
               {$mastery_select}
        FROM decks d
        LEFT JOIN cards c ON d.id = c.deck_id AND c.user_id = d.user_id
        WHERE d.user_id = ?
        GROUP BY d.id, d.title, d.color
        HAVING card_count > 0
        ORDER BY d.updated_at DESC
        LIMIT 3
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $colors = ['#f97316', '#22d3ee', '#a855f7', '#34d399', '#f472b6', '#fbbf24'];
    $color_index = 0;
    
    while ($row = $result->fetch_assoc()) {
        $deck_id = $row['id'];
        $deck_title = $row['title'];
        $deck_color = $row['color'] ?: $colors[$color_index % count($colors)];
        $mastery_score = (float)($row['mastery_score'] ?? 0);
        
        // Calculate delta (compare with last week)
        $delta = 0;
        if (columnExists($conn, 'cards', 'mastery') && $logsTable && columnExists($conn, $logsTable, 'card_id')) {
            $dateCol = columnExists($conn, $logsTable, 'created_at') ? 'created_at' : (columnExists($conn, $logsTable, 'reviewed_at') ? 'reviewed_at' : null);
            if ($dateCol) {
                // Get average mastery from cards reviewed in this deck in the last week
                $stmt2 = $conn->prepare("
                    SELECT AVG(CASE WHEN c.mastery <= 1 THEN c.mastery*100 ELSE c.mastery END) AS recent_mastery
                    FROM cards c
                    INNER JOIN `{$logsTable}` l ON c.id = l.card_id
                    WHERE c.deck_id = ? AND c.user_id = ? 
                    AND l.`{$dateCol}` >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
                ");
                if ($stmt2) {
                    $stmt2->bind_param("ii", $deck_id, $user_id);
                    if ($stmt2->execute()) {
                        $res2 = $stmt2->get_result()->fetch_assoc();
                        $recent_mastery = (float)($res2['recent_mastery'] ?? $mastery_score);
                        $delta = round($mastery_score - $recent_mastery, 1);
                    }
                    $stmt2->close();
                }
            }
        }
        
        $recent_progress[] = [
            'deck' => $deck_title,
            'score' => (int)round($mastery_score),
            'delta' => $delta > 0 ? '+' . $delta : ($delta < 0 ? (string)$delta : '0'),
            'color' => $deck_color
        ];
        $color_index++;
    }
    $stmt->close();
}

// If no recent progress, use empty array (will show empty state)

function formatRelativeTime(?string $datetime): string {
    if (empty($datetime)) {
        return '';
    }
    try {
        $time = new DateTime($datetime);
    } catch (Exception $e) {
        return '';
    }
    $now = new DateTime();
    $diff = $now->getTimestamp() - $time->getTimestamp();

    if ($diff < 60) {
        return $diff <= 1 ? 'just now' : $diff . 's ago';
    }
    if ($diff < 3600) {
        $mins = floor($diff / 60);
        return $mins . 'm ago';
    }
    if ($diff < 86400) {
        $hours = floor($diff / 3600);
        return $hours . 'h ago';
    }
    if ($diff < 604800) {
        $days = floor($diff / 86400);
        return $days . 'd ago';
    }
    return $time->format('M j');
}

// Handle notification dismissal
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['dismiss_notification'])) {
    $notif_id = $_POST['notif_id'] ?? '';
    if (!empty($notif_id)) {
        if (!isset($_SESSION['dismissed_notifications'])) {
            $_SESSION['dismissed_notifications'] = [];
        }
        if (!in_array($notif_id, $_SESSION['dismissed_notifications'])) {
            $_SESSION['dismissed_notifications'][] = $notif_id;
        }
        
        if (isset($_POST['ajax'])) {
            // Explicitly save session before sending AJAX response
            session_write_close();
            header('Content-Type: application/json');
            echo json_encode(['success' => true]);
            exit();
        }
        header("Location: " . strtok($_SERVER['REQUEST_URI'], '?'));
        exit();
    }
}

$notifications = [];
$dismissed_notifications = $_SESSION['dismissed_notifications'] ?? [];

if (tableExists($conn, 'friends')) {
    $stmt = $conn->prepare("
        SELECT f.created_at, u.full_name
        FROM friends f
        INNER JOIN users u ON f.user_id = u.id
        WHERE f.friend_id = ? AND f.status = 'pending'
        ORDER BY f.created_at DESC
        LIMIT 5
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $name = $row['full_name'] ?? 'Someone';
        $notif_id = 'friend_request_' . md5($row['created_at'] . $name);
        if (!in_array($notif_id, $dismissed_notifications)) {
            $notifications[] = [
                'id' => $notif_id,
                'title' => 'Friend request',
                'message' => "{$name} wants to connect with you.",
                'time' => formatRelativeTime($row['created_at'] ?? null),
                'icon' => '👥',
                'timestamp' => $row['created_at'] ?? date('Y-m-d H:i:s'),
                'type' => 'friend_request',
                'url' => 'friends.php'
            ];
        }
    }
    $stmt->close();
}

// 2. Deck shares received
if (tableExists($conn, 'deck_shares')) {
    $stmt = $conn->prepare("
        SELECT ds.id, ds.created_at, ds.message, d.title, u.full_name AS sender_name
        FROM deck_shares ds
        INNER JOIN decks d ON ds.deck_id = d.id
        INNER JOIN users u ON ds.sender_id = u.id
        WHERE ds.recipient_id = ? AND ds.status = 'pending'
        ORDER BY ds.created_at DESC
        LIMIT 5
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $sender = $row['sender_name'] ?? 'Someone';
        $deckTitle = $row['title'] ?? 'a deck';
        $share_id = $row['id'] ?? 0;
        $notif_id = 'deck_share_' . $share_id;
        if (!in_array($notif_id, $dismissed_notifications)) {
            $notifications[] = [
                'id' => $notif_id,
                'title' => 'Deck shared with you',
                'message' => "{$sender} shared \"{$deckTitle}\" with you.",
                'time' => formatRelativeTime($row['created_at'] ?? null),
                'icon' => '📤',
                'timestamp' => $row['created_at'] ?? date('Y-m-d H:i:s'),
                'type' => 'deck_share',
                'url' => 'friends.php'
            ];
        }
    }
    $stmt->close();
}

if (tableExists($conn, 'decks')) {
    $stmt = $conn->prepare("
        SELECT title, created_at, updated_at
        FROM decks
        WHERE user_id = ?
        ORDER BY updated_at DESC
        LIMIT 5
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $title = $row['title'] ?? 'Untitled deck';
        $createdAt = $row['created_at'] ?? $row['updated_at'] ?? null;
        $updatedAt = $row['updated_at'] ?? $createdAt;
        $isNew = $createdAt && $updatedAt && strtotime($createdAt) === strtotime($updatedAt);
        $notifications[] = [
            'title' => $isNew ? 'New deck created' : 'Deck updated',
            'message' => sprintf('“%s” was %s.', $title, $isNew ? 'created' : 'updated'),
            'time' => formatRelativeTime($updatedAt),
            'icon' => $isNew ? '🆕' : '📚',
            'timestamp' => $updatedAt ?? date('Y-m-d H:i:s')
        ];
    }
    $stmt->close();
}

usort($notifications, function ($a, $b) {
    return strtotime($b['timestamp']) <=> strtotime($a['timestamp']);
});
$notifications = array_slice($notifications, 0, 10);
$has_notifications = !empty($notifications);

// Handle clear all notifications (after notifications are built)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['clear_all_notifications'])) {
    $all_notif_ids = array_column($notifications, 'id');
    if (!isset($_SESSION['dismissed_notifications'])) {
        $_SESSION['dismissed_notifications'] = [];
    }
    foreach ($all_notif_ids as $notif_id) {
        if (!empty($notif_id) && !in_array($notif_id, $_SESSION['dismissed_notifications'])) {
            $_SESSION['dismissed_notifications'][] = $notif_id;
        }
    }
    if (isset($_POST['ajax'])) {
        session_write_close();
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'count' => count($all_notif_ids)]);
        exit();
    }
    header("Location: " . strtok($_SERVER['REQUEST_URI'], '?'));
    exit();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bizmo – Progress</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #0b0b12;
            --text: #ffffff;
            --muted: #a2a3ad;
            --accent: <?php echo $user_theme_color; ?>;
            --accent-700: <?php echo $theme_darker; ?>;
            --surface: #111118;
            --border: rgba(255,255,255,0.08);
            --soft-accent: <?php echo $theme_rgba_15; ?>;
        }

        * { box-sizing: border-box; }
        html, body { height: 100%; }
        body {
            margin: 0;
            font-family: 'Inter', ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            background: linear-gradient(180deg, #0c0c14 0%, #0c0c14 55%, #0c0c14 100%);
            color: var(--text);
        }

        /* Header */
        .header {
            position: sticky; top: 0; z-index: 30;
            backdrop-filter: saturate(180%) blur(20px);
            background: rgba(10,10,15,0.8);
            border-bottom: 1px solid var(--border);
            box-shadow: 0 4px 24px rgba(0,0,0,0.2);
        }
        .header-content {
            max-width: 1400px; margin: 0 auto; padding: 18px 24px;
            display: flex; align-items: center; justify-content: space-between;
        }
        .brand {
            display: inline-flex; align-items: center; gap: 12px;
            font-weight: 800; font-size: 18px; color: var(--text);
            text-decoration: none; transition: transform .2s ease;
        }
        .brand:hover { transform: scale(1.02); }
        .logo {
            background: linear-gradient(135deg, <?php echo $theme_rgba_10; ?>, <?php echo $theme_rgba_05; ?>);
            box-shadow: 0 4px 12px <?php echo $theme_rgba_15; ?>;
            border: 1px solid <?php echo $theme_rgba_20; ?>;
            width: 50px; height: 50px; border-radius: 12px;
            display: grid; place-items: center;
            transition: all .3s ease;
        }
        .logo:hover { transform: rotate(5deg) scale(1.03); }
        .logo img { width: 50px; height: 50px; display: block; }
        .header-right { display: flex; align-items: center; gap: 12px; }
        .notif-btn {
            width: 44px; height: 44px; border-radius: 12px;
            background: rgba(255,255,255,0.04);
            border: 1px solid var(--border);
            display: grid; place-items: center; cursor: pointer;
            color: var(--text); transition: all .25s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
        }
        .notif-btn:hover {
            background: rgba(255,255,255,0.08);
            border-color: var(--accent);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px <?php echo $theme_rgba_20; ?>;
        }
        .notif-btn::after {
            content: '';
            position: absolute;
            top: 8px; right: 8px;
            width: 8px; height: 8px;
            border-radius: 50%;
            background: var(--accent);
            box-shadow: 0 0 8px var(--accent);
            opacity: 0;
            transform: scale(0.4);
            transition: opacity 0.2s ease, transform 0.2s ease;
        }
        .notif-btn.has-alert::after {
            opacity: 1;
            transform: scale(1);
        }
        .notif-dropdown {
            position: absolute;
            top: calc(100% + 12px);
            right: 0;
            width: min(360px, 90vw);
            max-height: 500px;
            background: rgba(10,10,15,0.98);
            backdrop-filter: blur(20px);
            border: 1px solid var(--border);
            border-radius: 16px;
            box-shadow: 0 16px 40px rgba(0,0,0,0.45);
            padding: 0;
            display: none;
            z-index: 1000;
            overflow: hidden;
        }
        .notif-dropdown.show { display: block; }
        .notif-dropdown h4 {
            margin: 0;
            padding: 16px 16px 12px;
            font-size: 16px;
            font-weight: 700;
            border-bottom: 1px solid var(--border);
        }
        .notif-list {
            display: flex;
            flex-direction: column;
            gap: 0;
            max-height: 420px;
            overflow-y: auto;
            overflow-x: hidden;
            padding: 8px;
        }
        .notif-list::-webkit-scrollbar {
            width: 6px;
        }
        .notif-list::-webkit-scrollbar-track {
            background: transparent;
        }
        .notif-list::-webkit-scrollbar-thumb {
            background: rgba(255,255,255,0.15);
            border-radius: 3px;
        }
        .notif-list::-webkit-scrollbar-thumb:hover {
            background: rgba(255,255,255,0.25);
        }
        .notif-item {
            display: flex;
            gap: 12px;
            padding: 14px 40px 14px 14px;
            border-radius: 10px;
            border: 1px solid rgba(255,255,255,0.05);
            background: rgba(255,255,255,0.02);
            transition: all 0.2s ease;
            position: relative;
            cursor: pointer;
            margin-bottom: 8px;
        }
        .notif-item:last-child {
            margin-bottom: 0;
        }
        .notif-item:hover {
            border-color: rgba(255,255,255,0.15);
            background: rgba(255,255,255,0.06);
            transform: translateX(2px);
        }
        .notif-item-link {
            display: flex;
            gap: 12px;
            flex: 1;
            text-decoration: none;
            color: inherit;
            min-width: 0;
        }
        .notif-dismiss {
            position: absolute;
            top: 50%;
            right: 12px;
            transform: translateY(-50%);
            width: 28px;
            height: 28px;
            border: none;
            background: rgba(255,255,255,0.08);
            border-radius: 8px;
            color: rgba(255,255,255,0.6);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: 600;
            line-height: 1;
            opacity: 0.6;
            transition: all 0.2s ease;
            z-index: 20;
            flex-shrink: 0;
        }
        .notif-item:hover .notif-dismiss {
            opacity: 1;
            background: rgba(239,68,68,0.15);
            color: #fca5a5;
        }
        .notif-dismiss:hover {
            background: rgba(239,68,68,0.25);
            color: #f87171;
            transform: translateY(-50%) scale(1.1);
        }
        .notif-dismiss:active {
            transform: translateY(-50%) scale(0.95);
        }
        .notif-icon {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            background: rgba(255,255,255,0.06);
            display: grid;
            place-items: center;
            font-size: 22px;
            flex-shrink: 0;
        }
        .notif-body { 
            flex: 1; 
            min-width: 0;
            overflow: hidden;
        }
        .notif-title {
            margin: 0;
            font-size: 14px;
            font-weight: 700;
            color: var(--text);
            line-height: 1.4;
        }
        .notif-message {
            margin: 6px 0 0;
            font-size: 13px;
            color: var(--muted);
            line-height: 1.5;
            word-wrap: break-word;
        }
        .notif-time {
            margin: 8px 0 0;
            font-size: 12px;
            color: rgba(255,255,255,0.5);
            font-weight: 500;
        }
        .notif-empty {
            padding: 40px 20px;
            text-align: center;
        }
        .notif-empty p {
            margin: 0;
            font-weight: 600;
            font-size: 15px;
            color: var(--text);
        }
        .notif-empty span {
            display: block;
            margin-top: 8px;
            font-size: 13px;
            color: var(--muted);
        }
        .user-menu {
            display: flex; align-items: center; gap: 12px; cursor: pointer;
            padding: 8px 14px 8px 8px; border-radius: 999px;
            background: rgba(255,255,255,0.04);
            border: 1px solid var(--border);
            transition: all .25s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
        }
        .user-menu:hover {
            background: rgba(255,255,255,0.08);
            border-color: var(--accent);
            transform: translateY(-1px);
        }
        .user-avatar {
            width: 36px; height: 36px; border-radius: 999px;
            background: linear-gradient(135deg, var(--accent), var(--accent-700));
            display: grid; place-items: center;
            font-weight: 700; font-size: 14px;
            box-shadow: 0 4px 12px <?php echo $theme_rgba_30; ?>;
            overflow: hidden;
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        .user-avatar img {
            width: 100%; height: 100%; object-fit: cover; display: block;
        }
        .user-dropdown {
            position: absolute;
            top: calc(100% + 10px);
            right: 0;
            background: rgba(10,10,15,0.95);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 8px;
            min-width: 200px;
            box-shadow: 0 12px 32px rgba(0,0,0,0.45);
            display: none;
            z-index: 1000;
        }
        .user-dropdown a {
            display: block;
            padding: 12px;
            color: var(--text);
            text-decoration: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            transition: background 0.2s ease;
        }
        .user-dropdown a:hover {
            background: rgba(255,255,255,0.05);
        }

        /* Layout */
        .dashboard-layout {
            display: grid; grid-template-columns: 280px 1fr;
            max-width: 1400px; margin: 0 auto;
            min-height: calc(100vh - 74px);
        }

        /* Sidebar */
        .sidebar {
            padding: 28px 20px; border-right: 1px solid var(--border);
            background: rgba(10,10,15,0.6);
            backdrop-filter: blur(10px);
        }
        .sidebar-nav { display: flex; flex-direction: column; gap: 4px; }
        .nav-item {
            display: flex; align-items: center; gap: 14px;
            padding: 14px 16px; border-radius: 14px;
            color: var(--muted); text-decoration: none;
            font-weight: 600; font-size: 15px;
            transition: all .25s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
        }
        .nav-item:hover {
            background: rgba(255,255,255,0.05);
            color: var(--text);
            transform: translateX(4px);
        }
        .nav-item.active {
            background: linear-gradient(135deg, <?php echo $theme_rgba_20; ?>, <?php echo $theme_rgba_10; ?>);
            color: var(--text);
            border: 1px solid <?php echo $theme_rgba_30; ?>;
            box-shadow: 0 4px 12px <?php echo $theme_rgba_15; ?>;
        }
        .nav-item.active::before {
            content: ''; position: absolute; left: 0; top: 50%;
            transform: translateY(-50%);
            width: 3px; height: 60%; border-radius: 0 4px 4px 0;
            background: var(--accent);
        }
        .nav-icon {
            width: 22px; height: 22px; display: grid; place-items: center;
            font-size: 20px;
        }
        .nav-icon img,
        .nav-icon svg {
            width: 20px;
            height: 20px;
            display: block;
            object-fit: contain;
            filter: brightness(0) invert(1);
            opacity: 0.75;
            transition: opacity 0.2s ease, filter 0.2s ease;
        }
        .nav-item:hover .nav-icon img,
        .nav-item:hover .nav-icon svg,
        .nav-item.active .nav-icon img,
        .nav-item.active .nav-icon svg {
            opacity: 1;
        }
        .nav-item.active .nav-icon img,
        .nav-item.active .nav-icon svg {
            filter: brightness(0) invert(1) drop-shadow(0 0 6px <?php echo $theme_rgba_25; ?>);
        }

        /* Main */
        .main-content { padding: 40px; }
        .page-header { margin-bottom: 32px; }
        .page-title {
            font-size: 36px; font-weight: 900; margin: 0 0 8px;
            background: linear-gradient(135deg, #fff, rgba(255,255,255,0.75));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .page-subtitle {
            color: var(--muted); margin: 0;
            font-size: 17px; font-weight: 500;
        }

        /* Panels */
        .grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 24px;
        }
        .panel {
            background: rgba(255,255,255,0.02);
            border: 1px solid var(--border);
            border-radius: 20px;
            padding: 24px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.25);
        }
        .panel h3 {
            margin: 0 0 16px;
            font-size: 20px;
            font-weight: 800;
            letter-spacing: -0.3px;
        }

        /* Learning Level */
        .level-track {
            display: flex;
            gap: 16px;
            margin-top: 24px;
            flex-wrap: wrap;
        }
        .level-step {
            flex: 1;
            min-width: 180px;
            padding: 16px;
            border-radius: 16px;
            border: 1px solid rgba(255,255,255,0.08);
            background: rgba(255,255,255,0.02);
            transition: border 0.2s ease, transform 0.2s ease;
        }
        .level-step:hover {
            border-color: rgba(255,255,255,0.16);
            transform: translateY(-3px);
        }
        .progress-ring {
            width: 180px;
            height: 180px;
            border-radius: 50%;
            border: 12px solid rgba(255,255,255,0.08);
            border-top-color: var(--accent);
            display: flex; align-items: center; justify-content: center;
            margin: 0 auto;
            font-weight: 800; font-size: 36px;
            box-shadow: inset 0 0 30px rgba(0,0,0,0.3);
        }

        /* Milestones */
        .milestone-list {
            display: flex; flex-direction: column; gap: 12px;
        }
        .milestone-item {
            padding: 16px;
            border-radius: 16px;
            border: 1px solid rgba(255,255,255,0.06);
            background: rgba(255,255,255,0.02);
            display: flex; justify-content: space-between;
            align-items: center;
            transition: border 0.2s ease, transform 0.2s ease;
        }
        .milestone-item:hover {
            border-color: rgba(255,255,255,0.12);
            transform: translateX(3px);
        }
        .milestone-left {
            display: flex; flex-direction: column; gap: 4px;
        }
        .badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 600;
            background: rgba(255,255,255,0.05);
            color: var(--muted);
        }

        /* Recent Progress */
        .recent-progress {
            display: flex; flex-direction: column; gap: 12px;
        }
        .recent-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 16px;
            border: 1px solid rgba(255,255,255,0.06);
            border-radius: 16px;
            background: rgba(255,255,255,0.02);
            transition: border 0.2s ease, transform 0.2s ease;
        }
        .recent-item:hover {
            border-color: rgba(255,255,255,0.12);
            transform: translateX(3px);
        }
        .recent-score {
            font-size: 28px;
            font-weight: 800;
        }

        /* Logout Modal */
        .logout-modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.75);
            backdrop-filter: blur(4px);
            z-index: 10000;
            align-items: center;
            justify-content: center;
            padding: 20px;
            animation: fadeIn 0.3s ease;
        }
        .logout-modal-overlay.active {
            display: flex;
        }
        .logout-modal {
            background: rgba(10,10,15,0.98);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 32px;
            max-width: 400px;
            width: 100%;
            position: relative;
            box-shadow: 0 40px 120px rgba(0,0,0,0.5);
            animation: slideUp 0.3s ease;
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        .logout-modal-icon {
            width: 64px;
            height: 64px;
            margin: 0 auto 20px;
            background: rgba(239, 68, 68, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .logout-modal-icon svg {
            width: 32px;
            height: 32px;
            color: #ef4444;
        }
        .logout-modal-header {
            text-align: center;
            margin-bottom: 20px;
        }
        .logout-modal-title {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 8px;
            color: var(--text);
        }
        .logout-modal-message {
            color: var(--muted);
            font-size: 14px;
            line-height: 1.6;
        }
        .logout-modal-actions {
            display: flex;
            gap: 12px;
            margin-top: 24px;
        }
        .btn-modal {
            flex: 1;
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
        }
        .btn-modal-cancel {
            background: rgba(255,255,255,0.05);
            border: 1px solid var(--border);
            color: var(--text);
        }
        .btn-modal-cancel:hover {
            background: rgba(255,255,255,0.08);
        }
        .btn-modal-logout {
            background: #ef4444;
            color: white;
        }
        .btn-modal-logout:hover {
            background: #dc2626;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
        }

        @media (max-width: 1024px) {
            .dashboard-layout { grid-template-columns: 1fr; }
            .sidebar { display: none; }
        }
        @media (max-width: 980px) {
            .grid {
                grid-template-columns: 1fr;
            }
            .main-content { padding: 28px 20px; }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-content">
            <a href="dashboard.php" class="brand">
                <div class="logo"><img src="icons/bizmo.png" alt="Bizmo logo" width="50" height="50" /></div>
                <span>Bizmo</span>
            </a>
            <div class="header-right">
                <div style="position: relative;">
                    <button class="notif-btn<?php echo $has_notifications ? ' has-alert' : ''; ?>" aria-label="Notifications" id="notifBtn">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/>
                        </svg>
                    </button>
                    <div class="notif-dropdown" id="notifDropdown">
                        <h4>
                            <span>Notifications</span>
                            <?php if (!empty($notifications)): ?>
                                <button type="button" class="notif-clear-all" onclick="clearAllNotifications(event)" aria-label="Clear all notifications">
                                    Clear all
                                </button>
                            <?php endif; ?>
                        </h4>
                        <?php if (!empty($notifications)): ?>
                            <div class="notif-list">
                                <?php foreach ($notifications as $notification): ?>
                                    <div class="notif-item" data-notif-id="<?php echo htmlspecialchars($notification['id'] ?? ''); ?>">
                                        <a href="<?php echo htmlspecialchars($notification['url'] ?? '#'); ?>" class="notif-item-link">
                                            <div class="notif-icon"><?php echo htmlspecialchars($notification['icon']); ?></div>
                                            <div class="notif-body">
                                                <p class="notif-title"><?php echo htmlspecialchars($notification['title']); ?></p>
                                                <p class="notif-message"><?php echo htmlspecialchars($notification['message']); ?></p>
                                                <p class="notif-time"><?php echo htmlspecialchars($notification['time']); ?></p>
                                            </div>
                                        </a>
                                        <button type="button" class="notif-dismiss" aria-label="Dismiss notification" onclick="dismissNotification(event, '<?php echo htmlspecialchars($notification['id'] ?? ''); ?>')">
                                            ×
                                        </button>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="notif-empty">
                                <p>You're all caught up</p>
                                <span>We'll let you know when something new happens.</span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="user-menu" id="userMenu">
                    <div class="user-avatar" style="<?php if ($profile_picture_path): ?>background-image: url('<?php echo htmlspecialchars($profile_picture_path); ?>');<?php endif; ?>">
                        <?php if (!$profile_picture_path): ?>
                            <?php echo htmlspecialchars($user_initials); ?>
                        <?php endif; ?>
                    </div>
                    <span style="font-weight:600;font-size:14px;"><?php echo htmlspecialchars($user_name); ?></span>
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                    </svg>
                    <div class="user-dropdown" id="userDropdown">
                        <div style="padding: 12px; border-bottom: 1px solid var(--border);">
                            <div style="font-weight: 600; font-size: 14px; margin-bottom: 4px;"><?php echo htmlspecialchars($user_name); ?></div>
                            <div style="font-size: 12px; color: var(--muted);"><?php echo htmlspecialchars($user_email); ?></div>
                        </div>
                        <a href="#" id="logoutBtn">
                            <span style="margin-right:8px;">🚪</span> Logout
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <div class="dashboard-layout">
        <aside class="sidebar">
            <nav class="sidebar-nav">
                <a href="dashboard.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/dashboard.png" alt="" loading="lazy">
                    </span>
                    <span>Dashboard</span>
                </a>
                <a href="decks.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/cards.png" alt="" loading="lazy">
                    </span>
                    <span>My Decks</span>
                </a>
                <a href="progress.php" class="nav-item active">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/progress.png" alt="" loading="lazy">
                    </span>
                    <span>Progress</span>
                </a>
                <a href="favorites.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/favorite.png" alt="" loading="lazy">
                    </span>
                    <span>Favorites</span>
                </a>
                <a href="friends.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/friends.png" alt="" loading="lazy">
                    </span>
                    <span>Friends</span>
                </a>
                <a href="reports.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                        </svg>
                    </span>
                    <span>Reports</span>
                </a>
                <a href="planner.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/planner.png" alt="" loading="lazy">
                    </span>
                    <span>Study Planner</span>
                </a>
                <a href="settings.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/settings.png" alt="" loading="lazy">
                    </span>
                    <span>Settings</span>
                </a>
            </nav>
        </aside>
        <main class="main-content">
            <div class="page-header">
                <h1 class="page-title">Progress Insights</h1>
                <p class="page-subtitle">Track your consistency, mastery, and milestones.</p>
            </div>
            <div class="grid">
                <section class="panel">
                    <h3>Learning Level</h3>
                    <div class="progress-ring" style="border-top-color: <?php echo $current_level['color']; ?>;"><?php echo (int)round($overall_progress); ?>%</div>
                    <div style="text-align:center;margin-top:12px;">
                        <p style="margin:0;font-size:18px;font-weight:700;color:<?php echo $current_level['color']; ?>;"><?php echo htmlspecialchars($current_level['label']); ?></p>
                        <p style="margin:4px 0 0;color:var(--muted);font-size:14px;"><?php echo (int)$user_points; ?> points</p>
                    </div>
                    <div class="level-track">
                        <?php foreach ($level_definitions as $level): ?>
                            <?php 
                            $is_current = ($level['label'] === $current_level['label']);
                            $is_past = ($user_points > $level['end']);
                            $level_width = 0;
                            
                            if ($is_past) {
                                $level_width = 100;
                            } elseif ($is_current) {
                                $level_width = $level_progress;
                            }
                            ?>
                            <div class="level-step" style="border-color: <?php echo $is_current ? $level['color'] : ($is_past ? $level['color'] . '44' : $level['color'] . '22'); ?>;">
                                <p style="margin:0;font-weight:700;"><?php echo htmlspecialchars($level['label']); ?></p>
                                <p style="margin:6px 0 0; color: var(--muted); font-size: 13px;"><?php echo $level['start']; ?>–<?php echo $level['end']; ?> pts</p>
                                <div style="height:6px;border-radius:999px;background:rgba(255,255,255,0.06);margin-top:10px;">
                                    <div style="height:100%;border-radius:999px;background:<?php echo $level['color']; ?>;width:<?php echo $level_width; ?>%;"></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </section>
                <section class="panel">
                    <h3>Milestones</h3>
                    <div class="milestone-list">
                        <?php if (!empty($milestones)): ?>
                            <?php foreach ($milestones as $milestone): ?>
                                <div class="milestone-item">
                                    <div class="milestone-left">
                                        <strong><?php echo htmlspecialchars($milestone['title']); ?></strong>
                                        <?php if (!empty($milestone['date'])): ?>
                                            <span style="font-size:12px;color:var(--muted);">Completed <?php echo htmlspecialchars($milestone['date']); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <?php if ($milestone['status'] === 'completed'): ?>
                                        <span class="badge" style="color:#bbf7d0;">✔ Completed</span>
                                    <?php elseif ($milestone['status'] === 'in-progress'): ?>
                                        <span class="badge" style="color:#fde68a;">● <?php echo (int)($milestone['progress'] ?? 0); ?>%</span>
                                    <?php else: ?>
                                        <span class="badge">Pending</span>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p style="color:var(--muted);text-align:center;padding:20px;">No milestones yet. Start studying to unlock achievements!</p>
                        <?php endif; ?>
                    </div>
                </section>
            </div>
            <section class="panel" style="margin-top:24px;">
                <h3>Recent Deck Progress</h3>
                <div class="recent-progress">
                    <?php if (!empty($recent_progress)): ?>
                        <?php foreach ($recent_progress as $item): ?>
                            <div class="recent-item">
                                <div>
                                    <strong><?php echo htmlspecialchars($item['deck']); ?></strong>
                                    <p style="margin:4px 0 0;color:var(--muted);font-size:13px;">Mastery Score</p>
                                </div>
                                <div style="text-align:right;">
                                    <span class="recent-score" style="color: <?php echo htmlspecialchars($item['color']); ?>;"><?php echo (int)$item['score']; ?>%</span>
                                    <p style="margin:4px 0 0;font-size:12px;color:<?php echo (strpos($item['delta'], '+') === 0) ? '#4ade80' : ((strpos($item['delta'], '-') === 0) ? '#f87171' : 'var(--muted)'); ?>;">
                                        <?php echo htmlspecialchars($item['delta']); ?> since last week
                                    </p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p style="color:var(--muted);text-align:center;padding:20px;">No deck progress yet. Start studying your decks to see your progress here!</p>
                    <?php endif; ?>
                </div>
            </section>
        </main>
    </div>
    <script>
        (function () {
            const notifBtn = document.getElementById('notifBtn');
            const notifDropdown = document.getElementById('notifDropdown');
            if (notifBtn && notifDropdown) {
                notifBtn.addEventListener('click', function (e) {
                    e.stopPropagation();
                    notifDropdown.classList.toggle('show');
                });
                document.addEventListener('click', function (e) {
                    if (!notifDropdown.contains(e.target) && e.target !== notifBtn) {
                        notifDropdown.classList.remove('show');
                    }
                });
            }

            // Clear all notifications function
            window.clearAllNotifications = function(event) {
                event.preventDefault();
                event.stopPropagation();
                
                if (!confirm('Clear all notifications?')) {
                    return;
                }
                
                const form = document.createElement('form');
                form.method = 'POST';
                form.style.display = 'none';
                
                const inputAction = document.createElement('input');
                inputAction.type = 'hidden';
                inputAction.name = 'clear_all_notifications';
                inputAction.value = '1';
                
                const inputAjax = document.createElement('input');
                inputAjax.type = 'hidden';
                inputAjax.name = 'ajax';
                inputAjax.value = '1';
                
                form.appendChild(inputAction);
                form.appendChild(inputAjax);
                document.body.appendChild(form);
                
                fetch(window.location.href, {
                    method: 'POST',
                    body: new FormData(form)
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const notifList = document.querySelector('.notif-list');
                        if (notifList) {
                            const items = notifList.querySelectorAll('.notif-item');
                            items.forEach((item, index) => {
                                setTimeout(() => {
                                    item.style.opacity = '0';
                                    item.style.transform = 'translateX(-10px)';
                                    setTimeout(() => item.remove(), 200);
                                }, index * 50);
                            });
                            
                            setTimeout(() => {
                                const notifDropdown = document.getElementById('notifDropdown');
                                if (notifDropdown) {
                                    notifDropdown.innerHTML = '<h4><span>Notifications</span></h4><div class="notif-empty"><p>You\'re all caught up</p><span>We\'ll let you know when something new happens.</span></div>';
                                }
                                const notifBtn = document.getElementById('notifBtn');
                                if (notifBtn) {
                                    notifBtn.classList.remove('has-alert');
                                }
                            }, items.length * 50 + 200);
                        }
                    }
                })
                .catch(error => {
                    console.error('Error clearing notifications:', error);
                    form.submit();
                });
                
                document.body.removeChild(form);
            };

            // Dismiss notification function
            window.dismissNotification = function(event, notifId) {
                event.preventDefault();
                event.stopPropagation();
                
                if (!notifId) return;
                
                const form = document.createElement('form');
                form.method = 'POST';
                form.style.display = 'none';
                
                const inputAction = document.createElement('input');
                inputAction.type = 'hidden';
                inputAction.name = 'dismiss_notification';
                inputAction.value = '1';
                
                const inputId = document.createElement('input');
                inputId.type = 'hidden';
                inputId.name = 'notif_id';
                inputId.value = notifId;
                
                const inputAjax = document.createElement('input');
                inputAjax.type = 'hidden';
                inputAjax.name = 'ajax';
                inputAjax.value = '1';
                
                form.appendChild(inputAction);
                form.appendChild(inputId);
                form.appendChild(inputAjax);
                document.body.appendChild(form);
                
                fetch(window.location.href, {
                    method: 'POST',
                    body: new FormData(form)
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const notifItem = document.querySelector(`[data-notif-id="${notifId}"]`);
                        if (notifItem) {
                            notifItem.style.opacity = '0';
                            notifItem.style.transform = 'translateX(-10px)';
                            setTimeout(() => {
                                notifItem.remove();
                                const notifList = document.querySelector('.notif-list');
                                if (notifList && notifList.children.length === 0) {
                                    const notifDropdown = document.getElementById('notifDropdown');
                                    if (notifDropdown) {
                                        notifDropdown.innerHTML = '<h4>Notifications</h4><div class="notif-empty"><p>You\'re all caught up</p><span>We\'ll let you know when something new happens.</span></div>';
                                    }
                                    const notifBtn = document.getElementById('notifBtn');
                                    if (notifBtn) {
                                        notifBtn.classList.remove('has-alert');
                                    }
                                }
                            }, 200);
                        }
                    }
                })
                .catch(error => {
                    console.error('Error dismissing notification:', error);
                    form.submit();
                });
                
                document.body.removeChild(form);
            };

            const userMenu = document.getElementById('userMenu');
            const userDropdown = document.getElementById('userDropdown');
            if (userMenu && userDropdown) {
                userMenu.addEventListener('click', function (e) {
                    e.stopPropagation();
                    const isVisible = userDropdown.style.display === 'block';
                    userDropdown.style.display = isVisible ? 'none' : 'block';
                });
                document.addEventListener('click', function (e) {
                    if (!userMenu.contains(e.target)) {
                        userDropdown.style.display = 'none';
                    }
                });
            }
        })();

    </script>

    <!-- Logout Confirmation Modal -->
    <div class="logout-modal-overlay" id="logoutModal">
        <div class="logout-modal">
            <div class="logout-modal-icon">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                </svg>
            </div>
            <div class="logout-modal-header">
                <h3 class="logout-modal-title">Confirm Logout</h3>
                <p class="logout-modal-message">Are you sure you want to logout? You will need to login again to access your account.</p>
            </div>
            <div class="logout-modal-actions">
                <button class="btn-modal btn-modal-cancel" id="logoutCancelBtn">Cancel</button>
                <button class="btn-modal btn-modal-logout" id="logoutConfirmBtn">Logout</button>
            </div>
        </div>
    </div>

    <script>
        // Logout Modal - Initialize after modal HTML is in DOM
        document.addEventListener('DOMContentLoaded', function() {
            const logoutBtn = document.getElementById('logoutBtn');
            const logoutModal = document.getElementById('logoutModal');
            const logoutConfirmBtn = document.getElementById('logoutConfirmBtn');
            const logoutCancelBtn = document.getElementById('logoutCancelBtn');

            if (logoutBtn) {
                logoutBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    if (logoutModal) {
                        logoutModal.classList.add('active');
                    }
                    // Close user dropdown when opening logout modal
                    const userDropdown = document.getElementById('userDropdown');
                    if (userDropdown) {
                        userDropdown.style.display = 'none';
                    }
                });
            }

            if (logoutCancelBtn) {
                logoutCancelBtn.addEventListener('click', function() {
                    if (logoutModal) {
                        logoutModal.classList.remove('active');
                    }
                });
            }

            if (logoutConfirmBtn) {
                logoutConfirmBtn.addEventListener('click', function() {
                    window.location.href = 'dashboard.php?logout=1';
                });
            }

            if (logoutModal) {
                logoutModal.addEventListener('click', function(e) {
                    if (e.target === logoutModal) {
                        logoutModal.classList.remove('active');
                    }
                });
            }

            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && logoutModal && logoutModal.classList.contains('active')) {
                    logoutModal.classList.remove('active');
                }
            });
        });
    </script>
</body>
</html>


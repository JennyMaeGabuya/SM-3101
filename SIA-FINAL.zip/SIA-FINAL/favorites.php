<?php
session_start();
require_once 'config.php';

if (!function_exists('ensureFavoritesTable')) {
    function ensureFavoritesTable(mysqli $conn) {
        $conn->query("
            CREATE TABLE IF NOT EXISTS `favorites` (
                `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `user_id` INT NOT NULL,
                `deck_id` INT UNSIGNED NOT NULL,
                `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                UNIQUE KEY `unique_favorite` (`user_id`, `deck_id`),
                KEY `idx_favorites_user` (`user_id`),
                KEY `idx_favorites_deck` (`deck_id`),
                CONSTRAINT `fk_favorites_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
                CONSTRAINT `fk_favorites_deck` FOREIGN KEY (`deck_id`) REFERENCES `decks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
    }
}

if (!function_exists('buildDeckIconSrc')) {
    function buildDeckIconSrc($iconValue) {
        if ($iconValue === null || $iconValue === '') {
            return '';
        }
        if (strpos($iconValue, 'data:') === 0) {
            return $iconValue;
        }
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = $finfo ? finfo_buffer($finfo, $iconValue) : null;
        if ($finfo) {
            finfo_close($finfo);
        }
        if (!$mime) {
            $mime = 'image/png';
        }
        return 'data:' . $mime . ';base64,' . base64_encode($iconValue);
    }
}

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'] ?? 'Learner';
$user_email = $_SESSION['user_email'] ?? '';
$user_username = $_SESSION['user_username'] ?? '';

ensureFavoritesTable($conn);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_favorite'], $_POST['deck_id'])) {
    $deck_id = (int)($_POST['deck_id'] ?? 0);
    if ($deck_id > 0) {
        $stmt = $conn->prepare("SELECT id FROM decks WHERE id = ? AND user_id = ?");
        if ($stmt) {
            $stmt->bind_param("ii", $deck_id, $user_id);
            $stmt->execute();
            $ownsDeck = $stmt->get_result()->num_rows > 0;
            $stmt->close();

            if ($ownsDeck) {
                $stmt = $conn->prepare("SELECT id FROM favorites WHERE user_id = ? AND deck_id = ?");
                if ($stmt) {
                    $stmt->bind_param("ii", $user_id, $deck_id);
                    $stmt->execute();
                    $favoriteExists = $stmt->get_result()->num_rows > 0;
                    $stmt->close();

                    if ($favoriteExists) {
                        $stmt = $conn->prepare("DELETE FROM favorites WHERE user_id = ? AND deck_id = ?");
                        if ($stmt) {
                            $stmt->bind_param("ii", $user_id, $deck_id);
                            $stmt->execute();
                            $stmt->close();
                        }
                    } else {
                        $stmt = $conn->prepare("INSERT INTO favorites (user_id, deck_id) VALUES (?, ?)");
                        if ($stmt) {
                            $stmt->bind_param("ii", $user_id, $deck_id);
                            $stmt->execute();
                            $stmt->close();
                        }
                    }
                }
            }
        }
    }

    header("Location: " . strtok($_SERVER['REQUEST_URI'], '?'));
    exit();
}

// Profile picture
$upload_dir = 'uploads/profiles/';
$profile_picture_path = null;
if ($user_id) {
    $stmt = $conn->prepare("SELECT profile_picture FROM profiles WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $profile_filename = $row['profile_picture'] ?? null;
        if (!empty($profile_filename)) {
            $candidate_path = $upload_dir . $profile_filename;
            $filesystem_path = __DIR__ . '/' . $candidate_path;
            if (file_exists($filesystem_path)) {
                $profile_picture_path = $candidate_path;
            }
        }
    }
    $stmt->close();
}

// Theme
$user_theme_color = '#dc2626';
if ($user_id) {
    $stmt = $conn->prepare("SELECT theme_color FROM themes WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $user_theme_color = $row['theme_color'];
    }
    $stmt->close();
}

function hexToRgb($hex) {
    $hex = str_replace('#', '', $hex);
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    return [$r, $g, $b];
}

function darkenColor($hex, $percent = 20) {
    $rgb = hexToRgb($hex);
    $r = max(0, min(255, $rgb[0] - ($rgb[0] * $percent / 100)));
    $g = max(0, min(255, $rgb[1] - ($rgb[1] * $percent / 100)));
    $b = max(0, min(255, $rgb[2] - ($rgb[2] * $percent / 100)));
    return sprintf("#%02x%02x%02x", round($r), round($g), round($b));
}

$theme_rgb = hexToRgb($user_theme_color);
$theme_rgba_15 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.15)";
$theme_rgba_10 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.1)";
$theme_rgba_05 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.05)";
$theme_rgba_20 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.2)";
$theme_rgba_25 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.25)";
$theme_rgba_30 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.3)";
$theme_rgba_40 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.4)";
$theme_darker = darkenColor($user_theme_color, 15);

function getInitials($name) {
    $words = preg_split('/\s+/', trim($name));
    if (!$words || count($words) === 0) {
        return '??';
    }
    if (count($words) >= 2) {
        return strtoupper(substr($words[0], 0, 1) . substr($words[count($words) - 1], 0, 1));
    }
    return strtoupper(substr($words[0], 0, 2));
}
$user_initials = getInitials($user_name);

function tableExists(mysqli $conn, $table) {
    $table = $conn->real_escape_string($table);
    $res = $conn->query("SHOW TABLES LIKE '{$table}'");
    return $res && $res->num_rows > 0;
}

function columnExists(mysqli $conn, $table, $column) {
    $table = $conn->real_escape_string($table);
    $column = $conn->real_escape_string($column);
    $res = $conn->query("SHOW COLUMNS FROM `{$table}` LIKE '{$column}'");
    return $res && $res->num_rows > 0;
}

function formatRelativeTime(?string $datetime): string {
    if (empty($datetime)) {
        return '';
    }
    try {
        $time = new DateTime($datetime);
    } catch (Exception $e) {
        return '';
    }
    $now = new DateTime();
    $diff = $now->getTimestamp() - $time->getTimestamp();

    if ($diff < 60) {
        return $diff <= 1 ? 'just now' : $diff . 's ago';
    }
    if ($diff < 3600) {
        $mins = floor($diff / 60);
        return $mins . 'm ago';
    }
    if ($diff < 86400) {
        $hours = floor($diff / 3600);
        return $hours . 'h ago';
    }
    if ($diff < 604800) {
        $days = floor($diff / 86400);
        return $days . 'd ago';
    }
    return $time->format('M j');
}

$favorite_decks = [];
$favorite_ids = [];

if ($user_id) {
    if (tableExists($conn, 'favorites')) {
        $stmt = $conn->prepare("
            SELECT d.id, d.title, d.description, d.color, d.icon, d.updated_at, f.created_at AS favorited_at
            FROM favorites f
            INNER JOIN decks d ON f.deck_id = d.id
            WHERE f.user_id = ?
            ORDER BY f.created_at DESC
        ");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $row['deck_id'] = (int)$row['id'];
            $favorite_decks[] = $row;
            $favorite_ids[] = (int)$row['id'];
        }
        $stmt->close();
    } elseif (tableExists($conn, 'decks') && columnExists($conn, 'decks', 'is_favorite')) {
        $stmt = $conn->prepare("
            SELECT id, title, description, color, icon, updated_at
            FROM decks
            WHERE user_id = ? AND is_favorite = 1
            ORDER BY updated_at DESC
        ");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $row['deck_id'] = (int)$row['id'];
            $row['favorited_at'] = $row['updated_at'] ?? null;
            $favorite_decks[] = $row;
            $favorite_ids[] = (int)$row['id'];
        }
        $stmt->close();
    }
}

$suggested_decks = [];
if ($user_id && tableExists($conn, 'decks')) {
    $stmt = $conn->prepare("
        SELECT id, title, description, color, icon, updated_at
        FROM decks
        WHERE user_id = ?
        ORDER BY updated_at DESC
        LIMIT 8
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        if (!in_array((int)$row['id'], $favorite_ids, true)) {
            $suggested_decks[] = $row;
        }
    }
    $stmt->close();
}

$has_favorites = !empty($favorite_decks);
$total_favorites = count($favorite_decks);

// Handle notification dismissal
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['dismiss_notification'])) {
    $notif_id = $_POST['notif_id'] ?? '';
    if (!empty($notif_id)) {
        if (!isset($_SESSION['dismissed_notifications'])) {
            $_SESSION['dismissed_notifications'] = [];
        }
        if (!in_array($notif_id, $_SESSION['dismissed_notifications'])) {
            $_SESSION['dismissed_notifications'][] = $notif_id;
        }
        
        if (isset($_POST['ajax'])) {
            // Explicitly save session before sending AJAX response
            session_write_close();
            header('Content-Type: application/json');
            echo json_encode(['success' => true]);
            exit();
        }
        header("Location: " . strtok($_SERVER['REQUEST_URI'], '?'));
        exit();
    }
}

// Notification system
$notifications = [];
$dismissed_notifications = $_SESSION['dismissed_notifications'] ?? [];

// 1. Friend requests
if (tableExists($conn, 'friends')) {
    $stmt = $conn->prepare("
        SELECT f.created_at, u.full_name
        FROM friends f
        INNER JOIN users u ON f.user_id = u.id
        WHERE f.friend_id = ? AND f.status = 'pending'
        ORDER BY f.created_at DESC
        LIMIT 5
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $name = $row['full_name'] ?? 'Someone';
        $notif_id = 'friend_request_' . md5($row['created_at'] . $name);
        if (!in_array($notif_id, $dismissed_notifications)) {
            $notifications[] = [
                'id' => $notif_id,
                'title' => 'Friend request',
                'message' => "{$name} wants to connect with you.",
                'time' => formatRelativeTime($row['created_at'] ?? null),
                'icon' => '👥',
                'timestamp' => $row['created_at'] ?? date('Y-m-d H:i:s'),
                'type' => 'friend_request',
                'url' => 'friends.php'
            ];
        }
    }
    $stmt->close();
}

// 2. Deck shares received
if (tableExists($conn, 'deck_shares')) {
    $stmt = $conn->prepare("
        SELECT ds.id, ds.created_at, ds.message, d.title, u.full_name AS sender_name
        FROM deck_shares ds
        INNER JOIN decks d ON ds.deck_id = d.id
        INNER JOIN users u ON ds.sender_id = u.id
        WHERE ds.recipient_id = ? AND ds.status = 'pending'
        ORDER BY ds.created_at DESC
        LIMIT 5
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $sender = $row['sender_name'] ?? 'Someone';
        $deckTitle = $row['title'] ?? 'a deck';
        $share_id = $row['id'] ?? 0;
        $notif_id = 'deck_share_' . $share_id;
        if (!in_array($notif_id, $dismissed_notifications)) {
            $notifications[] = [
                'id' => $notif_id,
                'title' => 'Deck shared with you',
                'message' => "{$sender} shared \"{$deckTitle}\" with you.",
                'time' => formatRelativeTime($row['created_at'] ?? null),
                'icon' => '📤',
                'timestamp' => $row['created_at'] ?? date('Y-m-d H:i:s'),
                'type' => 'deck_share',
                'url' => 'friends.php'
            ];
        }
    }
    $stmt->close();
}

// 3. Favorite deck updates
if (tableExists($conn, 'favorites') && tableExists($conn, 'decks')) {
    $stmt = $conn->prepare("
        SELECT d.id, d.title, d.updated_at, f.created_at AS favorited_at
        FROM favorites f
        INNER JOIN decks d ON f.deck_id = d.id
        WHERE f.user_id = ? 
        AND d.updated_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
        AND d.updated_at > f.created_at
        ORDER BY d.updated_at DESC
        LIMIT 5
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $title = $row['title'] ?? 'Untitled deck';
        $deck_id = $row['id'] ?? 0;
        $notif_id = 'favorite_update_' . $deck_id . '_' . md5($row['updated_at']);
        if (!in_array($notif_id, $dismissed_notifications)) {
            $notifications[] = [
                'id' => $notif_id,
                'title' => 'Favorite deck updated',
                'message' => "\"{$title}\" has been updated.",
                'time' => formatRelativeTime($row['updated_at'] ?? null),
                'icon' => '⭐',
                'timestamp' => $row['updated_at'] ?? date('Y-m-d H:i:s'),
                'type' => 'favorite_update',
                'url' => 'deck.php?id=' . $deck_id
            ];
        }
    }
    $stmt->close();
}

usort($notifications, function ($a, $b) {
    return strtotime($b['timestamp']) <=> strtotime($a['timestamp']);
});
$notifications = array_slice($notifications, 0, 10);
$has_notifications = !empty($notifications);

// Handle clear all notifications (after notifications are built)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['clear_all_notifications'])) {
    $all_notif_ids = array_column($notifications, 'id');
    if (!isset($_SESSION['dismissed_notifications'])) {
        $_SESSION['dismissed_notifications'] = [];
    }
    foreach ($all_notif_ids as $notif_id) {
        if (!empty($notif_id) && !in_array($notif_id, $_SESSION['dismissed_notifications'])) {
            $_SESSION['dismissed_notifications'][] = $notif_id;
        }
    }
    if (isset($_POST['ajax'])) {
        session_write_close();
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'count' => count($all_notif_ids)]);
        exit();
    }
    header("Location: " . strtok($_SERVER['REQUEST_URI'], '?'));
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bizmo – Favorites</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #0b0b12;
            --text: #ffffff;
            --muted: #a2a3ad;
            --accent: <?php echo $user_theme_color; ?>;
            --accent-700: <?php echo $theme_darker; ?>;
            --surface: #111118;
            --border: rgba(255,255,255,0.08);
            --soft-accent: <?php echo $theme_rgba_15; ?>;
        }
        * { box-sizing: border-box; }
        html, body { height: 100%; }
        body {
            margin: 0;
            font-family: 'Inter', ui-sans-serif, system-ui, -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            background: linear-gradient(180deg, #0c0c14 0%, #0c0c14 55%, #0c0c14 100%);
            color: var(--text);
        }
        .header {
            position: sticky; top: 0; z-index: 30;
            backdrop-filter: saturate(180%) blur(20px);
            background: rgba(10,10,15,0.8);
            border-bottom: 1px solid var(--border);
            box-shadow: 0 4px 24px rgba(0,0,0,0.2);
        }
        .header-content {
            max-width: 1400px; margin: 0 auto; padding: 18px 24px;
            display: flex; align-items: center; justify-content: space-between;
        }
        .brand {
            display: inline-flex; align-items: center; gap: 12px;
            font-weight: 800; font-size: 18px; color: var(--text);
            text-decoration: none; transition: transform .2s ease;
        }
        .brand:hover { transform: scale(1.02); }
        .logo {
            background: linear-gradient(135deg, <?php echo $theme_rgba_10; ?>, <?php echo $theme_rgba_05; ?>);
            box-shadow: 0 4px 12px <?php echo $theme_rgba_15; ?>;
            border: 1px solid <?php echo $theme_rgba_20; ?>;
            width: 50px; height: 50px; border-radius: 12px;
            display: grid; place-items: center;
        }
        .logo img { width: 50px; height: 50px; display: block; }
        .header-right { display: flex; align-items: center; gap: 12px; position: relative; }
        .notif-btn {
            width: 44px; height: 44px; border-radius: 12px;
            background: rgba(255,255,255,0.04);
            border: 1px solid var(--border);
            display: grid; place-items: center; cursor: pointer;
            color: var(--text); transition: all .25s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
        }
        .notif-btn:hover {
            background: rgba(255,255,255,0.08);
            border-color: var(--accent);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px <?php echo $theme_rgba_20; ?>;
        }
        .notif-btn::after {
            content: '';
            position: absolute;
            top: 8px; right: 8px;
            width: 8px; height: 8px;
            border-radius: 50%;
            background: var(--accent);
            box-shadow: 0 0 8px var(--accent);
            opacity: 0;
            transform: scale(0.4);
            transition: opacity 0.2s ease, transform 0.2s ease;
        }
        .notif-btn.has-alert::after {
            opacity: 1;
            transform: scale(1);
        }
        .notif-dropdown {
            position: absolute;
            top: calc(100% + 12px);
            right: 0;
            width: min(360px, 90vw);
            max-height: 500px;
            background: rgba(10,10,15,0.98);
            backdrop-filter: blur(20px);
            border: 1px solid var(--border);
            border-radius: 16px;
            box-shadow: 0 16px 40px rgba(0,0,0,0.45);
            padding: 0;
            display: none;
            z-index: 1000;
            overflow: hidden;
        }
        .notif-dropdown.show { display: block; }
        .notif-dropdown h4 {
            margin: 0;
            padding: 16px 16px 12px;
            font-size: 16px;
            font-weight: 700;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .notif-clear-all {
            font-size: 13px;
            font-weight: 600;
            color: var(--muted);
            background: none;
            border: none;
            cursor: pointer;
            padding: 4px 8px;
            border-radius: 6px;
            transition: all 0.2s ease;
            text-decoration: none;
            display: inline-block;
        }
        .notif-clear-all:hover {
            color: var(--text);
            background: rgba(255,255,255,0.05);
        }
        .notif-clear-all:active {
            transform: scale(0.95);
        }
        .notif-list {
            display: flex;
            flex-direction: column;
            gap: 0;
            max-height: 420px;
            overflow-y: auto;
            overflow-x: hidden;
            padding: 8px;
        }
        .notif-list::-webkit-scrollbar {
            width: 6px;
        }
        .notif-list::-webkit-scrollbar-track {
            background: transparent;
        }
        .notif-list::-webkit-scrollbar-thumb {
            background: rgba(255,255,255,0.15);
            border-radius: 3px;
        }
        .notif-list::-webkit-scrollbar-thumb:hover {
            background: rgba(255,255,255,0.25);
        }
        .notif-item {
            display: flex;
            gap: 12px;
            padding: 14px 40px 14px 14px;
            border-radius: 10px;
            border: 1px solid rgba(255,255,255,0.05);
            background: rgba(255,255,255,0.02);
            transition: all 0.2s ease;
            position: relative;
            cursor: pointer;
            margin-bottom: 8px;
        }
        .notif-item:last-child {
            margin-bottom: 0;
        }
        .notif-item:hover {
            border-color: rgba(255,255,255,0.15);
            background: rgba(255,255,255,0.06);
            transform: translateX(2px);
        }
        .notif-item-link {
            display: flex;
            gap: 12px;
            flex: 1;
            text-decoration: none;
            color: inherit;
        }
        .notif-dismiss {
            position: absolute;
            top: 50%;
            right: 12px;
            transform: translateY(-50%);
            width: 28px;
            height: 28px;
            border: none;
            background: rgba(255,255,255,0.08);
            border-radius: 8px;
            color: rgba(255,255,255,0.6);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: 600;
            line-height: 1;
            opacity: 0.6;
            transition: all 0.2s ease;
            z-index: 20;
            flex-shrink: 0;
        }
        .notif-item:hover .notif-dismiss {
            opacity: 1;
            background: rgba(239,68,68,0.15);
            color: #fca5a5;
        }
        .notif-dismiss:hover {
            background: rgba(239,68,68,0.25);
            color: #f87171;
            transform: translateY(-50%) scale(1.1);
        }
        .notif-dismiss:active {
            transform: translateY(-50%) scale(0.95);
        }
        .notif-icon {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            background: rgba(255,255,255,0.06);
            display: grid;
            place-items: center;
            font-size: 22px;
            flex-shrink: 0;
        }
        .notif-body { 
            flex: 1; 
            min-width: 0;
            overflow: hidden;
        }
        .notif-title {
            margin: 0;
            font-size: 14px;
            font-weight: 700;
            color: var(--text);
            line-height: 1.4;
        }
        .notif-message {
            margin: 6px 0 0;
            font-size: 13px;
            color: var(--muted);
            line-height: 1.5;
            word-wrap: break-word;
        }
        .notif-time {
            margin: 8px 0 0;
            font-size: 12px;
            color: rgba(255,255,255,0.5);
            font-weight: 500;
        }
        .notif-empty {
            padding: 40px 20px;
            text-align: center;
        }
        .notif-empty p {
            margin: 0;
            font-weight: 600;
            font-size: 15px;
            color: var(--text);
        }
        .notif-empty span {
            display: block;
            margin-top: 8px;
            font-size: 13px;
            color: var(--muted);
        }
        .user-menu {
            display: flex; align-items: center; gap: 12px; cursor: pointer;
            padding: 8px 14px 8px 8px; border-radius: 999px;
            background: rgba(255,255,255,0.04);
            border: 1px solid var(--border);
            transition: all .25s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
        }
        .user-menu:hover {
            background: rgba(255,255,255,0.08);
            border-color: var(--accent);
            transform: translateY(-1px);
        }
        .user-avatar {
            width: 36px; height: 36px; border-radius: 999px;
            background: linear-gradient(135deg, var(--accent), var(--accent-700));
            display: grid; place-items: center;
            font-weight: 700; font-size: 14px;
            box-shadow: 0 4px 12px <?php echo $theme_rgba_30; ?>;
            overflow: hidden;
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        .user-avatar img {
            width: 100%; height: 100%; object-fit: cover;
        }
        .user-dropdown {
            position: absolute;
            top: calc(100% + 10px);
            right: 0;
            background: rgba(10,10,15,0.95);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 8px;
            min-width: 200px;
            box-shadow: 0 12px 32px rgba(0,0,0,0.45);
            display: none;
            z-index: 1000;
        }
        .user-dropdown a {
            display: block;
            padding: 12px;
            color: var(--text);
            text-decoration: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
        }
        .user-dropdown a:hover {
            background: rgba(255,255,255,0.05);
        }
        .dashboard-layout {
            display: grid; grid-template-columns: 280px 1fr;
            max-width: 1400px; margin: 0 auto;
            min-height: calc(100vh - 74px);
        }
        .sidebar {
            padding: 28px 20px; border-right: 1px solid var(--border);
            background: rgba(10,10,15,0.6);
            backdrop-filter: blur(10px);
        }
        .sidebar-nav { display: flex; flex-direction: column; gap: 4px; }
        .nav-item {
            display: flex; align-items: center; gap: 14px;
            padding: 14px 16px; border-radius: 14px;
            color: var(--muted); text-decoration: none;
            font-weight: 600; font-size: 15px;
            transition: all .25s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
        }
        .nav-item:hover {
            background: rgba(255,255,255,0.05);
            color: var(--text);
            transform: translateX(4px);
        }
        .nav-item.active {
            background: linear-gradient(135deg, <?php echo $theme_rgba_20; ?>, <?php echo $theme_rgba_10; ?>);
            color: var(--text);
            border: 1px solid <?php echo $theme_rgba_30; ?>;
            box-shadow: 0 4px 12px <?php echo $theme_rgba_15; ?>;
        }
        .nav-item.active::before {
            content: ''; position: absolute; left: 0; top: 50%;
            transform: translateY(-50%);
            width: 3px; height: 60%; border-radius: 0 4px 4px 0;
            background: var(--accent);
        }
        .nav-icon {
            width: 22px; height: 22px; display: grid; place-items: center;
            font-size: 20px;
        }
        .nav-icon img,
        .nav-icon svg {
            width: 20px;
            height: 20px;
            display: block;
            object-fit: contain;
            filter: brightness(0) invert(1);
            opacity: 0.75;
            transition: opacity 0.2s ease, filter 0.2s ease;
        }
        .nav-item:hover .nav-icon img,
        .nav-item:hover .nav-icon svg,
        .nav-item.active .nav-icon img,
        .nav-item.active .nav-icon svg {
            opacity: 1;
        }
        .nav-item.active .nav-icon img,
        .nav-item.active .nav-icon svg {
            filter: brightness(0) invert(1) drop-shadow(0 0 6px <?php echo $theme_rgba_25; ?>);
        }
        .main-content { padding: 40px; }
        .page-header { margin-bottom: 32px; }
        .page-title {
            font-size: 36px; font-weight: 900; margin: 0 0 8px;
            background: linear-gradient(135deg, #fff, rgba(255,255,255,0.75));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .page-subtitle {
            color: var(--muted); margin: 0;
            font-size: 17px; font-weight: 500;
        }
        .favorites-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
            gap: 20px;
        }
        .favorite-card {
            border: 1px solid var(--border);
            border-radius: 18px;
            padding: 20px;
            background: rgba(255,255,255,0.02);
            position: relative;
            overflow: hidden;
            color: inherit;
            transition: all .25s ease;
        }
        .favorite-card-link {
            display: block;
            color: inherit;
            text-decoration: none;
            height: 100%;
            cursor: inherit;
        }
        .favorite-form {
            position: absolute;
            top: 18px;
            right: 18px;
            margin: 0;
            z-index: 2;
        }
        .favorite-toggle {
            border: 1px solid var(--border);
            background: rgba(10,10,15,0.6);
            color: var(--muted);
            width: 34px;
            height: 34px;
            border-radius: 50%;
            font-size: 15px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all .2s ease;
        }
        .favorite-toggle:hover,
        .favorite-toggle:focus-visible {
            border-color: var(--accent);
            color: var(--text);
            outline: none;
        }
        .favorite-toggle.active {
            background: var(--accent);
            border-color: var(--accent);
            color: #0b0b12;
            box-shadow: 0 0 12px <?php echo $theme_rgba_30; ?>;
        }
        .favorite-card::before {
            content: '';
            position: absolute;
            inset: 0;
            background: radial-gradient(circle at top right, <?php echo $theme_rgba_10; ?>, transparent 60%);
            opacity: 0;
            transition: opacity .25s ease;
        }
        .favorite-card:hover {
            border-color: var(--accent);
            transform: translateY(-4px);
            box-shadow: 0 10px 30px <?php echo $theme_rgba_20; ?>;
        }
        .favorite-card:hover::before { opacity: 1; }
        .deck-icon {
            width: 56px;
            height: 56px;
            border-radius: 14px;
            border: 1px solid var(--border);
            display: grid;
            place-items: center;
            font-size: 24px;
            font-weight: 800;
            overflow: hidden;
            background: transparent;
            box-shadow: none;
        }
        .deck-icon img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }
        .favorite-card h3 {
            margin: 16px 0 8px;
            font-size: 20px;
            font-weight: 800;
        }
        .favorite-card p {
            margin: 0;
            color: var(--muted);
            font-size: 14px;
            line-height: 1.5;
        }
        .favorite-meta {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-top: 18px;
            font-size: 12px;
            color: var(--muted);
        }
        .badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 600;
            background: rgba(255,255,255,0.04);
            color: var(--muted);
        }
        .btn {
            border: none;
            border-radius: 12px;
            padding: 12px 20px;
            font-weight: 600;
            cursor: pointer;
            transition: all .25s ease;
            font-size: 14px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
        }
        .btn-primary {
            background: linear-gradient(135deg, var(--accent), var(--accent-700));
            color: #0b0b12;
            border: 1px solid <?php echo $theme_rgba_30; ?>;
            box-shadow: 0 10px 24px <?php echo $theme_rgba_20; ?>;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 14px 32px <?php echo $theme_rgba_25; ?>;
        }
        .btn-secondary {
            background: rgba(255,255,255,0.05);
            color: var(--text);
            border: 1px solid var(--border);
        }
        .btn-secondary:hover {
            border-color: var(--accent);
            transform: translateY(-2px);
        }
        .empty-state {
            padding: 60px 20px;
            border: 1px dashed var(--border);
            border-radius: 20px;
            text-align: center;
            background: rgba(255,255,255,0.02);
            color: var(--muted);
        }
        .empty-state h3 {
            margin: 12px 0 8px;
            font-size: 22px;
            color: var(--text);
        }
        .empty-state p {
            margin: 0 0 16px;
            font-size: 14px;
        }
        .suggestions {
            margin-top: 40px;
        }
        .suggestion-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(210px, 1fr));
            gap: 16px;
        }
        .suggestion-card {
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 16px;
            background: rgba(255,255,255,0.02);
            display: flex;
            flex-direction: column;
            gap: 12px;
            position: relative;
        }
        .suggestion-card button {
            border: none;
            border-radius: 10px;
            padding: 10px 14px;
            font-weight: 600;
            cursor: pointer;
            background: rgba(255,255,255,0.08);
            color: var(--text);
        }
        .suggestion-card button:hover {
            background: rgba(255,255,255,0.12);
        }
        /* Logout Modal */
        .logout-modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.75);
            backdrop-filter: blur(4px);
            z-index: 10000;
            align-items: center;
            justify-content: center;
            padding: 20px;
            animation: fadeIn 0.3s ease;
        }
        .logout-modal-overlay.active {
            display: flex;
        }
        .logout-modal {
            background: rgba(10,10,15,0.98);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 32px;
            max-width: 400px;
            width: 100%;
            position: relative;
            box-shadow: 0 40px 120px rgba(0,0,0,0.5);
            animation: slideUp 0.3s ease;
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        .logout-modal-icon {
            width: 64px;
            height: 64px;
            margin: 0 auto 20px;
            background: rgba(239, 68, 68, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .logout-modal-icon svg {
            width: 32px;
            height: 32px;
            color: #ef4444;
        }
        .logout-modal-header {
            text-align: center;
            margin-bottom: 20px;
        }
        .logout-modal-title {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 8px;
            color: var(--text);
        }
        .logout-modal-message {
            color: var(--muted);
            font-size: 14px;
            line-height: 1.6;
        }
        .logout-modal-actions {
            display: flex;
            gap: 12px;
            margin-top: 24px;
        }
        .btn-modal {
            flex: 1;
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
        }
        .btn-modal-cancel {
            background: rgba(255,255,255,0.05);
            border: 1px solid var(--border);
            color: var(--text);
        }
        .btn-modal-cancel:hover {
            background: rgba(255,255,255,0.08);
        }
        .btn-modal-logout {
            background: #ef4444;
            color: white;
        }
        .btn-modal-logout:hover {
            background: #dc2626;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
        }

        @media (max-width: 1024px) {
            .dashboard-layout { grid-template-columns: 1fr; }
            .sidebar { display: none; }
        }
        @media (max-width: 720px) {
            .main-content { padding: 24px; }
            .page-title { font-size: 28px; }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-content">
            <a href="dashboard.php" class="brand">
                <div class="logo"><img src="icons/bizmo.png" alt="Bizmo logo" width="50" height="50" /></div>
                <span>Bizmo</span>
            </a>
            <div class="header-right">
                <div style="position: relative;">
                    <button class="notif-btn<?php echo $has_notifications ? ' has-alert' : ''; ?>" aria-label="Notifications" id="notifBtn">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/>
                        </svg>
                    </button>
                    <div class="notif-dropdown" id="notifDropdown">
                        <h4>
                            <span>Notifications</span>
                            <?php if (!empty($notifications)): ?>
                                <button type="button" class="notif-clear-all" onclick="clearAllNotifications(event)" aria-label="Clear all notifications">
                                    Clear all
                                </button>
                            <?php endif; ?>
                        </h4>
                        <?php if (!empty($notifications)): ?>
                            <div class="notif-list">
                                <?php foreach ($notifications as $notification): ?>
                                    <div class="notif-item" data-notif-id="<?php echo htmlspecialchars($notification['id'] ?? ''); ?>">
                                        <a href="<?php echo htmlspecialchars($notification['url'] ?? '#'); ?>" class="notif-item-link">
                                            <div class="notif-icon"><?php echo htmlspecialchars($notification['icon']); ?></div>
                                            <div class="notif-body">
                                                <p class="notif-title"><?php echo htmlspecialchars($notification['title']); ?></p>
                                                <p class="notif-message"><?php echo htmlspecialchars($notification['message']); ?></p>
                                                <p class="notif-time"><?php echo htmlspecialchars($notification['time']); ?></p>
                                            </div>
                                        </a>
                                        <button type="button" class="notif-dismiss" aria-label="Dismiss notification" onclick="dismissNotification(event, '<?php echo htmlspecialchars($notification['id'] ?? ''); ?>')">
                                            ×
                                        </button>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="notif-empty">
                                <p>You're all caught up</p>
                                <span>We'll let you know when something new happens.</span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="user-menu" id="userMenu">
                    <div class="user-avatar" style="<?php if ($profile_picture_path): ?>background-image: url('<?php echo htmlspecialchars($profile_picture_path); ?>');<?php endif; ?>">
                        <?php if (!$profile_picture_path): ?>
                            <?php echo htmlspecialchars($user_initials); ?>
                        <?php endif; ?>
                    </div>
                    <span style="font-weight:600;font-size:14px;"><?php echo htmlspecialchars($user_name); ?></span>
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                    </svg>
                    <div class="user-dropdown" id="userDropdown">
                        <div style="padding: 12px; border-bottom: 1px solid var(--border);">
                            <div style="font-weight: 600; font-size: 14px; margin-bottom: 4px;"><?php echo htmlspecialchars($user_name); ?></div>
                            <div style="font-size: 12px; color: var(--muted);"><?php echo htmlspecialchars($user_email); ?></div>
                        </div>
                        <a href="#" id="logoutBtn">
                            <span style="margin-right:8px;">🚪</span> Logout
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <div class="dashboard-layout">
        <aside class="sidebar">
            <nav class="sidebar-nav">
                <a href="dashboard.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/dashboard.png" alt="" loading="lazy">
                    </span>
                    <span>Dashboard</span>
                </a>
                <a href="decks.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/cards.png" alt="" loading="lazy">
                    </span>
                    <span>My Decks</span>
                </a>
                <a href="progress.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/progress.png" alt="" loading="lazy">
                    </span>
                    <span>Progress</span>
                </a>
                <a href="favorites.php" class="nav-item active">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/favorite.png" alt="" loading="lazy">
                    </span>
                    <span>Favorites</span>
                </a>
                <a href="friends.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/friends.png" alt="" loading="lazy">
                    </span>
                    <span>Friends</span>
                </a>
                <a href="reports.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                        </svg>
                    </span>
                    <span>Reports</span>
                </a>
                <a href="planner.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/planner.png" alt="" loading="lazy">
                    </span>
                    <span>Study Planner</span>
                </a>
                <a href="settings.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/settings.png" alt="" loading="lazy">
                    </span>
                    <span>Settings</span>
                </a>
            </nav>
        </aside>
        <main class="main-content">
            <div class="page-header">
                <h1 class="page-title">Favorites</h1>
                <p class="page-subtitle">
                    Keep your most important decks close. Pin them here to jump back in fast.
                </p>
            </div>

            <section>
                <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:16px;">
                    <h2 style="margin:0;font-size:22px;">Your Favorites</h2>
                    <span style="font-size:14px;color:var(--muted);"><?php echo $total_favorites; ?> deck<?php echo $total_favorites === 1 ? '' : 's'; ?></span>
                </div>
                <?php if ($has_favorites): ?>
                    <div class="favorites-grid">
                        <?php foreach ($favorite_decks as $fav): 
                            $deck_color = $fav['color'] ?: $user_theme_color;
                            $deck_icon_src = buildDeckIconSrc($fav['icon'] ?? null);
                            $deck_initial = mb_strtoupper(mb_substr($fav['title'] ?? 'D', 0, 1));
                        ?>
                            <div class="favorite-card">
                                <form method="post" class="favorite-form">
                                    <input type="hidden" name="toggle_favorite" value="1">
                                    <input type="hidden" name="deck_id" value="<?php echo (int)$fav['deck_id']; ?>">
                                    <button type="submit" class="favorite-toggle active" title="Remove from favorites" aria-label="Remove from favorites">
                                        ★
                                    </button>
                                </form>
                                <a href="deck.php?id=<?php echo (int)$fav['deck_id']; ?>" class="favorite-card-link">
                                    <div class="deck-icon">
                                        <?php if ($deck_icon_src !== ''): ?>
                                            <img src="<?php echo htmlspecialchars($deck_icon_src, ENT_QUOTES); ?>" alt="Deck icon">
                                        <?php else: ?>
                                            <span style="color: <?php echo htmlspecialchars($deck_color); ?>;"><?php echo htmlspecialchars($deck_initial); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <h3><?php echo htmlspecialchars($fav['title']); ?></h3>
                                    <?php if (!empty($fav['description'])): ?>
                                        <p><?php echo htmlspecialchars($fav['description']); ?></p>
                                    <?php else: ?>
                                        <p style="opacity:0.7;">No description provided.</p>
                                    <?php endif; ?>
                                    <div class="favorite-meta">
                                        <span>Updated <?php echo htmlspecialchars(formatRelativeTime($fav['updated_at'] ?? null)); ?></span>
                                        <span style="color: <?php echo $theme_rgba_40; ?>;">★ Favorited <?php echo htmlspecialchars(formatRelativeTime($fav['favorited_at'] ?? $fav['updated_at'] ?? null)); ?></span>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <div style="font-size:48px;">⭐</div>
                        <h3>No favorites yet</h3>
                        <p>Mark any deck as a favorite to keep it handy. You'll see it here instantly.</p>
                        <div style="display:flex;justify-content:center;gap:12px;flex-wrap:wrap;">
                            <a href="decks.php" class="btn btn-primary">Browse decks</a>
                            <a href="progress.php" class="btn btn-secondary">See your progress</a>
                        </div>
                    </div>
                <?php endif; ?>
            </section>

            <section class="suggestions">
                <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:16px;">
                    <h2 style="margin:0;font-size:22px;">Suggested for you</h2>
                    <a href="decks.php" style="font-size:14px;color:var(--accent);text-decoration:none;font-weight:600;">View all decks →</a>
                </div>
                <?php if (!empty($suggested_decks)): ?>
                    <div class="suggestion-list">
                        <?php foreach ($suggested_decks as $suggestion):
                            $deck_icon_src = buildDeckIconSrc($suggestion['icon'] ?? null);
                            $deck_initial = mb_strtoupper(mb_substr($suggestion['title'] ?? 'D', 0, 1));
                        ?>
                            <div class="suggestion-card">
                                <div class="deck-icon" style="width:48px;height:48px;">
                                    <?php if ($deck_icon_src !== ''): ?>
                                        <img src="<?php echo htmlspecialchars($deck_icon_src, ENT_QUOTES); ?>" alt="Deck icon">
                                    <?php else: ?>
                                        <span style="color: <?php echo htmlspecialchars($suggestion['color'] ?: $user_theme_color); ?>;"><?php echo htmlspecialchars($deck_initial); ?></span>
                                    <?php endif; ?>
                                </div>
                                <strong><?php echo htmlspecialchars($suggestion['title']); ?></strong>
                                <p style="margin:0;font-size:13px;color:var(--muted);">
                                    Updated <?php echo htmlspecialchars(formatRelativeTime($suggestion['updated_at'] ?? null)); ?>
                                </p>
                                <a href="deck.php?id=<?php echo (int)$suggestion['id']; ?>" style="text-decoration:none;">
                                    <button type="button">Open deck</button>
                                </a>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state" style="margin-top:0;">
                        <p>Once you create decks, you'll see suggestions here that aren't already in favorites.</p>
                    </div>
                <?php endif; ?>
            </section>
        </main>
    </div>
    <script>
        // Notifications dropdown
        const notifBtn = document.getElementById('notifBtn');
        const notifDropdown = document.getElementById('notifDropdown');

        if (notifBtn && notifDropdown) {
            notifBtn.addEventListener('click', function (e) {
                e.stopPropagation();
                notifDropdown.classList.toggle('show');
            });

            document.addEventListener('click', function (e) {
                if (!notifDropdown.contains(e.target) && e.target !== notifBtn) {
                    notifDropdown.classList.remove('show');
                }
            });
        }

        // Clear all notifications function
        function clearAllNotifications(event) {
            event.preventDefault();
            event.stopPropagation();
            
            if (!confirm('Clear all notifications?')) {
                return;
            }
            
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            
            const inputAction = document.createElement('input');
            inputAction.type = 'hidden';
            inputAction.name = 'clear_all_notifications';
            inputAction.value = '1';
            
            const inputAjax = document.createElement('input');
            inputAjax.type = 'hidden';
            inputAjax.name = 'ajax';
            inputAjax.value = '1';
            
            form.appendChild(inputAction);
            form.appendChild(inputAjax);
            document.body.appendChild(form);
            
            fetch(window.location.href, {
                method: 'POST',
                body: new FormData(form)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const notifList = document.querySelector('.notif-list');
                    if (notifList) {
                        const items = notifList.querySelectorAll('.notif-item');
                        items.forEach((item, index) => {
                            setTimeout(() => {
                                item.style.opacity = '0';
                                item.style.transform = 'translateX(-10px)';
                                setTimeout(() => item.remove(), 200);
                            }, index * 50);
                        });
                        
                        setTimeout(() => {
                            const notifDropdown = document.getElementById('notifDropdown');
                            if (notifDropdown) {
                                notifDropdown.innerHTML = '<h4><span>Notifications</span></h4><div class="notif-empty"><p>You\'re all caught up</p><span>We\'ll let you know when something new happens.</span></div>';
                            }
                            const notifBtn = document.getElementById('notifBtn');
                            if (notifBtn) {
                                notifBtn.classList.remove('has-alert');
                            }
                        }, items.length * 50 + 200);
                    }
                }
            })
            .catch(error => {
                console.error('Error clearing notifications:', error);
                form.submit();
            });
            
            document.body.removeChild(form);
        }

        // Dismiss notification function
        function dismissNotification(event, notifId) {
            event.preventDefault();
            event.stopPropagation();
            
            if (!notifId) return;
            
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            
            const inputAction = document.createElement('input');
            inputAction.type = 'hidden';
            inputAction.name = 'dismiss_notification';
            inputAction.value = '1';
            
            const inputId = document.createElement('input');
            inputId.type = 'hidden';
            inputId.name = 'notif_id';
            inputId.value = notifId;
            
            const inputAjax = document.createElement('input');
            inputAjax.type = 'hidden';
            inputAjax.name = 'ajax';
            inputAjax.value = '1';
            
            form.appendChild(inputAction);
            form.appendChild(inputId);
            form.appendChild(inputAjax);
            document.body.appendChild(form);
            
            fetch(window.location.href, {
                method: 'POST',
                body: new FormData(form)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const notifItem = document.querySelector(`[data-notif-id="${notifId}"]`);
                    if (notifItem) {
                        notifItem.style.opacity = '0';
                        notifItem.style.transform = 'translateX(-10px)';
                        setTimeout(() => {
                            notifItem.remove();
                            const notifList = document.querySelector('.notif-list');
                            if (notifList && notifList.children.length === 0) {
                                const notifDropdown = document.getElementById('notifDropdown');
                                if (notifDropdown) {
                                    notifDropdown.innerHTML = '<h4>Notifications</h4><div class="notif-empty"><p>You\'re all caught up</p><span>We\'ll let you know when something new happens.</span></div>';
                                }
                                const notifBtn = document.getElementById('notifBtn');
                                if (notifBtn) {
                                    notifBtn.classList.remove('has-alert');
                                }
                            }
                        }, 200);
                    }
                }
            })
            .catch(error => {
                console.error('Error dismissing notification:', error);
                form.submit();
            });
            
            document.body.removeChild(form);
        }

        const userMenu = document.getElementById('userMenu');
        const userDropdown = document.getElementById('userDropdown');
        if (userMenu && userDropdown) {
            userMenu.addEventListener('click', function (e) {
                e.stopPropagation();
                const isVisible = userDropdown.style.display === 'block';
                userDropdown.style.display = isVisible ? 'none' : 'block';
            });
            document.addEventListener('click', function (e) {
                // Don't close if clicking on logout button (it will handle its own modal)
                if (!userMenu.contains(e.target) && e.target.id !== 'logoutBtn' && !e.target.closest('#logoutBtn')) {
                    userDropdown.style.display = 'none';
                }
            });
        }
    </script>

    <!-- Logout Confirmation Modal -->
    <div class="logout-modal-overlay" id="logoutModal">
        <div class="logout-modal">
            <div class="logout-modal-icon">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                </svg>
            </div>
            <div class="logout-modal-header">
                <h3 class="logout-modal-title">Confirm Logout</h3>
                <p class="logout-modal-message">Are you sure you want to logout? You will need to login again to access your account.</p>
            </div>
            <div class="logout-modal-actions">
                <button class="btn-modal btn-modal-cancel" id="logoutCancelBtn">Cancel</button>
                <button class="btn-modal btn-modal-logout" id="logoutConfirmBtn">Logout</button>
            </div>
        </div>
    </div>

    <script>
        // Logout Modal - Initialize after modal HTML is in DOM
        document.addEventListener('DOMContentLoaded', function() {
            const logoutBtn = document.getElementById('logoutBtn');
            const logoutModal = document.getElementById('logoutModal');
            const logoutConfirmBtn = document.getElementById('logoutConfirmBtn');
            const logoutCancelBtn = document.getElementById('logoutCancelBtn');

            if (logoutBtn) {
                logoutBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    if (logoutModal) {
                        logoutModal.classList.add('active');
                    }
                    // Close user dropdown when opening logout modal
                    const userDropdown = document.getElementById('userDropdown');
                    if (userDropdown) {
                        userDropdown.style.display = 'none';
                    }
                });
            }

            if (logoutCancelBtn) {
                logoutCancelBtn.addEventListener('click', function() {
                    if (logoutModal) {
                        logoutModal.classList.remove('active');
                    }
                });
            }

            if (logoutConfirmBtn) {
                logoutConfirmBtn.addEventListener('click', function() {
                    window.location.href = 'dashboard.php?logout=1';
                });
            }

            if (logoutModal) {
                logoutModal.addEventListener('click', function(e) {
                    if (e.target === logoutModal) {
                        logoutModal.classList.remove('active');
                    }
                });
            }

            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && logoutModal && logoutModal.classList.contains('active')) {
                    logoutModal.classList.remove('active');
                }
            });
        });
    </script>
</body>
</html>


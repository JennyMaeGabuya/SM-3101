<?php
require_once 'config.php';

// Include PHPMailer files
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

session_start();

$signup_error = '';
$signup_success = '';
$login_error = '';
$otp_error = '';
$otp_success = '';
$show_otp_form = false;
$forgot_password_error = '';
$forgot_password_success = '';

// Handle OTP verification
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify_otp'])) {
    $input_otp = $_POST['otp'] ?? '';
    $stored_otp = $_SESSION['otp'] ?? null;
    $signup_data = $_SESSION['signup_data'] ?? null;
    $expiry = $_SESSION['otp_expire'] ?? 0;

    if (!$stored_otp || !$signup_data) {
        $otp_error = "No OTP found. Please sign up again.";
        unset($_SESSION['otp'], $_SESSION['signup_data'], $_SESSION['otp_expire'], $_SESSION['email']);
    } elseif (time() > $expiry) {
        unset($_SESSION['otp'], $_SESSION['signup_data'], $_SESSION['otp_expire'], $_SESSION['email']);
        $otp_error = "OTP expired. Please sign up again.";
    } elseif ($input_otp == $stored_otp) {
        // OTP verified, create the account
        $full_name = $signup_data['full_name'];
        $email = $signup_data['email'];
        $username = $signup_data['username'];
        $password_hash = $signup_data['password_hash'];

        // Check if email/username still doesn't exist (in case of race condition)
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? OR username = ?");
        $stmt->bind_param("ss", $email, $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $otp_error = "Email or username already exists. Please use different credentials.";
            $stmt->close();
            unset($_SESSION['otp'], $_SESSION['signup_data'], $_SESSION['otp_expire'], $_SESSION['email']);
        } else {
            $stmt->close();
            // Insert into database with verified status
            $status = 'verified';
            $stmt = $conn->prepare("INSERT INTO users (full_name, email, username, password, status) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssss", $full_name, $email, $username, $password_hash, $status);

            if ($stmt->execute()) {
                // Get the newly created user ID
                $new_user_id = $stmt->insert_id;
                $stmt->close();
                
                // Clear OTP session data
                unset($_SESSION['otp'], $_SESSION['signup_data'], $_SESSION['otp_expire'], $_SESSION['email']);
                
                // Automatically log in the user
                $_SESSION['user_id'] = $new_user_id;
                $_SESSION['user_name'] = $full_name;
                $_SESSION['user_email'] = $email;
                $_SESSION['user_username'] = $username;
                
                // Redirect to dashboard
                header("Location: dashboard.php");
                exit();
            } else {
                $otp_error = "Error creating account. Please try again.";
                $stmt->close();
            }
        }
    } else {
        $otp_error = "Incorrect OTP! Please try again.";
    }
}

// Handle resend OTP
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['resend_otp'])) {
    $signup_data = $_SESSION['signup_data'] ?? null;
    if ($signup_data && isset($signup_data['email'])) {
        $email = $signup_data['email'];
        $otp = rand(100000, 999999);
        $_SESSION['otp'] = $otp;
        $_SESSION['otp_expire'] = time() + 300; // 5 min expiry

        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'bizmobsu@gmail.com';
            $mail->Password = 'cohrugzxdhsjqybd';
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;
            $mail->SMTPOptions = array(
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                )
            );

            $mail->setFrom('bizmobsu@gmail.com', 'Bizmo OTP System');
            $mail->addAddress($email);
            $mail->isHTML(true);
            $mail->Subject = 'Your OTP Verification Code';
            $mail->Body = "
                <p>Hello,</p>
                <p>Your One-Time Password (OTP) is: <b>$otp</b></p>
                <p>This code will expire in 5 minutes.</p>
            ";
            $mail->AltBody = "Your OTP is $otp. It will expire in 5 minutes.";

            $mail->send();
            $otp_success = "OTP has been resent to $email";
        } catch (Exception $e) {
            $otp_error = "Failed to send OTP. Please try again.";
        }
    }
}

// Handle forgot password request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['forgot_password'])) {
    $email = trim($_POST['email'] ?? '');
    
    if (empty($email)) {
        $forgot_password_error = "Please enter your email address.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $forgot_password_error = "Please enter a valid email address.";
    } else {
        // Check if email exists
        $stmt = $conn->prepare("SELECT id, full_name, email FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            
            // Generate secure reset token
            $reset_token = bin2hex(random_bytes(32));
            $reset_expiry = time() + (60 * 60); // 1 hour expiry
            
            // Store token in database
            $update_stmt = $conn->prepare("UPDATE users SET reset_token = ?, reset_token_expiry = ? WHERE id = ?");
            if ($update_stmt) {
                $update_stmt->bind_param("sii", $reset_token, $reset_expiry, $user['id']);
                if ($update_stmt->execute()) {
                    // Success
                } else {
                    $forgot_password_error = "Database error: " . $update_stmt->error;
                }
                $update_stmt->close();
            } else {
                $forgot_password_error = "Database error: " . $conn->error;
            }
            
            // Create reset link
            $reset_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/reset_password.php?token=" . $reset_token;
            
            // Send email
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'bizmobsu@gmail.com';
                $mail->Password = 'cohrugzxdhsjqybd';
                $mail->SMTPSecure = 'tls';
                $mail->Port = 587;
                $mail->SMTPOptions = array(
                    'ssl' => array(
                        'verify_peer' => false,
                        'verify_peer_name' => false,
                        'allow_self_signed' => true
                    )
                );

                $mail->setFrom('bizmobsu@gmail.com', 'Bizmo Password Reset');
                $mail->addAddress($email);
                $mail->isHTML(true);
                $mail->Subject = 'Password Reset Request';
                $mail->Body = "
                    <p>Hello {$user['full_name']},</p>
                    <p>You have requested to reset your password for your Bizmo account.</p>
                    <p>Click the link below to reset your password:</p>
                    <p><a href='$reset_link' style='display: inline-block; padding: 12px 24px; background: #dc2626; color: #fff; text-decoration: none; border-radius: 8px; font-weight: 600;'>Reset Password</a></p>
                    <p>Or copy and paste this link into your browser:</p>
                    <p style='word-break: break-all; color: #666;'>$reset_link</p>
                    <p>This link will expire in 1 hour.</p>
                    <p>If you did not request this password reset, please ignore this email.</p>
                    <p>Best regards,<br>Bizmo Team</p>
                ";
                $mail->AltBody = "Click this link to reset your password: $reset_link\n\nThis link will expire in 1 hour.";

                $mail->send();
                $forgot_password_success = "Password reset link has been sent to your email. Please check your inbox.";
                $forgot_password_error = '';
            } catch (Exception $e) {
                $forgot_password_error = "Failed to send email. Please try again.";
                $forgot_password_success = '';
            }
        } else {
            // Don't reveal if email exists for security
            $forgot_password_success = "If that email exists in our system, a password reset link has been sent.";
            $forgot_password_error = '';
        }
        $stmt->close();
    }
}

// Redirect to dashboard if user is already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['signup']) && !isset($_POST['verify_otp']) && !isset($_POST['resend_otp']) && !isset($_POST['forgot_password'])) {
    $email_or_username = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($email_or_username) || empty($password)) {
        $login_error = "Please enter both email/username and password.";
    } else {
        // Check if user exists by email or username
        $stmt = $conn->prepare("SELECT id, full_name, email, username, password, status FROM users WHERE email = ? OR username = ?");
        $stmt->bind_param("ss", $email_or_username, $email_or_username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            
            // Check if account is verified
            if ($user['status'] !== 'verified') {
                $login_error = "Your account is not verified. Please verify your email first.";
            } elseif (password_verify($password, $user['password'])) {
                // Login successful
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['full_name'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['user_username'] = $user['username'];
                
                header("Location: dashboard.php");
                exit();
            } else {
                $login_error = "Invalid email/username or password.";
            }
        } else {
            $login_error = "Invalid email/username or password.";
        }
        $stmt->close();
    }
}

// Handle sign-up form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['signup'])) {
    // Get form data
    $full_name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm-password'] ?? '';
    $terms = isset($_POST['terms']) ? true : false;
    
    // Validation
    $errors = [];
    
    if (empty($full_name)) {
        $errors[] = "Full name is required.";
    } elseif (strlen($full_name) < 2) {
        $errors[] = "Full name must be at least 2 characters.";
    }
    
    if (empty($email)) {
        $errors[] = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Please enter a valid email address.";
    }
    
    if (empty($username)) {
        $errors[] = "Username is required.";
    } elseif (strlen($username) < 3) {
        $errors[] = "Username must be at least 3 characters.";
    } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
        $errors[] = "Username can only contain letters, numbers, and underscores.";
    }
    
    if (empty($password)) {
        $errors[] = "Password is required.";
    } elseif (strlen($password) < 6) {
        $errors[] = "Password must be at least 6 characters.";
    }
    
    if ($password !== $confirm_password) {
        $errors[] = "Passwords do not match.";
    }
    
    if (!$terms) {
        $errors[] = "You must agree to the Terms & Conditions.";
    }
    
    // If no errors, proceed with OTP sending
    if (empty($errors)) {
        // Check if email already exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? OR username = ?");
        $stmt->bind_param("ss", $email, $username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $signup_error = "Email or username already exists. Please use different credentials.";
            $stmt->close();
        } else {
            $stmt->close();
            // Hash the password
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            
            // Generate OTP
            $otp = rand(100000, 999999);
            
            // Store signup data in session
            $_SESSION['signup_data'] = [
                'full_name' => $full_name,
                'email' => $email,
                'username' => $username,
                'password_hash' => $password_hash
            ];
            $_SESSION['otp'] = $otp;
            $_SESSION['email'] = $email;
            $_SESSION['otp_expire'] = time() + 300; // 5 min expiry
            
            // Send OTP via email
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'bizmobsu@gmail.com';
                $mail->Password = 'cohrugzxdhsjqybd';
                $mail->SMTPSecure = 'tls';
                $mail->Port = 587;
                $mail->SMTPOptions = array(
                    'ssl' => array(
                        'verify_peer' => false,
                        'verify_peer_name' => false,
                        'allow_self_signed' => true
                    )
                );

                $mail->setFrom('bizmobsu@gmail.com', 'Bizmo OTP System');
                $mail->addAddress($email);
                $mail->isHTML(true);
                $mail->Subject = 'Your OTP Verification Code';
                $mail->Body = "
                    <p>Hello $full_name,</p>
                    <p>Thank you for signing up with Bizmo!</p>
                    <p>Your One-Time Password (OTP) is: <b>$otp</b></p>
                    <p>This code will expire in 5 minutes.</p>
                    <p>Please enter this code to complete your registration.</p>
                ";
                $mail->AltBody = "Your OTP is $otp. It will expire in 5 minutes.";

                $mail->send();
                $show_otp_form = true;
                $otp_success = "OTP has been sent to $email. Please check your email.";
            } catch (Exception $e) {
                $signup_error = "Failed to send OTP. Please try again.";
                unset($_SESSION['signup_data'], $_SESSION['otp'], $_SESSION['email'], $_SESSION['otp_expire']);
            }
        }
    } else {
        $signup_error = implode(" ", $errors);
    }
}

// Check if we should show OTP form (if OTP is in session)
if (isset($_SESSION['otp']) && isset($_SESSION['signup_data'])) {
    $show_otp_form = true;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bizmo – Login</title>
    <meta name="description" content="Login to your Bizmo account.">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #0b0b12; /* dark base */
            --text: #ffffff; /* light text */
            --muted: #a2a3ad; /* muted on dark */
            --accent: #dc2626; /* red-600 */
            --accent-700: #b91c1c; /* red-700 */
            --surface: #111118; /* panels */
            --border: rgba(255,255,255,0.08); /* subtle border on dark */
            --soft-red: rgba(220,38,38,0.15); /* red glow */
        }

        * { box-sizing: border-box; }
        html, body { height: 100%; }
        body {
            margin: 0;
            font-family: 'Inter', ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial;
            background: linear-gradient(180deg, #0c0c14 0%, #0c0c14 55%, #0c0c14 100%);
            color: var(--text);
        }

        .container { max-width: 1180px; margin: 0 auto; padding: 0 20px; }

        /* Header */
        .header {
            position: sticky; top: 0; z-index: 30;
            backdrop-filter: saturate(140%) blur(8px);
            background: rgba(10,10,15,0.75);
            border-bottom: 1px solid var(--border);
        }
        .nav { display: flex; align-items: center; justify-content: space-between; padding: 16px 0; }
        .brand { display: inline-flex; align-items: center; gap: 10px; font-weight: 800; font-size: 18px; color: var(--text); text-decoration: none; }
        .logo {
            background: transparent;
            box-shadow: none;
            border: 1px solid var(--border);
            width: 50px; height: 50px; border-radius: 10px; display: grid; place-items: center;
        }
        .logo svg, .logo img { width: 50px; height: 50px; display: block; }

        .links { display: flex; align-items: center; gap: 18px; }
        .link { color: var(--muted); text-decoration: none; font-weight: 600; }
        .link:hover { color: var(--text); }
        .cta { text-decoration: none; font-weight: 700; color: #fff; background: var(--accent); padding: 10px 14px; border-radius: 999px; border: 1px solid var(--accent-700); }
        .cta:hover { background: var(--accent-700); }

        /* Login Section */
        .login-section {
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: calc(100vh - 74px);
            padding: 60px 20px 40px;
            position: relative;
        }
        .login-card {
            width: 100%;
            max-width: 600px;
            background: rgba(255,255,255,0.03);
            border: 1px solid var(--border);
            border-radius: 24px;
            padding: 48px;
            box-shadow: 0 40px 120px rgba(220,38,38,0.2);
            position: relative;
            z-index: 1;
        }
        .login-header {
            text-align: center;
            margin-bottom: 36px;
        }
        .login-title {
            font-size: 32px;
            font-weight: 900;
            margin: 0 0 8px;
            background: linear-gradient(135deg, #fff, rgba(255,255,255,0.8));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .login-subtitle {
            color: var(--muted);
            font-size: 15px;
            margin: 0;
        }
        .form-group {
            margin-bottom: 24px;
        }
        .form-label {
            display: block;
            color: var(--text);
            font-weight: 600;
            font-size: 14px;
            margin-bottom: 8px;
        }
        .form-input {
            width: 100%;
            padding: 14px 18px;
            border-radius: 12px;
            background: rgba(255,255,255,0.03) !important;
            border: 1px solid var(--border);
            color: var(--text) !important;
            font: inherit;
            font-size: 15px;
            outline: none;
            transition: all .25s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .form-input:focus {
            border-color: var(--accent);
            background: rgba(255,255,255,0.05) !important;
            box-shadow: 0 0 0 3px rgba(220,38,38,0.1);
        }
        .form-input::placeholder {
            color: var(--muted);
        }
        /* Override browser autofill styles */
        .form-input:-webkit-autofill,
        .form-input:-webkit-autofill:hover,
        .form-input:-webkit-autofill:focus,
        .form-input:-webkit-autofill:active {
            -webkit-box-shadow: 0 0 0 30px rgba(10,10,15,0.95) inset !important;
            -webkit-text-fill-color: var(--text) !important;
            background-color: rgba(10,10,15,0.95) !important;
            border: 1px solid var(--border) !important;
            caret-color: var(--text) !important;
        }
        .form-input:-webkit-autofill:focus {
            border-color: var(--accent) !important;
            -webkit-box-shadow: 0 0 0 30px rgba(10,10,15,0.95) inset, 0 0 0 3px rgba(220,38,38,0.1) !important;
        }
        /* Firefox autofill */
        .form-input:-moz-autofill {
            background-color: rgba(10,10,15,0.95) !important;
            color: var(--text) !important;
            border: 1px solid var(--border) !important;
        }
        /* General input styling to prevent white backgrounds */
        input[type="text"],
        input[type="email"],
        input[type="password"] {
            background-color: rgba(255,255,255,0.03) !important;
            color: var(--text) !important;
        }
        .password-wrapper {
            position: relative;
        }
        .password-toggle {
            position: absolute;
            right: 14px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: var(--muted);
            cursor: pointer;
            padding: 4px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: color .2s ease;
        }
        .password-toggle:hover {
            color: var(--text);
        }
        .password-toggle svg {
            width: 20px;
            height: 20px;
        }
        .form-options {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 24px;
            font-size: 14px;
        }
        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .checkbox {
            width: 18px;
            height: 18px;
            border-radius: 4px;
            border: 1px solid var(--border);
            background: rgba(255,255,255,0.03);
            cursor: pointer;
            accent-color: var(--accent);
        }
        .checkbox-label {
            color: var(--muted);
            cursor: pointer;
            user-select: none;
        }
        .forgot-link {
            color: var(--accent);
            text-decoration: none;
            font-weight: 600;
        }
        .forgot-link:hover {
            text-decoration: underline;
        }
        .login-btn {
            width: 100%;
            padding: 14px 22px;
            border-radius: 12px;
            border: 1px solid transparent;
            background: linear-gradient(135deg, var(--accent), var(--accent-700));
            color: #fff;
            font-weight: 700;
            font-size: 16px;
            cursor: pointer;
            transition: all .25s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 4px 12px rgba(220,38,38,0.3);
            margin-bottom: 24px;
        }
        .login-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(220,38,38,0.4);
        }
        .login-btn:active {
            transform: translateY(0);
        }
        .divider {
            display: flex;
            align-items: center;
            gap: 12px;
            margin: 24px 0;
            color: var(--muted);
            font-size: 14px;
        }
        .divider::before,
        .divider::after {
            content: '';
            flex: 1;
            height: 1px;
            background: var(--border);
        }
        .signup-link {
            text-align: center;
            color: var(--muted);
            font-size: 14px;
        }
        .signup-link a {
            color: var(--accent);
            text-decoration: none;
            font-weight: 700;
            margin-left: 4px;
        }
        .signup-link a:hover {
            text-decoration: underline;
        }

        /* Form Toggle */
        .form-container {
            position: relative;
            width: 100%;
        }
        .login-form, .signup-form {
            transition: opacity 0.3s ease, transform 0.3s ease;
            width: 100%;
        }
        .signup-form-grid {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        .signup-form .form-options {
            margin-top: 24px;
        }
        .login-form.hidden, .signup-form.hidden, .otp-form.hidden {
            display: none;
        }
        .signup-form, .otp-form {
            display: none;
        }
        .signup-form.active, .otp-form.active {
            display: block;
            animation: fadeIn 0.3s ease;
        }
        .login-form.active {
            display: block;
            animation: fadeIn 0.3s ease;
        }
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Terms & Conditions Modal */
        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.75);
            backdrop-filter: blur(4px);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            padding: 20px;
            animation: fadeIn 0.3s ease;
        }
        .modal-overlay.active {
            display: flex;
        }
        .modal-content {
            background: rgba(255,255,255,0.05);
            border: 1px solid var(--border);
            border-radius: 24px;
            padding: 40px;
            max-width: 700px;
            width: 100%;
            max-height: 80vh;
            overflow-y: auto;
            position: relative;
            box-shadow: 0 40px 120px rgba(0,0,0,0.5);
            animation: slideUp 0.3s ease;
        }
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        .modal-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 24px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--border);
        }
        .modal-title {
            font-size: 28px;
            font-weight: 900;
            margin: 0;
            color: var(--text);
        }
        .modal-close {
            background: rgba(255,255,255,0.05);
            border: 1px solid var(--border);
            border-radius: 12px;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            color: var(--text);
            transition: all 0.2s ease;
        }
        .modal-close:hover {
            background: rgba(255,255,255,0.1);
            border-color: var(--accent);
        }
        .modal-body {
            color: var(--muted);
            line-height: 1.8;
            font-size: 15px;
        }
        .modal-body h3 {
            color: var(--text);
            font-size: 20px;
            font-weight: 700;
            margin: 24px 0 12px;
        }
        .modal-body h3:first-child {
            margin-top: 0;
        }
        .modal-body p {
            margin: 12px 0;
        }
        .modal-body ul {
            margin: 12px 0;
            padding-left: 24px;
        }
        .modal-body li {
            margin: 8px 0;
        }

        /* Footer */
        footer {
            padding: 36px 0 64px;
            color: var(--muted);
            text-align: center;
            border-top: 1px solid var(--border);
        }

        /* Responsive */
        @media (max-width: 520px) {
            .login-card {
                padding: 36px 28px;
                max-width: 100%;
            }
            .login-title {
                font-size: 28px;
            }
            .login-section {
                padding: 20px 16px;
            }
            .form-group {
                margin-bottom: 20px;
            }
            .signup-form-grid {
                gap: 20px;
            }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="container nav">
            <a href="index.php" class="brand">
                <div class="logo" aria-label="Bizmo logo">
                    <img src="icons/bizmo.png" alt="" width="50" height="50" />
                </div>
                <span>Bizmo</span>
            </a>
            <div class="links">
            <a class="link" href="home.php">Home</a>
            <a class="link" href="login.php">Login</a>
                <a class="cta" href="login.php">Get started</a>
            </div>
        </div>
    </header>

    <main>
        <section class="login-section">
            <div class="login-card">
                <div class="form-container">
                    <!-- Login Form -->
                    <div class="login-form active" id="loginForm">
                        <div class="login-header">
                            <h1 class="login-title">Welcome back</h1>
                            <p class="login-subtitle">Sign in to continue your learning journey</p>
                        </div>

                        <?php if ($login_error): ?>
                            <div class="error-message" style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); color: #fca5a5; padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; font-size: 14px;">
                                <?php echo htmlspecialchars($login_error); ?>
                            </div>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" autocomplete="off">
                            <div class="form-group">
                                <label for="email" class="form-label">Email or Username</label>
                                <input 
                                    type="text" 
                                    id="email" 
                                    name="email" 
                                    class="form-input" 
                                    placeholder="Enter your email or username"
                                    required
                                    autocomplete="off"
                                    maxlength="100"
                                    pattern="[a-zA-Z0-9@._-]+"
                                    title="Only letters, numbers, @, ., _, and - are allowed"
                                    readonly
                                    onfocus="this.removeAttribute('readonly')"
                                />
                            </div>

                            <div class="form-group">
                                <label for="password" class="form-label">Password</label>
                                <div class="password-wrapper">
                                    <input 
                                        type="password" 
                                        id="password" 
                                        name="password" 
                                        class="form-input" 
                                        placeholder="Enter your password"
                                        required
                                        autocomplete="new-password"
                                        minlength="6"
                                        maxlength="128"
                                        readonly
                                        onfocus="this.removeAttribute('readonly')"
                                    />
                                    <button type="button" class="password-toggle" id="passwordToggle" aria-label="Show password">
                                        <svg id="eyeIcon" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="display: block;">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                                        </svg>
                                        <svg id="eyeOffIcon" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="display: none;">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"/>
                                        </svg>
                                    </button>
                                </div>
                            </div>

                            <div class="form-options">
                                <div class="checkbox-group">
                                    <input type="checkbox" id="remember" name="remember" class="checkbox" />
                                    <label for="remember" class="checkbox-label">Remember me</label>
                                </div>
                                <a href="#" class="forgot-link" id="showForgotPasswordModal">Forgot password?</a>
                            </div>

                            <button type="submit" class="login-btn">Sign in</button>
                        </form>

                        <div class="divider">or</div>

                        <div class="signup-link">
                            Don't have an account? <a href="#" id="showSignup">Sign up</a>
                        </div>
                    </div>

                    <!-- Sign Up Form -->
                    <div class="signup-form" id="signupForm">
                        <div class="login-header">
                            <h1 class="login-title">Create account</h1>
                            <p class="login-subtitle">Join Bizmo and start your learning journey</p>
                        </div>

                        <?php if ($signup_error): ?>
                            <div style="background: rgba(220,38,38,0.1); border: 1px solid rgba(220,38,38,0.3); border-radius: 12px; padding: 12px 16px; margin-bottom: 20px; color: #ff6b6b; font-size: 14px;">
                                <?php echo htmlspecialchars($signup_error); ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($signup_success): ?>
                            <div style="background: rgba(34,197,94,0.1); border: 1px solid rgba(34,197,94,0.3); border-radius: 12px; padding: 12px 16px; margin-bottom: 20px; color: #4ade80; font-size: 14px;">
                                <?php echo htmlspecialchars($signup_success); ?>
                            </div>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                            <input type="hidden" name="signup" value="1">
                            <div class="signup-form-grid">
                                <div class="form-group">
                                    <label for="signup-name" class="form-label">Full Name</label>
                                    <input 
                                        type="text" 
                                        id="signup-name" 
                                        name="name" 
                                        class="form-input" 
                                        placeholder="Enter your full name"
                                        value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>"
                                        required
                                        autocomplete="off"
                                        minlength="2"
                                        maxlength="100"
                                        pattern="[a-zA-Z\s'-]+"
                                        title="Only letters, spaces, hyphens, and apostrophes are allowed"
                                    />
                                </div>

                                <div class="form-group">
                                    <label for="signup-email" class="form-label">Email</label>
                                    <input 
                                        type="email" 
                                        id="signup-email" 
                                        name="email" 
                                        class="form-input" 
                                        placeholder="Enter your email"
                                        value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>"
                                        required
                                        autocomplete="off"
                                        maxlength="255"
                                        pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"
                                        title="Please enter a valid email address"
                                    />
                                </div>

                                <div class="form-group">
                                    <label for="signup-username" class="form-label">Username</label>
                                    <input 
                                        type="text" 
                                        id="signup-username" 
                                        name="username" 
                                        class="form-input" 
                                        placeholder="Choose a username"
                                        value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>"
                                        required
                                        autocomplete="off"
                                        minlength="3"
                                        maxlength="30"
                                        pattern="[a-zA-Z0-9_]+"
                                        title="Username must be 3-30 characters and can only contain letters, numbers, and underscores"
                                    />
                                </div>

                                <div class="form-group">
                                    <label for="signup-password" class="form-label">Password</label>
                                    <div class="password-wrapper">
                                        <input 
                                            type="password" 
                                            id="signup-password" 
                                            name="password" 
                                            class="form-input" 
                                            placeholder="Create a password"
                                            required
                                            autocomplete="off"
                                            minlength="6"
                                            maxlength="128"
                                            title="Password must be at least 6 characters long"
                                        />
                                        <button type="button" class="password-toggle" id="signupPasswordToggle" aria-label="Show password">
                                            <svg id="signupEyeIcon" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="display: block;">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                                            </svg>
                                            <svg id="signupEyeOffIcon" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="display: none;">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"/>
                                            </svg>
                                        </button>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="signup-confirm-password" class="form-label">Confirm Password</label>
                                    <div class="password-wrapper">
                                        <input 
                                            type="password" 
                                            id="signup-confirm-password" 
                                            name="confirm-password" 
                                            class="form-input" 
                                            placeholder="Confirm your password"
                                            required
                                            autocomplete="off"
                                            minlength="6"
                                            maxlength="128"
                                            title="Password must be at least 6 characters long"
                                        />
                                        <button type="button" class="password-toggle" id="signupConfirmPasswordToggle" aria-label="Show password">
                                            <svg id="signupConfirmEyeIcon" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="display: block;">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                                            </svg>
                                            <svg id="signupConfirmEyeOffIcon" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="display: none;">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"/>
                                            </svg>
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <div class="form-options">
                                <div class="checkbox-group">
                                    <input type="checkbox" id="terms" name="terms" class="checkbox" required />
                                    <label for="terms" class="checkbox-label">I agree to the <a href="#" id="termsLink" style="color: var(--accent);">Terms & Conditions</a></label>
                                </div>
                            </div>

                            <button type="submit" class="login-btn">Create account</button>
                        </form>

                        <div class="divider">or</div>

                        <div class="signup-link">
                            Already have an account? <a href="#" id="showLogin">Sign in</a>
                        </div>
                    </div>

                    <!-- OTP Verification Form -->
                    <div class="otp-form" id="otpForm">
                        <div class="login-header">
                            <h1 class="login-title">Verify Your Email</h1>
                            <p class="login-subtitle">We've sent a verification code to <?php echo isset($_SESSION['email']) ? htmlspecialchars($_SESSION['email']) : 'your email'; ?></p>
                        </div>

                        <?php if ($otp_error): ?>
                            <div style="background: rgba(220,38,38,0.1); border: 1px solid rgba(220,38,38,0.3); border-radius: 12px; padding: 12px 16px; margin-bottom: 20px; color: #ff6b6b; font-size: 14px;">
                                <?php echo htmlspecialchars($otp_error); ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($otp_success): ?>
                            <div style="background: rgba(34,197,94,0.1); border: 1px solid rgba(34,197,94,0.3); border-radius: 12px; padding: 12px 16px; margin-bottom: 20px; color: #4ade80; font-size: 14px;">
                                <?php echo htmlspecialchars($otp_success); ?>
                            </div>
                        <?php endif; ?>

                        <!-- OTP Timer -->
                        <?php 
                        $otp_expire = $_SESSION['otp_expire'] ?? 0;
                        $remaining_time = max(0, $otp_expire - time());
                        ?>
                        <div id="otpTimer" style="text-align: center; margin-bottom: 24px; padding: 12px; background: rgba(220,38,38,0.1); border: 1px solid rgba(220,38,38,0.3); border-radius: 12px;">
                            <div style="color: var(--muted); font-size: 13px; margin-bottom: 4px;">OTP expires in</div>
                            <div id="timerDisplay" style="color: var(--accent); font-size: 20px; font-weight: 700; font-family: 'Courier New', monospace;">
                                <?php 
                                if ($remaining_time > 0) {
                                    $minutes = floor($remaining_time / 60);
                                    $seconds = $remaining_time % 60;
                                    echo sprintf("%02d:%02d", $minutes, $seconds);
                                } else {
                                    echo "00:00";
                                }
                                ?>
                            </div>
                        </div>

                        <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" id="otpFormElement">
                            <div class="form-group">
                                <label for="otp" class="form-label">Enter 6-digit OTP</label>
                                <input 
                                    type="text" 
                                    id="otp" 
                                    name="otp" 
                                    class="form-input" 
                                    placeholder="000000"
                                    maxlength="6"
                                    minlength="6"
                                    pattern="[0-9]{6}"
                                    required
                                    autocomplete="off"
                                    inputmode="numeric"
                                    title="Please enter a 6-digit number"
                                    style="text-align: center; font-size: 24px; letter-spacing: 8px; font-weight: 600; background: rgba(255,255,255,0.03) !important; color: var(--text) !important;"
                                />
                            </div>

                            <button type="submit" name="verify_otp" class="login-btn" id="verifyOtpBtn">Verify OTP</button>
                        </form>

                        <div style="text-align: center; margin-top: 20px;">
                            <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" style="display: inline;" id="resendOtpForm">
                                <button type="submit" name="resend_otp" class="forgot-link" id="resendOtpBtn" style="background: none; border: none; cursor: pointer; padding: 0;" disabled>
                                    Resend OTP
                                </button>
                            </form>
                        </div>

                        <div class="divider">or</div>

                        <div class="signup-link">
                            <a href="#" id="backToSignup" style="color: var(--accent); text-decoration: none; font-weight: 700;">Back to Sign Up</a>
                        </div>

                        <!-- Gmail Link -->
                        <div style="text-align: center; margin-top: 24px; padding-top: 20px; border-top: 1px solid var(--border);">
                            <a href="https://mail.google.com" target="_blank" id="gmailLink" style="display: inline-flex; align-items: center; gap: 8px; color: var(--accent); text-decoration: none; font-weight: 600; font-size: 14px; padding: 10px 16px; border: 1px solid var(--accent); border-radius: 8px; transition: all 0.2s ease;">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M24 5.457v13.909c0 .904-.732 1.636-1.636 1.636h-3.819V11.73L12 16.64l-6.545-4.91v9.273H1.636A1.636 1.636 0 0 1 0 19.366V5.457c0-2.023 2.309-3.178 3.927-1.964L5.455 4.64 12 9.548l6.545-4.91 1.528-1.145C21.69 2.28 24 3.434 24 5.457z"/>
                                </svg>
                                Open Gmail
                            </a>
                        </div>
                    </div>

                </div>
            </div>
        </section>
    </main>

    <footer>
        <div class="container">© 2025 Bizmo. All rights reserved.</div>
    </footer>

    <!-- Forgot Password Modal -->
    <div class="modal-overlay" id="forgotPasswordModal">
        <div class="modal-content" style="max-width: 500px;">
            <div class="modal-header">
                <h2 class="modal-title">Forgot Password</h2>
                <button class="modal-close" id="closeForgotPasswordModal" aria-label="Close modal">
                    <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                    </svg>
                </button>
            </div>
            <div class="modal-body">
                <p style="color: var(--muted); margin-bottom: 24px;">Enter your email address and we'll send you a link to reset your password.</p>

                <?php if ($forgot_password_error): ?>
                    <div style="background: rgba(220,38,38,0.1); border: 1px solid rgba(220,38,38,0.3); border-radius: 12px; padding: 12px 16px; margin-bottom: 20px; color: #ff6b6b; font-size: 14px;">
                        <?php echo htmlspecialchars($forgot_password_error); ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($forgot_password_success): ?>
                    <div style="background: rgba(34,197,94,0.1); border: 1px solid rgba(34,197,94,0.3); border-radius: 12px; padding: 12px 16px; margin-bottom: 20px; color: #4ade80; font-size: 14px;">
                        <?php echo htmlspecialchars($forgot_password_success); ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" id="forgotPasswordForm">
                    <div class="form-group">
                        <label for="forgot-email" class="form-label">Email Address</label>
                        <input 
                            type="email" 
                            id="forgot-email" 
                            name="email" 
                            class="form-input" 
                            placeholder="Enter your email address"
                            required
                            autocomplete="off"
                            maxlength="255"
                            pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"
                            title="Please enter a valid email address"
                            value="<?php echo isset($_POST['email']) && isset($_POST['forgot_password']) ? htmlspecialchars($_POST['email']) : ''; ?>"
                        />
                    </div>

                    <button type="submit" name="forgot_password" class="login-btn" style="margin-bottom: 0;">Send Reset Link</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Terms & Conditions Modal -->
    <div class="modal-overlay" id="termsModal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">Terms & Conditions</h2>
                <button class="modal-close" id="closeModal" aria-label="Close modal">
                    <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                    </svg>
                </button>
            </div>
            <div class="modal-body">
                <h3>1. Acceptance of Terms</h3>
                <p>By accessing and using Bizmo, you accept and agree to be bound by the terms and provision of this agreement. If you do not agree to abide by the above, please do not use this service.</p>

                <h3>2. Use License</h3>
                <p>Permission is granted to temporarily access the materials on Bizmo's website for personal, non-commercial transitory viewing only. This is the grant of a license, not a transfer of title, and under this license you may not:</p>
                <ul>
                    <li>Modify or copy the materials</li>
                    <li>Use the materials for any commercial purpose or for any public display</li>
                    <li>Attempt to reverse engineer any software contained on Bizmo's website</li>
                    <li>Remove any copyright or other proprietary notations from the materials</li>
                </ul>

                <h3>3. User Accounts</h3>
                <p>When you create an account with us, you must provide information that is accurate, complete, and current at all times. You are responsible for safeguarding the password and for all activities that occur under your account.</p>

                <h3>4. Content</h3>
                <p>Our service allows you to create, post, and share content. You retain ownership of any intellectual property rights that you hold in that content. By posting content, you grant Bizmo a worldwide, non-exclusive, royalty-free license to use, reproduce, and distribute your content.</p>

                <h3>5. Prohibited Uses</h3>
                <p>You may not use our service:</p>
                <ul>
                    <li>In any way that violates any applicable national or international law or regulation</li>
                    <li>To transmit, or procure the sending of, any advertising or promotional material</li>
                    <li>To impersonate or attempt to impersonate the company, a company employee, another user, or any other person or entity</li>
                </ul>

                <h3>6. Privacy Policy</h3>
                <p>Your use of Bizmo is also governed by our Privacy Policy. Please review our Privacy Policy to understand our practices regarding the collection and use of your personal information.</p>

                <h3>7. Limitation of Liability</h3>
                <p>In no event shall Bizmo, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential, or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from your use of the service.</p>

                <h3>8. Changes to Terms</h3>
                <p>We reserve the right, at our sole discretion, to modify or replace these Terms at any time. If a revision is material, we will provide at least 30 days notice prior to any new terms taking effect.</p>

                <h3>9. Contact Information</h3>
                <p>If you have any questions about these Terms & Conditions, please contact us at support@bizmo.com</p>

                <p><strong>Last updated:</strong> January 2025</p>
            </div>
        </div>
    </div>

    <script>
        // Form toggle functionality
        let loginForm, signupForm, otpForm, showSignupLink, showLoginLink, backToSignupLink, loginSection;

        // Wait for DOM to be fully loaded
        document.addEventListener('DOMContentLoaded', function() {
            loginForm = document.getElementById('loginForm');
            signupForm = document.getElementById('signupForm');
            otpForm = document.getElementById('otpForm');
            showSignupLink = document.getElementById('showSignup');
            showLoginLink = document.getElementById('showLogin');
            backToSignupLink = document.getElementById('backToSignup');
            loginSection = document.querySelector('.login-section');

            // Show OTP form if needed
            <?php if ($show_otp_form): ?>
            if (loginForm) loginForm.classList.remove('active');
            if (loginForm) loginForm.classList.add('hidden');
            if (signupForm) signupForm.classList.remove('active');
            if (signupForm) signupForm.classList.add('hidden');
            if (otpForm) otpForm.classList.remove('hidden');
            if (otpForm) otpForm.classList.add('active');
            <?php endif; ?>

            // Show signup form if there's an error or success message (but not OTP form)
            <?php if (($signup_error || $signup_success) && !$show_otp_form): ?>
            if (loginForm) loginForm.classList.remove('active');
            if (loginForm) loginForm.classList.add('hidden');
            if (signupForm) signupForm.classList.remove('hidden');
            if (signupForm) signupForm.classList.add('active');
            if (loginSection) loginSection.classList.add('signup-active');
            <?php endif; ?>
            
            // Auto-hide success message after 5 seconds and show login form
            <?php if ($signup_success && !$show_otp_form): ?>
            setTimeout(function() {
                if (signupForm) signupForm.classList.remove('active');
                if (signupForm) signupForm.classList.add('hidden');
                if (loginForm) loginForm.classList.remove('hidden');
                if (loginForm) loginForm.classList.add('active');
                if (loginSection) loginSection.classList.remove('signup-active');
            }, 5000);
            <?php endif; ?>

        if (showSignupLink) {
            showSignupLink.addEventListener('click', function(e) {
                e.preventDefault();
                if (loginForm) {
                    loginForm.classList.remove('active');
                    loginForm.classList.add('hidden');
                }
                if (otpForm) {
                    otpForm.classList.remove('active');
                    otpForm.classList.add('hidden');
                }
                if (signupForm) {
                    signupForm.classList.remove('hidden');
                    signupForm.classList.add('active');
                }
                if (loginSection) {
                    loginSection.classList.add('signup-active');
                }
            });
        }

        if (showLoginLink) {
            showLoginLink.addEventListener('click', function(e) {
                e.preventDefault();
                if (signupForm) {
                    signupForm.classList.remove('active');
                    signupForm.classList.add('hidden');
                }
                if (otpForm) {
                    otpForm.classList.remove('active');
                    otpForm.classList.add('hidden');
                }
                if (loginForm) {
                    loginForm.classList.remove('hidden');
                    loginForm.classList.add('active');
                }
                if (loginSection) {
                    loginSection.classList.remove('signup-active');
                }
            });
        }

            // Back to signup from OTP form
            if (backToSignupLink) {
                backToSignupLink.addEventListener('click', function(e) {
                    e.preventDefault();
                    if (otpForm) otpForm.classList.remove('active');
                    if (otpForm) otpForm.classList.add('hidden');
                    if (signupForm) signupForm.classList.remove('hidden');
                    if (signupForm) signupForm.classList.add('active');
                });
            }

                // Input field restrictions
            // Username field - only alphanumeric and underscore
            const usernameInput = document.getElementById('signup-username');
            if (usernameInput) {
                usernameInput.addEventListener('input', function(e) {
                    // Remove any characters that are not letters, numbers, or underscore
                    this.value = this.value.replace(/[^a-zA-Z0-9_]/g, '');
                });
            }

            // Full name field - only letters, spaces, hyphens, and apostrophes
            const nameInput = document.getElementById('signup-name');
            if (nameInput) {
                nameInput.addEventListener('input', function(e) {
                    // Allow letters, spaces, hyphens, and apostrophes
                    this.value = this.value.replace(/[^a-zA-Z\s'-]/g, '');
                });
            }

            // Login email/username field - restrict special characters
            const loginEmailInput = document.getElementById('email');
            if (loginEmailInput) {
                loginEmailInput.addEventListener('input', function(e) {
                    // Allow letters, numbers, @, ., _, and -
                    this.value = this.value.replace(/[^a-zA-Z0-9@._-]/g, '');
                });
            }

            // OTP input formatting - only allow numbers
            const otpInput = document.getElementById('otp');
            if (otpInput) {
                otpInput.addEventListener('input', function(e) {
                    // Remove any non-numeric characters
                    this.value = this.value.replace(/[^0-9]/g, '');
                    // Limit to 6 digits
                    if (this.value.length > 6) {
                        this.value = this.value.slice(0, 6);
                    }
                });

                // Auto-focus on OTP form load
                <?php if ($show_otp_form): ?>
                setTimeout(function() {
                    if (otpInput) otpInput.focus();
                }, 300);
                <?php endif; ?>
            }

            // Password confirmation validation
            const signupPasswordInput = document.getElementById('signup-password');
            const signupConfirmPasswordInput = document.getElementById('signup-confirm-password');
            
            function validatePasswordMatch() {
                if (signupPasswordInput && signupConfirmPasswordInput) {
                    if (signupConfirmPasswordInput.value && signupPasswordInput.value !== signupConfirmPasswordInput.value) {
                        signupConfirmPasswordInput.setCustomValidity('Passwords do not match');
                    } else {
                        signupConfirmPasswordInput.setCustomValidity('');
                    }
                }
            }

            if (signupPasswordInput) {
                signupPasswordInput.addEventListener('input', validatePasswordMatch);
            }
            if (signupConfirmPasswordInput) {
                signupConfirmPasswordInput.addEventListener('input', validatePasswordMatch);
            }

        // OTP Timer Countdown
        <?php if ($show_otp_form && isset($_SESSION['otp_expire'])): ?>
        (function() {
            const timerDisplay = document.getElementById('timerDisplay');
            const verifyOtpBtn = document.getElementById('verifyOtpBtn');
            const resendOtpBtn = document.getElementById('resendOtpBtn');
            const otpFormElement = document.getElementById('otpFormElement');
            const otpTimer = document.getElementById('otpTimer');
            
            if (!timerDisplay) return;
            
            // Calculate remaining time in seconds
            const expiryTime = <?php echo $_SESSION['otp_expire']; ?>;
            const currentTime = <?php echo time(); ?>;
            let remainingSeconds = Math.max(0, expiryTime - currentTime);
            
            function updateTimer() {
                if (remainingSeconds <= 0) {
                    timerDisplay.textContent = '00:00';
                    timerDisplay.style.color = '#ff6b6b';
                    otpTimer.style.background = 'rgba(220,38,38,0.2)';
                    otpTimer.style.borderColor = 'rgba(220,38,38,0.5)';
                    
                    // Disable verify button and form
                    if (verifyOtpBtn) verifyOtpBtn.disabled = true;
                    if (otpInput) otpInput.disabled = true;
                    if (otpFormElement) otpFormElement.style.opacity = '0.5';
                    if (otpFormElement) otpFormElement.style.pointerEvents = 'none';
                    
                    // Enable resend button
                    if (resendOtpBtn) {
                        resendOtpBtn.disabled = false;
                        resendOtpBtn.style.color = 'var(--accent)';
                        resendOtpBtn.style.cursor = 'pointer';
                    }
                    
                    // Update timer text
                    const timerLabel = otpTimer.querySelector('div:first-child');
                    if (timerLabel) timerLabel.textContent = 'OTP has expired';
                    
                    return;
                }
                
                const minutes = Math.floor(remainingSeconds / 60);
                const seconds = remainingSeconds % 60;
                timerDisplay.textContent = String(minutes).padStart(2, '0') + ':' + String(seconds).padStart(2, '0');
                
                // Change color when less than 1 minute remaining
                if (remainingSeconds < 60) {
                    timerDisplay.style.color = '#ff6b6b';
                    otpTimer.style.background = 'rgba(220,38,38,0.15)';
                } else {
                    timerDisplay.style.color = 'var(--accent)';
                    otpTimer.style.background = 'rgba(220,38,38,0.1)';
                }
                
                remainingSeconds--;
                
                // Continue countdown
                setTimeout(updateTimer, 1000);
            }
            
            // Start the timer
            updateTimer();
        })();
        <?php endif; ?>

            // Gmail link hover effect
            const gmailLink = document.getElementById('gmailLink');
            if (gmailLink) {
                gmailLink.addEventListener('mouseenter', function() {
                    this.style.background = 'rgba(220,38,38,0.1)';
                    this.style.transform = 'translateY(-2px)';
                });
                gmailLink.addEventListener('mouseleave', function() {
                    this.style.background = 'transparent';
                    this.style.transform = 'translateY(0)';
                });
            }

            // Clear any pre-filled values on page load
            const emailInput = document.getElementById('email');
            const passwordInput = document.getElementById('password');
            
            // Clear immediately
            if (emailInput) {
                emailInput.value = '';
                emailInput.removeAttribute('readonly');
            }
            if (passwordInput) {
                passwordInput.value = '';
                passwordInput.removeAttribute('readonly');
            }
            
            // Clear again after a short delay to catch browser autofill
            setTimeout(function() {
                if (emailInput && emailInput.value) {
                    emailInput.value = '';
                }
                if (passwordInput && passwordInput.value) {
                    passwordInput.value = '';
                }
            }, 100);
            
            // Clear on focus if still has value
            if (emailInput) {
                emailInput.addEventListener('focus', function() {
                    if (this.value && (this.value === 'records123' || this.value.includes('records'))) {
                        this.value = '';
                    }
                });
            }
            if (passwordInput) {
                passwordInput.addEventListener('focus', function() {
                    if (this.value) {
                        this.value = '';
                    }
                });
            }

            // Password toggle functionality for login form
            const passwordToggle = document.getElementById('passwordToggle');
            const eyeIcon = document.getElementById('eyeIcon');
            const eyeOffIcon = document.getElementById('eyeOffIcon');

            if (passwordToggle && passwordInput) {
                passwordToggle.addEventListener('click', function() {
                    if (passwordInput.type === 'password') {
                        passwordInput.type = 'text';
                        if (eyeIcon) eyeIcon.style.display = 'none';
                        if (eyeOffIcon) eyeOffIcon.style.display = 'block';
                        passwordToggle.setAttribute('aria-label', 'Hide password');
                    } else {
                        passwordInput.type = 'password';
                        if (eyeIcon) eyeIcon.style.display = 'block';
                        if (eyeOffIcon) eyeOffIcon.style.display = 'none';
                        passwordToggle.setAttribute('aria-label', 'Show password');
                    }
                });
            }

            // Password toggle functionality for signup form - password field
            const signupPasswordToggle = document.getElementById('signupPasswordToggle');
            const signupEyeIcon = document.getElementById('signupEyeIcon');
            const signupEyeOffIcon = document.getElementById('signupEyeOffIcon');

            if (signupPasswordToggle && signupPasswordInput) {
                signupPasswordToggle.addEventListener('click', function() {
                    if (signupPasswordInput.type === 'password') {
                        signupPasswordInput.type = 'text';
                        if (signupEyeIcon) signupEyeIcon.style.display = 'none';
                        if (signupEyeOffIcon) signupEyeOffIcon.style.display = 'block';
                        signupPasswordToggle.setAttribute('aria-label', 'Hide password');
                    } else {
                        signupPasswordInput.type = 'password';
                        if (signupEyeIcon) signupEyeIcon.style.display = 'block';
                        if (signupEyeOffIcon) signupEyeOffIcon.style.display = 'none';
                        signupPasswordToggle.setAttribute('aria-label', 'Show password');
                    }
                });
            }

            // Password toggle functionality for signup form - confirm password field
            const signupConfirmPasswordToggle = document.getElementById('signupConfirmPasswordToggle');
            const signupConfirmEyeIcon = document.getElementById('signupConfirmEyeIcon');
            const signupConfirmEyeOffIcon = document.getElementById('signupConfirmEyeOffIcon');

            if (signupConfirmPasswordToggle && signupConfirmPasswordInput) {
                signupConfirmPasswordToggle.addEventListener('click', function() {
                    if (signupConfirmPasswordInput.type === 'password') {
                        signupConfirmPasswordInput.type = 'text';
                        if (signupConfirmEyeIcon) signupConfirmEyeIcon.style.display = 'none';
                        if (signupConfirmEyeOffIcon) signupConfirmEyeOffIcon.style.display = 'block';
                        signupConfirmPasswordToggle.setAttribute('aria-label', 'Hide password');
                    } else {
                        signupConfirmPasswordInput.type = 'password';
                        if (signupConfirmEyeIcon) signupConfirmEyeIcon.style.display = 'block';
                        if (signupConfirmEyeOffIcon) signupConfirmEyeOffIcon.style.display = 'none';
                        signupConfirmPasswordToggle.setAttribute('aria-label', 'Show password');
                    }
                });
            }

            // Terms & Conditions Modal functionality
            const termsLink = document.getElementById('termsLink');
            const termsModal = document.getElementById('termsModal');
            const closeModal = document.getElementById('closeModal');

            if (termsLink) {
                termsLink.addEventListener('click', function(e) {
                    e.preventDefault();
                    if (termsModal) {
                        termsModal.classList.add('active');
                        document.body.style.overflow = 'hidden';
                    }
                });
            }

            if (closeModal) {
                closeModal.addEventListener('click', function() {
                    if (termsModal) {
                        termsModal.classList.remove('active');
                        document.body.style.overflow = '';
                    }
                });
            }

            // Close modal when clicking outside the modal content
            if (termsModal) {
                termsModal.addEventListener('click', function(e) {
                    if (e.target === termsModal) {
                        termsModal.classList.remove('active');
                        document.body.style.overflow = '';
                    }
                });
            }

            // Close modal with Escape key
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape') {
                    if (termsModal && termsModal.classList.contains('active')) {
                        termsModal.classList.remove('active');
                        document.body.style.overflow = '';
                    }
                    if (forgotPasswordModal && forgotPasswordModal.classList.contains('active')) {
                        forgotPasswordModal.classList.remove('active');
                        document.body.style.overflow = '';
                    }
                }
            });

            // Forgot Password Modal functionality
            const showForgotPasswordModalLink = document.getElementById('showForgotPasswordModal');
            const forgotPasswordModal = document.getElementById('forgotPasswordModal');
            const closeForgotPasswordModal = document.getElementById('closeForgotPasswordModal');

            if (showForgotPasswordModalLink) {
                showForgotPasswordModalLink.addEventListener('click', function(e) {
                    e.preventDefault();
                    if (forgotPasswordModal) {
                        forgotPasswordModal.classList.add('active');
                        document.body.style.overflow = 'hidden';
                        // Focus on email input
                        setTimeout(function() {
                            const emailInput = document.getElementById('forgot-email');
                            if (emailInput) emailInput.focus();
                        }, 300);
                    }
                });
            }

            if (closeForgotPasswordModal) {
                closeForgotPasswordModal.addEventListener('click', function() {
                    if (forgotPasswordModal) {
                        forgotPasswordModal.classList.remove('active');
                        document.body.style.overflow = '';
                    }
                });
            }

            // Close forgot password modal when clicking outside
            if (forgotPasswordModal) {
                forgotPasswordModal.addEventListener('click', function(e) {
                    if (e.target === forgotPasswordModal) {
                        forgotPasswordModal.classList.remove('active');
                        document.body.style.overflow = '';
                    }
                });
            }

            // Show modal if there's an error or success message
            <?php if ($forgot_password_error || $forgot_password_success): ?>
            if (forgotPasswordModal) {
                forgotPasswordModal.classList.add('active');
                document.body.style.overflow = 'hidden';
            }
            <?php endif; ?>
        }); // End of DOMContentLoaded
    </script>
</body>
</html>

<?php
session_start();
require_once 'config.php';

if (!function_exists('buildDeckIconSrc')) {
    function buildDeckIconSrc($iconValue) {
        if ($iconValue === null || $iconValue === '') {
            return '';
        }
        if (strpos($iconValue, 'data:') === 0) {
            return $iconValue;
        }
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = $finfo ? finfo_buffer($finfo, $iconValue) : null;
        if ($finfo) {
            finfo_close($finfo);
        }
        if (!$mime) {
            $mime = 'image/png';
        }
        return 'data:' . $mime . ';base64,' . base64_encode($iconValue);
    }
}

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$deck_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($deck_id <= 0) {
    header("Location: decks.php");
    exit();
}

// Ensure deck belongs to user
$stmt = $conn->prepare("SELECT id, user_id, title, description, color, icon FROM decks WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $deck_id, $user_id);
$stmt->execute();
$deck = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$deck) {
    header("Location: decks.php");
    exit();
}

$deck_icon_src = buildDeckIconSrc($deck['icon'] ?? null);
$deck_icon_fallback = mb_strtoupper(mb_substr($deck['title'], 0, 1));

// Fetch cards
$cards = [];
$stmt = $conn->prepare("SELECT id, front, back FROM cards WHERE deck_id = ? AND user_id = ? ORDER BY id ASC");
$stmt->bind_param("ii", $deck_id, $user_id);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    $cards[] = $row;
}
$stmt->close();

if (empty($cards)) {
    header("Location: deck.php?id=" . $deck_id);
    exit();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo htmlspecialchars($deck['title']); ?> – Quiz</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #0b0b12;
            --text: #ffffff;
            --muted: #a2a3ad;
            --accent: <?php echo htmlspecialchars($deck['color'] ?: '#dc2626'); ?>;
            --border: rgba(255,255,255,0.08);
        }
        * { box-sizing: border-box; }
        body {
            margin: 0;
            font-family: 'Inter', system-ui, sans-serif;
            background: #0c0c14;
            color: var(--text);
        }
        .container { max-width: 960px; margin: 0 auto; padding: 24px; }
        .topbar { display:flex; justify-content:space-between; align-items:center; margin-bottom:24px; }
        .title-block { display:flex; align-items:center; gap:12px; }
        .icon { width: 48px; height:48px; border-radius:16px; display:grid; place-items:center; background: var(--accent); font-size:26px; overflow:hidden; }
        .icon img { width:100%; height:100%; object-fit:cover; display:block; }
        .card {
            background: linear-gradient(135deg, rgba(255,255,255,0.05), rgba(255,255,255,0.02));
            border:1px solid var(--border);
            border-radius:20px;
            padding:28px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.35);
            position:relative;
            overflow:hidden;
        }
        .question {
            font-size: 20px;
            font-weight: 600;
            line-height: 1.5;
            margin-bottom: 24px;
            white-space: pre-wrap;
        }
        .muted { color: var(--muted); }
        .answer-input {
            width:100%;
            padding:16px 18px;
            border-radius:16px;
            border:1px solid var(--border);
            background: rgba(10,10,15,0.92);
            color: var(--text);
            font-size:16px;
        }
        .controls { display:flex; gap:12px; margin-top:20px; }
        button {
            border-radius:14px;
            border:1px solid var(--border);
            padding:12px 18px;
            font-weight:600;
            cursor:pointer;
            background: rgba(255,255,255,0.04);
            color: var(--text);
            transition: transform .2s ease, box-shadow .2s ease;
        }
        button.primary {
            background: linear-gradient(135deg, var(--accent), #ef4444);
            border:none;
            color: #0b0b12;
        }
        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.25);
        }
        button:disabled {
            opacity: .5;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }
        .hud {
            display:flex;
            justify-content:space-between;
            align-items:center;
            margin-bottom:16px;
            font-size:14px;
        }
        .timer {
            font-size: 24px;
            font-weight: 700;
            letter-spacing: 1px;
        }
        .progress {
            height: 8px;
            background: rgba(255,255,255,0.08);
            border-radius:999px;
            overflow:hidden;
            margin-top: 18px;
        }
        .progress-fill {
            height: 100%;
            background: linear-gradient(135deg, var(--accent), #ef4444);
            width: 0%;
            transition: width .3s ease;
        }
        .status {
            margin-top: 18px;
            font-size: 14px;
            color: var(--muted);
            line-height: 1.8;
            padding: 16px;
            background: rgba(255,255,255,0.03);
            border-radius: 12px;
            border: 1px solid var(--border);
        }
        .status strong { color: #fff; font-weight: 600; }
        .hidden { display:none !important; }
        .summary {
            text-align:center;
            padding:40px 20px;
        }
        .summary h2 { margin-bottom:12px; }
        .pill {
            display:inline-flex;
            align-items:center;
            gap:6px;
            background: rgba(255,255,255,0.06);
            padding: 8px 14px;
            border-radius: 999px;
            margin: 4px;
            font-size: 13px;
        }
        .chip-green { color: #4ade80; }
        .chip-red { color: #fca5a5; }
    </style>
</head>
<body>
    <div class="container">
        <div class="topbar">
            <div class="title-block">
                <div class="icon" style="background: <?php echo htmlspecialchars($deck['color'] ?: '#dc2626'); ?>;">
                    <?php if ($deck_icon_src !== ''): ?>
                        <img src="<?php echo htmlspecialchars($deck_icon_src, ENT_QUOTES); ?>" alt="Deck icon">
                    <?php else: ?>
                        <span><?php echo htmlspecialchars($deck_icon_fallback); ?></span>
                    <?php endif; ?>
                </div>
                <div>
                    <div class="muted" style="font-size:13px;">Deck quiz</div>
                    <h1 style="margin:4px 0;"><?php echo htmlspecialchars($deck['title']); ?></h1>
                </div>
            </div>
            <div>
                <a href="deck.php?id=<?php echo (int)$deck['id']; ?>" style="text-decoration:none;">
                    <button type="button">Exit Quiz</button>
                </a>
            </div>
        </div>

        <div class="card" id="quizCard">
            <div class="hud">
                <div>
                    <div>Question <strong id="questionIndex">0</strong> / <strong><?php echo count($cards); ?></strong></div>
                </div>
                <div class="timer" id="timerDisplay">00:00</div>
            </div>

            <div id="quizBody">
                <div id="setupView">
                    <p class="muted" style="line-height:1.6;">
                        Ready to test your knowledge? Set a timer, then hit <strong>Start Quiz</strong>. Each card will appear as a question. Submit your answer—if it's incorrect the quiz automatically skips ahead, so keep up! See how many cards you can master before time runs out.
                    </p>
                    <label style="display:block; margin:20px 0 12px; font-weight:600;">
                        Timer (minutes)
                    </label>
                    <input type="number" id="timerMinutes" value="5" min="1" max="60" style="width:120px; padding:10px; border-radius:12px; border:1px solid var(--border); background:rgba(10,10,15,0.9); color:var(--text);">
                    <label style="display:block; margin:18px 0 8px; font-weight:600;">
                        Music volume
                    </label>
                    <input type="range" id="musicVolume" min="0" max="1" step="0.05" value="0.35" style="width:240px;">
                    <div class="controls" style="margin-top:30px;">
                        <button type="button" class="primary" id="startQuizBtn">Start Quiz</button>
                        <button type="button" id="shuffleBtn">Shuffle cards</button>
                    </div>
                </div>

                <div id="questionView" class="hidden">
                    <div class="question" id="questionText"></div>
                    <input type="text" id="answerInput" class="answer-input" placeholder="Type your answer…" autocomplete="off">
                    <div class="controls">
                        <button type="button" class="primary" id="submitAnswerBtn">Submit</button>
                        <button type="button" id="skipBtn">Skip</button>
                        <button type="button" id="revealBtn">Reveal</button>
                    </div>
                    <div class="status" id="statusText"></div>
                    <div class="progress">
                        <div class="progress-fill" id="progressFill"></div>
                    </div>
                </div>

                <div id="summaryView" class="hidden summary">
                    <h2>Quiz finished!</h2>
                    <p class="muted">Great effort. Here's how you did.</p>
                    <div id="summaryStats" style="margin:22px 0;"></div>
                    <div class="controls" style="justify-content:center;">
                        <button type="button" id="restartBtn" class="primary">Try Again</button>
                        <a href="deck.php?id=<?php echo (int)$deck['id']; ?>" style="text-decoration:none;">
                            <button type="button">Back to Deck</button>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        (function () {
            const cards = <?php echo json_encode($cards); ?>;
            const totalCards = cards.length;
            let order = cards.map((card, index) => index);
            let currentIndex = 0;
            let answered = 0;
            let correct = 0;
            let incorrect = 0;
            let timerSeconds = 0;
            let timerInterval = null;
            let quizActive = false;
            let locked = false;

            // Sound effects
            const correctSound = new Audio('sounds/correct.mp3');
            correctSound.volume = 1;
            const wrongSound = new Audio('sounds/wrong.mp3');
            wrongSound.volume = 1;
            const bgMusic = new Audio('sounds/quiz_bg.mp3');
            bgMusic.loop = true;
            bgMusic.volume = 0.35;

            function setLocked(state) {
                locked = state;
                els.answerInput.disabled = state;
                els.submitBtn.disabled = state;
                els.skipBtn.disabled = state;
                els.revealBtn.disabled = state;
            }

            const els = {
                setupView: document.getElementById('setupView'),
                questionView: document.getElementById('questionView'),
                summaryView: document.getElementById('summaryView'),
                questionText: document.getElementById('questionText'),
                answerInput: document.getElementById('answerInput'),
                submitBtn: document.getElementById('submitAnswerBtn'),
                skipBtn: document.getElementById('skipBtn'),
                revealBtn: document.getElementById('revealBtn'),
                statusText: document.getElementById('statusText'),
                progressFill: document.getElementById('progressFill'),
                questionIndex: document.getElementById('questionIndex'),
                timerDisplay: document.getElementById('timerDisplay'),
                summaryStats: document.getElementById('summaryStats'),
                timerMinutes: document.getElementById('timerMinutes'),
                musicVolume: document.getElementById('musicVolume'),
                startBtn: document.getElementById('startQuizBtn'),
                shuffleBtn: document.getElementById('shuffleBtn'),
                restartBtn: document.getElementById('restartBtn')
            };

            function shuffle(array) {
                for (let i = array.length - 1; i > 0; i--) {
                    const j = Math.floor(Math.random() * (i + 1));
                    [array[i], array[j]] = [array[j], array[i]];
                }
            }

            function updateProgress() {
                const percent = answered === 0 ? 0 : Math.min(100, (answered / totalCards) * 100);
                els.progressFill.style.width = percent + '%';
                els.questionIndex.textContent = Math.min(answered + 1, totalCards);
            }

            function setStatus(message, type) {
                els.statusText.innerHTML = message;
                if (type === 'correct') {
                    els.statusText.style.color = '#4ade80';
                } else if (type === 'incorrect') {
                    els.statusText.style.color = '#fca5a5';
                } else {
                    els.statusText.style.color = 'var(--muted)';
                }
            }

            function formatTime(seconds) {
                const m = Math.floor(seconds / 60);
                const s = seconds % 60;
                return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
            }

            function tick() {
                timerSeconds -= 1;
                els.timerDisplay.textContent = formatTime(Math.max(timerSeconds, 0));
                if (timerSeconds <= 0) {
                    finishQuiz();
                }
            }

            function startTimer(minutes) {
                stopTimer();
                timerSeconds = minutes * 60;
                els.timerDisplay.textContent = formatTime(timerSeconds);
                timerInterval = setInterval(tick, 1000);
            }

            function stopTimer() {
                if (timerInterval) {
                    clearInterval(timerInterval);
                    timerInterval = null;
                }
            }

            function startMusic() {
                bgMusic.currentTime = 0;
                bgMusic.play().catch(function (err) {
                    console.warn('Quiz music autoplay blocked:', err);
                });
            }

            function stopMusic() {
                try {
                    bgMusic.pause();
                } catch (err) {
                    console.warn('Unable to stop quiz music:', err);
                }
            }

            function showQuestion() {
                if (currentIndex >= totalCards) {
                    finishQuiz();
                    return;
                }
                setLocked(false);
                const card = cards[order[currentIndex]];
                els.questionText.textContent = card.front;
                els.answerInput.value = '';
                els.answerInput.focus();
                setStatus('Type your answer and press Submit.', 'neutral');
                updateProgress();
            }

            function nextQuestion() {
                answered++;
                currentIndex++;
                if (currentIndex < totalCards) {
                    showQuestion();
                } else {
                    finishQuiz();
                }
            }

            function skipQuestion(reason, userAnswer) {
                incorrect++;
                const card = cards[order[currentIndex]];
                let statusMessage = reason || 'Skipped. Moving to the next card.';
                
                if (userAnswer !== undefined && userAnswer !== null) {
                    statusMessage = `Wrong! ✗<br><br><strong>Question:</strong> ${card.front}<br><strong>Your answer:</strong> ${userAnswer}<br><strong>Correct answer:</strong> ${card.back}`;
                } else if (reason && reason.includes('Incorrect')) {
                    // Already formatted with correct answer
                    statusMessage = reason;
                }
                
                setStatus(statusMessage, 'incorrect');
                // Play wrong sound effect
                wrongSound.currentTime = 0; // Reset to start
                wrongSound.play().catch(function(error) {
                    // Handle any audio play errors silently
                    console.log('Audio play failed:', error);
                });
                setLocked(true);
                setTimeout(function () {
                    setLocked(false);
                    nextQuestion();
                }, 3000); // Increased timeout to show question and answers
            }

            function checkAnswer() {
                if (!quizActive) return;
                const answer = els.answerInput.value.trim();
                if (!answer) {
                    setStatus('Please enter an answer or use Skip.', 'neutral');
                    return;
                }
                const card = cards[order[currentIndex]];
                const normalizedAnswer = answer.toLowerCase();
                const normalizedKey = String(card.back || '').trim().toLowerCase();

                if (normalizedAnswer === normalizedKey) {
                    correct++;
                    setStatus(`Correct! ✨<br><br><strong>Question:</strong> ${card.front}<br><strong>Your answer:</strong> ${answer}<br><strong>Correct answer:</strong> ${card.back}`, 'correct');
                    // Play correct sound effect
                    correctSound.currentTime = 0; // Reset to start
                    correctSound.play().catch(function(error) {
                        // Handle any audio play errors silently
                        console.log('Audio play failed:', error);
                    });
                    setLocked(true);
                    setTimeout(function () {
                        setLocked(false);
                        nextQuestion();
                    }, 3000); // Increased timeout to show question and answers
                } else {
                    skipQuestion(`Incorrect.`, answer);
                }
            }

            function finishQuiz() {
                quizActive = false;
                stopTimer();
                stopMusic();
                els.setupView.classList.add('hidden');
                els.questionView.classList.add('hidden');
                els.summaryView.classList.remove('hidden');

                const unanswered = totalCards - (correct + incorrect);
                els.summaryStats.innerHTML = `
                    <div class="pill chip-green">Correct: <strong>${correct}</strong></div>
                    <div class="pill chip-red">Incorrect / Skipped: <strong>${incorrect}</strong></div>
                    <div class="pill">Unanswered: <strong>${Math.max(unanswered, 0)}</strong></div>
                `;
            }

            function startQuiz() {
                const minutes = parseInt(els.timerMinutes.value, 10);
                if (Number.isNaN(minutes) || minutes <= 0) {
                    alert('Please enter a positive number of minutes.');
                    return;
                }

                quizActive = true;
                startMusic();
                answered = 0;
                correct = 0;
                incorrect = 0;
                currentIndex = 0;
                setStatus('', 'neutral');
                els.summaryView.classList.add('hidden');
                els.setupView.classList.add('hidden');
                els.questionView.classList.remove('hidden');
                els.answerInput.focus();
                updateProgress();
                shuffle(order);
                startTimer(minutes);
                showQuestion();
            }

            // Event bindings
            els.startBtn.addEventListener('click', startQuiz);
            els.shuffleBtn.addEventListener('click', function () {
                shuffle(order);
                setStatus('Cards shuffled. Start when ready.', 'neutral');
            });
            els.submitBtn.addEventListener('click', checkAnswer);
            els.skipBtn.addEventListener('click', function () {
                skipQuestion('Skipped. Keep pushing!');
            });
            els.revealBtn.addEventListener('click', function () {
                const card = cards[order[currentIndex]];
                const userAnswer = els.answerInput.value.trim() || 'No answer provided';
                setStatus(`Revealed Answer<br><br><strong>Question:</strong> ${card.front}<br><strong>Your answer:</strong> ${userAnswer}<br><strong>Correct answer:</strong> ${card.back}`, 'neutral');
                skipQuestion();
            });
            els.musicVolume.addEventListener('input', function (event) {
                const volume = parseFloat(event.target.value);
                bgMusic.volume = Math.min(1, Math.max(0, volume));
            });

            els.restartBtn.addEventListener('click', function () {
                order = cards.map((card, index) => index);
                shuffle(order);
                els.setupView.classList.remove('hidden');
                els.summaryView.classList.add('hidden');
                els.questionView.classList.add('hidden');
                els.timerDisplay.textContent = '00:00';
                stopTimer();
                stopMusic();
                setStatus('', 'neutral');
            });
            els.answerInput.addEventListener('keydown', function (e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    checkAnswer();
                }
            });
        })();
    </script>
</body>
</html>



<?php
// Test IMAP Extension
echo "<h2>IMAP Extension Test</h2>";

if (function_exists('imap_open')) {
    echo "<p style='color: green; font-weight: bold;'>✓ IMAP extension is ENABLED!</p>";
} else {
    echo "<p style='color: red; font-weight: bold;'>✗ IMAP extension is NOT enabled</p>";
    echo "<p>Please follow the instructions in ENABLE_IMAP_GUIDE.md</p>";
}

echo "<hr>";
echo "<h3>PHP Configuration Info:</h3>";
echo "<p>PHP Version: " . phpversion() . "</p>";
echo "<p>php.ini location: " . php_ini_loaded_file() . "</p>";

echo "<hr>";
echo "<h3>Loaded Extensions:</h3>";
$extensions = get_loaded_extensions();
if (in_array('imap', $extensions)) {
    echo "<p style='color: green;'>IMAP extension is loaded</p>";
} else {
    echo "<p style='color: red;'>IMAP extension is NOT loaded</p>";
}

echo "<hr>";
echo "<h3>Full PHP Info:</h3>";
phpinfo();
?>


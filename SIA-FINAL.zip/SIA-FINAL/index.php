<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bizmo – The easiest way to learn</title>
    <meta name="description" content="A.I. quizzes that make learning easy.">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #0b0b12; /* dark base */
            --text: #ffffff; /* light text */
            --muted: #a2a3ad; /* muted on dark */
            --accent: #dc2626; /* red-600 */
            --accent-700: #b91c1c; /* red-700 */
            --surface: #111118; /* panels */
            --border: rgba(255,255,255,0.08); /* subtle border on dark */
            --soft-red: rgba(220,38,38,0.15); /* red glow */
        }

        * { box-sizing: border-box; }
        html, body { height: 100%; }
        body {
            margin: 0;
            font-family: 'Inter', ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial;
            background:
                radial-gradient(70% 40% at 50% 90%, var(--soft-red), transparent 60%),
                linear-gradient(180deg, #0c0c14 0%, #0c0c14 55%, #120b12 100%);
            color: var(--text);
        }

        .container { max-width: 1180px; margin: 0 auto; padding: 0 20px; }

        /* Header */
        .header {
            position: sticky; top: 0; z-index: 30;
            backdrop-filter: saturate(140%) blur(8px);
            background: rgba(10,10,15,0.75);
            border-bottom: 1px solid var(--border);
        }
        .nav { display: flex; align-items: center; justify-content: space-between; padding: 16px 0; }
        .brand { display: inline-flex; align-items: center; gap: 10px; font-weight: 800; font-size: 18px; color: var(--text); }
        .logo {
            background: transparent; /* removed red background */
            box-shadow: none;
            border: 1px solid var(--border);
        }
        .logo svg, .logo img { width: 50px; height: 50px; display: block; }

        .links { display: flex; align-items: center; gap: 18px; }
        .link { color: var(--muted); text-decoration: none; font-weight: 600; }
        .link:hover { color: var(--text); }
        .cta { text-decoration: none; font-weight: 700; color: #fff; background: var(--accent); padding: 10px 14px; border-radius: 999px; border: 1px solid var(--accent-700); }
        .cta:hover { background: var(--accent-700); }

        /* Hero */
        .hero { padding: 72px 0 28px; text-align: center; }
        .eyebrow { display: inline-flex; align-items: center; gap: 8px; color: var(--muted); font-weight: 700; font-size: 12px; letter-spacing: 0.1em; text-transform: uppercase; }
        .hero h1 { font-size: clamp(40px, 7vw, 72px); line-height: 1.05; margin: 16px 0 12px; font-weight: 900; color: var(--text); }
        .lead { font-size: clamp(16px, 2.2vw, 22px); color: #c9cad1; max-width: 840px; margin: 0 auto; }
        .primary-btn {
            margin-top: 28px; display: inline-flex; align-items: center; gap: 10px; background: var(--accent);
            color: #fff; padding: 14px 22px; border-radius: 16px; font-weight: 800; text-decoration: none;
            box-shadow: 0 16px 32px rgba(220,38,38,0.45);
        }
        .primary-btn:hover { background: var(--accent-700); }

        /* Showcase Mockup */
        .showcase-wrap { position: relative; padding: 40px 0 90px; }
        .glass {
            margin: 0 auto; width: min(980px, 92%);
            background: rgba(255,255,255,0.03);
            border: 1px solid var(--border);
            border-radius: 22px; overflow: hidden;
            box-shadow: 0 40px 120px rgba(220,38,38,0.35);
        }
        .toolbar { display: flex; align-items: center; justify-content: space-between; padding: 12px 16px; background: rgba(14,14,20,0.75); border-bottom: 1px solid var(--border); }
        .toolbar .dots { display: inline-flex; gap: 6px; }
        .dot { width: 10px; height: 10px; border-radius: 999px; background: #7a2b2b; }
        .content { display: grid; grid-template-columns: 240px 1fr; gap: 18px; padding: 18px; }
        .sidebar { background: rgba(255,255,255,0.02); border: 1px solid var(--border); border-radius: 16px; padding: 14px; }
        .sidebar h4 { margin: 6px 0 10px; color: #c6c7d2; }
        .sidebar .item { display: block; width: 100%; padding: 10px 12px; border-radius: 10px; margin-bottom: 8px; background: #3a0f14; color: #ffd7d7; font-weight: 700; text-decoration: none; }
        .sidebar .item.secondary { background: #16161f; color: #bdbfd0; font-weight: 600; }
        .main { background: rgba(255,255,255,0.02); border: 1px solid var(--border); border-radius: 16px; padding: 16px; }
        .grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-top: 10px; }
        .deck { border-radius: 12px; padding: 12px; color: #ffffff; font-weight: 800; height: 84px; display: flex; align-items: end; justify-content: space-between; }
        .deck span { color: #ffffff; background: rgba(255,255,255,0.2); padding: 4px 8px; border-radius: 999px; font-size: 12px; font-weight: 900; border: 0; }
        .pink { background: #7f1d1d; }
        .orange { background: #9f1239; }
        .red { background: #b91c1c; }
        .blue { background: #991b1b; }
        .violet { background: #7c1d1d; }
        .green { background: #8a1c1c; }
        .yellow { background: #a11d1d; }
        .teal { background: #6b0f0f; }

        /* Footer */
        footer { padding: 36px 0 64px; color: var(--muted); text-align: center; }

        /* Responsive */
        @media (max-width: 980px) {
            .content { grid-template-columns: 1fr; }
            .grid { grid-template-columns: repeat(3, 1fr); }
        }
        @media (max-width: 720px) {
            .grid { grid-template-columns: repeat(2, 1fr); }
        }
        @media (max-width: 520px) {
            .grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="container nav">
            <div class="brand">
                <div class="logo" aria-label="Bizmo logo">
                    <img src="icons/bizmo.png" alt="" width="60" height="60" />
                </div>
                <span>Bizmo</span>
            </div>
            <div class="links">
                <a class="link" href="home.php">Home</a>
                <a class="link" href="login.php">Login</a>
                <a class="cta" href="login.php">Start learning</a>
            </div>
        </div>
    </header>

    <main>
        <section class="hero container">
            <h1>The easiest way to learn</h1>
            <p class="lead">Blended Interactive Zone for Modern Learning</p>
            <a class="primary-btn" href="login.php">Start learning</a>
        </section>

        <section id="showcase" class="showcase-wrap">
            <div class="glass">
                <div class="toolbar container">
                    <div class="dots"><span class="dot"></span><span class="dot"></span><span class="dot"></span></div>
                    <div style="height:10px"></div>
                </div>
                <div class="content">
                    <aside class="sidebar">
                        <h4>Library</h4>
                        <a href="#" class="item">My decks</a>
                        <a href="#" class="item secondary">Progress</a>
                        <a href="#" class="item secondary">Public decks</a>
                    </aside>
                    <section class="main">
                        <div style="display:flex; align-items:center; justify-content:space-between; gap:10px;">
                            <h3 style="margin:0; color:#dfe0e8">My decks</h3>
                            <a href="#" class="cta" style="background:#2b2541">Add deck</a>
                        </div>
                        <div class="grid">
                            <div class="deck pink">Psychology <span>30 cards</span></div>
                            <div class="deck orange">Biology <span>30 cards</span></div>
                            <div class="deck red">Chemistry <span>30 cards</span></div>
                            <div class="deck blue">Physics <span>30 cards</span></div>
                            <div class="deck violet">Geography <span>30 cards</span></div>
                            <div class="deck teal">English <span>30 cards</span></div>
                            <div class="deck yellow">Economics <span>30 cards</span></div>
                            <div class="deck green">Spanish <span>30 cards</span></div>
                        </div>
                    </section>
                </div>
            </div>
        </section>
    </main>

    <footer>
        <div class="container">© 2025 Bizmo. All rights reserved.</div>
    </footer>
</body>
</html>


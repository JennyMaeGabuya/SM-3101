<?php
session_start();
require_once 'config.php';

if (!function_exists('buildDeckIconSrc')) {
    function buildDeckIconSrc($iconValue) {
        if ($iconValue === null || $iconValue === '') {
            return '';
        }
        if (strpos($iconValue, 'data:') === 0) {
            return $iconValue;
        }
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = $finfo ? finfo_buffer($finfo, $iconValue) : null;
        if ($finfo) {
            finfo_close($finfo);
        }
        if (!$mime) {
            $mime = 'image/png';
        }
        return 'data:' . $mime . ';base64,' . base64_encode($iconValue);
    }
}

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$deck_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($deck_id <= 0) {
    header("Location: decks.php");
    exit();
}

// Load deck (ensure it belongs to user)
$stmt = $conn->prepare("SELECT id, user_id, title, description, color, icon FROM decks WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $deck_id, $user_id);
$stmt->execute();
$deck = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$deck) {
    header("Location: decks.php");
    exit();
}

$card_error = null;
$deck_update_error = null;
$card_update_error = null;
$card_update_success = null;

// Handle card creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_card'])) {
    $front = trim($_POST['front'] ?? '');
    $back = trim($_POST['back'] ?? '');

    if ($front === '' || $back === '') {
        $card_error = 'Both front and back are required.';
    } else {
        $stmt = $conn->prepare("INSERT INTO cards (deck_id, user_id, front, back) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiss", $deck_id, $user_id, $front, $back);
        if ($stmt->execute()) {
            header("Location: deck.php?id=" . $deck_id);
            exit();
        } else {
            $card_error = 'Failed to add card. Please try again.';
        }
        $stmt->close();
    }
}

// Handle card update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_card'])) {
    $card_id = isset($_POST['card_id']) ? (int)$_POST['card_id'] : 0;
    $front = trim($_POST['front'] ?? '');
    $back = trim($_POST['back'] ?? '');

    if ($card_id <= 0) {
        $card_update_error = 'Invalid card ID.';
    } elseif ($front === '' || $back === '') {
        $card_update_error = 'Both front and back are required.';
    } else {
        $stmt = $conn->prepare("UPDATE cards SET front = ?, back = ? WHERE id = ? AND deck_id = ? AND user_id = ?");
        $stmt->bind_param("ssiii", $front, $back, $card_id, $deck_id, $user_id);
        if ($stmt->execute()) {
            if ($stmt->affected_rows > 0) {
                header("Location: deck.php?id=" . $deck_id);
                exit();
            } else {
                $card_update_error = 'Card not found or you do not have permission to edit it.';
            }
        } else {
            $card_update_error = 'Failed to update card. Please try again.';
        }
        $stmt->close();
    }
}

// Handle card deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_card'])) {
    $card_id = isset($_POST['card_id']) ? (int)$_POST['card_id'] : 0;
    
    if ($card_id > 0) {
        $stmt = $conn->prepare("DELETE FROM cards WHERE id = ? AND deck_id = ? AND user_id = ?");
        $stmt->bind_param("iii", $card_id, $deck_id, $user_id);
        if ($stmt->execute()) {
            header("Location: deck.php?id=" . $deck_id);
            exit();
        }
        $stmt->close();
    }
}

// Handle deck update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_deck'])) {
    $new_title = trim($_POST['deck_title'] ?? '');
    $new_description = trim($_POST['deck_description'] ?? '');
    $new_color = trim($_POST['deck_color'] ?? '');
    $new_icon_data = $deck['icon'];

    if ($new_title === '') {
        $deck_update_error = 'Title is required.';
    } else {
        if (isset($_FILES['deck_icon']) && $_FILES['deck_icon']['error'] !== UPLOAD_ERR_NO_FILE) {
            if ($_FILES['deck_icon']['error'] === UPLOAD_ERR_OK) {
                $tmp_path = $_FILES['deck_icon']['tmp_name'];
                $file_size = (int)($_FILES['deck_icon']['size'] ?? 0);
                $max_icon_size = 512 * 1024;

                if ($file_size > $max_icon_size) {
                    $deck_update_error = 'Icon file must be 512KB or smaller.';
                } else {
                    $finfo = finfo_open(FILEINFO_MIME_TYPE);
                    $mime = $finfo ? finfo_file($finfo, $tmp_path) : null;
                    if ($finfo) {
                        finfo_close($finfo);
                    }

                    $allowed_mimes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml'];
                    if ($mime && in_array($mime, $allowed_mimes, true)) {
                        $icon_data = file_get_contents($tmp_path);
                        if ($icon_data !== false) {
                            $new_icon_data = $icon_data;
                        } else {
                            $deck_update_error = 'Failed to read uploaded icon. Please try again.';
                        }
                    } else {
                        $deck_update_error = 'Icon must be an image file (PNG, JPG, GIF, WEBP, SVG).';
                    }
                }
            } else {
                $deck_update_error = 'Icon upload encountered an error. Please try again.';
            }
        }

        if (empty($deck_update_error)) {
            $stmt = $conn->prepare("UPDATE decks SET title = ?, description = ?, color = ?, icon = ? WHERE id = ? AND user_id = ?");
            $icon_param = $new_icon_data;
            $stmt->bind_param("ssssii", $new_title, $new_description, $new_color, $icon_param, $deck_id, $user_id);
            if ($stmt->execute()) {
                $stmt->close();
                header("Location: deck.php?id=" . $deck_id);
                exit();
            } else {
                $deck_update_error = 'Failed to update deck. Please try again.';
                $stmt->close();
            }
        }
    }
}

// Fetch cards for this deck
$cards = [];
$stmt = $conn->prepare("SELECT id, front, back, created_at, updated_at FROM cards WHERE deck_id = ? AND user_id = ? ORDER BY id DESC");
$stmt->bind_param("ii", $deck_id, $user_id);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    $cards[] = $row;
}
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo htmlspecialchars($deck['title']); ?> – Deck</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #0b0b12;
            --text: #ffffff;
            --muted: #a2a3ad;
            --surface: #111118;
            --border: rgba(255,255,255,0.08);
        }
        * { box-sizing: border-box; }
        body { margin:0; font-family: 'Inter', ui-sans-serif, system-ui; background: #0c0c14; color: var(--text); }
        .container { max-width: 1100px; margin: 0 auto; padding: 24px; }
        .breadcrumb { margin-bottom: 20px; }
        .breadcrumb a {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: var(--muted);
            text-decoration: none;
            font-size: 14px;
            font-weight: 600;
            padding: 10px 16px;
            border-radius: 12px;
            background: rgba(255,255,255,0.03);
            border: 1px solid var(--border);
            transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .breadcrumb a:hover {
            color: var(--text);
            background: rgba(255,255,255,0.05);
            border-color: rgba(255,255,255,0.12);
            transform: translateX(-2px);
        }
        .header { display: flex; align-items: center; justify-content: space-between; margin: 8px 0 20px; }
        .title { display:flex; align-items:center; gap:12px; }
        .icon { width: 42px; height: 42px; border-radius: 12px; display:grid; place-items:center; box-shadow: 0 4px 12px rgba(0,0,0,0.3); overflow: hidden; }
        .icon img { width: 100%; height: 100%; object-fit: cover; display: block; }
        .panel { background: linear-gradient(135deg, rgba(255,255,255,0.05), rgba(255,255,255,0.02)); border:1px solid var(--border); border-radius:16px; padding:16px; }
        .grid { display:flex; flex-direction: column; gap: 24px; }
        .add-card-grid { display:grid; grid-template-columns: 1fr 1fr; gap: 16px; }
        .field { display:grid; gap:6px; }
        @media (max-width: 768px) {
            .add-card-grid { grid-template-columns: 1fr; }
        }
        .input, .textarea { width:100%; border:1px solid var(--border); border-radius:12px; background: rgba(10,10,15,0.9); color: var(--text); padding:12px 14px; }
        .textarea { min-height: 120px; resize: vertical; }
        .btn { border:1px solid var(--border); background:#1a1a22; color:#fff; padding:10px 16px; border-radius:12px; cursor:pointer; font-weight:600; }
        .btn:hover { border-color:#666; }
        .cards { display: flex; flex-direction: column; gap: 12px; margin-top: 16px; }
        .card-item {
            background: linear-gradient(135deg, rgba(255,255,255,0.05), rgba(255,255,255,0.02));
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 20px;
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 16px;
            transition: all 0.2s ease;
        }
        .card-item:hover {
            background: linear-gradient(135deg, rgba(255,255,255,0.08), rgba(255,255,255,0.04));
            border-color: rgba(255,255,255,0.12);
            transform: translateY(-2px);
        }
        .card-content {
            flex: 1;
            min-width: 0;
        }
        .card-title {
            font-weight: 700;
            font-size: 16px;
            margin: 0 0 8px;
            color: var(--text);
            line-height: 1.4;
        }
        .card-description {
            color: var(--muted);
            font-size: 14px;
            line-height: 1.6;
            margin: 0;
            white-space: pre-wrap;
        }
        .card-menu {
            position: relative;
            flex-shrink: 0;
        }
        .card-menu-btn {
            background: transparent;
            border: none;
            cursor: pointer;
            padding: 8px;
            border-radius: 8px;
            color: var(--muted);
            font-size: 18px;
            line-height: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s ease;
        }
        .card-menu-btn:hover {
            background: rgba(255,255,255,0.05);
            color: var(--text);
        }
        .card-menu-dropdown {
            position: absolute;
            top: 100%;
            right: 0;
            margin-top: 8px;
            background: rgba(10,10,15,0.98);
            border: 1px solid var(--border);
            border-radius: 8px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.4);
            min-width: 160px;
            z-index: 100;
            display: none;
            overflow: hidden;
        }
        .card-menu-dropdown.show {
            display: block;
        }
        .card-menu-item {
            display: block;
            width: 100%;
            padding: 10px 16px;
            text-align: left;
            background: transparent;
            border: none;
            color: var(--text);
            font-size: 14px;
            cursor: pointer;
            transition: background 0.2s ease;
        }
        .card-menu-item:hover {
            background: rgba(255,255,255,0.05);
        }
        .card-menu-item.delete {
            color: #fecaca;
        }
        .card-menu-item.delete:hover {
            background: rgba(239,68,68,0.1);
        }
        .link { background: transparent; color: var(--muted); border: 1px solid var(--border); padding: 6px 10px; border-radius: 10px; cursor: pointer; font-size: 12px; }
        .link:hover { color:#fff; border-color:#666; }
        .link-danger { color: #fecaca; border-color: rgba(239,68,68,0.3); }
        .link-danger:hover { color: #fee2e2; border-color: rgba(239,68,68,0.5); background: rgba(239,68,68,0.1); }
        .link-edit { color: #bfdbfe; border-color: rgba(59,130,246,0.3); }
        .link-edit:hover { color: #dbeafe; border-color: rgba(59,130,246,0.5); background: rgba(59,130,246,0.1); }
        .error { color: #fecaca; background: rgba(239,68,68,0.06); border:1px solid rgba(239,68,68,0.25); padding:10px 12px; border-radius:10px; margin-bottom:10px; }
        .success { color: #bbf7d0; background: rgba(34,197,94,0.06); border:1px solid rgba(34,197,94,0.25); padding:10px 12px; border-radius:10px; margin-bottom:10px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="breadcrumb"><a href="decks.php">← Back to My Decks</a></div>
        <div class="header">
            <div class="title">
                <?php
                    $deck_icon_src = buildDeckIconSrc($deck['icon'] ?? null);
                    $deck_icon_fallback = mb_strtoupper(mb_substr($deck['title'], 0, 1));
                ?>
                <div class="icon" style="background: <?php echo htmlspecialchars($deck['color'] ?: 'rgba(255,255,255,0.1)'); ?>;">
                    <?php if ($deck_icon_src !== ''): ?>
                        <img src="<?php echo htmlspecialchars($deck_icon_src, ENT_QUOTES); ?>" alt="Deck icon" />
                    <?php else: ?>
                        <span style="font-weight:800;"><?php echo htmlspecialchars($deck_icon_fallback); ?></span>
                    <?php endif; ?>
                </div>
                <div>
                    <h1 style="margin:0 0 4px; font-size: 22px;"><?php echo htmlspecialchars($deck['title']); ?></h1>
                    <?php if (!empty($deck['description'])): ?>
                        <div style="color: var(--muted); font-size: 13px;"><?php echo htmlspecialchars($deck['description']); ?></div>
                    <?php endif; ?>
                </div>
            </div>
            <div>
                <div style="display:flex; gap:10px; align-items:center;">
                    <?php if (!empty($cards)): ?>
                        <a href="quiz.php?id=<?php echo (int)$deck['id']; ?>" class="btn">Start Quiz</a>
                    <?php endif; ?>
                    <button type="button" id="openEditDeck" class="btn">Edit</button>
                    <a href="decks.php" class="btn" style="background: rgba(255,255,255,0.04);">My Decks</a>
                </div>
            </div>
        </div>

        <div class="grid">
            <div class="panel">
                <h3 style="margin:0 0 12px;">Add Card</h3>
                <?php if (!empty($card_error)): ?>
                    <div class="error"><?php echo htmlspecialchars($card_error); ?></div>
                <?php endif; ?>
                <form method="post" autocomplete="off" enctype="multipart/form-data">
                    <input type="hidden" name="create_card" value="1" />
                    <div class="add-card-grid">
                        <div class="field">
                            <label for="front" style="color:var(--muted); font-size:13px;">Front (Question)</label>
                            <textarea id="front" name="front" class="textarea" placeholder="Question, term, or prompt..."></textarea>
                        </div>
                        <div class="field">
                            <label for="back" style="color:var(--muted); font-size:13px;">Back (Answer)</label>
                            <textarea id="back" name="back" class="textarea" placeholder="Answer, definition, or explanation..."></textarea>
                        </div>
                    </div>
                    <div style="display:flex; justify-content:flex-end; gap:10px; margin-top:12px;">
                        <button type="submit" class="btn">Add Card</button>
                    </div>
                </form>
            </div>

            <div class="panel">
                <h3 style="margin:0 0 12px;">Cards (<?php echo count($cards); ?>)</h3>
                <?php if (!empty($cards)): ?>
                    <div class="cards" id="cardsList">
                        <?php foreach ($cards as $c): ?>
                            <div class="card-item" data-card-id="<?php echo (int)$c['id']; ?>">
                                <div class="card-content">
                                    <div class="card-title" style="color: <?php echo htmlspecialchars($deck['color'] ?: '#ffffff'); ?>;"><?php echo htmlspecialchars($c['front']); ?></div>
                                    <p class="card-description"><?php echo htmlspecialchars($c['back']); ?></p>
                                </div>
                                <div class="card-menu">
                                    <button class="card-menu-btn" type="button" data-menu-id="menu-<?php echo (int)$c['id']; ?>">⋮</button>
                                    <div class="card-menu-dropdown" id="menu-<?php echo (int)$c['id']; ?>">
                                        <button class="card-menu-item edit-card-btn" type="button" data-card-id="<?php echo (int)$c['id']; ?>" data-front="<?php echo htmlspecialchars($c['front'], ENT_QUOTES); ?>" data-back="<?php echo htmlspecialchars($c['back'], ENT_QUOTES); ?>">Edit</button>
                                        <button class="card-menu-item delete delete-card-btn" type="button" data-card-id="<?php echo (int)$c['id']; ?>">Delete</button>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div style="color:var(--muted); text-align:center; padding:40px 20px;">No cards yet. Add your first card above.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        // Card menu dropdown functionality
        (function () {
            var cardsList = document.getElementById('cardsList');
            if (!cardsList) return;

            // Close all dropdowns when clicking outside
            document.addEventListener('click', function(e) {
                if (!e.target.closest('.card-menu')) {
                    var dropdowns = document.querySelectorAll('.card-menu-dropdown');
                    dropdowns.forEach(function(dropdown) {
                        dropdown.classList.remove('show');
                    });
                }
            });

            // Toggle dropdown on menu button click
            cardsList.addEventListener('click', function(e) {
                var menuBtn = e.target.closest('.card-menu-btn');
                if (menuBtn) {
                    e.stopPropagation();
                    var menuId = menuBtn.getAttribute('data-menu-id');
                    var dropdown = document.getElementById(menuId);
                    if (dropdown) {
                        // Close all other dropdowns
                        var allDropdowns = document.querySelectorAll('.card-menu-dropdown');
                        allDropdowns.forEach(function(d) {
                            if (d !== dropdown) {
                                d.classList.remove('show');
                            }
                        });
                        // Toggle current dropdown
                        dropdown.classList.toggle('show');
                    }
                }
            });
        })();

        // Edit Deck modal
        (function () {
            var openBtn = document.getElementById('openEditDeck');
            if (!openBtn) return;

            var overlay = document.createElement('div');
            overlay.id = 'editDeckOverlay';
            overlay.style.position = 'fixed';
            overlay.style.inset = '0';
            overlay.style.background = 'rgba(0,0,0,0.6)';
            overlay.style.backdropFilter = 'blur(2px)';
            overlay.style.display = 'none';
            overlay.style.alignItems = 'center';
            overlay.style.justifyContent = 'center';
            overlay.style.zIndex = '10000';

            var modal = document.createElement('div');
            modal.style.background = 'rgba(10,10,15,0.98)';
            modal.style.border = '1px solid rgba(255,255,255,0.08)';
            modal.style.borderRadius = '16px';
            modal.style.padding = '20px';
            modal.style.width = 'min(520px, 92vw)';
            modal.style.boxShadow = '0 12px 40px rgba(0,0,0,0.5)';

            modal.innerHTML = `
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
                    <h3 style="margin:0;font-size:20px;font-weight:800;">Edit Deck</h3>
                    <button type="button" id="closeEditDeck" style="background:transparent;border:1px solid rgba(255,255,255,0.08);color:#fff;border-radius:10px;padding:6px 10px;cursor:pointer;">✕</button>
                </div>
                <?php if (!empty($deck_update_error)): ?>
                    <div style="margin: 10px 0 14px; color: #fecaca; background: rgba(239, 68, 68, 0.08); border: 1px solid rgba(239, 68, 68, 0.25); padding: 10px 12px; border-radius: 10px;"><?php echo htmlspecialchars($deck_update_error); ?></div>
                <?php endif; ?>
                <form method="post" autocomplete="off" enctype="multipart/form-data">
                    <input type="hidden" name="update_deck" value="1" />
                    <div style="display:grid;gap:12px;">
                        <div>
                            <label for="deck_title" style="display:block;font-size:13px;color:#a2a3ad;margin-bottom:6px;">Title</label>
                            <input required id="deck_title" name="deck_title" type="text" value="<?php echo htmlspecialchars($deck['title']); ?>" style="width:100%;padding:12px 14px;border-radius:12px;border:1px solid rgba(255,255,255,0.08);background:rgba(10,10,15,0.9);color:#fff;" />
                        </div>
                        <div>
                            <label for="deck_description" style="display:block;font-size:13px;color:#a2a3ad;margin-bottom:6px;">Description</label>
                            <textarea id="deck_description" name="deck_description" rows="3" style="width:100%;padding:12px 14px;border-radius:12px;border:1px solid rgba(255,255,255,0.08);background:rgba(10,10,15,0.9);color:#fff;"><?php echo htmlspecialchars($deck['description']); ?></textarea>
                        </div>
                        <div style="display:grid;grid-template-columns:1fr;gap:12px;">
                            <div>
                                <label for="deck_color" style="display:block;font-size:13px;color:#a2a3ad;margin-bottom:6px;">Color</label>
                                <input id="deck_color" name="deck_color" type="text" value="<?php echo htmlspecialchars($deck['color']); ?>" placeholder="#8b5cf6 or rgba(...)" style="width:100%;padding:12px 14px;border-radius:12px;border:1px solid rgba(255,255,255,0.08);background:rgba(10,10,15,0.9);color:#fff;" />
                            </div>
                            <div>
                                <label for="deck_icon" style="display:block;font-size:13px;color:#a2a3ad;margin-bottom:6px;">Icon Image</label>
                                <input id="deck_icon" name="deck_icon" type="file" accept="image/*" style="width:100%;padding:10px 0;border-radius:12px;border:1px dashed rgba(255,255,255,0.08);background:rgba(10,10,15,0.9);color:#fff;" />
                                <div style="font-size:12px;color:#6b7280;margin-top:4px;">Upload a square image, PNG/JPG/GIF/WEBP/SVG.</div>
                                <?php $current_icon_preview = buildDeckIconSrc($deck['icon'] ?? null); ?>
                                <?php if ($current_icon_preview !== ''): ?>
                                    <div style="margin-top:8px; display:flex; align-items:center; gap:10px;">
                                        <div style="width:42px;height:42px;border-radius:12px;overflow:hidden;border:1px solid rgba(255,255,255,0.08);">
                                            <img src="<?php echo htmlspecialchars($current_icon_preview, ENT_QUOTES); ?>" alt="Current deck icon" style="width:100%;height:100%;object-fit:cover;display:block;" />
                                        </div>
                                        <span style="font-size:12px;color:#9ca3af;">Current icon preview</span>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:6px;">
                            <button type="button" id="cancelEditDeck" class="btn" style="background:rgba(255,255,255,0.04);padding:10px 16px;">Cancel</button>
                            <button type="submit" class="btn" style="padding:10px 16px;">Save</button>
                        </div>
                    </div>
                </form>
            `;

            overlay.appendChild(modal);
            document.body.appendChild(overlay);

            function openModal() { overlay.style.display = 'flex'; }
            function closeModal() { overlay.style.display = 'none'; }

            openBtn.addEventListener('click', openModal);
            overlay.addEventListener('click', function (e) {
                if (e.target === overlay) closeModal();
            });
            modal.querySelector('#closeEditDeck').addEventListener('click', closeModal);
            modal.querySelector('#cancelEditDeck').addEventListener('click', closeModal);
        })();

        // Edit Card modal
        (function () {
            var editCardOverlay = document.createElement('div');
            editCardOverlay.id = 'editCardOverlay';
            editCardOverlay.style.position = 'fixed';
            editCardOverlay.style.inset = '0';
            editCardOverlay.style.background = 'rgba(0,0,0,0.6)';
            editCardOverlay.style.backdropFilter = 'blur(2px)';
            editCardOverlay.style.display = 'none';
            editCardOverlay.style.alignItems = 'center';
            editCardOverlay.style.justifyContent = 'center';
            editCardOverlay.style.zIndex = '10000';

            var editCardModal = document.createElement('div');
            editCardModal.style.background = 'rgba(10,10,15,0.98)';
            editCardModal.style.border = '1px solid rgba(255,255,255,0.08)';
            editCardModal.style.borderRadius = '16px';
            editCardModal.style.padding = '20px';
            editCardModal.style.width = 'min(520px, 92vw)';
            editCardModal.style.boxShadow = '0 12px 40px rgba(0,0,0,0.5)';

            var errorHtml = '';
            <?php if (!empty($card_update_error)): ?>
            errorHtml = '<div id="editCardError" style="display:block; margin: 10px 0 14px; color: #fecaca; background: rgba(239, 68, 68, 0.08); border: 1px solid rgba(239, 68, 68, 0.25); padding: 10px 12px; border-radius: 10px;"><?php echo htmlspecialchars($card_update_error, ENT_QUOTES); ?></div>';
            <?php else: ?>
            errorHtml = '<div id="editCardError" style="display:none; margin: 10px 0 14px; color: #fecaca; background: rgba(239, 68, 68, 0.08); border: 1px solid rgba(239, 68, 68, 0.25); padding: 10px 12px; border-radius: 10px;"></div>';
            <?php endif; ?>

            editCardModal.innerHTML = `
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
                    <h3 style="margin:0;font-size:20px;font-weight:800;">Edit Card</h3>
                    <button type="button" id="closeEditCard" style="background:transparent;border:1px solid rgba(255,255,255,0.08);color:#fff;border-radius:10px;padding:6px 10px;cursor:pointer;">✕</button>
                </div>
                ${errorHtml}
                <form id="editCardForm" method="post" autocomplete="off">
                    <input type="hidden" name="update_card" value="1" />
                    <input type="hidden" id="editCardId" name="card_id" value="" />
                    <div style="display:grid;gap:12px;">
                        <div>
                            <label for="editFront" style="display:block;font-size:13px;color:#a2a3ad;margin-bottom:6px;">Front (Question)</label>
                            <textarea required id="editFront" name="front" rows="4" style="width:100%;padding:12px 14px;border-radius:12px;border:1px solid rgba(255,255,255,0.08);background:rgba(10,10,15,0.9);color:#fff;resize:vertical;"></textarea>
                        </div>
                        <div>
                            <label for="editBack" style="display:block;font-size:13px;color:#a2a3ad;margin-bottom:6px;">Back (Answer)</label>
                            <textarea required id="editBack" name="back" rows="4" style="width:100%;padding:12px 14px;border-radius:12px;border:1px solid rgba(255,255,255,0.08);background:rgba(10,10,15,0.9);color:#fff;resize:vertical;"></textarea>
                        </div>
                        <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:6px;">
                            <button type="button" id="cancelEditCard" class="btn" style="background:rgba(255,255,255,0.04);padding:10px 16px;">Cancel</button>
                            <button type="submit" class="btn" style="padding:10px 16px;">Save Changes</button>
                        </div>
                    </div>
                </form>
            `;

            editCardOverlay.appendChild(editCardModal);
            document.body.appendChild(editCardOverlay);

            function openEditCardModal(cardId, front, back) {
                document.getElementById('editCardId').value = cardId;
                document.getElementById('editFront').value = front;
                document.getElementById('editBack').value = back;
                var errorDiv = document.getElementById('editCardError');
                if (errorDiv) {
                    errorDiv.style.display = 'none';
                    errorDiv.textContent = '';
                }
                editCardOverlay.style.display = 'flex';
            }
            
            // Auto-open modal if there's an error (form was submitted with error)
            <?php if (!empty($card_update_error) && isset($_POST['card_id'])): ?>
            window.addEventListener('DOMContentLoaded', function() {
                var cardId = <?php echo (int)$_POST['card_id']; ?>;
                var front = <?php echo json_encode($_POST['front'] ?? ''); ?>;
                var back = <?php echo json_encode($_POST['back'] ?? ''); ?>;
                openEditCardModal(cardId, front, back);
            });
            <?php endif; ?>

            function closeEditCardModal() {
                editCardOverlay.style.display = 'none';
            }

            // Handle edit button clicks
            document.addEventListener('click', function(e) {
                var editBtn = e.target.closest('.edit-card-btn');
                if (editBtn) {
                    e.stopPropagation();
                    var cardId = editBtn.getAttribute('data-card-id');
                    var front = editBtn.getAttribute('data-front');
                    var back = editBtn.getAttribute('data-back');
                    openEditCardModal(cardId, front, back);
                }
            });

            editCardOverlay.addEventListener('click', function (e) {
                if (e.target === editCardOverlay) closeEditCardModal();
            });
            document.getElementById('closeEditCard').addEventListener('click', closeEditCardModal);
            document.getElementById('cancelEditCard').addEventListener('click', closeEditCardModal);
        })();

        // Delete Card confirmation
        (function () {
            document.addEventListener('click', function(e) {
                var deleteBtn = e.target.closest('.delete-card-btn');
                if (deleteBtn) {
                    e.stopPropagation();
                    var cardId = deleteBtn.getAttribute('data-card-id');
                    if (confirm('Are you sure you want to delete this card? This action cannot be undone.')) {
                        var form = document.createElement('form');
                        form.method = 'POST';
                        form.style.display = 'none';
                        
                        var input1 = document.createElement('input');
                        input1.type = 'hidden';
                        input1.name = 'delete_card';
                        input1.value = '1';
                        form.appendChild(input1);
                        
                        var input2 = document.createElement('input');
                        input2.type = 'hidden';
                        input2.name = 'card_id';
                        input2.value = cardId;
                        form.appendChild(input2);
                        
                        document.body.appendChild(form);
                        form.submit();
                    }
                }
            });
        })();
    </script>
</body>
</html>



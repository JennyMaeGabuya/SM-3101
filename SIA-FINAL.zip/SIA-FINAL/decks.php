<?php
session_start();
require_once 'config.php';

if (!function_exists('buildDeckIconSrc')) {
    function buildDeckIconSrc($iconValue) {
        if ($iconValue === null || $iconValue === '') {
            return '';
        }
        if (strpos($iconValue, 'data:') === 0) {
            return $iconValue;
        }
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = $finfo ? finfo_buffer($finfo, $iconValue) : null;
        if ($finfo) {
            finfo_close($finfo);
        }
        if (!$mime) {
            $mime = 'image/png';
        }
        return 'data:' . $mime . ';base64,' . base64_encode($iconValue);
    }
}

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'] ?? 'Learner';
$user_email = $_SESSION['user_email'] ?? '';

$upload_dir = 'uploads/profiles/';
$profile_picture_path = null;

$stmt = $conn->prepare("SELECT profile_picture FROM profiles WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    $profile_filename = $row['profile_picture'] ?? null;
    if (!empty($profile_filename)) {
        $candidate_path = $upload_dir . $profile_filename;
        $filesystem_path = __DIR__ . '/' . $candidate_path;
        if (file_exists($filesystem_path)) {
            $profile_picture_path = $candidate_path;
        }
    }
}
$stmt->close();

$user_theme_color = '#dc2626';
$stmt = $conn->prepare("SELECT theme_color FROM themes WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    $user_theme_color = $row['theme_color'];
}
$stmt->close();

function hexToRgb($hex) {
    $hex = str_replace('#', '', $hex);
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    return [$r, $g, $b];
}

function darkenColor($hex, $percent = 20) {
    $rgb = hexToRgb($hex);
    $r = max(0, min(255, $rgb[0] - ($rgb[0] * $percent / 100)));
    $g = max(0, min(255, $rgb[1] - ($rgb[1] * $percent / 100)));
    $b = max(0, min(255, $rgb[2] - ($rgb[2] * $percent / 100)));
    return sprintf("#%02x%02x%02x", round($r), round($g), round($b));
}

$theme_rgb = hexToRgb($user_theme_color);
$theme_rgba_15 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.15)";
$theme_rgba_10 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.1)";
$theme_rgba_05 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.05)";
$theme_rgba_20 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.2)";
$theme_rgba_25 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.25)";
$theme_rgba_30 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.3)";
$theme_darker = darkenColor($user_theme_color, 15);

function getInitials($name) {
    $words = explode(' ', trim($name));
    if (count($words) >= 2) {
        return strtoupper(substr($words[0], 0, 1) . substr($words[count($words) - 1], 0, 1));
    }
    return strtoupper(substr($name, 0, 2));
}
$user_initials = getInitials($user_name);

// Deck management
$deck_error = null;
$deck_delete_error = null;
$deck_delete_success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_deck'])) {
    $delete_deck_id = isset($_POST['deck_id']) ? (int)$_POST['deck_id'] : 0;

    if ($delete_deck_id <= 0) {
        $deck_delete_error = 'Invalid deck selected.';
    } else {
        $stmt = $conn->prepare("SELECT id FROM decks WHERE id = ? AND user_id = ?");
        $stmt->bind_param("ii", $delete_deck_id, $user_id);
        $stmt->execute();
        $deck_exists = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$deck_exists) {
            $deck_delete_error = 'Deck not found or you do not have permission to delete it.';
        } else {
            $conn->begin_transaction();
            try {
                $stmt = $conn->prepare("DELETE FROM cards WHERE deck_id = ? AND user_id = ?");
                $stmt->bind_param("ii", $delete_deck_id, $user_id);
                $stmt->execute();
                $stmt->close();

                $stmt = $conn->prepare("DELETE FROM decks WHERE id = ? AND user_id = ?");
                $stmt->bind_param("ii", $delete_deck_id, $user_id);
                $stmt->execute();
                $stmt->close();

                $conn->commit();
                $deck_delete_success = 'Deck deleted successfully.';
                header("Location: " . strtok($_SERVER['REQUEST_URI'], '?'));
                exit();
            } catch (Exception $e) {
                $conn->rollback();
                $deck_delete_error = 'Failed to delete deck. Please try again.';
            }
        }
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_deck'])) {
    $title = trim($_POST['deck_title'] ?? '');
    $description = trim($_POST['deck_description'] ?? '');
    $color = trim($_POST['deck_color'] ?? '');
    $icon = null;

    if ($title === '') {
        $deck_error = 'Title is required.';
    } else {
        $stmt = $conn->prepare("INSERT INTO decks (user_id, title, description, color, icon) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("issss", $user_id, $title, $description, $color, $icon);
        if ($stmt->execute()) {
            header("Location: " . strtok($_SERVER['REQUEST_URI'], '?'));
            exit();
        } else {
            $deck_error = 'Failed to create deck. Please try again.';
        }
        $stmt->close();
    }
}

$user_decks = [];
$stmt = $conn->prepare("SELECT d.id, d.title, d.description, d.color, d.icon, d.updated_at,
                               COUNT(c.id) as card_count,
                               sender.full_name AS shared_by_name
                        FROM decks d 
                        LEFT JOIN cards c ON d.id = c.deck_id AND c.user_id = d.user_id 
                        LEFT JOIN deck_shares ds ON ds.recipient_deck_id = d.id AND ds.status = 'accepted'
                        LEFT JOIN users sender ON sender.id = ds.sender_id
                        WHERE d.user_id = ? 
                        GROUP BY d.id, d.title, d.description, d.color, d.icon, d.updated_at, sender.full_name 
                        ORDER BY d.updated_at DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $user_decks[] = $row;
}
$stmt->close();

// Handle notification dismissal
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['dismiss_notification'])) {
    $notif_id = $_POST['notif_id'] ?? '';
    if (!empty($notif_id)) {
        if (!isset($_SESSION['dismissed_notifications'])) {
            $_SESSION['dismissed_notifications'] = [];
        }
        if (!in_array($notif_id, $_SESSION['dismissed_notifications'])) {
            $_SESSION['dismissed_notifications'][] = $notif_id;
        }
        
        if (isset($_POST['ajax'])) {
            // Explicitly save session before sending AJAX response
            session_write_close();
            header('Content-Type: application/json');
            echo json_encode(['success' => true]);
            exit();
        }
        header("Location: " . strtok($_SERVER['REQUEST_URI'], '?'));
        exit();
    }
}

// Notification system
$notifications = [];
$dismissed_notifications = $_SESSION['dismissed_notifications'] ?? [];

function formatRelativeTime(?string $datetime): string {
    if (empty($datetime)) {
        return '';
    }
    try {
        $time = new DateTime($datetime);
    } catch (Exception $e) {
        return '';
    }
    $now = new DateTime();
    $diff = $now->getTimestamp() - $time->getTimestamp();

    if ($diff < 60) {
        return $diff <= 1 ? 'just now' : $diff . 's ago';
    }
    if ($diff < 3600) {
        $mins = floor($diff / 60);
        return $mins . 'm ago';
    }
    if ($diff < 86400) {
        $hours = floor($diff / 3600);
        return $hours . 'h ago';
    }
    if ($diff < 604800) {
        $days = floor($diff / 86400);
        return $days . 'd ago';
    }
    return $time->format('M j');
}

function tableExists(mysqli $conn, $table) {
    $table = $conn->real_escape_string($table);
    $res = $conn->query("SHOW TABLES LIKE '{$table}'");
    return $res && $res->num_rows > 0;
}

// 1. Friend requests
if (tableExists($conn, 'friends')) {
    $stmt = $conn->prepare("
        SELECT f.created_at, u.full_name
        FROM friends f
        INNER JOIN users u ON f.user_id = u.id
        WHERE f.friend_id = ? AND f.status = 'pending'
        ORDER BY f.created_at DESC
        LIMIT 5
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $name = $row['full_name'] ?? 'Someone';
        $notif_id = 'friend_request_' . md5($row['created_at'] . $name);
        if (!in_array($notif_id, $dismissed_notifications)) {
            $notifications[] = [
                'id' => $notif_id,
                'title' => 'Friend request',
                'message' => "{$name} wants to connect with you.",
                'time' => formatRelativeTime($row['created_at'] ?? null),
                'icon' => '👥',
                'timestamp' => $row['created_at'] ?? date('Y-m-d H:i:s'),
                'type' => 'friend_request',
                'url' => 'friends.php'
            ];
        }
    }
    $stmt->close();
}

// 2. Deck shares received
if (tableExists($conn, 'deck_shares')) {
    $stmt = $conn->prepare("
        SELECT ds.id, ds.created_at, ds.message, d.title, u.full_name AS sender_name
        FROM deck_shares ds
        INNER JOIN decks d ON ds.deck_id = d.id
        INNER JOIN users u ON ds.sender_id = u.id
        WHERE ds.recipient_id = ? AND ds.status = 'pending'
        ORDER BY ds.created_at DESC
        LIMIT 5
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $sender = $row['sender_name'] ?? 'Someone';
        $deckTitle = $row['title'] ?? 'a deck';
        $share_id = $row['id'] ?? 0;
        $notif_id = 'deck_share_' . $share_id;
        if (!in_array($notif_id, $dismissed_notifications)) {
            $notifications[] = [
                'id' => $notif_id,
                'title' => 'Deck shared with you',
                'message' => "{$sender} shared \"{$deckTitle}\" with you.",
                'time' => formatRelativeTime($row['created_at'] ?? null),
                'icon' => '📤',
                'timestamp' => $row['created_at'] ?? date('Y-m-d H:i:s'),
                'type' => 'deck_share',
                'url' => 'friends.php'
            ];
        }
    }
    $stmt->close();
}

usort($notifications, function ($a, $b) {
    return strtotime($b['timestamp']) <=> strtotime($a['timestamp']);
});
$notifications = array_slice($notifications, 0, 10);
$has_notifications = !empty($notifications);

// Handle clear all notifications (after notifications are built)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['clear_all_notifications'])) {
    $all_notif_ids = array_column($notifications, 'id');
    if (!isset($_SESSION['dismissed_notifications'])) {
        $_SESSION['dismissed_notifications'] = [];
    }
    foreach ($all_notif_ids as $notif_id) {
        if (!empty($notif_id) && !in_array($notif_id, $_SESSION['dismissed_notifications'])) {
            $_SESSION['dismissed_notifications'][] = $notif_id;
        }
    }
    if (isset($_POST['ajax'])) {
        session_write_close();
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'count' => count($all_notif_ids)]);
        exit();
    }
    header("Location: " . strtok($_SERVER['REQUEST_URI'], '?'));
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bizmo – My Decks</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #0b0b12;
            --text: #ffffff;
            --muted: #a2a3ad;
            --accent: <?php echo $user_theme_color; ?>;
            --accent-700: <?php echo $theme_darker; ?>;
            --surface: #111118;
            --border: rgba(255,255,255,0.08);
            --soft-accent: <?php echo $theme_rgba_15; ?>;
        }
        * { box-sizing: border-box; }
        html, body { height: 100%; }
        body {
            margin: 0;
            font-family: 'Inter', ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial;
            background: linear-gradient(180deg, #0c0c14 0%, #0c0c14 55%, #0c0c14 100%);
            color: var(--text);
        }
        .header {
            position: sticky; top: 0; z-index: 30;
            backdrop-filter: saturate(180%) blur(20px);
            background: rgba(10,10,15,0.8);
            border-bottom: 1px solid var(--border);
            box-shadow: 0 4px 24px rgba(0,0,0,0.2);
        }
        .header-content {
            max-width: 1400px; margin: 0 auto; padding: 0 24px;
            display: flex; align-items: center; justify-content: space-between;
            padding-top: 18px; padding-bottom: 18px;
        }
        .brand {
            display: inline-flex; align-items: center; gap: 12px;
            font-weight: 800; font-size: 18px; color: var(--text);
            text-decoration: none; transition: transform .2s ease;
        }
        .brand:hover { transform: scale(1.02); }
        .logo {
            background: linear-gradient(135deg, <?php echo $theme_rgba_10; ?>, <?php echo $theme_rgba_05; ?>);
            box-shadow: 0 4px 12px <?php echo $theme_rgba_15; ?>;
            border: 1px solid <?php echo $theme_rgba_20; ?>;
            width: 50px; height: 50px; border-radius: 12px;
            display: grid; place-items: center;
            transition: all .3s ease;
        }
        .logo:hover { transform: rotate(5deg) scale(1.05); }
        .logo img { width: 50px; height: 50px; display: block; }
        .header-right { display: flex; align-items: center; gap: 12px; position: relative; }
        .notif-btn {
            width: 44px; height: 44px; border-radius: 12px;
            background: rgba(255,255,255,0.04);
            border: 1px solid var(--border);
            display: grid; place-items: center; cursor: pointer;
            color: var(--text); transition: all .25s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
        }
        .notif-btn:hover {
            background: rgba(255,255,255,0.08);
            border-color: var(--accent);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px <?php echo $theme_rgba_20; ?>;
        }
        .notif-btn::after {
            content: ''; position: absolute; top: 8px; right: 8px;
            width: 8px; height: 8px; border-radius: 50%;
            background: var(--accent); box-shadow: 0 0 8px var(--accent);
            opacity: 0;
            transform: scale(0.4);
            transition: opacity 0.2s ease, transform 0.2s ease;
        }
        .notif-btn.has-alert::after {
            opacity: 1;
            transform: scale(1);
        }
        .notif-dropdown {
            position: absolute;
            top: calc(100% + 12px);
            right: 0;
            width: min(360px, 90vw);
            max-height: 500px;
            background: rgba(10,10,15,0.98);
            backdrop-filter: blur(20px);
            border: 1px solid var(--border);
            border-radius: 16px;
            box-shadow: 0 16px 40px rgba(0,0,0,0.45);
            padding: 0;
            display: none;
            z-index: 1000;
            overflow: hidden;
        }
        .notif-dropdown.show { display: block; }
        .notif-dropdown h4 {
            margin: 0;
            padding: 16px 16px 12px;
            font-size: 16px;
            font-weight: 700;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .notif-clear-all {
            font-size: 13px;
            font-weight: 600;
            color: var(--muted);
            background: none;
            border: none;
            cursor: pointer;
            padding: 4px 8px;
            border-radius: 6px;
            transition: all 0.2s ease;
            text-decoration: none;
            display: inline-block;
        }
        .notif-clear-all:hover {
            color: var(--text);
            background: rgba(255,255,255,0.05);
        }
        .notif-clear-all:active {
            transform: scale(0.95);
        }
        .notif-list {
            display: flex;
            flex-direction: column;
            gap: 0;
            max-height: 420px;
            overflow-y: auto;
            overflow-x: hidden;
            padding: 8px;
        }
        .notif-list::-webkit-scrollbar {
            width: 6px;
        }
        .notif-list::-webkit-scrollbar-track {
            background: transparent;
        }
        .notif-list::-webkit-scrollbar-thumb {
            background: rgba(255,255,255,0.15);
            border-radius: 3px;
        }
        .notif-list::-webkit-scrollbar-thumb:hover {
            background: rgba(255,255,255,0.25);
        }
        .notif-item {
            display: flex;
            gap: 12px;
            padding: 14px 40px 14px 14px;
            border-radius: 10px;
            border: 1px solid rgba(255,255,255,0.05);
            background: rgba(255,255,255,0.02);
            transition: all 0.2s ease;
            position: relative;
            cursor: pointer;
            margin-bottom: 8px;
        }
        .notif-item:last-child {
            margin-bottom: 0;
        }
        .notif-item:hover {
            border-color: rgba(255,255,255,0.15);
            background: rgba(255,255,255,0.06);
            transform: translateX(2px);
        }
        .notif-item-link {
            display: flex;
            gap: 12px;
            flex: 1;
            text-decoration: none;
            color: inherit;
        }
        .notif-dismiss {
            position: absolute;
            top: 50%;
            right: 12px;
            transform: translateY(-50%);
            width: 28px;
            height: 28px;
            border: none;
            background: rgba(255,255,255,0.08);
            border-radius: 8px;
            color: rgba(255,255,255,0.6);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: 600;
            line-height: 1;
            opacity: 0.6;
            transition: all 0.2s ease;
            z-index: 20;
            flex-shrink: 0;
        }
        .notif-item:hover .notif-dismiss {
            opacity: 1;
            background: rgba(239,68,68,0.15);
            color: #fca5a5;
        }
        .notif-dismiss:hover {
            background: rgba(239,68,68,0.25);
            color: #f87171;
            transform: translateY(-50%) scale(1.1);
        }
        .notif-dismiss:active {
            transform: translateY(-50%) scale(0.95);
        }
        .notif-icon {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            background: rgba(255,255,255,0.06);
            display: grid;
            place-items: center;
            font-size: 22px;
            flex-shrink: 0;
        }
        .notif-body { 
            flex: 1; 
            min-width: 0;
            overflow: hidden;
        }
        .notif-title {
            margin: 0;
            font-size: 14px;
            font-weight: 700;
            color: var(--text);
            line-height: 1.4;
        }
        .notif-message {
            margin: 6px 0 0;
            font-size: 13px;
            color: var(--muted);
            line-height: 1.5;
            word-wrap: break-word;
        }
        .notif-time {
            margin: 8px 0 0;
            font-size: 12px;
            color: rgba(255,255,255,0.5);
            font-weight: 500;
        }
        .notif-empty {
            padding: 40px 20px;
            text-align: center;
        }
        .notif-empty p {
            margin: 0;
            font-weight: 600;
            font-size: 15px;
            color: var(--text);
        }
        .notif-empty span {
            display: block;
            margin-top: 8px;
            font-size: 13px;
            color: var(--muted);
        }
        .user-menu {
            display: flex; align-items: center; gap: 12px; cursor: pointer;
            padding: 8px 14px 8px 8px; border-radius: 999px;
            background: rgba(255,255,255,0.04);
            border: 1px solid var(--border);
            transition: all .25s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
        }
        .user-menu:hover {
            background: rgba(255,255,255,0.08);
            border-color: var(--accent);
            transform: translateY(-1px);
        }
        .user-avatar {
            width: 36px; height: 36px; border-radius: 999px;
            background: linear-gradient(135deg, var(--accent), var(--accent-700));
            display: grid; place-items: center;
            font-weight: 700; font-size: 14px;
            box-shadow: 0 4px 12px <?php echo $theme_rgba_30; ?>;
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            overflow: hidden;
        }
        .dashboard-layout {
            display: grid; grid-template-columns: 280px 1fr;
            max-width: 1400px; margin: 0 auto;
            min-height: calc(100vh - 74px);
        }
        .sidebar {
            padding: 28px 20px; border-right: 1px solid var(--border);
            background: rgba(10,10,15,0.6);
            backdrop-filter: blur(10px);
        }
        .sidebar-nav { display: flex; flex-direction: column; gap: 4px; }
        .nav-item {
            display: flex; align-items: center; gap: 14px;
            padding: 14px 16px; border-radius: 14px;
            color: var(--muted); text-decoration: none;
            font-weight: 600; font-size: 15px;
            transition: all .25s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
        }
        .nav-item:hover {
            background: rgba(255,255,255,0.05);
            color: var(--text);
            transform: translateX(4px);
        }
        .nav-item.active {
            background: linear-gradient(135deg, <?php echo $theme_rgba_20; ?>, <?php echo $theme_rgba_10; ?>);
            color: var(--text);
            border: 1px solid <?php echo $theme_rgba_30; ?>;
            box-shadow: 0 4px 12px <?php echo $theme_rgba_15; ?>;
        }
        .nav-item.active::before {
            content: ''; position: absolute; left: 0; top: 50%;
            transform: translateY(-50%);
            width: 3px; height: 60%; border-radius: 0 4px 4px 0;
            background: var(--accent);
        }
        .nav-icon {
            width: 22px; height: 22px; display: grid; place-items: center;
            font-size: 20px;
        }
        .nav-icon img,
        .nav-icon svg {
            width: 20px;
            height: 20px;
            display: block;
            object-fit: contain;
            filter: brightness(0) invert(1);
            opacity: 0.75;
            transition: opacity 0.2s ease, filter 0.2s ease;
        }
        .nav-item:hover .nav-icon img,
        .nav-item:hover .nav-icon svg,
        .nav-item.active .nav-icon img,
        .nav-item.active .nav-icon svg {
            opacity: 1;
        }
        .nav-item.active .nav-icon img,
        .nav-item.active .nav-icon svg {
            filter: brightness(0) invert(1) drop-shadow(0 0 6px <?php echo $theme_rgba_25; ?>);
        }
        .main-content { padding: 40px; }
        .page-header { margin-bottom: 32px; }
        .page-title {
            font-size: 36px; font-weight: 900; margin: 0 0 10px;
            background: linear-gradient(135deg, #fff, rgba(255,255,255,0.8));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .page-subtitle {
            color: var(--muted); font-size: 17px; margin: 0;
            font-weight: 500;
        }
        .deck-toolbar {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            margin-bottom: 24px;
        }
        .alert {
            margin-bottom: 16px;
            padding: 12px 16px;
            border-radius: 12px;
            border: 1px solid var(--border);
            font-size: 14px;
        }
        .alert-error {
            color: #fecaca;
            background: rgba(239,68,68,0.08);
            border-color: rgba(239,68,68,0.4);
        }
        .alert-success {
            color: #bbf7d0;
            background: rgba(34,197,94,0.08);
            border-color: rgba(34,197,94,0.4);
        }
        .deck-toolbar .btn {
            border: none;
            border-radius: 12px;
            padding: 12px 20px;
            font-weight: 600;
            cursor: pointer;
            transition: all .25s ease;
            font-size: 14px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .btn-primary {
            background: linear-gradient(135deg, var(--accent), var(--accent-700));
            color: #0b0b12;
            border: 1px solid <?php echo $theme_rgba_30; ?>;
            box-shadow: 0 10px 24px <?php echo $theme_rgba_20; ?>;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 14px 32px <?php echo $theme_rgba_25; ?>;
        }
        .btn-secondary {
            background: rgba(255,255,255,0.05);
            color: var(--text);
            border: 1px solid var(--border);
        }
        .btn-secondary:hover {
            border-color: var(--accent);
            transform: translateY(-2px);
        }
        .deck-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 20px;
        }
        .deck-card {
            background: linear-gradient(135deg, rgba(255,255,255,0.05), rgba(255,255,255,0.02));
            border: 1px solid var(--border);
            border-radius: 20px;
            padding: 0;
            transition: all .3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
            color: inherit;
            display: flex;
            flex-direction: column;
            min-height: 240px;
            aspect-ratio: 1 / 1;
            max-height: 320px;
        }
        .deck-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: radial-gradient(circle at top right, <?php echo $theme_rgba_10; ?>, transparent 70%);
            opacity: 0;
            transition: opacity .3s ease;
            z-index: 0;
        }
        .deck-card:hover::before {
            opacity: 1;
        }
        .deck-card:hover {
            background: linear-gradient(135deg, rgba(255,255,255,0.08), rgba(255,255,255,0.04));
            border-color: var(--accent);
            transform: translateY(-6px) scale(1.02);
            box-shadow: 0 16px 40px <?php echo $theme_rgba_25; ?>;
        }
        .deck-color-bar {
            height: 6px;
            width: 100%;
            background: var(--accent);
            position: relative;
            z-index: 1;
        }
        .deck-card-link {
            text-decoration: none;
            color: inherit;
            display: flex;
            flex-direction: column;
            flex: 1;
        }
        .deck-content {
            padding: 20px;
            flex: 1;
            display: flex;
            flex-direction: column;
            position: relative;
            z-index: 1;
        }
        .deck-header {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            margin-bottom: 16px;
        }
        .deck-icon {
            width: 56px;
            height: 56px;
            border-radius: 16px;
            display: grid;
            place-items: center;
            font-size: 24px;
            color: #fff;
            font-weight: 800;
            box-shadow: none;
            flex-shrink: 0;
            overflow: hidden;
            background: transparent;
            border: 1px solid var(--border);
        }
        .deck-icon img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }
        .deck-meta {
            font-size: 11px;
            color: var(--muted);
            text-align: right;
            line-height: 1.4;
        }
        .deck-delete-btn {
            position: absolute;
            top: 12px;
            right: 12px;
            border: none;
            background: rgba(0,0,0,0.35);
            color: #fecaca;
            width: 34px;
            height: 34px;
            border-radius: 10px;
            display: grid;
            place-items: center;
            cursor: pointer;
            z-index: 2;
            transition: all 0.2s ease;
        }
        .deck-delete-btn:hover {
            background: rgba(239,68,68,0.25);
            color: #fee2e2;
        }
        .confirm-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.65);
            backdrop-filter: blur(2px);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 20000;
            padding: 20px;
        }
        .confirm-modal {
            background: rgba(10,10,15,0.98);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 24px;
            width: min(360px, 92vw);
            box-shadow: 0 16px 40px rgba(0,0,0,0.45);
        }
        .confirm-modal h4 {
            margin: 0 0 8px;
            font-size: 18px;
        }
        .confirm-modal p {
            margin: 0 0 18px;
            color: var(--muted);
            font-size: 14px;
            line-height: 1.6;
        }
        .confirm-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }
        .confirm-actions button {
            border-radius: 10px;
            padding: 10px 16px;
            font-weight: 600;
            cursor: pointer;
            border: 1px solid var(--border);
            background: rgba(255,255,255,0.05);
            color: var(--text);
        }
        .confirm-actions button:hover {
            background: rgba(255,255,255,0.08);
        }
        .confirm-actions .danger {
            border-color: rgba(239,68,68,0.5);
            background: rgba(239,68,68,0.15);
            color: #fee2e2;
        }
        .confirm-actions .danger:hover {
            background: rgba(239,68,68,0.25);
        }
        .deck-title {
            font-size: 20px;
            font-weight: 800;
            margin: 0 0 8px;
            line-height: 1.3;
            color: var(--text);
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        .deck-description {
            color: var(--muted);
            font-size: 13px;
            line-height: 1.5;
            margin: 0 0 16px;
            flex: 1;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        .deck-shared-label {
            font-size: 12px;
            color: var(--muted);
            font-weight: 600;
            margin: -6px 0 10px;
        }
        .deck-footer {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-top: auto;
            padding-top: 12px;
            border-top: 1px solid var(--border);
        }
        .deck-shared-label {
            font-size: 12px;
            color: var(--muted);
            font-weight: 600;
            margin: -6px 0 10px;
        }
        .progress-bar {
            height: 6px;
            background: rgba(255,255,255,0.08);
            border-radius: 999px;
            overflow: hidden;
            flex: 1;
            margin-right: 12px;
        }
        .progress-fill {
            height: 100%;
            border-radius: 999px;
            background: linear-gradient(135deg, var(--accent), var(--accent-700));
            transition: width 0.3s ease;
        }
        .deck-stats {
            font-size: 11px;
            color: var(--muted);
            white-space: nowrap;
        }
        .section-split {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 24px;
            margin-top: 32px;
        }
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: var(--muted);
            border: 1px dashed var(--border);
            border-radius: 20px;
            background: rgba(255,255,255,0.02);
        }
        .empty-icon {
            font-size: 36px;
            margin-bottom: 12px;
        }
        /* Logout Modal */
        .logout-modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.75);
            backdrop-filter: blur(4px);
            z-index: 10000;
            align-items: center;
            justify-content: center;
            padding: 20px;
            animation: fadeIn 0.3s ease;
        }
        .logout-modal-overlay.active {
            display: flex;
        }
        .logout-modal {
            background: rgba(10,10,15,0.98);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 32px;
            max-width: 400px;
            width: 100%;
            position: relative;
            box-shadow: 0 40px 120px rgba(0,0,0,0.5);
            animation: slideUp 0.3s ease;
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        .logout-modal-icon {
            width: 64px;
            height: 64px;
            margin: 0 auto 20px;
            background: rgba(239, 68, 68, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .logout-modal-icon svg {
            width: 32px;
            height: 32px;
            color: #ef4444;
        }
        .logout-modal-header {
            text-align: center;
            margin-bottom: 20px;
        }
        .logout-modal-title {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 8px;
            color: var(--text);
        }
        .logout-modal-message {
            color: var(--muted);
            font-size: 14px;
            line-height: 1.6;
        }
        .logout-modal-actions {
            display: flex;
            gap: 12px;
            margin-top: 24px;
        }
        .btn-modal {
            flex: 1;
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
        }
        .btn-modal-cancel {
            background: rgba(255,255,255,0.05);
            border: 1px solid var(--border);
            color: var(--text);
        }
        .btn-modal-cancel:hover {
            background: rgba(255,255,255,0.08);
        }
        .btn-modal-logout {
            background: #ef4444;
            color: white;
        }
        .btn-modal-logout:hover {
            background: #dc2626;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
        }

        @media (max-width: 1024px) {
            .dashboard-layout { grid-template-columns: 1fr; }
            .sidebar { display: none; }
        }
        @media (max-width: 720px) {
            .main-content { padding: 24px; }
            .page-title { font-size: 28px; }
            .section-split { grid-template-columns: 1fr; }
            .deck-grid {
                grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
                gap: 16px;
            }
            .deck-card {
                min-height: 220px;
                max-height: 280px;
            }
            .deck-content {
                padding: 16px;
            }
            .deck-icon {
                width: 48px;
                height: 48px;
                font-size: 20px;
            }
            .deck-title {
                font-size: 18px;
            }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-content">
            <a href="dashboard.php" class="brand">
                <div class="logo" aria-label="Bizmo logo">
                    <img src="icons/bizmo.png" alt="" width="50" height="50" />
                </div>
                <span>Bizmo</span>
            </a>
            <div class="header-right">
                <div style="position: relative;">
                    <button class="notif-btn<?php echo $has_notifications ? ' has-alert' : ''; ?>" aria-label="Notifications" id="notifBtn">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/>
                        </svg>
                    </button>
                    <div class="notif-dropdown" id="notifDropdown">
                        <h4>
                            <span>Notifications</span>
                            <?php if (!empty($notifications)): ?>
                                <button type="button" class="notif-clear-all" onclick="clearAllNotifications(event)" aria-label="Clear all notifications">
                                    Clear all
                                </button>
                            <?php endif; ?>
                        </h4>
                        <?php if (!empty($notifications)): ?>
                            <div class="notif-list">
                                <?php foreach ($notifications as $notification): ?>
                                    <div class="notif-item" data-notif-id="<?php echo htmlspecialchars($notification['id'] ?? ''); ?>">
                                        <a href="<?php echo htmlspecialchars($notification['url'] ?? '#'); ?>" class="notif-item-link">
                                            <div class="notif-icon"><?php echo htmlspecialchars($notification['icon']); ?></div>
                                            <div class="notif-body">
                                                <p class="notif-title"><?php echo htmlspecialchars($notification['title']); ?></p>
                                                <p class="notif-message"><?php echo htmlspecialchars($notification['message']); ?></p>
                                                <p class="notif-time"><?php echo htmlspecialchars($notification['time']); ?></p>
                                            </div>
                                        </a>
                                        <button type="button" class="notif-dismiss" aria-label="Dismiss notification" onclick="dismissNotification(event, '<?php echo htmlspecialchars($notification['id'] ?? ''); ?>')">
                                            ×
                                        </button>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="notif-empty">
                                <p>You're all caught up</p>
                                <span>We'll let you know when something new happens.</span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="user-menu" id="userMenu">
                    <div class="user-avatar" style="<?php if ($profile_picture_path): ?>background-image: url('<?php echo htmlspecialchars($profile_picture_path); ?>');<?php endif; ?>">
                        <?php if (!$profile_picture_path): ?>
                            <?php echo htmlspecialchars($user_initials); ?>
                        <?php endif; ?>
                    </div>
                    <span style="font-weight: 600; font-size: 14px;"><?php echo htmlspecialchars($user_name); ?></span>
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                    </svg>
                    <div class="user-dropdown" id="userDropdown" style="display: none; position: absolute; top: calc(100% + 8px); right: 0; background: rgba(10,10,15,0.95); border: 1px solid var(--border); border-radius: 12px; padding: 8px; min-width: 200px; box-shadow: 0 8px 24px rgba(0,0,0,0.4); z-index: 1000;">
                        <div style="padding: 12px; border-bottom: 1px solid var(--border);">
                            <div style="font-weight: 600; font-size: 14px; margin-bottom: 4px;"><?php echo htmlspecialchars($user_name); ?></div>
                            <div style="font-size: 12px; color: var(--muted);"><?php echo htmlspecialchars($user_email); ?></div>
                        </div>
                        <a href="#" id="logoutBtn" style="display: block; padding: 12px; color: var(--text); text-decoration: none; border-radius: 8px; transition: background 0.2s ease; font-size: 14px; font-weight: 600;" onmouseover="this.style.background='rgba(255,255,255,0.05)'" onmouseout="this.style.background='transparent'">
                            <span style="margin-right: 8px;">🚪</span> Logout
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <div class="dashboard-layout">
        <aside class="sidebar">
            <nav class="sidebar-nav">
                <a href="dashboard.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/dashboard.png" alt="" loading="lazy">
                    </span>
                    <span>Dashboard</span>
                </a>
                <a href="decks.php" class="nav-item active">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/cards.png" alt="" loading="lazy">
                    </span>
                    <span>My Decks</span>
                </a>
                <a href="progress.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/progress.png" alt="" loading="lazy">
                    </span>
                    <span>Progress</span>
                </a>
                <a href="favorites.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/favorite.png" alt="" loading="lazy">
                    </span>
                    <span>Favorites</span>
                </a>
                <a href="friends.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/friends.png" alt="" loading="lazy">
                    </span>
                    <span>Friends</span>
                </a>
                <a href="reports.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                        </svg>
                    </span>
                    <span>Reports</span>
                </a>
                <a href="planner.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/planner.png" alt="" loading="lazy">
                    </span>
                    <span>Study Planner</span>
                </a>
                <a href="settings.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/settings.png" alt="" loading="lazy">
                    </span>
                    <span>Settings</span>
                </a>
            </nav>
        </aside>

        <main class="main-content">
            <div class="page-header">
                <h1 class="page-title">My Decks</h1>
                <p class="page-subtitle">Organize, build, and track your study decks.</p>
            </div>

            <div class="deck-toolbar">
                <button class="btn btn-primary" id="openCreateDeck">+ Create New Deck</button>
               
            </div>

            <?php if (!empty($deck_delete_error)): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($deck_delete_error); ?></div>
            <?php elseif (!empty($deck_delete_success)): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($deck_delete_success); ?></div>
            <?php endif; ?>

            <div class="deck-grid">
                <?php if (!empty($user_decks)): ?>
                    <?php foreach ($user_decks as $deck): 
                        $deck_color = $deck['color'] ?: $user_theme_color;
                        $deck_rgb = hexToRgb($deck_color);
                        $deck_rgba_20 = "rgba({$deck_rgb[0]},{$deck_rgb[1]},{$deck_rgb[2]},0.2)";
                        $deck_rgba_30 = "rgba({$deck_rgb[0]},{$deck_rgb[1]},{$deck_rgb[2]},0.3)";
                        $deck_icon_src = buildDeckIconSrc($deck['icon'] ?? null);
                        $deck_icon_fallback = mb_strtoupper(mb_substr($deck['title'], 0, 1));
                    ?>
                        <div class="deck-card">
                            <button type="button" class="deck-delete-btn deck-delete-trigger" data-deck-id="<?php echo (int)$deck['id']; ?>" data-deck-title="<?php echo htmlspecialchars($deck['title'], ENT_QUOTES); ?>" aria-label="Delete deck">🗑</button>
                            <a href="deck.php?id=<?php echo (int)$deck['id']; ?>" class="deck-card-link">
                                <div class="deck-color-bar" style="background: linear-gradient(135deg, <?php echo htmlspecialchars($deck_color); ?>, <?php echo htmlspecialchars(darkenColor($deck_color, 15)); ?>);"></div>
                                <div class="deck-content">
                                    <div class="deck-header">
                                        <div class="deck-icon">
                                            <?php if ($deck_icon_src !== ''): ?>
                                                <img src="<?php echo htmlspecialchars($deck_icon_src, ENT_QUOTES); ?>" alt="Deck icon" />
                                            <?php else: ?>
                                                <span><?php echo htmlspecialchars($deck_icon_fallback); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <h3 class="deck-title"><?php echo htmlspecialchars($deck['title']); ?></h3>
                                    <?php if (!empty($deck['shared_by_name'])): ?>
                                        <div class="deck-shared-label">by <?php echo htmlspecialchars($deck['shared_by_name']); ?></div>
                                    <?php endif; ?>
                                    <?php if (!empty($deck['description'])): ?>
                                        <p class="deck-description"><?php echo htmlspecialchars($deck['description']); ?></p>
                                    <?php else: ?>
                                        <p class="deck-description" style="opacity: 0.5;">No description</p>
                                    <?php endif; ?>
                                    <div class="deck-footer">
                                        <div class="progress-bar">
                                            <div class="progress-fill" style="width: 0%;"></div>
                                        </div>
                                        <div class="deck-stats"><?php echo (int)$deck['card_count']; ?> <?php echo (int)$deck['card_count'] === 1 ? 'card' : 'cards'; ?></div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div style="grid-column: 1 / -1; padding: 60px 20px; border: 1px dashed var(--border); border-radius: 20px; color: var(--muted); text-align: center; background: rgba(255,255,255,0.02);">
                        <div style="font-size: 48px; margin-bottom: 16px;">📚</div>
                        <div style="font-size: 18px; font-weight: 600; margin-bottom: 8px; color: var(--text);">No decks yet</div>
                        <div style="font-size: 14px;">Use "+ Create New Deck" to add your first deck</div>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <div id="deleteDeckOverlay" class="confirm-overlay">
        <div class="confirm-modal">
            <h4>Delete deck?</h4>
            <p>You're about to delete <strong id="deleteDeckName"></strong>. This action cannot be undone.</p>
            <div class="confirm-actions">
                <button type="button" id="cancelDeleteDeck">Cancel</button>
                <button type="button" id="confirmDeleteDeck" class="danger">Delete</button>
            </div>
        </div>
    </div>

    <script>
        // Create Deck modal
        (function () {
            const openBtn = document.getElementById('openCreateDeck');
            if (!openBtn) return;

            const overlay = document.createElement('div');
            overlay.id = 'createDeckOverlay';
            overlay.style.position = 'fixed';
            overlay.style.inset = '0';
            overlay.style.background = 'rgba(0,0,0,0.6)';
            overlay.style.backdropFilter = 'blur(2px)';
            overlay.style.display = 'none';
            overlay.style.alignItems = 'center';
            overlay.style.justifyContent = 'center';
            overlay.style.zIndex = '10000';

            const modal = document.createElement('div');
            modal.style.background = 'rgba(10,10,15,0.98)';
            modal.style.border = '1px solid var(--border)';
            modal.style.borderRadius = '16px';
            modal.style.padding = '20px';
            modal.style.width = 'min(480px, 92vw)';
            modal.style.boxShadow = '0 12px 40px rgba(0,0,0,0.5)';

            modal.innerHTML = `
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
                    <h3 style="margin:0;font-size:20px;font-weight:800;">Create Deck</h3>
                    <button type="button" id="closeCreateDeck" style="background:transparent;border:1px solid var(--border);color:var(--text);border-radius:10px;padding:6px 10px;cursor:pointer;">✕</button>
                </div>
                <?php if (!empty($deck_error)): ?>
                    <div style="margin: 10px 0 14px; color: #fecaca; background: rgba(239, 68, 68, 0.08); border: 1px solid rgba(239, 68, 68, 0.25); padding: 10px 12px; border-radius: 10px;"><?php echo htmlspecialchars($deck_error); ?></div>
                <?php endif; ?>
                <form method="post" autocomplete="off">
                    <input type="hidden" name="create_deck" value="1" />
                    <div style="display:grid;gap:12px;">
                        <div>
                            <label for="deck_title" style="display:block;font-size:13px;color:var(--muted);margin-bottom:6px;">Title</label>
                            <input required id="deck_title" name="deck_title" type="text" placeholder="e.g. World History" style="width:100%;padding:12px 14px;border-radius:12px;border:1px solid var(--border);background:rgba(10,10,15,0.9);color:var(--text);" />
                        </div>
                        <div>
                            <label for="deck_description" style="display:block;font-size:13px;color:var(--muted);margin-bottom:6px;">Description</label>
                            <textarea id="deck_description" name="deck_description" rows="3" placeholder="Short description (optional)" style="width:100%;padding:12px 14px;border-radius:12px;border:1px solid var(--border);background:rgba(10,10,15,0.9);color:var(--text);"></textarea>
                        </div>
                        <div style="display:grid;grid-template-columns:1fr;gap:12px;">
                            <div>
                                <label for="deck_color" style="display:block;font-size:13px;color:var(--muted);margin-bottom:6px;">Color</label>
                                <input id="deck_color" name="deck_color" type="text" placeholder="#8b5cf6 or rgba(...)" style="width:100%;padding:12px 14px;border-radius:12px;border:1px solid var(--border);background:rgba(10,10,15,0.9);color:var(--text);" />
                            </div>
                        </div>
                        <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:6px;">
                            <button type="button" id="cancelCreateDeck" class="btn btn-secondary" style="padding:10px 16px;">Cancel</button>
                            <button type="submit" class="btn btn-primary" style="padding:10px 16px;">Create</button>
                        </div>
                    </div>
                </form>
            `;

            overlay.appendChild(modal);
            document.body.appendChild(overlay);

            function openModal() { overlay.style.display = 'flex'; }
            function closeModal() { overlay.style.display = 'none'; }

            openBtn.addEventListener('click', openModal);
            overlay.addEventListener('click', function (e) {
                if (e.target === overlay) closeModal();
            });
            modal.querySelector('#closeCreateDeck').addEventListener('click', closeModal);
            modal.querySelector('#cancelCreateDeck').addEventListener('click', closeModal);
        })();

        // Notifications dropdown
        const notifBtn = document.getElementById('notifBtn');
        const notifDropdown = document.getElementById('notifDropdown');

        if (notifBtn && notifDropdown) {
            notifBtn.addEventListener('click', function (e) {
                e.stopPropagation();
                notifDropdown.classList.toggle('show');
            });

            document.addEventListener('click', function (e) {
                if (!notifDropdown.contains(e.target) && e.target !== notifBtn) {
                    notifDropdown.classList.remove('show');
                }
            });
        }

        // Clear all notifications function
        function clearAllNotifications(event) {
            event.preventDefault();
            event.stopPropagation();
            
            if (!confirm('Clear all notifications?')) {
                return;
            }
            
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            
            const inputAction = document.createElement('input');
            inputAction.type = 'hidden';
            inputAction.name = 'clear_all_notifications';
            inputAction.value = '1';
            
            const inputAjax = document.createElement('input');
            inputAjax.type = 'hidden';
            inputAjax.name = 'ajax';
            inputAjax.value = '1';
            
            form.appendChild(inputAction);
            form.appendChild(inputAjax);
            document.body.appendChild(form);
            
            fetch(window.location.href, {
                method: 'POST',
                body: new FormData(form)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const notifList = document.querySelector('.notif-list');
                    if (notifList) {
                        const items = notifList.querySelectorAll('.notif-item');
                        items.forEach((item, index) => {
                            setTimeout(() => {
                                item.style.opacity = '0';
                                item.style.transform = 'translateX(-10px)';
                                setTimeout(() => item.remove(), 200);
                            }, index * 50);
                        });
                        
                        setTimeout(() => {
                            const notifDropdown = document.getElementById('notifDropdown');
                            if (notifDropdown) {
                                notifDropdown.innerHTML = '<h4><span>Notifications</span></h4><div class="notif-empty"><p>You\'re all caught up</p><span>We\'ll let you know when something new happens.</span></div>';
                            }
                            const notifBtn = document.getElementById('notifBtn');
                            if (notifBtn) {
                                notifBtn.classList.remove('has-alert');
                            }
                        }, items.length * 50 + 200);
                    }
                }
            })
            .catch(error => {
                console.error('Error clearing notifications:', error);
                form.submit();
            });
            
            document.body.removeChild(form);
        }

        // Dismiss notification function
        function dismissNotification(event, notifId) {
            event.preventDefault();
            event.stopPropagation();
            
            if (!notifId) return;
            
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            
            const inputAction = document.createElement('input');
            inputAction.type = 'hidden';
            inputAction.name = 'dismiss_notification';
            inputAction.value = '1';
            
            const inputId = document.createElement('input');
            inputId.type = 'hidden';
            inputId.name = 'notif_id';
            inputId.value = notifId;
            
            const inputAjax = document.createElement('input');
            inputAjax.type = 'hidden';
            inputAjax.name = 'ajax';
            inputAjax.value = '1';
            
            form.appendChild(inputAction);
            form.appendChild(inputId);
            form.appendChild(inputAjax);
            document.body.appendChild(form);
            
            fetch(window.location.href, {
                method: 'POST',
                body: new FormData(form)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const notifItem = document.querySelector(`[data-notif-id="${notifId}"]`);
                    if (notifItem) {
                        notifItem.style.opacity = '0';
                        notifItem.style.transform = 'translateX(-10px)';
                        setTimeout(() => {
                            notifItem.remove();
                            const notifList = document.querySelector('.notif-list');
                            if (notifList && notifList.children.length === 0) {
                                const notifDropdown = document.getElementById('notifDropdown');
                                if (notifDropdown) {
                                    notifDropdown.innerHTML = '<h4>Notifications</h4><div class="notif-empty"><p>You\'re all caught up</p><span>We\'ll let you know when something new happens.</span></div>';
                                }
                                const notifBtn = document.getElementById('notifBtn');
                                if (notifBtn) {
                                    notifBtn.classList.remove('has-alert');
                                }
                            }
                        }, 200);
                    }
                }
            })
            .catch(error => {
                console.error('Error dismissing notification:', error);
                form.submit();
            });
            
            document.body.removeChild(form);
        }

        const userMenu = document.getElementById('userMenu');
        const userDropdown = document.getElementById('userDropdown');

        if (userMenu && userDropdown) {
            userMenu.addEventListener('click', function (e) {
                e.stopPropagation();
                const isVisible = userDropdown.style.display === 'block';
                userDropdown.style.display = isVisible ? 'none' : 'block';
            });

            document.addEventListener('click', function (e) {
                // Don't close if clicking on logout button (it will handle its own modal)
                if (!userMenu.contains(e.target) && e.target.id !== 'logoutBtn' && !e.target.closest('#logoutBtn')) {
                    userDropdown.style.display = 'none';
                }
            });
        }

        // Deck deletion modal
        (function () {
            const deckGrid = document.querySelector('.deck-grid');
            const deleteOverlay = document.getElementById('deleteDeckOverlay');
            const deleteDeckName = document.getElementById('deleteDeckName');
            const cancelDeleteBtn = document.getElementById('cancelDeleteDeck');
            const confirmDeleteBtn = document.getElementById('confirmDeleteDeck');
            let pendingDeleteDeckId = null;

            if (!deckGrid || !deleteOverlay || !cancelDeleteBtn || !confirmDeleteBtn) return;

            function openDeleteModal(deckId, deckTitle) {
                pendingDeleteDeckId = deckId;
                if (deleteDeckName) {
                    deleteDeckName.textContent = deckTitle || 'this deck';
                }
                deleteOverlay.style.display = 'flex';
            }

            function closeDeleteModal() {
                pendingDeleteDeckId = null;
                deleteOverlay.style.display = 'none';
            }

            cancelDeleteBtn.addEventListener('click', closeDeleteModal);
            deleteOverlay.addEventListener('click', function(e) {
                if (e.target === deleteOverlay) {
                    closeDeleteModal();
                }
            });

            confirmDeleteBtn.addEventListener('click', function() {
                if (!pendingDeleteDeckId) return;
                const form = document.createElement('form');
                form.method = 'POST';
                form.style.display = 'none';

                const inputAction = document.createElement('input');
                inputAction.type = 'hidden';
                inputAction.name = 'delete_deck';
                inputAction.value = '1';

                const inputId = document.createElement('input');
                inputId.type = 'hidden';
                inputId.name = 'deck_id';
                inputId.value = pendingDeleteDeckId;

                form.appendChild(inputAction);
                form.appendChild(inputId);
                document.body.appendChild(form);
                form.submit();
                closeDeleteModal();
            });

            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && deleteOverlay.style.display === 'flex') {
                    closeDeleteModal();
                }
            });

            deckGrid.addEventListener('click', function(e) {
                const deleteBtn = e.target.closest('.deck-delete-btn');
                if (deleteBtn) {
                    e.stopPropagation();
                    const deckId = deleteBtn.getAttribute('data-deck-id');
                    const deckTitle = deleteBtn.getAttribute('data-deck-title') || '';
                    if (deckId) {
                        openDeleteModal(deckId, deckTitle);
                    }
                }
            });
        })();

    </script>

    <!-- Logout Confirmation Modal -->
    <div class="logout-modal-overlay" id="logoutModal">
        <div class="logout-modal">
            <div class="logout-modal-icon">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                </svg>
            </div>
            <div class="logout-modal-header">
                <h3 class="logout-modal-title">Confirm Logout</h3>
                <p class="logout-modal-message">Are you sure you want to logout? You will need to login again to access your account.</p>
            </div>
            <div class="logout-modal-actions">
                <button class="btn-modal btn-modal-cancel" id="logoutCancelBtn">Cancel</button>
                <button class="btn-modal btn-modal-logout" id="logoutConfirmBtn">Logout</button>
            </div>
        </div>
    </div>

    <script>
        // Logout Modal - Initialize after modal HTML is in DOM
        document.addEventListener('DOMContentLoaded', function() {
            const logoutBtn = document.getElementById('logoutBtn');
            const logoutModal = document.getElementById('logoutModal');
            const logoutConfirmBtn = document.getElementById('logoutConfirmBtn');
            const logoutCancelBtn = document.getElementById('logoutCancelBtn');

            if (logoutBtn) {
                logoutBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    if (logoutModal) {
                        logoutModal.classList.add('active');
                    }
                    // Close user dropdown when opening logout modal
                    const userDropdown = document.getElementById('userDropdown');
                    if (userDropdown) {
                        userDropdown.style.display = 'none';
                    }
                });
            }

            if (logoutCancelBtn) {
                logoutCancelBtn.addEventListener('click', function() {
                    if (logoutModal) {
                        logoutModal.classList.remove('active');
                    }
                });
            }

            if (logoutConfirmBtn) {
                logoutConfirmBtn.addEventListener('click', function() {
                    window.location.href = 'dashboard.php?logout=1';
                });
            }

            if (logoutModal) {
                logoutModal.addEventListener('click', function(e) {
                    if (e.target === logoutModal) {
                        logoutModal.classList.remove('active');
                    }
                });
            }

            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && logoutModal && logoutModal.classList.contains('active')) {
                    logoutModal.classList.remove('active');
                }
            });
        });

    </script>
</body>
</html>


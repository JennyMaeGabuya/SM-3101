<?php
require_once 'config.php';

session_start();

$reset_error = '';
$reset_success = '';
$token = $_GET['token'] ?? '';

// Handle password reset form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset_password'])) {
    $token = $_POST['token'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    if (empty($password) || empty($confirm_password)) {
        $reset_error = "Please fill in all fields.";
    } elseif (strlen($password) < 6) {
        $reset_error = "Password must be at least 6 characters.";
    } elseif ($password !== $confirm_password) {
        $reset_error = "Passwords do not match.";
    } else {
        // Verify token
        $stmt = $conn->prepare("SELECT id, reset_token_expiry FROM users WHERE reset_token = ?");
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            
            // Check if token is expired
            if (time() > $user['reset_token_expiry']) {
                $reset_error = "This reset link has expired. Please request a new one.";
            } else {
                // Update password
                $password_hash = password_hash($password, PASSWORD_DEFAULT);
                $update_stmt = $conn->prepare("UPDATE users SET password = ?, reset_token = NULL, reset_token_expiry = NULL WHERE id = ?");
                $update_stmt->bind_param("si", $password_hash, $user['id']);
                
                if ($update_stmt->execute()) {
                    $reset_success = "Password has been reset successfully! You can now log in.";
                    $token = ''; // Clear token after successful reset
                } else {
                    $reset_error = "Error resetting password. Please try again.";
                }
                $update_stmt->close();
            }
        } else {
            $reset_error = "Invalid or expired reset token. Please request a new password reset link.";
        }
        $stmt->close();
    }
}

// Verify token on page load
$valid_token = false;
$token_expired = false;
if (!empty($token)) {
    $stmt = $conn->prepare("SELECT id, reset_token_expiry FROM users WHERE reset_token = ?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (time() > $user['reset_token_expiry']) {
            $token_expired = true;
        } else {
            $valid_token = true;
        }
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bizmo – Reset Password</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #0b0b12;
            --text: #ffffff;
            --muted: #a2a3ad;
            --accent: #dc2626;
            --accent-700: #b91c1c;
            --surface: #111118;
            --border: rgba(255,255,255,0.08);
        }

        * { box-sizing: border-box; }
        html, body { height: 100%; }
        body {
            margin: 0;
            font-family: 'Inter', ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial;
            background: linear-gradient(180deg, #0c0c14 0%, #0c0c14 55%, #0c0c14 100%);
            color: var(--text);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .reset-card {
            width: 100%;
            max-width: 500px;
            background: rgba(255,255,255,0.03);
            border: 1px solid var(--border);
            border-radius: 24px;
            padding: 48px;
            box-shadow: 0 40px 120px rgba(220,38,38,0.2);
        }

        .reset-header {
            text-align: center;
            margin-bottom: 36px;
        }

        .reset-title {
            font-size: 32px;
            font-weight: 900;
            margin: 0 0 8px;
            background: linear-gradient(135deg, #fff, rgba(255,255,255,0.8));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .reset-subtitle {
            color: var(--muted);
            font-size: 15px;
            margin: 0;
        }

        .form-group {
            margin-bottom: 24px;
        }

        .form-label {
            display: block;
            color: var(--text);
            font-weight: 600;
            font-size: 14px;
            margin-bottom: 8px;
        }

        .form-input {
            width: 100%;
            padding: 14px 18px;
            border-radius: 12px;
            background: rgba(255,255,255,0.03) !important;
            border: 1px solid var(--border);
            color: var(--text) !important;
            font: inherit;
            font-size: 15px;
            outline: none;
            transition: all .25s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .form-input:focus {
            border-color: var(--accent);
            background: rgba(255,255,255,0.05) !important;
            box-shadow: 0 0 0 3px rgba(220,38,38,0.1);
        }

        .password-wrapper {
            position: relative;
        }

        .password-toggle {
            position: absolute;
            right: 14px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: var(--muted);
            cursor: pointer;
            padding: 4px;
        }

        .reset-btn {
            width: 100%;
            padding: 14px 22px;
            border-radius: 12px;
            border: 1px solid transparent;
            background: linear-gradient(135deg, var(--accent), var(--accent-700));
            color: #fff;
            font-weight: 700;
            font-size: 16px;
            cursor: pointer;
            transition: all .25s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 4px 12px rgba(220,38,38,0.3);
            margin-bottom: 24px;
        }

        .reset-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(220,38,38,0.4);
        }

        .back-link {
            text-align: center;
            margin-top: 20px;
        }

        .back-link a {
            color: var(--accent);
            text-decoration: none;
            font-weight: 700;
        }

        .back-link a:hover {
            text-decoration: underline;
        }

        .error-message {
            background: rgba(220,38,38,0.1);
            border: 1px solid rgba(220,38,38,0.3);
            border-radius: 12px;
            padding: 12px 16px;
            margin-bottom: 20px;
            color: #ff6b6b;
            font-size: 14px;
        }

        .success-message {
            background: rgba(34,197,94,0.1);
            border: 1px solid rgba(34,197,94,0.3);
            border-radius: 12px;
            padding: 12px 16px;
            margin-bottom: 20px;
            color: #4ade80;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="reset-card">
        <div class="reset-header">
            <h1 class="reset-title">Reset Password</h1>
            <p class="reset-subtitle">Enter your new password below</p>
        </div>

        <?php if ($reset_error): ?>
            <div class="error-message">
                <?php echo htmlspecialchars($reset_error); ?>
            </div>
        <?php endif; ?>

        <?php if ($reset_success): ?>
            <div class="success-message">
                <?php echo htmlspecialchars($reset_success); ?>
            </div>
            <div class="back-link">
                <a href="login.php">Go to Login</a>
            </div>
        <?php elseif ($token_expired || (empty($token) && !$reset_success)): ?>
            <div class="error-message">
                Invalid or expired reset token. Please request a new password reset link.
            </div>
            <div class="back-link">
                <a href="login.php">Back to Login</a>
            </div>
        <?php elseif ($valid_token): ?>
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
                
                <div class="form-group">
                    <label for="password" class="form-label">New Password</label>
                    <div class="password-wrapper">
                        <input 
                            type="password" 
                            id="password" 
                            name="password" 
                            class="form-input" 
                            placeholder="Enter new password"
                            required
                            autocomplete="new-password"
                            minlength="6"
                        />
                        <button type="button" class="password-toggle" onclick="togglePassword('password')">
                            👁️
                        </button>
                    </div>
                </div>

                <div class="form-group">
                    <label for="confirm_password" class="form-label">Confirm New Password</label>
                    <div class="password-wrapper">
                        <input 
                            type="password" 
                            id="confirm_password" 
                            name="confirm_password" 
                            class="form-input" 
                            placeholder="Confirm new password"
                            required
                            autocomplete="new-password"
                            minlength="6"
                        />
                        <button type="button" class="password-toggle" onclick="togglePassword('confirm_password')">
                            👁️
                        </button>
                    </div>
                </div>

                <button type="submit" name="reset_password" class="reset-btn">Reset Password</button>
            </form>

            <div class="back-link">
                <a href="login.php">Back to Login</a>
            </div>
        <?php endif; ?>
    </div>

    <script>
        function togglePassword(inputId) {
            const input = document.getElementById(inputId);
            if (input.type === 'password') {
                input.type = 'text';
            } else {
                input.type = 'password';
            }
        }
    </script>
</body>
</html>













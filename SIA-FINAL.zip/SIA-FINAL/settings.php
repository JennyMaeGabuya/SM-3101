<?php
session_start();
require_once 'config.php';

// Include PHPMailer files
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$update_success = '';
$update_error = '';

// Create uploads directory if it doesn't exist
$upload_dir = 'uploads/profiles/';
if (!file_exists($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}

// Check if themes table exists, create if it doesn't
$table_check = $conn->query("SHOW TABLES LIKE 'themes'");
if ($table_check->num_rows == 0) {
    // Create themes table
    $conn->query("CREATE TABLE IF NOT EXISTS `themes` (
        `id` INT(11) NOT NULL AUTO_INCREMENT,
        `user_id` INT(11) NOT NULL,
        `theme_color` VARCHAR(7) NOT NULL DEFAULT '#dc2626',
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `user_id` (`user_id`),
        CONSTRAINT `fk_themes_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

// Get current user data from database
$stmt = $conn->prepare("SELECT full_name, email, username, status FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user_data = $result->fetch_assoc();
$stmt->close();

$current_name = $user_data['full_name'] ?? $_SESSION['user_name'] ?? '';
$current_email = $user_data['email'] ?? $_SESSION['user_email'] ?? '';
$current_username = $user_data['username'] ?? $_SESSION['user_username'] ?? '';
$email_verified = ($user_data['status'] ?? '') === 'verified';

// Get theme from themes table
$stmt = $conn->prepare("SELECT theme_color FROM themes WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$theme_data = $result->fetch_assoc();
$stmt->close();

$current_theme = $theme_data['theme_color'] ?? '#dc2626';

// If user doesn't have a theme record, create one
if (!$theme_data) {
    $stmt = $conn->prepare("INSERT INTO themes (user_id, theme_color) VALUES (?, ?)");
    $default_theme = '#dc2626';
    $stmt->bind_param("is", $user_id, $default_theme);
    $stmt->execute();
    $stmt->close();
    $current_theme = $default_theme;
}

// Check if theme was just updated (must happen before theme color calculation)
if (isset($_GET['theme_updated']) && $_GET['theme_updated'] == '1') {
    // Refresh the theme data
    $stmt = $conn->prepare("SELECT theme_color FROM themes WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $current_theme = $row['theme_color'];
    }
    $stmt->close();
}

// Function to convert hex to RGB
function hexToRgb($hex) {
    $hex = str_replace('#', '', $hex);
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    return [$r, $g, $b];
}

// Function to darken a color
function darkenColor($hex, $percent = 20) {
    $rgb = hexToRgb($hex);
    $r = max(0, min(255, $rgb[0] - ($rgb[0] * $percent / 100)));
    $g = max(0, min(255, $rgb[1] - ($rgb[1] * $percent / 100)));
    $b = max(0, min(255, $rgb[2] - ($rgb[2] * $percent / 100)));
    return sprintf("#%02x%02x%02x", round($r), round($g), round($b));
}

// Calculate theme colors
$theme_rgb = hexToRgb($current_theme);
$theme_rgba_15 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.15)";
$theme_rgba_10 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.1)";
$theme_rgba_05 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.05)";
$theme_rgba_20 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.2)";
$theme_rgba_25 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.25)";
$theme_rgba_30 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.3)";
$theme_darker = darkenColor($current_theme, 15);

// Handle account update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_account'])) {
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    $errors = [];
    
    // Validate full name
    if (empty($full_name)) {
        $errors[] = "Full name is required.";
    } elseif (strlen($full_name) < 2) {
        $errors[] = "Full name must be at least 2 characters.";
    }
    
    // Validate email
    if (empty($email)) {
        $errors[] = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Please enter a valid email address.";
    }
    
    // Validate username
    if (empty($username)) {
        $errors[] = "Username is required.";
    } elseif (strlen($username) < 3) {
        $errors[] = "Username must be at least 3 characters.";
    } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
        $errors[] = "Username can only contain letters, numbers, and underscores.";
    }
    
    // Check if email or username is already taken by another user
    if (empty($errors)) {
        $stmt = $conn->prepare("SELECT id FROM users WHERE (email = ? OR username = ?) AND id != ?");
        $stmt->bind_param("ssi", $email, $username, $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $errors[] = "Email or username already exists. Please use different credentials.";
        }
        $stmt->close();
    }
    
    if (empty($errors)) {
        $email_changed = ($email !== $current_email);
        $verification_sent = false;
        
        // If email changed, generate verification token and send email
        if ($email_changed) {
            // Generate verification token
            $verification_token = bin2hex(random_bytes(32));
            $verification_expiry = time() + (24 * 60 * 60); // 24 hours
            
            // Check if email_verification_token column exists, if not add it
            $columns_check = $conn->query("SHOW COLUMNS FROM users LIKE 'email_verification_token'");
            if ($columns_check->num_rows == 0) {
                $conn->query("ALTER TABLE users ADD COLUMN email_verification_token VARCHAR(64) NULL AFTER reset_token_expiry");
                $conn->query("ALTER TABLE users ADD COLUMN email_verification_expiry INT(11) NULL AFTER email_verification_token");
            }
            
            // Send verification email
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'jibemolina@gmail.com';
                $mail->Password = 'ighnwwzekbxclvoe';
                $mail->SMTPSecure = 'tls';
                $mail->Port = 587;
                $mail->SMTPOptions = array(
                    'ssl' => array(
                        'verify_peer' => false,
                        'verify_peer_name' => false,
                        'allow_self_signed' => true
                    )
                );
                
                $mail->setFrom('jibemolina@gmail.com', 'Bizmo');
                $mail->addAddress($email, $full_name);
                
                $verification_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/verify_email.php?token=" . $verification_token;
                
                $mail->isHTML(true);
                $mail->Subject = 'Verify Your New Email Address';
                $mail->Body = "
                    <h2>Email Verification Required</h2>
                    <p>Hello {$full_name},</p>
                    <p>You have changed your email address to: <strong>{$email}</strong></p>
                    <p>Please click the link below to verify your new email address:</p>
                    <p><a href='{$verification_link}' style='background: #dc2626; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px; display: inline-block;'>Verify Email Address</a></p>
                    <p>Or copy and paste this link into your browser:</p>
                    <p>{$verification_link}</p>
                    <p>This link will expire in 24 hours.</p>
                    <p>If you did not request this change, please ignore this email.</p>
                ";
                
                $mail->send();
                $verification_sent = true;
            } catch (Exception $e) {
                $update_error = "Account updated, but verification email could not be sent. Error: " . $mail->ErrorInfo;
            }
        }
        
        // Update user data
        if (!empty($password)) {
            // Update with password
            if (strlen($password) < 6) {
                $errors[] = "Password must be at least 6 characters.";
            } else {
                $password_hash = password_hash($password, PASSWORD_DEFAULT);
                if ($email_changed && $verification_sent) {
                    // Update with new email, password, and set status to unverified
                    $status = 'unverified';
                    $stmt = $conn->prepare("UPDATE users SET full_name = ?, email = ?, username = ?, password = ?, status = ?, email_verification_token = ?, email_verification_expiry = ? WHERE id = ?");
                    $stmt->bind_param("ssssssii", $full_name, $email, $username, $password_hash, $status, $verification_token, $verification_expiry, $user_id);
                } else {
                    $stmt = $conn->prepare("UPDATE users SET full_name = ?, email = ?, username = ?, password = ? WHERE id = ?");
                    $stmt->bind_param("ssssi", $full_name, $email, $username, $password_hash, $user_id);
                }
            }
        } else {
            // Update without password
            if ($email_changed && $verification_sent) {
                // Update with new email and set status to unverified
                $status = 'unverified';
                $stmt = $conn->prepare("UPDATE users SET full_name = ?, email = ?, username = ?, status = ?, email_verification_token = ?, email_verification_expiry = ? WHERE id = ?");
                $stmt->bind_param("sssssii", $full_name, $email, $username, $status, $verification_token, $verification_expiry, $user_id);
            } else {
                $stmt = $conn->prepare("UPDATE users SET full_name = ?, email = ?, username = ? WHERE id = ?");
                $stmt->bind_param("sssi", $full_name, $email, $username, $user_id);
            }
        }
        
        if (isset($stmt) && $stmt->execute()) {
            // Update session data
            $_SESSION['user_name'] = $full_name;
            $_SESSION['user_email'] = $email;
            $_SESSION['user_username'] = $username;
            
            if ($email_changed && $verification_sent) {
                $update_success = "Account updated successfully! A verification email has been sent to your new email address. Please check your inbox and verify your email.";
                $email_verified = false;
            } else {
                $update_success = "Account updated successfully!";
            }
            $current_name = $full_name;
            $current_email = $email;
            $current_username = $username;
        } else {
            $update_error = "Error updating account. Please try again.";
        }
        if (isset($stmt)) {
            $stmt->close();
        }
    } else {
        $update_error = implode(" ", $errors);
    }
}

// Handle theme preference update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_theme'])) {
    $theme_color = trim($_POST['theme_color'] ?? '#dc2626');
    
    // Validate hex color
    if (!preg_match('/^#[a-fA-F0-9]{6}$/', $theme_color)) {
        $update_error = "Invalid theme color format.";
    } else {
        // Use INSERT ... ON DUPLICATE KEY UPDATE to insert or update theme
        $stmt = $conn->prepare("INSERT INTO themes (user_id, theme_color) VALUES (?, ?) ON DUPLICATE KEY UPDATE theme_color = ?");
        $stmt->bind_param("iss", $user_id, $theme_color, $theme_color);
        
        if ($stmt->execute()) {
            // Reload the page to apply the new theme immediately
            header("Location: settings.php?theme_updated=1");
            exit();
        } else {
            $update_error = "Error updating theme preference. Please try again.";
        }
        $stmt->close();
    }
}

// Set success message if theme was just updated
if (isset($_GET['theme_updated']) && $_GET['theme_updated'] == '1') {
    $update_success = "Theme preference updated successfully!";
}

// Get current profile picture
$current_profile_picture = null;
$profile_picture_path = null;
$stmt = $conn->prepare("SELECT profile_picture FROM profiles WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    $current_profile_picture = $row['profile_picture'];
    if ($current_profile_picture) {
        $profile_picture_path = $upload_dir . $current_profile_picture;
        if (!file_exists($profile_picture_path)) {
            $profile_picture_path = null;
        }
    }
}
$stmt->close();

// Handle profile picture upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK && !isset($_POST['delete_profile_picture'])) {
    $file = $_FILES['profile_picture'];
    $file_name = $file['name'];
    $file_tmp = $file['tmp_name'];
    $file_size = $file['size'];
    $file_error = $file['error'];
    
    // Validate file
    $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    $file_extension = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
    
    if (!in_array($file_extension, $allowed_extensions)) {
        $update_error = "Invalid file type. Only JPG, JPEG, PNG, GIF, and WEBP are allowed.";
    } elseif ($file_size > 5 * 1024 * 1024) { // 5MB limit
        $update_error = "File size too large. Maximum size is 5MB.";
    } else {
        // Generate unique filename
        $new_filename = 'profile_' . $user_id . '_' . time() . '.' . $file_extension;
        $upload_path = $upload_dir . $new_filename;
        
        // Delete old profile picture if exists
        if ($current_profile_picture && file_exists($upload_dir . $current_profile_picture)) {
            unlink($upload_dir . $current_profile_picture);
        }
        
        // Move uploaded file
        if (move_uploaded_file($file_tmp, $upload_path)) {
            // Update database
            $stmt = $conn->prepare("INSERT INTO profiles (user_id, profile_picture) VALUES (?, ?) ON DUPLICATE KEY UPDATE profile_picture = ?");
            $stmt->bind_param("iss", $user_id, $new_filename, $new_filename);
            
            if ($stmt->execute()) {
                $update_success = "Profile picture updated successfully!";
                $current_profile_picture = $new_filename;
                // Reload page to show new picture
                header("Location: settings.php?picture_updated=1");
                exit();
            } else {
                $update_error = "Error updating profile picture in database.";
                // Delete uploaded file if database update failed
                if (file_exists($upload_path)) {
                    unlink($upload_path);
                }
            }
            $stmt->close();
        } else {
            $update_error = "Error uploading file. Please try again.";
        }
    }
}

// Handle profile picture deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_profile_picture'])) {
    if ($current_profile_picture && file_exists($upload_dir . $current_profile_picture)) {
        unlink($upload_dir . $current_profile_picture);
    }
    
    $stmt = $conn->prepare("UPDATE profiles SET profile_picture = NULL WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    if ($stmt->execute()) {
        $update_success = "Profile picture deleted successfully!";
        $current_profile_picture = null;
        header("Location: settings.php?picture_deleted=1");
        exit();
    } else {
        $update_error = "Error deleting profile picture.";
    }
    $stmt->close();
}

// Refresh profile picture if just updated
if (isset($_GET['picture_updated']) || isset($_GET['picture_deleted'])) {
    $stmt = $conn->prepare("SELECT profile_picture FROM profiles WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $current_profile_picture = $row['profile_picture'];
        if ($current_profile_picture) {
            $profile_picture_path = $upload_dir . $current_profile_picture;
            if (!file_exists($profile_picture_path)) {
                $profile_picture_path = null;
            }
        } else {
            $profile_picture_path = null;
        }
    } else {
        $current_profile_picture = null;
        $profile_picture_path = null;
    }
    $stmt->close();
    
    if (isset($_GET['picture_updated'])) {
        $update_success = "Profile picture updated successfully!";
    } elseif (isset($_GET['picture_deleted'])) {
        $update_success = "Profile picture deleted successfully!";
    }
}

// Generate initials for avatar
function getInitials($name) {
    $words = explode(' ', trim($name));
    if (count($words) >= 2) {
        return strtoupper(substr($words[0], 0, 1) . substr($words[count($words) - 1], 0, 1));
    } else {
        return strtoupper(substr($name, 0, 2));
    }
}
$user_initials = getInitials($current_name);

// Ensure profile_picture_path is always set
if (!isset($profile_picture_path)) {
    $profile_picture_path = null;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bizmo – Settings</title>
    <meta name="description" content="Manage your account settings and preferences.">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #0b0b12;
            --text: #ffffff;
            --muted: #a2a3ad;
            --accent: <?php echo $current_theme; ?>;
            --accent-700: <?php echo $theme_darker; ?>;
            --surface: #111118;
            --border: rgba(255,255,255,0.08);
            --soft-accent: <?php echo $theme_rgba_15; ?>;
        }

        * { box-sizing: border-box; }
        html, body { height: 100%; }
        body {
            margin: 0;
            font-family: 'Inter', ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial;
            background: linear-gradient(180deg, #0c0c14 0%, #0c0c14 55%, #0c0c14 100%);
            color: var(--text);
        }

        /* Header */
        .header {
            position: sticky; top: 0; z-index: 30;
            backdrop-filter: saturate(180%) blur(20px);
            background: rgba(10,10,15,0.8);
            border-bottom: 1px solid var(--border);
            box-shadow: 0 4px 24px rgba(0,0,0,0.2);
        }
        .header-content {
            max-width: 1400px; margin: 0 auto; padding: 0 24px;
            display: flex; align-items: center; justify-content: space-between;
            padding-top: 18px; padding-bottom: 18px;
        }
        .brand {
            display: inline-flex; align-items: center; gap: 12px;
            font-weight: 800; font-size: 18px; color: var(--text);
            text-decoration: none; transition: transform .2s ease;
        }
        .brand:hover { transform: scale(1.02); }
        .logo {
            background: linear-gradient(135deg, <?php echo $theme_rgba_10; ?>, <?php echo $theme_rgba_05; ?>);
            box-shadow: 0 4px 12px <?php echo $theme_rgba_15; ?>;
            border: 1px solid <?php echo $theme_rgba_20; ?>;
            width: 50px; height: 50px; border-radius: 12px;
            display: grid; place-items: center;
            transition: all .3s ease;
        }
        .logo:hover { transform: rotate(5deg) scale(1.05); }
        .logo svg, .logo img { width: 50px; height: 50px; display: block; }

        .header-right { display: flex; align-items: center; gap: 12px; }
        .search-btn, .notif-btn {
            width: 44px; height: 44px; border-radius: 12px;
            background: rgba(255,255,255,0.04);
            border: 1px solid var(--border);
            display: grid; place-items: center; cursor: pointer;
            color: var(--text); transition: all .25s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
        }
        .search-btn:hover, .notif-btn:hover {
            background: rgba(255,255,255,0.08);
            border-color: var(--accent);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px <?php echo $theme_rgba_20; ?>;
        }
        .notif-btn::after {
            content: ''; position: absolute; top: 8px; right: 8px;
            width: 8px; height: 8px; border-radius: 50%;
            background: var(--accent); box-shadow: 0 0 8px var(--accent);
        }
        .user-menu {
            display: flex; align-items: center; gap: 12px; cursor: pointer;
            padding: 8px 14px 8px 8px; border-radius: 999px;
            background: rgba(255,255,255,0.04);
            border: 1px solid var(--border);
            transition: all .25s cubic-bezier(0.4, 0, 0.2, 1);
            color: #ffffff;
            position: relative;
        }
        .user-menu:hover {
            background: rgba(255,255,255,0.08);
            border-color: var(--accent);
            transform: translateY(-1px);
        }
        .user-menu span {
            color: #ffffff !important;
            font-weight: 600;
            font-size: 14px;
        }
        .user-menu svg {
            color: #ffffff;
            stroke: #ffffff;
        }
        .user-avatar {
            width: 36px; height: 36px; border-radius: 999px;
            background: linear-gradient(135deg, var(--accent), var(--accent-700));
            display: grid; place-items: center;
            font-weight: 700; font-size: 14px;
            color: #ffffff;
            box-shadow: 0 4px 12px <?php echo $theme_rgba_30; ?>;
        }
        .user-dropdown {
            display: none;
            position: absolute;
            top: calc(100% + 8px);
            right: 0;
            background: rgba(10,10,15,0.95);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 8px;
            min-width: 200px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.4);
            z-index: 1000;
        }
        .user-dropdown > div {
            padding: 12px;
            border-bottom: 1px solid var(--border);
        }
        .user-dropdown > div > div:first-child {
            font-weight: 600;
            font-size: 14px;
            margin-bottom: 4px;
            color: var(--text);
        }
        .user-dropdown > div > div:last-child {
            font-size: 12px;
            color: var(--muted);
        }
        .user-dropdown a {
            display: block;
            padding: 12px;
            color: var(--text);
            text-decoration: none;
            border-radius: 8px;
            transition: background 0.2s ease;
            font-size: 14px;
            font-weight: 600;
        }
        .user-dropdown a:hover {
            background: rgba(255,255,255,0.05);
        }

        /* Layout */
        .dashboard-layout {
            display: grid; grid-template-columns: 280px 1fr;
            max-width: 1400px; margin: 0 auto;
            min-height: calc(100vh - 74px);
        }

        /* Sidebar */
        .sidebar {
            padding: 28px 20px; border-right: 1px solid var(--border);
            background: rgba(10,10,15,0.6);
            backdrop-filter: blur(10px);
        }
        .sidebar-nav { display: flex; flex-direction: column; gap: 4px; }
        .nav-item {
            display: flex; align-items: center; gap: 14px;
            padding: 14px 16px; border-radius: 14px;
            color: var(--muted); text-decoration: none;
            font-weight: 600; font-size: 15px;
            transition: all .25s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
        }
        .nav-item:hover {
            background: rgba(255,255,255,0.05);
            color: var(--text);
            transform: translateX(4px);
        }
        .nav-item.active {
            background: linear-gradient(135deg, <?php echo $theme_rgba_20; ?>, <?php echo $theme_rgba_10; ?>);
            color: var(--text);
            border: 1px solid <?php echo $theme_rgba_30; ?>;
            box-shadow: 0 4px 12px <?php echo $theme_rgba_15; ?>;
        }
        .nav-item.active::before {
            content: ''; position: absolute; left: 0; top: 50%;
            transform: translateY(-50%);
            width: 3px; height: 60%; border-radius: 0 4px 4px 0;
            background: var(--accent);
        }
        .nav-icon {
            width: 22px; height: 22px; display: grid; place-items: center;
            font-size: 20px;
        }
        .nav-icon img,
        .nav-icon svg {
            width: 20px;
            height: 20px;
            display: block;
            object-fit: contain;
            filter: brightness(0) invert(1);
            opacity: 0.75;
            transition: opacity 0.2s ease, filter 0.2s ease;
        }
        .nav-item:hover .nav-icon img,
        .nav-item:hover .nav-icon svg,
        .nav-item.active .nav-icon img,
        .nav-item.active .nav-icon svg {
            opacity: 1;
        }
        .nav-item.active .nav-icon img,
        .nav-item.active .nav-icon svg {
            filter: brightness(0) invert(1) drop-shadow(0 0 6px <?php echo $theme_rgba_25; ?>);
        }

        /* Main Content */
        .main-content { padding: 40px; }
        .page-header { margin-bottom: 40px; }
        .page-title {
            font-size: 36px; font-weight: 900; margin: 0 0 10px;
            background: linear-gradient(135deg, #fff, rgba(255,255,255,0.8));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .page-subtitle {
            color: var(--muted); font-size: 17px; margin: 0;
            font-weight: 500;
        }

        /* Settings Sections */
        .settings-section {
            background: linear-gradient(135deg, rgba(255,255,255,0.05), rgba(255,255,255,0.02));
            border: 1px solid var(--border);
            border-radius: 20px; padding: 32px;
            margin-bottom: 24px;
        }
        .section-title {
            font-size: 24px; font-weight: 800; margin: 0 0 24px;
            letter-spacing: -0.5px;
        }
        .form-group {
            margin-bottom: 24px;
        }
        .form-label {
            display: block; margin-bottom: 8px;
            font-weight: 600; font-size: 14px;
            color: var(--text);
        }
        .form-input {
            width: 100%; padding: 12px 16px;
            background: rgba(255,255,255,0.04);
            border: 1px solid var(--border);
            border-radius: 12px;
            color: var(--text);
            font-size: 15px; font-family: inherit;
            outline: none; transition: all .25s ease;
        }
        .form-input:focus {
            border-color: var(--accent);
            background: rgba(255,255,255,0.08);
            box-shadow: 0 0 0 3px <?php echo $theme_rgba_10; ?>;
        }
        .form-input::placeholder {
            color: var(--muted);
        }
        .form-help {
            font-size: 13px; color: var(--muted);
            margin-top: 6px;
        }
        .btn {
            padding: 12px 24px; border-radius: 12px;
            border: 1px solid transparent;
            background: linear-gradient(135deg, var(--accent), var(--accent-700));
            color: #fff; font-weight: 700; font-size: 14px;
            cursor: pointer; text-decoration: none;
            display: inline-flex; align-items: center; gap: 8px;
            transition: all .25s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 4px 12px <?php echo $theme_rgba_30; ?>;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px <?php echo $theme_rgba_20; ?>;
        }
        .btn:disabled {
            opacity: 0.5; cursor: not-allowed;
        }
        .alert {
            padding: 14px 18px; border-radius: 12px;
            margin-bottom: 24px; font-size: 14px;
            font-weight: 600;
        }
        .alert-success {
            background: rgba(34,197,94,0.15);
            border: 1px solid rgba(34,197,94,0.3);
            color: #4ade80;
        }
        .alert-error {
            background: rgba(239,68,68,0.15);
            border: 1px solid rgba(239,68,68,0.3);
            color: #f87171;
        }

        /* Theme Color Picker */
        .theme-colors {
            display: grid; grid-template-columns: repeat(auto-fill, minmax(60px, 1fr));
            gap: 16px; margin-top: 16px;
        }
        .theme-color-option {
            width: 60px; height: 60px; border-radius: 12px;
            cursor: pointer; transition: all .25s ease;
            border: 3px solid transparent;
            position: relative;
        }
        .theme-color-option:hover {
            transform: scale(1.1);
        }
        .theme-color-option.active {
            border-color: var(--text);
            box-shadow: 0 0 0 3px rgba(255,255,255,0.2);
        }
        .theme-color-option input[type="radio"] {
            position: absolute; opacity: 0;
            width: 0; height: 0;
        }
        .custom-color-input {
            width: 100%; padding: 12px 16px;
            background: rgba(255,255,255,0.04);
            border: 1px solid var(--border);
            border-radius: 12px;
            color: var(--text);
            font-size: 15px; font-family: inherit;
            outline: none; transition: all .25s ease;
            margin-top: 16px;
        }
        .custom-color-input:focus {
            border-color: var(--accent);
            background: rgba(255,255,255,0.08);
            box-shadow: 0 0 0 3px <?php echo $theme_rgba_10; ?>;
        }

        /* Profile Picture */
        .profile-picture-section {
            display: flex;
            align-items: center;
            gap: 24px;
            margin-bottom: 24px;
            padding: 24px;
            background: rgba(255,255,255,0.02);
            border: 1px solid var(--border);
            border-radius: 16px;
        }
        .profile-picture-preview {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--border);
            background: linear-gradient(135deg, var(--accent), var(--accent-700));
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-weight: 700;
            font-size: 36px;
            flex-shrink: 0;
            cursor: pointer;
            position: relative;
            transition: all .3s ease;
        }
        .profile-picture-preview:hover {
            transform: scale(1.05);
            border-color: var(--accent);
            box-shadow: 0 0 20px <?php echo $theme_rgba_30; ?>;
        }
        .profile-picture-preview:hover::after {
            content: '📷';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border-radius: 50%;
            background: rgba(0,0,0,0.6);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            backdrop-filter: blur(4px);
        }
        .profile-picture-preview img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
        }
        .profile-picture-actions {
            flex: 1;
        }
        .btn-danger {
            padding: 10px 20px;
            border-radius: 8px;
            border: 1px solid rgba(239,68,68,0.3);
            background: rgba(239,68,68,0.15);
            color: #f87171;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: all .25s ease;
        }
        .btn-danger:hover {
            background: rgba(239,68,68,0.25);
            border-color: rgba(239,68,68,0.5);
        }

        /* Responsive */
        /* Logout Modal */
        .logout-modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.75);
            backdrop-filter: blur(4px);
            z-index: 10000;
            align-items: center;
            justify-content: center;
            padding: 20px;
            animation: fadeIn 0.3s ease;
        }
        .logout-modal-overlay.active {
            display: flex;
        }
        .logout-modal {
            background: rgba(10,10,15,0.98);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 32px;
            max-width: 400px;
            width: 100%;
            position: relative;
            box-shadow: 0 40px 120px rgba(0,0,0,0.5);
            animation: slideUp 0.3s ease;
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        .logout-modal-icon {
            width: 64px;
            height: 64px;
            margin: 0 auto 20px;
            background: rgba(239, 68, 68, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .logout-modal-icon svg {
            width: 32px;
            height: 32px;
            color: #ef4444;
        }
        .logout-modal-header {
            text-align: center;
            margin-bottom: 20px;
        }
        .logout-modal-title {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 8px;
            color: var(--text);
        }
        .logout-modal-message {
            color: var(--muted);
            font-size: 14px;
            line-height: 1.6;
        }
        .logout-modal-actions {
            display: flex;
            gap: 12px;
            margin-top: 24px;
        }
        .btn-modal {
            flex: 1;
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
        }
        .btn-modal-cancel {
            background: rgba(255,255,255,0.05);
            border: 1px solid var(--border);
            color: var(--text);
        }
        .btn-modal-cancel:hover {
            background: rgba(255,255,255,0.08);
        }
        .btn-modal-logout {
            background: #ef4444;
            color: white;
        }
        .btn-modal-logout:hover {
            background: #dc2626;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
        }

        @media (max-width: 1024px) {
            .dashboard-layout { grid-template-columns: 1fr; }
            .sidebar { display: none; }
        }
        @media (max-width: 720px) {
            .main-content { padding: 24px; }
            .page-title { font-size: 28px; }
            .settings-section { padding: 24px; }
            .theme-colors { grid-template-columns: repeat(auto-fill, minmax(50px, 1fr)); }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-content">
            <a href="dashboard.php" class="brand">
                <div class="logo" aria-label="Bizmo logo">
                    <img src="icons/bizmo.png" alt="" width="50" height="50" />
                </div>
                <span>Bizmo</span>
            </a>
            <div class="header-right">
                <div class="user-menu" id="userMenu">
                    <div class="user-avatar" style="<?php if ($profile_picture_path && file_exists($profile_picture_path)): ?>background-image: url('<?php echo htmlspecialchars($profile_picture_path); ?>'); background-size: cover; background-position: center;<?php endif; ?>">
                        <?php if (!($profile_picture_path && file_exists($profile_picture_path))): ?>
                            <?php echo htmlspecialchars($user_initials); ?>
                        <?php endif; ?>
                    </div>
                    <span><?php echo htmlspecialchars($current_name); ?></span>
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                    </svg>
                    <div class="user-dropdown" id="userDropdown">
                        <div>
                            <div><?php echo htmlspecialchars($current_name); ?></div>
                            <div><?php echo htmlspecialchars($current_email); ?></div>
                        </div>
                        <a href="#" id="logoutBtn">
                            <span style="margin-right: 8px;">🚪</span> Logout
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <div class="dashboard-layout">
        <aside class="sidebar">
            <nav class="sidebar-nav">
                <a href="dashboard.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/dashboard.png" alt="" loading="lazy">
                    </span>
                    <span>Dashboard</span>
                </a>
                <a href="decks.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/cards.png" alt="" loading="lazy">
                    </span>
                    <span>My Decks</span>
                </a>
                <a href="progress.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/progress.png" alt="" loading="lazy">
                    </span>
                    <span>Progress</span>
                </a>
                <a href="favorites.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/favorite.png" alt="" loading="lazy">
                    </span>
                    <span>Favorites</span>
                </a>
                <a href="friends.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/friends.png" alt="" loading="lazy">
                    </span>
                    <span>Friends</span>
                </a>
                <a href="reports.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                        </svg>
                    </span>
                    <span>Reports</span>
                </a>
                <a href="planner.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/planner.png" alt="" loading="lazy">
                    </span>
                    <span>Study Planner</span>
                </a>
                <a href="settings.php" class="nav-item active">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/settings.png" alt="" loading="lazy">
                    </span>
                    <span>Settings</span>
                </a>
            </nav>
        </aside>

        <main class="main-content">
            <div class="page-header">
                <h1 class="page-title">Settings</h1>
                <p class="page-subtitle">Manage your account and preferences</p>
            </div>

            <?php if ($update_success): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($update_success); ?></div>
            <?php endif; ?>
            <?php if ($update_error): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($update_error); ?></div>
            <?php endif; ?>

            <!-- Email Verification Notice (only show if not verified) -->
            <?php if (!$email_verified): ?>
                <div class="alert" id="emailVerificationNotice" style="background: rgba(251,191,36,0.15); border: 1px solid rgba(251,191,36,0.3); color: #fbbf24; margin-bottom: 24px; position: relative; padding-right: 40px;">
                    <button onclick="document.getElementById('emailVerificationNotice').style.display='none'" style="position: absolute; top: 8px; right: 8px; background: transparent; border: none; color: #fbbf24; font-size: 20px; cursor: pointer; padding: 4px 8px; line-height: 1;">&times;</button>
                    <strong>⚠️ Email Not Verified</strong><br>
                    Your email address has not been verified. Please check your inbox for a verification link. If you didn't receive it, changing your email will send a new verification link.
                </div>
            <?php endif; ?>

            <!-- Account Settings -->
            <div class="settings-section">
                <h2 class="section-title">Account</h2>
                
                <!-- Profile Picture Section -->
                <div class="profile-picture-section">
                    <form method="POST" action="" enctype="multipart/form-data" id="profilePictureForm">
                        <input type="file" name="profile_picture" id="profile_picture" accept="image/jpeg,image/jpg,image/png,image/gif,image/webp" style="display: none;" onchange="handleProfilePictureChange(this)">
                        <div class="profile-picture-preview" id="profilePreview" onclick="document.getElementById('profile_picture').click()" title="Click to change profile picture">
                            <?php if ($profile_picture_path && file_exists($profile_picture_path)): ?>
                                <img src="<?php echo htmlspecialchars($profile_picture_path); ?>" alt="Profile Picture" id="profileImg">
                            <?php else: ?>
                                <?php echo htmlspecialchars($user_initials); ?>
                            <?php endif; ?>
                        </div>
                    </form>
                    <div class="profile-picture-actions">
                        <div style="margin-bottom: 12px;">
                            <button type="button" onclick="document.getElementById('profile_picture').click()" class="btn">Change Profile Picture</button>
                            <?php if ($current_profile_picture): ?>
                                <form method="POST" action="" style="display: inline-block; margin-left: 12px;">
                                    <button type="submit" name="delete_profile_picture" class="btn-danger" onclick="return confirm('Are you sure you want to delete your profile picture?')">Delete Picture</button>
                                </form>
                            <?php endif; ?>
                        </div>
                        <div class="form-help">
                            Click the profile picture or button above to change it. Supported formats: JPG, PNG, GIF, WEBP. Maximum size: 5MB.
                        </div>
                    </div>
                </div>
                
                <form method="POST" action="">
                    <div class="form-group">
                        <label class="form-label" for="full_name">Full Name</label>
                        <input 
                            type="text" 
                            id="full_name" 
                            name="full_name" 
                            class="form-input" 
                            value="<?php echo htmlspecialchars($current_name); ?>"
                            required
                        />
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="email">Email</label>
                        <input 
                            type="email" 
                            id="email" 
                            name="email" 
                            class="form-input" 
                            value="<?php echo htmlspecialchars($current_email); ?>"
                            required
                        />
                        <?php if (!$email_verified): ?>
                            <div class="form-help" style="color: #fbbf24;">
                                ⚠️ Your email is not verified. Changing your email will send a new verification link.
                            </div>
                        <?php else: ?>
                            <div class="form-help">
                                ✅ Email verified. Changing your email will require verification.
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="username">Username</label>
                        <input 
                            type="text" 
                            id="username" 
                            name="username" 
                            class="form-input" 
                            value="<?php echo htmlspecialchars($current_username); ?>"
                            required
                        />
                        <div class="form-help">Username can only contain letters, numbers, and underscores.</div>
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="password">New Password (leave blank to keep current)</label>
                        <input 
                            type="password" 
                            id="password" 
                            name="password" 
                            class="form-input" 
                            placeholder="Enter new password"
                        />
                        <div class="form-help">Password must be at least 6 characters long.</div>
                    </div>
                    <button type="submit" name="update_account" class="btn">Save Changes</button>
                </form>
            </div>

            <!-- Preferences -->
            <div class="settings-section">
                <h2 class="section-title">Preferences</h2>
                <form method="POST" action="">
                    <div class="form-group">
                        <label class="form-label">Theme Color</label>
                        <div class="theme-colors">
                            <label class="theme-color-option <?php echo $current_theme === '#dc2626' ? 'active' : ''; ?>" style="background: #dc2626;">
                                <input type="radio" name="theme_color" value="#dc2626" <?php echo $current_theme === '#dc2626' ? 'checked' : ''; ?>>
                            </label>
                            <label class="theme-color-option <?php echo $current_theme === '#3b82f6' ? 'active' : ''; ?>" style="background: #3b82f6;">
                                <input type="radio" name="theme_color" value="#3b82f6" <?php echo $current_theme === '#3b82f6' ? 'checked' : ''; ?>>
                            </label>
                            <label class="theme-color-option <?php echo $current_theme === '#10b981' ? 'active' : ''; ?>" style="background: #10b981;">
                                <input type="radio" name="theme_color" value="#10b981" <?php echo $current_theme === '#10b981' ? 'checked' : ''; ?>>
                            </label>
                            <label class="theme-color-option <?php echo $current_theme === '#f59e0b' ? 'active' : ''; ?>" style="background: #f59e0b;">
                                <input type="radio" name="theme_color" value="#f59e0b" <?php echo $current_theme === '#f59e0b' ? 'checked' : ''; ?>>
                            </label>
                            <label class="theme-color-option <?php echo $current_theme === '#8b5cf6' ? 'active' : ''; ?>" style="background: #8b5cf6;">
                                <input type="radio" name="theme_color" value="#8b5cf6" <?php echo $current_theme === '#8b5cf6' ? 'checked' : ''; ?>>
                            </label>
                            <label class="theme-color-option <?php echo $current_theme === '#ec4899' ? 'active' : ''; ?>" style="background: #ec4899;">
                                <input type="radio" name="theme_color" value="#ec4899" <?php echo $current_theme === '#ec4899' ? 'checked' : ''; ?>>
                            </label>
                        </div>
                        <input 
                            type="text" 
                            name="theme_color" 
                            id="custom_theme_color"
                            class="custom-color-input" 
                            placeholder="#dc2626"
                            value="<?php echo htmlspecialchars($current_theme); ?>"
                            pattern="^#[a-fA-F0-9]{6}$"
                        />
                        <div class="form-help">Enter a custom hex color code (e.g., #dc2626) or select from presets above.</div>
                    </div>
                    <button type="submit" name="update_theme" class="btn">Save Theme</button>
                </form>
            </div>
        </main>
    </div>

    <script>
        // Theme color picker interaction
        document.querySelectorAll('.theme-color-option input[type="radio"]').forEach(radio => {
            radio.addEventListener('change', function() {
                document.getElementById('custom_theme_color').value = this.value;
                document.querySelectorAll('.theme-color-option').forEach(opt => {
                    opt.classList.remove('active');
                });
                this.closest('.theme-color-option').classList.add('active');
            });
        });

        // Custom color input
        const customColorInput = document.getElementById('custom_theme_color');
        customColorInput.addEventListener('input', function() {
            const value = this.value;
            if (/^#[a-fA-F0-9]{6}$/.test(value)) {
                // Update active state if it matches a preset
                document.querySelectorAll('.theme-color-option input[type="radio"]').forEach(radio => {
                    if (radio.value === value) {
                        radio.checked = true;
                        document.querySelectorAll('.theme-color-option').forEach(opt => {
                            opt.classList.remove('active');
                        });
                        radio.closest('.theme-color-option').classList.add('active');
                    }
                });
            }
        });

        // Auto-dismiss alerts after 5 seconds
        setTimeout(function() {
            document.querySelectorAll('.alert').forEach(alert => {
                alert.style.opacity = '0';
                alert.style.transition = 'opacity 0.5s ease';
                setTimeout(() => alert.remove(), 500);
            });
        }, 5000);

        // User menu dropdown toggle
        const userMenu = document.getElementById('userMenu');
        const userDropdown = document.getElementById('userDropdown');

        if (userMenu && userDropdown) {
            userMenu.addEventListener('click', function(e) {
                e.stopPropagation();
                const isVisible = userDropdown.style.display === 'block';
                userDropdown.style.display = isVisible ? 'none' : 'block';
            });

            // Close dropdown when clicking outside
            document.addEventListener('click', function(e) {
                if (!userMenu.contains(e.target)) {
                    userDropdown.style.display = 'none';
                }
            });
        }

        // Profile picture change handler
        function handleProfilePictureChange(input) {
            if (input.files && input.files[0]) {
                // Validate file size
                if (input.files[0].size > 5 * 1024 * 1024) {
                    alert('File size too large. Maximum size is 5MB.');
                    input.value = '';
                    return;
                }
                
                // Validate file type
                const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
                if (!allowedTypes.includes(input.files[0].type)) {
                    alert('Invalid file type. Only JPG, PNG, GIF, and WEBP are allowed.');
                    input.value = '';
                    return;
                }
                
                // Show preview
                const reader = new FileReader();
                reader.onload = function(e) {
                    const preview = document.getElementById('profilePreview');
                    preview.innerHTML = '<img src="' + e.target.result + '" alt="Profile Picture Preview" id="profileImg" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;">';
                };
                reader.readAsDataURL(input.files[0]);
                
                // Auto-submit form
                document.getElementById('profilePictureForm').submit();
            }
        }
    </script>

    <!-- Logout Confirmation Modal -->
    <div class="logout-modal-overlay" id="logoutModal">
        <div class="logout-modal">
            <div class="logout-modal-icon">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                </svg>
            </div>
            <div class="logout-modal-header">
                <h3 class="logout-modal-title">Confirm Logout</h3>
                <p class="logout-modal-message">Are you sure you want to logout? You will need to login again to access your account.</p>
            </div>
            <div class="logout-modal-actions">
                <button class="btn-modal btn-modal-cancel" id="logoutCancelBtn">Cancel</button>
                <button class="btn-modal btn-modal-logout" id="logoutConfirmBtn">Logout</button>
            </div>
        </div>
    </div>

    <script>
        // Logout Modal - Initialize after modal HTML is in DOM
        document.addEventListener('DOMContentLoaded', function() {
            const logoutBtn = document.getElementById('logoutBtn');
            const logoutModal = document.getElementById('logoutModal');
            const logoutConfirmBtn = document.getElementById('logoutConfirmBtn');
            const logoutCancelBtn = document.getElementById('logoutCancelBtn');

            if (logoutBtn) {
                logoutBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    if (logoutModal) {
                        logoutModal.classList.add('active');
                    }
                    // Close user dropdown when opening logout modal
                    const userDropdown = document.getElementById('userDropdown');
                    if (userDropdown) {
                        userDropdown.style.display = 'none';
                    }
                });
            }

            if (logoutCancelBtn) {
                logoutCancelBtn.addEventListener('click', function() {
                    if (logoutModal) {
                        logoutModal.classList.remove('active');
                    }
                });
            }

            if (logoutConfirmBtn) {
                logoutConfirmBtn.addEventListener('click', function() {
                    window.location.href = 'dashboard.php?logout=1';
                });
            }

            if (logoutModal) {
                logoutModal.addEventListener('click', function(e) {
                    if (e.target === logoutModal) {
                        logoutModal.classList.remove('active');
                    }
                });
            }

            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && logoutModal && logoutModal.classList.contains('active')) {
                    logoutModal.classList.remove('active');
                }
            });
        });
    </script>
</body>
</html>


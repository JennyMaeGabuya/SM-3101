<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Include PHPMailer files
require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

// When form is submitted
if (isset($_POST['send_otp'])) {
    $email = $_POST['email'];
    $otp = rand(100000, 999999); // generate 6-digit OTP
    $_SESSION['otp'] = $otp;
    $_SESSION['email'] = $email;
    $_SESSION['otp_expire'] = time() + 300; // 5 min expiry

    $mail = new PHPMailer(true);

    try {
        // SMTP settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'jibemolina@gmail.com'; // your Gmail
        $mail->Password   = 'ighnwwzekbxclvoe'; // 16-char app password
        $mail->SMTPSecure = 'tls';
        $mail->Port       = 587;
        
        // Fix SSL certificate verification issue
        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        );

        // Email content
        $mail->setFrom('jibemolina@gmail.com', 'AirCasa OTP System');
        $mail->addAddress($email);
        $mail->isHTML(true);
        $mail->Subject = 'Your OTP Verification Code';
        $mail->Body    = "
            <p>Hello,</p>
            <p>Your One-Time Password (OTP) is: <b>$otp</b></p>
            <p>This code will expire in 5 minutes.</p>
        ";
        $mail->AltBody = "Your OTP is $otp. It will expire in 5 minutes.";

        $mail->send();
        echo "<script>alert('OTP has been sent to $email'); window.location='verify_otp.php';</script>";
    } catch (Exception $e) {
        echo "Mailer Error: {$mail->ErrorInfo}";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Send OTP</title>
</head>
<body>
    <h2>Send OTP to Email</h2>
    <form method="POST">
        <input type="email" name="email" placeholder="Enter your email" required>
        <button type="submit" name="send_otp">Send OTP</button>
    </form>
</body>
</html>

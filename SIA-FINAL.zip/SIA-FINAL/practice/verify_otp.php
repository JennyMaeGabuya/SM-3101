<?php
session_start();

if (isset($_POST['verify_otp'])) {
    $input_otp = $_POST['otp'];
    $stored_otp = $_SESSION['otp'] ?? null;
    $email = $_SESSION['email'] ?? '';
    $expiry = $_SESSION['otp_expire'] ?? 0;

    if (!$stored_otp) {
        echo "<script>alert('No OTP found. Please request again.'); window.location='send_otp.php';</script>";
        exit;
    }

    if (time() > $expiry) {
        unset($_SESSION['otp']);
        echo "<script>alert('OTP expired. Please request again.'); window.location='send_otp.php';</script>";
        exit;
    }

    if ($input_otp == $stored_otp) {
        unset($_SESSION['otp']); // clear OTP after success
        echo "<h2>✅ OTP Verified Successfully for $email</h2>";
    } else {
        echo "<script>alert('Incorrect OTP! Try again.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Verify OTP</title>
</head>
<body>
    <h2>Verify OTP</h2>
    <form method="POST">
        <input type="text" name="otp" placeholder="Enter 6-digit OTP" required>
        <button type="submit" name="verify_otp">Verify</button>
    </form>
</body>
</html>

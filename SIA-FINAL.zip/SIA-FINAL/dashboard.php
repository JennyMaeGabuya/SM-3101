<?php
session_start();
require_once 'config.php';

if (!function_exists('ensureFavoritesTable')) {
    function ensureFavoritesTable(mysqli $conn) {
        $conn->query("
            CREATE TABLE IF NOT EXISTS `favorites` (
                `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `user_id` INT NOT NULL,
                `deck_id` INT UNSIGNED NOT NULL,
                `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                UNIQUE KEY `unique_favorite` (`user_id`, `deck_id`),
                KEY `idx_favorites_user` (`user_id`),
                KEY `idx_favorites_deck` (`deck_id`),
                CONSTRAINT `fk_favorites_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
                CONSTRAINT `fk_favorites_deck` FOREIGN KEY (`deck_id`) REFERENCES `decks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
    }
}

if (!function_exists('buildDeckIconSrc')) {
    function buildDeckIconSrc($iconValue) {
        if ($iconValue === null || $iconValue === '') {
            return '';
        }
        if (strpos($iconValue, 'data:') === 0) {
            return $iconValue;
        }
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = $finfo ? finfo_buffer($finfo, $iconValue) : null;
        if ($finfo) {
            finfo_close($finfo);
        }
        if (!$mime) {
            $mime = 'image/png';
        }
        return 'data:' . $mime . ';base64,' . base64_encode($iconValue);
    }
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get user information from session
$user_name = $_SESSION['user_name'] ?? 'User';
$user_email = $_SESSION['user_email'] ?? '';
$user_username = $_SESSION['user_username'] ?? '';
$user_id = $_SESSION['user_id'] ?? null;

if ($user_id) {
    ensureFavoritesTable($conn);
}

// Get profile picture
$profile_picture_path = null;
$upload_dir = 'uploads/profiles/';
if ($user_id) {
    $stmt = $conn->prepare("SELECT profile_picture FROM profiles WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $profile_filename = $row['profile_picture'] ?? null;
        if (!empty($profile_filename)) {
            $candidate_path = $upload_dir . $profile_filename;
            $filesystem_path = __DIR__ . '/' . $candidate_path;
            if (file_exists($filesystem_path)) {
                $profile_picture_path = $candidate_path;
            }
        }
    }
    $stmt->close();
}

// Get user's theme color from themes table
$user_theme_color = '#dc2626'; // default
if ($user_id) {
    $stmt = $conn->prepare("SELECT theme_color FROM themes WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $user_theme_color = $row['theme_color'];
    }
    $stmt->close();
}

// Function to convert hex to RGB
function hexToRgb($hex) {
    $hex = str_replace('#', '', $hex);
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    return [$r, $g, $b];
}

// Function to darken a color
function darkenColor($hex, $percent = 20) {
    $rgb = hexToRgb($hex);
    $r = max(0, min(255, $rgb[0] - ($rgb[0] * $percent / 100)));
    $g = max(0, min(255, $rgb[1] - ($rgb[1] * $percent / 100)));
    $b = max(0, min(255, $rgb[2] - ($rgb[2] * $percent / 100)));
    return sprintf("#%02x%02x%02x", round($r), round($g), round($b));
}

// Calculate theme colors
$theme_rgb = hexToRgb($user_theme_color);
$theme_rgba_15 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.15)";
$theme_rgba_10 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.1)";
$theme_rgba_05 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.05)";
$theme_rgba_20 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.2)";
$theme_rgba_25 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.25)";
$theme_rgba_30 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.3)";
$theme_rgba_50 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.5)";
$theme_darker = darkenColor($user_theme_color, 15);

// Generate initials for avatar
function getInitials($name) {
    $words = explode(' ', trim($name));
    if (count($words) >= 2) {
        return strtoupper(substr($words[0], 0, 1) . substr($words[count($words) - 1], 0, 1));
    } else {
        return strtoupper(substr($name, 0, 2));
    }
}
$user_initials = getInitials($user_name);

// Handle logout
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: login.php");
    exit();
}

// Handle notification dismissal
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['dismiss_notification'])) {
    $notif_id = $_POST['notif_id'] ?? '';
    if (!empty($notif_id)) {
        if (!isset($_SESSION['dismissed_notifications'])) {
            $_SESSION['dismissed_notifications'] = [];
        }
        if (!in_array($notif_id, $_SESSION['dismissed_notifications'])) {
            $_SESSION['dismissed_notifications'][] = $notif_id;
        }
        
        // Return JSON response for AJAX
        if (isset($_POST['ajax'])) {
            // Explicitly save session before sending AJAX response
            session_write_close();
            header('Content-Type: application/json');
            echo json_encode(['success' => true]);
            exit();
        }
        // Otherwise redirect back
        header("Location: " . strtok($_SERVER['REQUEST_URI'], '?'));
        exit();
    }
}

// --- Stats helpers ---
function tableExists(mysqli $conn, $table) {
    $table = $conn->real_escape_string($table);
    $res = $conn->query("SHOW TABLES LIKE '{$table}'");
    return $res && $res->num_rows > 0;
}

function columnExists(mysqli $conn, $table, $column) {
    $table = $conn->real_escape_string($table);
    $column = $conn->real_escape_string($column);
    $res = $conn->query("SHOW COLUMNS FROM `{$table}` LIKE '{$column}'");
    return $res && $res->num_rows > 0;
}

// Total decks
$stat_total_decks = 0;
$stat_decks_week_delta = 0;
if (tableExists($conn, 'decks')) {
    $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM decks WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $stat_total_decks = (int)($res['c'] ?? 0);
    $stmt->close();

    if (columnExists($conn, 'decks', 'created_at')) {
        $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM decks WHERE user_id = ? AND created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_assoc();
        $stat_decks_week_delta = (int)($res['c'] ?? 0);
        $stmt->close();
    }
}

// Cards studied (total and today)
$stat_cards_studied_total = 0;
$stat_cards_studied_today = 0;
$logsTable = null;
foreach (['card_reviews', 'reviews', 'study_logs'] as $candidate) {
    if (tableExists($conn, $candidate)) { $logsTable = $candidate; break; }
}
if ($logsTable) {
    // Assume columns: user_id, created_at (or reviewed_at)
    $dateCol = columnExists($conn, $logsTable, 'created_at') ? 'created_at' : (columnExists($conn, $logsTable, 'reviewed_at') ? 'reviewed_at' : null);
    if ($dateCol) {
        $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM `{$logsTable}` WHERE user_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_assoc();
        $stat_cards_studied_total = (int)($res['c'] ?? 0);
        $stmt->close();

        $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM `{$logsTable}` WHERE user_id = ? AND DATE(`{$dateCol}`) = CURDATE()");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_assoc();
        $stat_cards_studied_today = (int)($res['c'] ?? 0);
        $stmt->close();
    }
}
// Fallback to total cards if no logs table
if ($stat_cards_studied_total === 0 && tableExists($conn, 'cards')) {
    $stmt = $conn->prepare("SELECT COUNT(*) AS c FROM cards WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $stat_cards_studied_total = (int)($res['c'] ?? 0);
    $stmt->close();
}

// Study streak (consecutive days with activity up to today)
$stat_streak_days = 0;
if ($logsTable) {
    $dateCol = columnExists($conn, $logsTable, 'created_at') ? 'created_at' : (columnExists($conn, $logsTable, 'reviewed_at') ? 'reviewed_at' : null);
    if ($dateCol) {
        // Get distinct activity days (last 60 days)
        $stmt = $conn->prepare("SELECT DATE(`{$dateCol}`) AS d FROM `{$logsTable}` WHERE user_id = ? AND `{$dateCol}` >= DATE_SUB(CURDATE(), INTERVAL 60 DAY) GROUP BY DATE(`{$dateCol}`) ORDER BY d DESC");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $days = [];
        $r = $stmt->get_result();
        while ($row = $r->fetch_assoc()) { $days[] = $row['d']; }
        $stmt->close();
        // Count streak
        $cursor = new DateTime(); // today
        $streak = 0;
        foreach ($days as $day) {
            if ($day === $cursor->format('Y-m-d')) {
                $streak++;
                $cursor->modify('-1 day');
            } else {
                // If first day is yesterday (allow missing today)
                if ($streak === 0) {
                    $yesterday = (new DateTime())->modify('-1 day')->format('Y-m-d');
                    if ($day === $yesterday) {
                        $streak = 1;
                        $cursor = new DateTime($yesterday);
                        $cursor->modify('-1 day');
                        continue;
                    }
                }
                break;
            }
        }
        $stat_streak_days = $streak;
    }
}

// Mastery rate (from cards.mastery 0..100 or 0..1 if column exists)
$stat_mastery_rate = 0;
if (tableExists($conn, 'cards') && columnExists($conn, 'cards', 'mastery')) {
    $stmt = $conn->prepare("SELECT AVG(CASE WHEN mastery <= 1 THEN mastery*100 ELSE mastery END) AS avgm FROM cards WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $avg = (float)($res['avgm'] ?? 0);
    $stmt->close();
    $stat_mastery_rate = (int)round($avg);
}

function formatRelativeTime(?string $datetime): string {
    if (empty($datetime)) {
        return '';
    }
    try {
        $time = new DateTime($datetime);
    } catch (Exception $e) {
        return '';
    }
    $now = new DateTime();
    $diff = $now->getTimestamp() - $time->getTimestamp();

    if ($diff < 60) {
        return $diff <= 1 ? 'just now' : $diff . 's ago';
    }
    if ($diff < 3600) {
        $mins = floor($diff / 60);
        return $mins . 'm ago';
    }
    if ($diff < 86400) {
        $hours = floor($diff / 3600);
        return $hours . 'h ago';
    }
    if ($diff < 604800) {
        $days = floor($diff / 86400);
        return $days . 'd ago';
    }
    return $time->format('M j');
}

$notifications = [];
$dismissed_notifications = $_SESSION['dismissed_notifications'] ?? [];

if (tableExists($conn, 'friends')) {
    $stmt = $conn->prepare("
        SELECT f.created_at, u.full_name
        FROM friends f
        INNER JOIN users u ON f.user_id = u.id
        WHERE f.friend_id = ? AND f.status = 'pending'
        ORDER BY f.created_at DESC
        LIMIT 5
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $name = $row['full_name'] ?? 'Someone';
        $notif_id = 'friend_request_' . md5($row['created_at'] . $name);
        if (!in_array($notif_id, $dismissed_notifications)) {
            $notifications[] = [
                'id' => $notif_id,
                'title' => 'Friend request',
                'message' => "{$name} wants to connect with you.",
                'time' => formatRelativeTime($row['created_at'] ?? null),
                'icon' => '👥',
                'timestamp' => $row['created_at'] ?? date('Y-m-d H:i:s'),
                'type' => 'friend_request',
                'url' => 'friends.php'
            ];
        }
    }
    $stmt->close();
}

// 2. Deck shares received (pending)
if (tableExists($conn, 'deck_shares')) {
    $stmt = $conn->prepare("
        SELECT ds.id, ds.created_at, ds.message, d.title, u.full_name AS sender_name
        FROM deck_shares ds
        INNER JOIN decks d ON ds.deck_id = d.id
        INNER JOIN users u ON ds.sender_id = u.id
        WHERE ds.recipient_id = ? AND ds.status = 'pending'
        ORDER BY ds.created_at DESC
        LIMIT 5
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $sender = $row['sender_name'] ?? 'Someone';
        $deckTitle = $row['title'] ?? 'a deck';
        $share_id = $row['id'] ?? 0;
        $notif_id = 'deck_share_' . $share_id;
        if (!in_array($notif_id, $dismissed_notifications)) {
            $notifications[] = [
                'id' => $notif_id,
                'title' => 'Deck shared with you',
                'message' => "{$sender} shared \"{$deckTitle}\" with you.",
                'time' => formatRelativeTime($row['created_at'] ?? null),
                'icon' => '📤',
                'timestamp' => $row['created_at'] ?? date('Y-m-d H:i:s'),
                'type' => 'deck_share',
                'url' => 'friends.php'
            ];
        }
    }
    $stmt->close();
}

// 3. Favorite deck updates
if (tableExists($conn, 'favorites') && tableExists($conn, 'decks')) {
    $stmt = $conn->prepare("
        SELECT d.id, d.title, d.updated_at, f.created_at AS favorited_at
        FROM favorites f
        INNER JOIN decks d ON f.deck_id = d.id
        WHERE f.user_id = ? 
        AND d.updated_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
        AND d.updated_at > f.created_at
        ORDER BY d.updated_at DESC
        LIMIT 5
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $title = $row['title'] ?? 'Untitled deck';
        $deck_id = $row['id'] ?? 0;
        $notif_id = 'favorite_update_' . $deck_id . '_' . md5($row['updated_at']);
        if (!in_array($notif_id, $dismissed_notifications)) {
            $notifications[] = [
                'id' => $notif_id,
                'title' => 'Favorite deck updated',
                'message' => "\"{$title}\" has been updated.",
                'time' => formatRelativeTime($row['updated_at'] ?? null),
                'icon' => '⭐',
                'timestamp' => $row['updated_at'] ?? date('Y-m-d H:i:s'),
                'type' => 'favorite_update',
                'url' => 'deck.php?id=' . $deck_id
            ];
        }
    }
    $stmt->close();
}

// 4. Report status updates
if (tableExists($conn, 'reports')) {
    $stmt = $conn->prepare("
        SELECT id, subject, status, updated_at
        FROM reports
        WHERE user_id = ? 
        AND status IN ('resolved', 'in_progress', 'rejected')
        AND updated_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        ORDER BY updated_at DESC
        LIMIT 5
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $subject = $row['subject'] ?? 'Your report';
        $status = $row['status'] ?? 'updated';
        $report_id = $row['id'] ?? 0;
        $statusText = ucfirst(str_replace('_', ' ', $status));
        $notif_id = 'report_update_' . $report_id;
        if (!in_array($notif_id, $dismissed_notifications)) {
            $notifications[] = [
                'id' => $notif_id,
                'title' => 'Report status updated',
                'message' => "\"{$subject}\" is now {$statusText}.",
                'time' => formatRelativeTime($row['updated_at'] ?? null),
                'icon' => '📋',
                'timestamp' => $row['updated_at'] ?? date('Y-m-d H:i:s'),
                'type' => 'report_update',
                'url' => 'reports.php'
            ];
        }
    }
    $stmt->close();
}

// 5. Friend request accepted
if (tableExists($conn, 'friends')) {
    $stmt = $conn->prepare("
        SELECT f.updated_at, u.full_name
        FROM friends f
        INNER JOIN users u ON f.friend_id = u.id
        WHERE f.user_id = ? AND f.status = 'accepted'
        AND f.updated_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
        ORDER BY f.updated_at DESC
        LIMIT 5
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $name = $row['full_name'] ?? 'Someone';
        $notif_id = 'friend_accepted_' . md5($row['updated_at'] . $name);
        if (!in_array($notif_id, $dismissed_notifications)) {
            $notifications[] = [
                'id' => $notif_id,
                'title' => 'Friend request accepted',
                'message' => "{$name} accepted your friend request.",
                'time' => formatRelativeTime($row['updated_at'] ?? null),
                'icon' => '✅',
                'timestamp' => $row['updated_at'] ?? date('Y-m-d H:i:s'),
                'type' => 'friend_accepted',
                'url' => 'friends.php'
            ];
        }
    }
    $stmt->close();
}

// 6. Recent deck updates (user's own decks)
if (tableExists($conn, 'decks')) {
    $stmt = $conn->prepare("
        SELECT title, created_at, updated_at
        FROM decks
        WHERE user_id = ?
        AND updated_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
        ORDER BY updated_at DESC
        LIMIT 3
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $title = $row['title'] ?? 'Untitled deck';
        $createdAt = $row['created_at'] ?? $row['updated_at'] ?? null;
        $updatedAt = $row['updated_at'] ?? $createdAt;
        $isNew = $createdAt && $updatedAt && strtotime($createdAt) === strtotime($updatedAt);
        $notif_id = 'deck_update_' . md5($title . $updatedAt);
        if (!in_array($notif_id, $dismissed_notifications)) {
            $notifications[] = [
                'id' => $notif_id,
                'title' => $isNew ? 'New deck created' : 'Deck updated',
            'message' => sprintf('“%s” was %s.', $title, $isNew ? 'created' : 'updated'),
            'time' => formatRelativeTime($updatedAt),
            'icon' => $isNew ? '🆕' : '📚',
            'timestamp' => $updatedAt ?? date('Y-m-d H:i:s'),
            'type' => 'deck_update',
            'url' => 'decks.php'
            ];
        }
    }
    $stmt->close();
}

usort($notifications, function ($a, $b) {
    return strtotime($b['timestamp']) <=> strtotime($a['timestamp']);
});
$notifications = array_slice($notifications, 0, 10);
$has_notifications = !empty($notifications);

// Handle clear all notifications (after notifications are built)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['clear_all_notifications'])) {
    // Get all current notification IDs from the built array
    $all_notif_ids = array_column($notifications, 'id');
    
    // Add all notification IDs to dismissed list
    if (!isset($_SESSION['dismissed_notifications'])) {
        $_SESSION['dismissed_notifications'] = [];
    }
    foreach ($all_notif_ids as $notif_id) {
        if (!empty($notif_id) && !in_array($notif_id, $_SESSION['dismissed_notifications'])) {
            $_SESSION['dismissed_notifications'][] = $notif_id;
        }
    }
    
    if (isset($_POST['ajax'])) {
        session_write_close();
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'count' => count($all_notif_ids)]);
        exit();
    }
    header("Location: " . strtok($_SERVER['REQUEST_URI'], '?'));
    exit();
}

$favorite_deck_ids = [];
if ($user_id) {
    $stmt = $conn->prepare("SELECT deck_id FROM favorites WHERE user_id = ?");
    if ($stmt) {
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $favorite_deck_ids[] = (int)$row['deck_id'];
        }
        $stmt->close();
    }
}

if ($user_id && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_favorite'], $_POST['deck_id'])) {
    $deck_id = (int)$_POST['deck_id'];
    if ($deck_id > 0) {
        $stmt = $conn->prepare("SELECT id FROM decks WHERE id = ? AND user_id = ?");
        if ($stmt) {
            $stmt->bind_param("ii", $deck_id, $user_id);
            $stmt->execute();
            $ownsDeck = $stmt->get_result()->num_rows > 0;
            $stmt->close();

            if ($ownsDeck) {
                $stmt = $conn->prepare("SELECT id FROM favorites WHERE user_id = ? AND deck_id = ?");
                if ($stmt) {
                    $stmt->bind_param("ii", $user_id, $deck_id);
                    $stmt->execute();
                    $favoriteExists = $stmt->get_result()->num_rows > 0;
                    $stmt->close();

                    if ($favoriteExists) {
                        $stmt = $conn->prepare("DELETE FROM favorites WHERE user_id = ? AND deck_id = ?");
                        if ($stmt) {
                            $stmt->bind_param("ii", $user_id, $deck_id);
                            $stmt->execute();
                            $stmt->close();
                        }
                    } else {
                        $stmt = $conn->prepare("INSERT INTO favorites (user_id, deck_id) VALUES (?, ?)");
                        if ($stmt) {
                            $stmt->bind_param("ii", $user_id, $deck_id);
                            $stmt->execute();
                            $stmt->close();
                        }
                    }
                }
            }
        }
    }

    header("Location: " . strtok($_SERVER['REQUEST_URI'], '?'));
    exit();
}

// Handle create deck submission
$deck_error = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_deck'])) {
    $title = trim($_POST['deck_title'] ?? '');
    $description = trim($_POST['deck_description'] ?? '');
    $color = trim($_POST['deck_color'] ?? '');
    $icon = ''; // icon functionality removed

    if ($title === '') {
        $deck_error = 'Title is required.';
    } else {
        $stmt = $conn->prepare("INSERT INTO decks (user_id, title, description, color, icon) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("issss", $user_id, $title, $description, $color, $icon);
        if ($stmt->execute()) {
            header("Location: " . strtok($_SERVER['REQUEST_URI'], '?'));
            exit();
        } else {
            $deck_error = 'Failed to create deck. Please try again.';
        }
        $stmt->close();
    }
}

// Fetch user decks
$user_decks = [];
if ($user_id) {
    $stmt = $conn->prepare("SELECT id, title, description, color, icon, created_at, updated_at FROM decks WHERE user_id = ? ORDER BY updated_at DESC");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $user_decks[] = $row;
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bizmo – Dashboard</title>
    <meta name="description" content="Your learning dashboard on Bizmo.">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #0b0b12; /* dark base */
            --text: #ffffff; /* light text */
            --muted: #a2a3ad; /* muted on dark */
            --accent: <?php echo $user_theme_color; ?>;
            --accent-700: <?php echo $theme_darker; ?>;
            --surface: #111118; /* panels */
            --border: rgba(255,255,255,0.08); /* subtle border on dark */
            --soft-accent: <?php echo $theme_rgba_15; ?>;
        }

        * { box-sizing: border-box; }
        html, body { height: 100%; }
        body {
            margin: 0;
            font-family: 'Inter', ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial;
            background: linear-gradient(180deg, #0c0c14 0%, #0c0c14 55%, #0c0c14 100%);
            color: var(--text);
        }

        /* Header */
        .header {
            position: sticky; top: 0; z-index: 30;
            backdrop-filter: saturate(180%) blur(20px);
            background: rgba(10,10,15,0.8);
            border-bottom: 1px solid var(--border);
            box-shadow: 0 4px 24px rgba(0,0,0,0.2);
        }
        .header-content {
            max-width: 1400px; margin: 0 auto; padding: 0 24px;
            display: flex; align-items: center; justify-content: space-between;
            padding-top: 18px; padding-bottom: 18px;
        }
        .brand {
            display: inline-flex; align-items: center; gap: 12px;
            font-weight: 800; font-size: 18px; color: var(--text);
            text-decoration: none; transition: transform .2s ease;
        }
        .brand:hover { transform: scale(1.02); }
        .logo {
            background: linear-gradient(135deg, <?php echo $theme_rgba_10; ?>, <?php echo $theme_rgba_05; ?>);
            box-shadow: 0 4px 12px <?php echo $theme_rgba_15; ?>;
            border: 1px solid <?php echo $theme_rgba_20; ?>;
            width: 50px; height: 50px; border-radius: 12px;
            display: grid; place-items: center;
            transition: all .3s ease;
        }
        .logo:hover { transform: rotate(5deg) scale(1.05); }
        .logo svg, .logo img { width: 50px; height: 50px; display: block; }

        .header-right { display: flex; align-items: center; gap: 12px; }
        .notif-btn {
            width: 44px; height: 44px; border-radius: 12px;
            background: rgba(255,255,255,0.04);
            border: 1px solid var(--border);
            display: grid; place-items: center; cursor: pointer;
            color: var(--text); transition: all .25s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
        }
        .notif-btn:hover {
            background: rgba(255,255,255,0.08);
            border-color: var(--accent);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px <?php echo $theme_rgba_20; ?>;
        }
        .notif-btn::after {
            content: ''; position: absolute; top: 8px; right: 8px;
            width: 8px; height: 8px; border-radius: 50%;
            background: var(--accent); box-shadow: 0 0 8px var(--accent);
            opacity: 0; transform: scale(0.4);
            transition: opacity 0.2s ease, transform 0.2s ease;
        }
        .notif-btn.has-alert::after {
            opacity: 1;
            transform: scale(1);
        }
        .notif-dropdown {
            position: absolute;
            top: calc(100% + 12px);
            right: 0;
            width: min(340px, 90vw);
            background: rgba(10,10,15,0.98);
            border: 1px solid var(--border);
            border-radius: 16px;
            box-shadow: 0 16px 40px rgba(0,0,0,0.45);
            padding: 0;
            display: none;
            z-index: 1000;
            overflow: hidden;
        }
        .notif-dropdown.show { display: block; }
        .notif-dropdown h4 {
            margin: 0;
            padding: 16px 16px 12px;
            font-size: 16px;
            font-weight: 700;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .notif-clear-all {
            font-size: 13px;
            font-weight: 600;
            color: var(--muted);
            background: none;
            border: none;
            cursor: pointer;
            padding: 4px 8px;
            border-radius: 6px;
            transition: all 0.2s ease;
            text-decoration: none;
            display: inline-block;
        }
        .notif-clear-all:hover {
            color: var(--text);
            background: rgba(255,255,255,0.05);
        }
        .notif-clear-all:active {
            transform: scale(0.95);
        }
        .notif-list {
            display: flex;
            flex-direction: column;
            gap: 0;
            max-height: 420px;
            overflow-y: auto;
            overflow-x: hidden;
            padding: 8px;
        }
        .notif-list::-webkit-scrollbar {
            width: 6px;
        }
        .notif-list::-webkit-scrollbar-track {
            background: transparent;
        }
        .notif-list::-webkit-scrollbar-thumb {
            background: rgba(255,255,255,0.15);
            border-radius: 3px;
        }
        .notif-list::-webkit-scrollbar-thumb:hover {
            background: rgba(255,255,255,0.25);
        }
        .notif-item {
            display: flex;
            gap: 12px;
            padding: 14px 40px 14px 14px;
            border-radius: 10px;
            border: 1px solid rgba(255,255,255,0.05);
            background: rgba(255,255,255,0.02);
            transition: all 0.2s ease;
            position: relative;
            cursor: pointer;
            margin-bottom: 8px;
        }
        .notif-item:last-child {
            margin-bottom: 0;
        }
        .notif-item:hover {
            border-color: rgba(255,255,255,0.15);
            background: rgba(255,255,255,0.06);
            transform: translateX(2px);
        }
        .notif-item-link {
            display: flex;
            gap: 12px;
            flex: 1;
            text-decoration: none;
            color: inherit;
        }
        .notif-dismiss {
            position: absolute;
            top: 50%;
            right: 12px;
            transform: translateY(-50%);
            width: 28px;
            height: 28px;
            border: none;
            background: rgba(255,255,255,0.08);
            border-radius: 8px;
            color: rgba(255,255,255,0.6);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: 600;
            line-height: 1;
            opacity: 0.6;
            transition: all 0.2s ease;
            z-index: 20;
            flex-shrink: 0;
        }
        .notif-item:hover .notif-dismiss {
            opacity: 1;
            background: rgba(239,68,68,0.15);
            color: #fca5a5;
        }
        .notif-dismiss:hover {
            background: rgba(239,68,68,0.25);
            color: #f87171;
            transform: translateY(-50%) scale(1.1);
        }
        .notif-dismiss:active {
            transform: translateY(-50%) scale(0.95);
        }
        .notif-icon {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            background: rgba(255,255,255,0.06);
            display: grid;
            place-items: center;
            font-size: 22px;
            flex-shrink: 0;
        }
        .notif-body { 
            flex: 1; 
            min-width: 0;
            overflow: hidden;
        }
        .notif-title {
            margin: 0;
            font-size: 14px;
            font-weight: 700;
            color: var(--text);
            line-height: 1.4;
        }
        .notif-message {
            margin: 6px 0 0;
            font-size: 13px;
            color: var(--muted);
            line-height: 1.5;
            word-wrap: break-word;
        }
        .notif-time {
            margin: 8px 0 0;
            font-size: 12px;
            color: rgba(255,255,255,0.5);
            font-weight: 500;
        }
        .notif-empty {
            padding: 40px 20px;
            text-align: center;
        }
        .notif-empty p {
            margin: 0;
            font-weight: 600;
            font-size: 15px;
            color: var(--text);
        }
        .notif-empty span {
            display: block;
            margin-top: 8px;
            font-size: 13px;
            color: var(--muted);
        }
        .user-menu {
            display: flex; align-items: center; gap: 12px; cursor: pointer;
            padding: 8px 14px 8px 8px; border-radius: 999px;
            background: rgba(255,255,255,0.04);
            border: 1px solid var(--border);
            transition: all .25s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .user-menu:hover {
            background: rgba(255,255,255,0.08);
            border-color: var(--accent);
            transform: translateY(-1px);
        }
        .user-avatar {
            width: 36px; height: 36px; border-radius: 999px;
            background: linear-gradient(135deg, var(--accent), var(--accent-700));
            display: grid; place-items: center;
            font-weight: 700; font-size: 14px;
            box-shadow: 0 4px 12px <?php echo $theme_rgba_30; ?>;
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            overflow: hidden;
        }

        /* Layout */
        .dashboard-layout {
            display: grid; grid-template-columns: 280px 1fr;
            max-width: 1400px; margin: 0 auto;
            min-height: calc(100vh - 74px);
        }

        /* Sidebar */
        .sidebar {
            padding: 28px 20px; border-right: 1px solid var(--border);
            background: rgba(10,10,15,0.6);
            backdrop-filter: blur(10px);
        }
        .sidebar-nav { display: flex; flex-direction: column; gap: 4px; }
        .nav-item {
            display: flex; align-items: center; gap: 14px;
            padding: 14px 16px; border-radius: 14px;
            color: var(--muted); text-decoration: none;
            font-weight: 600; font-size: 15px;
            transition: all .25s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
        }
        .nav-item:hover {
            background: rgba(255,255,255,0.05);
            color: var(--text);
            transform: translateX(4px);
        }
        .nav-item.active {
            background: linear-gradient(135deg, <?php echo $theme_rgba_20; ?>, <?php echo $theme_rgba_10; ?>);
            color: var(--text);
            border: 1px solid <?php echo $theme_rgba_30; ?>;
            box-shadow: 0 4px 12px <?php echo $theme_rgba_15; ?>;
        }
        .nav-item.active::before {
            content: ''; position: absolute; left: 0; top: 50%;
            transform: translateY(-50%);
            width: 3px; height: 60%; border-radius: 0 4px 4px 0;
            background: var(--accent);
        }
        .nav-icon {
            width: 22px; height: 22px; display: grid; place-items: center;
            font-size: 20px;
        }
        .nav-icon img,
        .nav-icon svg {
            width: 20px;
            height: 20px;
            display: block;
            object-fit: contain;
            filter: brightness(0) invert(1);
            opacity: 0.75;
            transition: opacity 0.2s ease, filter 0.2s ease;
        }
        .nav-item:hover .nav-icon img,
        .nav-item:hover .nav-icon svg,
        .nav-item.active .nav-icon img,
        .nav-item.active .nav-icon svg {
            opacity: 1;
        }
        .nav-item.active .nav-icon img,
        .nav-item.active .nav-icon svg {
            filter: brightness(0) invert(1) drop-shadow(0 0 6px <?php echo $theme_rgba_25; ?>);
        }

        /* Main Content */
        .main-content { padding: 40px; }
        .page-header { margin-bottom: 40px; }
        .page-title {
            font-size: 36px; font-weight: 900; margin: 0 0 10px;
            background: linear-gradient(135deg, #fff, rgba(255,255,255,0.8));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .page-subtitle {
            color: var(--muted); font-size: 17px; margin: 0;
            font-weight: 500;
        }

        /* Search */
        .search-panel {
            margin-bottom: 32px;
            background: rgba(255,255,255,0.03);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 18px 20px;
            display: grid;
            gap: 16px;
        }
        .search-control {
            display: flex;
            gap: 12px;
            align-items: center;
            width: 100%;
        }
        .search-input {
            flex: 1;
            width: 100%;
            padding: 14px 18px 14px 48px;
            border-radius: 12px;
            border: 1px solid var(--border);
            background: rgba(10,10,15,0.8);
            color: var(--text);
            font-size: 15px;
            transition: border .2s ease, box-shadow .2s ease;
            position: relative;
        }
        .search-input:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px <?php echo $theme_rgba_10; ?>;
        }
        .search-input::placeholder {
            color: rgba(255,255,255,0.35);
        }
        .search-input-wrapper {
            position: relative;
            flex: 1;
            width: 100%;
        }
        .search-input-wrapper svg {
            position: absolute;
            top: 50%;
            left: 14px;
            transform: translateY(-50%);
            pointer-events: none;
            color: rgba(255,255,255,0.4);
        }
        .filter-group {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }
        .filter-btn {
            border: 1px solid var(--border);
            background: rgba(255,255,255,0.04);
            color: var(--text);
            padding: 8px 16px;
            border-radius: 999px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all .2s ease;
        }
        .filter-btn:hover {
            border-color: var(--accent);
            transform: translateY(-1px);
        }
        .filter-btn.active {
            background: var(--accent);
            border-color: var(--accent);
            color: #0b0b12;
            box-shadow: 0 6px 16px <?php echo $theme_rgba_20; ?>;
        }
        .search-feedback {
            font-size: 13px;
            color: var(--muted);
        }
        .hidden {
            display: none !important;
        }

        /* Stats Grid */
        .stats-grid {
            display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 24px; margin-bottom: 40px;
        }
        .stat-card {
            background: linear-gradient(135deg, rgba(255,255,255,0.05), rgba(255,255,255,0.02));
            border: 1px solid var(--border);
            border-radius: 20px; padding: 24px;
            transition: all .3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative; overflow: hidden;
        }
        .stat-card::before {
            content: ''; position: absolute; top: 0; left: 0;
            width: 100%; height: 100%;
            background: radial-gradient(circle at top right, <?php echo $theme_rgba_10; ?>, transparent 70%);
            opacity: 0; transition: opacity .3s ease;
        }
        .stat-card:hover::before { opacity: 1; }
        .stat-card:hover {
            background: linear-gradient(135deg, rgba(255,255,255,0.08), rgba(255,255,255,0.04));
            border-color: var(--accent);
            transform: translateY(-4px);
            box-shadow: 0 12px 32px <?php echo $theme_rgba_25; ?>;
        }
        .stat-header {
            display: flex; align-items: center; justify-content: space-between;
            margin-bottom: 16px;
        }
        .stat-label {
            color: var(--muted); font-size: 14px; font-weight: 600;
            text-transform: uppercase; letter-spacing: 0.5px;
        }
        .stat-icon {
            width: 48px; height: 48px; border-radius: 14px;
            background: linear-gradient(135deg, <?php echo $theme_rgba_25; ?>, <?php echo $theme_rgba_15; ?>);
            display: grid; place-items: center;
            color: var(--accent); font-size: 22px;
            box-shadow: 0 4px 12px <?php echo $theme_rgba_20; ?>;
        }
        .stat-value {
            font-size: 36px; font-weight: 900; margin: 0;
            background: linear-gradient(135deg, #fff, rgba(255,255,255,0.9));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .stat-change {
            font-size: 13px; color: var(--accent);
            margin-top: 12px; display: flex; align-items: center; gap: 6px;
            font-weight: 600;
        }

        /* Content Sections */
        .content-section { margin-bottom: 40px; }
        .section-header {
            display: flex; align-items: center; justify-content: space-between;
            margin-bottom: 24px;
        }
        .section-title {
            font-size: 24px; font-weight: 800; margin: 0;
            letter-spacing: -0.5px;
        }
        .btn {
            padding: 12px 22px; border-radius: 12px;
            border: 1px solid transparent;
            background: linear-gradient(135deg, var(--accent), var(--accent-700));
            color: #fff; font-weight: 700; font-size: 14px;
            cursor: pointer; text-decoration: none;
            display: inline-flex; align-items: center; gap: 8px;
            transition: all .25s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 4px 12px <?php echo $theme_rgba_30; ?>;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px <?php echo $theme_rgba_20; ?>;
        }
        .btn-secondary {
            background: rgba(255,255,255,0.05);
            color: var(--text);
            border-color: var(--border);
            box-shadow: none;
        }
        .btn-secondary:hover {
            background: rgba(255,255,255,0.08);
            border-color: var(--accent);
            box-shadow: 0 4px 12px <?php echo $theme_rgba_15; ?>;
        }

        /* Decks Grid */
        .decks-grid {
            display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 24px;
        }
        .deck-card {
            background: linear-gradient(135deg, rgba(255,255,255,0.05), rgba(255,255,255,0.02));
            border: 1px solid var(--border);
            border-radius: 20px; padding: 24px;
            transition: all .3s cubic-bezier(0.4, 0, 0.2, 1);
            cursor: pointer; text-decoration: none;
            color: inherit; display: block;
            position: relative; overflow: hidden;
        }
        .deck-card-link {
            display: block;
            color: inherit;
            text-decoration: none;
            height: 100%;
            cursor: inherit;
        }
        .favorite-form {
            position: absolute;
            top: 16px;
            right: 16px;
            margin: 0;
            z-index: 2;
        }
        .favorite-toggle {
            border: 1px solid var(--border);
            background: rgba(10,10,15,0.6);
            color: var(--muted);
            width: 36px;
            height: 36px;
            border-radius: 50%;
            font-size: 16px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            transition: all .2s ease;
        }
        .favorite-toggle:hover,
        .favorite-toggle:focus-visible {
            border-color: var(--accent);
            color: var(--text);
            outline: none;
        }
        .favorite-toggle.active {
            background: var(--accent);
            border-color: var(--accent);
            color: #0b0b12;
            box-shadow: 0 0 12px <?php echo $theme_rgba_30; ?>;
        }
        .deck-card::before {
            content: ''; position: absolute; top: 0; left: 0;
            width: 100%; height: 100%;
            background: radial-gradient(circle at top left, <?php echo $theme_rgba_10; ?>, transparent 60%);
            opacity: 0; transition: opacity .3s ease;
        }
        .deck-card:hover::before { opacity: 1; }
        .deck-card:hover {
            background: linear-gradient(135deg, rgba(255,255,255,0.08), rgba(255,255,255,0.04));
            border-color: var(--accent);
            transform: translateY(-4px);
            box-shadow: 0 12px 32px <?php echo $theme_rgba_25; ?>;
        }
        .deck-header {
            display: flex; align-items: start; justify-content: space-between;
            margin-bottom: 16px;
        }
        .deck-icon {
            width: 56px; height: 56px; border-radius: 16px;
            display: grid; place-items: center;
            font-size: 28px; font-weight: 800;
            border: 1px solid var(--border);
            background: transparent;
            box-shadow: none;
            overflow: hidden;
        }
        .deck-icon img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }
        .deck-title {
            font-size: 20px; font-weight: 700; margin: 0 0 10px;
            letter-spacing: -0.3px;
        }
        .deck-meta {
            display: flex; align-items: center; gap: 16px;
            font-size: 13px; color: var(--muted);
            margin-top: 16px; font-weight: 500;
        }
        .progress-bar {
            height: 8px; background: rgba(255,255,255,0.1);
            border-radius: 999px; overflow: hidden;
            margin-top: 16px; position: relative;
        }
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--accent), var(--accent-700));
            border-radius: 999px;
            transition: width .4s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 0 12px <?php echo $theme_rgba_50; ?>;
        }

        /* Activity List */
        .activity-list { display: flex; flex-direction: column; gap: 12px; }
        .activity-item {
            display: flex; align-items: center; gap: 16px;
            padding: 18px; background: rgba(255,255,255,0.03);
            border: 1px solid var(--border); border-radius: 16px;
            transition: all .25s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .activity-item:hover {
            background: rgba(255,255,255,0.06);
            border-color: var(--accent);
            transform: translateX(4px);
        }
        .activity-icon {
            width: 44px; height: 44px; border-radius: 12px;
            background: linear-gradient(135deg, <?php echo $theme_rgba_25; ?>, <?php echo $theme_rgba_15; ?>);
            display: grid; place-items: center;
            color: var(--accent); flex-shrink: 0;
            font-size: 20px;
            box-shadow: 0 4px 12px <?php echo $theme_rgba_20; ?>;
        }
        .activity-content { flex: 1; }
        .activity-title {
            font-weight: 600; margin: 0 0 6px;
            font-size: 15px;
        }
        .activity-time {
            font-size: 13px; color: var(--muted);
            font-weight: 500;
        }

        /* Logout Modal */
        .logout-modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.75);
            backdrop-filter: blur(4px);
            z-index: 10000;
            align-items: center;
            justify-content: center;
            padding: 20px;
            animation: fadeIn 0.3s ease;
        }
        .logout-modal-overlay.active {
            display: flex;
        }
        .logout-modal {
            background: rgba(10,10,15,0.98);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 32px;
            max-width: 400px;
            width: 100%;
            position: relative;
            box-shadow: 0 40px 120px rgba(0,0,0,0.5);
            animation: slideUp 0.3s ease;
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        .logout-modal-icon {
            width: 64px;
            height: 64px;
            margin: 0 auto 20px;
            background: rgba(239, 68, 68, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .logout-modal-icon svg {
            width: 32px;
            height: 32px;
            color: #ef4444;
        }
        .logout-modal-header {
            text-align: center;
            margin-bottom: 20px;
        }
        .logout-modal-title {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 8px;
            color: var(--text);
        }
        .logout-modal-message {
            color: var(--muted);
            font-size: 14px;
            line-height: 1.6;
        }
        .logout-modal-actions {
            display: flex;
            gap: 12px;
            margin-top: 24px;
        }
        .btn-modal {
            flex: 1;
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
        }
        .btn-modal-cancel {
            background: rgba(255,255,255,0.05);
            border: 1px solid var(--border);
            color: var(--text);
        }
        .btn-modal-cancel:hover {
            background: rgba(255,255,255,0.08);
        }
        .btn-modal-logout {
            background: #ef4444;
            color: white;
        }
        .btn-modal-logout:hover {
            background: #dc2626;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .dashboard-layout { grid-template-columns: 1fr; }
            .sidebar { display: none; }
        }
        @media (max-width: 720px) {
            .stats-grid { grid-template-columns: 1fr; }
            .decks-grid { grid-template-columns: 1fr; }
            .main-content { padding: 24px; }
            .page-title { font-size: 28px; }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-content">
            <a href="dashboard.php" class="brand">
                <div class="logo" aria-label="Bizmo logo">
                    <img src="icons/bizmo.png" alt="" width="50" height="50" />
                </div>
                <span>Bizmo</span>
            </a>
            <div class="header-right">
                <div style="position: relative;">
                    <button class="notif-btn<?php echo $has_notifications ? ' has-alert' : ''; ?>" aria-label="Notifications" id="notifBtn">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/>
                        </svg>
                    </button>
                    <div class="notif-dropdown" id="notifDropdown">
                        <h4>
                            <span>Notifications</span>
                            <?php if (!empty($notifications)): ?>
                                <button type="button" class="notif-clear-all" onclick="clearAllNotifications(event)" aria-label="Clear all notifications">
                                    Clear all
                                </button>
                            <?php endif; ?>
                        </h4>
                        <?php if (!empty($notifications)): ?>
                            <div class="notif-list">
                                <?php foreach ($notifications as $notification): ?>
                                    <div class="notif-item" data-notif-id="<?php echo htmlspecialchars($notification['id'] ?? ''); ?>">
                                        <a href="<?php echo htmlspecialchars($notification['url'] ?? '#'); ?>" class="notif-item-link">
                                            <div class="notif-icon"><?php echo htmlspecialchars($notification['icon']); ?></div>
                                            <div class="notif-body">
                                                <p class="notif-title"><?php echo htmlspecialchars($notification['title']); ?></p>
                                                <p class="notif-message"><?php echo htmlspecialchars($notification['message']); ?></p>
                                                <p class="notif-time"><?php echo htmlspecialchars($notification['time']); ?></p>
                                            </div>
                                        </a>
                                        <button type="button" class="notif-dismiss" aria-label="Dismiss notification" onclick="dismissNotification(event, '<?php echo htmlspecialchars($notification['id'] ?? ''); ?>')">
                                            ×
                                        </button>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="notif-empty">
                                <p>You're all caught up</p>
                                <span>We'll let you know when something new happens.</span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="user-menu" id="userMenu">
                    <div class="user-avatar" style="<?php if ($profile_picture_path): ?>background-image: url('<?php echo htmlspecialchars($profile_picture_path); ?>');<?php endif; ?>">
                        <?php if (!$profile_picture_path): ?>
                            <?php echo htmlspecialchars($user_initials); ?>
                        <?php endif; ?>
                    </div>
                    <span style="font-weight: 600; font-size: 14px;"><?php echo htmlspecialchars($user_name); ?></span>
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                    </svg>
                    <div class="user-dropdown" id="userDropdown" style="display: none; position: absolute; top: calc(100% + 8px); right: 0; background: rgba(10,10,15,0.95); border: 1px solid var(--border); border-radius: 12px; padding: 8px; min-width: 200px; box-shadow: 0 8px 24px rgba(0,0,0,0.4); z-index: 1000;">
                        <div style="padding: 12px; border-bottom: 1px solid var(--border);">
                            <div style="font-weight: 600; font-size: 14px; margin-bottom: 4px;"><?php echo htmlspecialchars($user_name); ?></div>
                            <div style="font-size: 12px; color: var(--muted);"><?php echo htmlspecialchars($user_email); ?></div>
                        </div>
                        <a href="#" id="logoutBtn" style="display: block; padding: 12px; color: var(--text); text-decoration: none; border-radius: 8px; transition: background 0.2s ease; font-size: 14px; font-weight: 600;" onmouseover="this.style.background='rgba(255,255,255,0.05)'" onmouseout="this.style.background='transparent'">
                            <span style="margin-right: 8px;">🚪</span> Logout
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <div class="dashboard-layout">
        <aside class="sidebar">
            <nav class="sidebar-nav">
                <a href="dashboard.php" class="nav-item active">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/dashboard.png" alt="" loading="lazy">
                    </span>
                    <span>Dashboard</span>
                </a>
                <a href="decks.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/cards.png" alt="" loading="lazy">
                    </span>
                    <span>My Decks</span>
                </a>

                <a href="progress.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/progress.png" alt="" loading="lazy">
                    </span>
                    <span>Progress</span>
                </a>
                <a href="favorites.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/favorite.png" alt="" loading="lazy">
                    </span>
                    <span>Favorites</span>
                </a>
                <a href="friends.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/friends.png" alt="" loading="lazy">
                    </span>
                    <span>Friends</span>
                </a>
                <a href="reports.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                        </svg>
                    </span>
                    <span>Reports</span>
                </a>
                <a href="planner.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/planner.png" alt="" loading="lazy">
                    </span>
                    <span>Study Planner</span>
                </a>
                <a href="settings.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/settings.png" alt="" loading="lazy">
                    </span>
                    <span>Settings</span>
                </a>
            </nav>
        </aside>

        <main class="main-content">
            <div class="page-header">
                <h1 class="page-title">Welcome back, <?php echo htmlspecialchars(explode(' ', $user_name)[0]); ?>! 👋</h1>
                <p class="page-subtitle">Here's your learning progress and recent activity</p>
            </div>

            <section class="search-panel" aria-labelledby="dashboardSearchLabel">
                <div class="search-control">
                    <div class="search-input-wrapper">
                        <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                        </svg>
                        <input type="search" id="dashboardSearch" class="search-input" placeholder="Search decks, activities, or keywords…" autocomplete="off" aria-label="Search dashboard content">
                    </div>
                </div>
                <div class="filter-group" role="tablist" aria-label="Search filters">
                    <button type="button" class="filter-btn active" data-filter="all">All</button>
                    <button type="button" class="filter-btn" data-filter="decks">Decks</button>
                    <button type="button" class="filter-btn" data-filter="activity">Activity</button>
                </div>
                <div class="search-feedback" id="searchFeedback">Showing all items</div>
            </section>

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-header">
                        <span class="stat-label">Total Decks</span>
                        <div class="stat-icon">📚</div>
                    </div>
                    <p class="stat-value"><?php echo number_format($stat_total_decks); ?></p>
                    <div class="stat-change">
                        <span><?php echo ($stat_decks_week_delta >= 0 ? '+' : '') . number_format($stat_decks_week_delta); ?> this week</span>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-header">
                        <span class="stat-label">Cards Studied</span>
                        <div class="stat-icon">🎯</div>
                    </div>
                    <p class="stat-value"><?php echo number_format($stat_cards_studied_total); ?></p>
                    <div class="stat-change">
                        <span><?php echo '+' . number_format($stat_cards_studied_today); ?> today</span>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-header">
                        <span class="stat-label">Mastery Rate</span>
                        <div class="stat-icon">⭐</div>
                    </div>
                    <p class="stat-value"><?php echo number_format($stat_mastery_rate); ?>%</p>
                    <div class="stat-change">
                        <span><?php echo $stat_mastery_rate > 0 ? '+5% this month' : 'Improve by studying daily'; ?></span>
                    </div>
                </div>
            </div>

            <div class="content-section" id="deckSection">
                <div class="section-header">
                    <h2 class="section-title">My Decks</h2>
                    <button type="button" class="btn" id="openCreateDeck">+ Create Deck</button>
                </div>
                <div class="decks-grid" id="deckList">
                    <?php if (!empty($user_decks)): ?>
                        <?php foreach ($user_decks as $deck):
                            $deck_icon_src = buildDeckIconSrc($deck['icon'] ?? null);
                            $deck_icon_fallback = mb_strtoupper(mb_substr($deck['title'], 0, 1));
                            $is_favorite = in_array((int)$deck['id'], $favorite_deck_ids, true);
                        ?>
                            <div class="deck-card search-item" data-type="decks" data-search="<?php echo htmlspecialchars($deck['title'] . ' ' . ($deck['description'] ?? '')); ?>">
                                <form method="post" class="favorite-form">
                                    <input type="hidden" name="toggle_favorite" value="1">
                                    <input type="hidden" name="deck_id" value="<?php echo (int)$deck['id']; ?>">
                                    <button type="submit" class="favorite-toggle<?php echo $is_favorite ? ' active' : ''; ?>" title="<?php echo $is_favorite ? 'Remove from favorites' : 'Add to favorites'; ?>" aria-label="<?php echo $is_favorite ? 'Remove from favorites' : 'Add to favorites'; ?>">
                                        <?php echo $is_favorite ? '★' : '☆'; ?>
                                    </button>
                                </form>
                                <a href="deck.php?id=<?php echo (int)$deck['id']; ?>" class="deck-card-link">
                                    <div class="deck-header">
                                        <div class="deck-icon" style="overflow:hidden;">
                                            <?php if ($deck_icon_src !== ''): ?>
                                                <img src="<?php echo htmlspecialchars($deck_icon_src, ENT_QUOTES); ?>" alt="Deck icon" />
                                            <?php else: ?>
                                                <span style="font-weight:800;"><?php echo htmlspecialchars($deck_icon_fallback); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <h3 class="deck-title"><?php echo htmlspecialchars($deck['title']); ?></h3>
                                    <?php if (!empty($deck['description'])): ?>
                                        <p style="font-size: 14px; color: var(--muted); margin: 0 0 12px;"><?php echo htmlspecialchars($deck['description']); ?></p>
                                    <?php endif; ?>
                                    <div class="progress-bar">
                                        <div class="progress-fill" style="width: 0%;"></div>
                                    </div>
                                    <div class="deck-meta">
                                        <span>New deck</span>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="search-item" data-type="decks" style="padding:16px;border:1px dashed var(--border);border-radius:12px;color:var(--muted);">
                            No decks yet. Click “+ Create Deck” to add your first one.
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="content-section" id="activitySection">
                <div class="section-header">
                    <h2 class="section-title">Recent Activity</h2>
                    <a href="#" class="btn btn-secondary" style="display:none;">View All</a>
                </div>
                <div class="activity-list" id="activityList">
                    <div class="search-item" data-type="activity" style="padding:16px;border:1px dashed var(--border);border-radius:12px;color:var(--muted);">
                        No activity yet.
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
        // Create Deck modal
        (function () {
            const openBtn = document.getElementById('openCreateDeck');
            if (!openBtn) return;

            // Build modal once
            const overlay = document.createElement('div');
            overlay.id = 'createDeckOverlay';
            overlay.style.position = 'fixed';
            overlay.style.inset = '0';
            overlay.style.background = 'rgba(0,0,0,0.6)';
            overlay.style.backdropFilter = 'blur(2px)';
            overlay.style.display = 'none';
            overlay.style.alignItems = 'center';
            overlay.style.justifyContent = 'center';
            overlay.style.zIndex = '10000';

            const modal = document.createElement('div');
            modal.style.background = 'rgba(10,10,15,0.98)';
            modal.style.border = '1px solid var(--border)';
            modal.style.borderRadius = '16px';
            modal.style.padding = '20px';
            modal.style.width = 'min(480px, 92vw)';
            modal.style.boxShadow = '0 12px 40px rgba(0,0,0,0.5)';

            modal.innerHTML = `
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
                    <h3 style="margin:0;font-size:20px;font-weight:800;">Create Deck</h3>
                    <button type="button" id="closeCreateDeck" style="background:transparent;border:1px solid var(--border);color:var(--text);border-radius:10px;padding:6px 10px;cursor:pointer;">✕</button>
                </div>
                <?php if (!empty($deck_error)): ?>
                    <div style="margin: 10px 0 14px; color: #fecaca; background: rgba(239, 68, 68, 0.08); border: 1px solid rgba(239, 68, 68, 0.25); padding: 10px 12px; border-radius: 10px;"><?php echo htmlspecialchars($deck_error); ?></div>
                <?php endif; ?>
                <form method="post" autocomplete="off">
                    <input type="hidden" name="create_deck" value="1" />
                    <div style="display:grid;gap:12px;">
                        <div>
                            <label for="deck_title" style="display:block;font-size:13px;color:var(--muted);margin-bottom:6px;">Title</label>
                            <input required id="deck_title" name="deck_title" type="text" placeholder="e.g. Biology Fundamentals" style="width:100%;padding:12px 14px;border-radius:12px;border:1px solid var(--border);background:rgba(10,10,15,0.9);color:var(--text);" />
                        </div>
                        <div>
                            <label for="deck_description" style="display:block;font-size:13px;color:var(--muted);margin-bottom:6px;">Description</label>
                            <textarea id="deck_description" name="deck_description" rows="3" placeholder="Short description (optional)" style="width:100%;padding:12px 14px;border-radius:12px;border:1px solid var(--border);background:rgba(10,10,15,0.9);color:var(--text);"></textarea>
                        </div>
                        <div style="display:grid;grid-template-columns:1fr;gap:12px;">
                            <div>
                                <label for="deck_color" style="display:block;font-size:13px;color:var(--muted);margin-bottom:6px;">Color</label>
                                <input id="deck_color" name="deck_color" type="text" placeholder="#7f1d1d or rgba(...)" style="width:100%;padding:12px 14px;border-radius:12px;border:1px solid var(--border);background:rgba(10,10,15,0.9);color:var(--text);" />
                            </div>
                        </div>
                        <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:6px;">
                            <button type="button" id="cancelCreateDeck" class="btn btn-secondary" style="padding:10px 16px;">Cancel</button>
                            <button type="submit" class="btn" style="padding:10px 16px;">Create</button>
                        </div>
                    </div>
                </form>
            `;

            overlay.appendChild(modal);
            document.body.appendChild(overlay);

            function openModal() { overlay.style.display = 'flex'; }
            function closeModal() { overlay.style.display = 'none'; }

            openBtn.addEventListener('click', openModal);
            overlay.addEventListener('click', function (e) {
                if (e.target === overlay) closeModal();
            });
            modal.querySelector('#closeCreateDeck').addEventListener('click', closeModal);
            modal.querySelector('#cancelCreateDeck').addEventListener('click', closeModal);
        })();

        const notifBtn = document.getElementById('notifBtn');
        const notifDropdown = document.getElementById('notifDropdown');

        if (notifBtn && notifDropdown) {
            notifBtn.addEventListener('click', function (e) {
                e.stopPropagation();
                notifDropdown.classList.toggle('show');
            });

            document.addEventListener('click', function (e) {
                if (!notifDropdown.contains(e.target) && e.target !== notifBtn) {
                    notifDropdown.classList.remove('show');
                }
            });
        }

        // Clear all notifications function
        function clearAllNotifications(event) {
            event.preventDefault();
            event.stopPropagation();
            
            if (!confirm('Clear all notifications?')) {
                return;
            }
            
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            
            const inputAction = document.createElement('input');
            inputAction.type = 'hidden';
            inputAction.name = 'clear_all_notifications';
            inputAction.value = '1';
            
            const inputAjax = document.createElement('input');
            inputAjax.type = 'hidden';
            inputAjax.name = 'ajax';
            inputAjax.value = '1';
            
            form.appendChild(inputAction);
            form.appendChild(inputAjax);
            document.body.appendChild(form);
            
            fetch(window.location.href, {
                method: 'POST',
                body: new FormData(form)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Remove all notifications from DOM
                    const notifList = document.querySelector('.notif-list');
                    if (notifList) {
                        const items = notifList.querySelectorAll('.notif-item');
                        items.forEach((item, index) => {
                            setTimeout(() => {
                                item.style.opacity = '0';
                                item.style.transform = 'translateX(-10px)';
                                setTimeout(() => item.remove(), 200);
                            }, index * 50);
                        });
                        
                        setTimeout(() => {
                            const notifDropdown = document.getElementById('notifDropdown');
                            if (notifDropdown) {
                                notifDropdown.innerHTML = '<h4><span>Notifications</span></h4><div class="notif-empty"><p>You\'re all caught up</p><span>We\'ll let you know when something new happens.</span></div>';
                            }
                            const notifBtn = document.getElementById('notifBtn');
                            if (notifBtn) {
                                notifBtn.classList.remove('has-alert');
                            }
                        }, items.length * 50 + 200);
                    }
                }
            })
            .catch(error => {
                console.error('Error clearing notifications:', error);
                form.submit();
            });
            
            document.body.removeChild(form);
        }

        // Dismiss notification function
        function dismissNotification(event, notifId) {
            event.preventDefault();
            event.stopPropagation();
            
            if (!notifId) return;
            
            // Create form and submit via AJAX
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            
            const inputAction = document.createElement('input');
            inputAction.type = 'hidden';
            inputAction.name = 'dismiss_notification';
            inputAction.value = '1';
            
            const inputId = document.createElement('input');
            inputId.type = 'hidden';
            inputId.name = 'notif_id';
            inputId.value = notifId;
            
            const inputAjax = document.createElement('input');
            inputAjax.type = 'hidden';
            inputAjax.name = 'ajax';
            inputAjax.value = '1';
            
            form.appendChild(inputAction);
            form.appendChild(inputId);
            form.appendChild(inputAjax);
            document.body.appendChild(form);
            
            // Submit via fetch for better UX
            fetch(window.location.href, {
                method: 'POST',
                body: new FormData(form)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Remove notification from DOM
                    const notifItem = document.querySelector(`[data-notif-id="${notifId}"]`);
                    if (notifItem) {
                        notifItem.style.opacity = '0';
                        notifItem.style.transform = 'translateX(-10px)';
                        setTimeout(() => {
                            notifItem.remove();
                            // Check if no notifications left
                            const notifList = document.querySelector('.notif-list');
                            if (notifList && notifList.children.length === 0) {
                                const notifDropdown = document.getElementById('notifDropdown');
                                if (notifDropdown) {
                                    notifDropdown.innerHTML = '<h4>Notifications</h4><div class="notif-empty"><p>You\'re all caught up</p><span>We\'ll let you know when something new happens.</span></div>';
                                }
                                // Remove alert indicator
                                const notifBtn = document.getElementById('notifBtn');
                                if (notifBtn) {
                                    notifBtn.classList.remove('has-alert');
                                }
                            }
                        }, 200);
                    }
                }
            })
            .catch(error => {
                console.error('Error dismissing notification:', error);
                // Fallback to form submission
                form.submit();
            });
            
            document.body.removeChild(form);
        }

        const userMenu = document.getElementById('userMenu');
        const userDropdown = document.getElementById('userDropdown');

        if (userMenu && userDropdown) {
            userMenu.addEventListener('click', function (e) {
                e.stopPropagation();
                const isVisible = userDropdown.style.display === 'block';
                userDropdown.style.display = isVisible ? 'none' : 'block';
            });

            // Close dropdown when clicking outside
            document.addEventListener('click', function (e) {
                // Don't close if clicking on logout button (it will handle its own modal)
                if (!userMenu.contains(e.target) && e.target.id !== 'logoutBtn' && !e.target.closest('#logoutBtn')) {
                    userDropdown.style.display = 'none';
                }
            });
        }

        // Dashboard search + filters
        const searchInput = document.getElementById('dashboardSearch');
        const filterButtons = document.querySelectorAll('.filter-btn');
        const searchItems = document.querySelectorAll('.search-item');
        const searchFeedback = document.getElementById('searchFeedback');
        const deckSection = document.getElementById('deckSection');
        const activitySection = document.getElementById('activitySection');

        let activeFilter = 'all';

        function hasVisibleItems(container) {
            if (!container) return false;
            return Array.from(container.querySelectorAll('.search-item')).some(function (item) {
                return !item.classList.contains('hidden');
            });
        }

        function updateSectionVisibility() {
            if (deckSection) {
                const showDecks = activeFilter !== 'activity' && hasVisibleItems(deckSection);
                deckSection.classList.toggle('hidden', !showDecks);
            }
            if (activitySection) {
                const showActivity = activeFilter !== 'decks' && hasVisibleItems(activitySection);
                activitySection.classList.toggle('hidden', !showActivity);
            }
        }

        function applyFilters() {
            const term = searchInput ? searchInput.value.trim().toLowerCase() : '';
            let visibleCount = 0;

            searchItems.forEach(function (item) {
                const itemType = item.dataset.type || 'all';
                const matchesFilter = activeFilter === 'all' || itemType === activeFilter;
                const searchData = (item.dataset.search || item.textContent || '').toLowerCase();
                const matchesSearch = term === '' || searchData.includes(term);

                if (matchesFilter && matchesSearch) {
                    item.classList.remove('hidden');
                    visibleCount++;
                } else {
                    item.classList.add('hidden');
                }
            });

            updateSectionVisibility();

            if (searchFeedback) {
                const filterLabel = activeFilter === 'all'
                    ? 'all items'
                    : activeFilter === 'decks'
                        ? 'decks'
                        : 'activity';

                let message = 'Showing all items';

                if (term && visibleCount > 0) {
                    message = `Showing ${visibleCount} result${visibleCount === 1 ? '' : 's'} for “${searchInput.value.trim()}” in ${filterLabel}.`;
                } else if (term && visibleCount === 0) {
                    message = `No results found for “${searchInput.value.trim()}” in ${filterLabel}.`;
                } else if (!term && activeFilter !== 'all') {
                    message = `Showing ${filterLabel}.`;
                } else {
                    message = 'Showing all items';
                }

                searchFeedback.textContent = message;
            }
        }

        if (searchInput) {
            searchInput.addEventListener('input', applyFilters);
        }

        if (filterButtons.length) {
            filterButtons.forEach(function (button) {
                button.addEventListener('click', function () {
                    filterButtons.forEach(function (btn) {
                        btn.classList.remove('active');
                    });
                    button.classList.add('active');
                    activeFilter = button.dataset.filter || 'all';
                    applyFilters();
                });
            });
        }

        applyFilters();
    </script>

    <!-- Logout Confirmation Modal -->
    <div class="logout-modal-overlay" id="logoutModal">
        <div class="logout-modal">
            <div class="logout-modal-icon">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                </svg>
            </div>
            <div class="logout-modal-header">
                <h3 class="logout-modal-title">Confirm Logout</h3>
                <p class="logout-modal-message">Are you sure you want to logout? You will need to login again to access your account.</p>
            </div>
            <div class="logout-modal-actions">
                <button class="btn-modal btn-modal-cancel" id="logoutCancelBtn">Cancel</button>
                <button class="btn-modal btn-modal-logout" id="logoutConfirmBtn">Logout</button>
            </div>
        </div>
    </div>

    <script>
        // Logout Modal - Initialize after modal HTML is in DOM
        document.addEventListener('DOMContentLoaded', function() {
            const logoutBtn = document.getElementById('logoutBtn');
            const logoutModal = document.getElementById('logoutModal');
            const logoutConfirmBtn = document.getElementById('logoutConfirmBtn');
            const logoutCancelBtn = document.getElementById('logoutCancelBtn');

            if (logoutBtn) {
                logoutBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation(); // Prevent event from bubbling to user menu
                    if (logoutModal) {
                        logoutModal.classList.add('active');
                    }
                    // Close user dropdown when opening logout modal
                    const userDropdown = document.getElementById('userDropdown');
                    if (userDropdown) {
                        userDropdown.style.display = 'none';
                    }
                });
            }

            if (logoutCancelBtn) {
                logoutCancelBtn.addEventListener('click', function() {
                    if (logoutModal) {
                        logoutModal.classList.remove('active');
                    }
                });
            }

            if (logoutConfirmBtn) {
                logoutConfirmBtn.addEventListener('click', function() {
                    window.location.href = 'dashboard.php?logout=1';
                });
            }

            if (logoutModal) {
                logoutModal.addEventListener('click', function(e) {
                    if (e.target === logoutModal) {
                        logoutModal.classList.remove('active');
                    }
                });
            }

            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && logoutModal && logoutModal.classList.contains('active')) {
                    logoutModal.classList.remove('active');
                }
            });
        });
    </script>
</body>
</html>


<?php
session_start();
require_once 'config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get user information from session
$user_name = $_SESSION['user_name'] ?? 'User';
$user_email = $_SESSION['user_email'] ?? '';
$user_username = $_SESSION['user_username'] ?? '';
$user_id = (int)($_SESSION['user_id'] ?? 0);

// Get profile picture
$profile_picture_path = null;
$upload_dir = 'uploads/profiles/';
if ($user_id) {
    $stmt = $conn->prepare("SELECT profile_picture FROM profiles WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $profile_filename = $row['profile_picture'] ?? null;
        if (!empty($profile_filename)) {
            $candidate_path = $upload_dir . $profile_filename;
            $filesystem_path = __DIR__ . '/' . $candidate_path;
            if (file_exists($filesystem_path)) {
                $profile_picture_path = $candidate_path;
            }
        }
    }
    $stmt->close();
}

// Get user's theme color from themes table
$user_theme_color = '#dc2626'; // default
if ($user_id) {
    $stmt = $conn->prepare("SELECT theme_color FROM themes WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $user_theme_color = $row['theme_color'];
    }
    $stmt->close();
}

// Function to convert hex to RGB
function hexToRgb($hex) {
    $hex = str_replace('#', '', $hex);
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    return [$r, $g, $b];
}

// Function to darken a color
function darkenColor($hex, $percent = 20) {
    $rgb = hexToRgb($hex);
    $r = max(0, min(255, $rgb[0] - ($rgb[0] * $percent / 100)));
    $g = max(0, min(255, $rgb[1] - ($rgb[1] * $percent / 100)));
    $b = max(0, min(255, $rgb[2] - ($rgb[2] * $percent / 100)));
    return sprintf("#%02x%02x%02x", round($r), round($g), round($b));
}

// Calculate theme colors
$theme_rgb = hexToRgb($user_theme_color);
$theme_rgba_15 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.15)";
$theme_rgba_10 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.1)";
$theme_rgba_05 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.05)";
$theme_rgba_20 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.2)";
$theme_rgba_25 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.25)";
$theme_rgba_30 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.3)";
$theme_rgba_50 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.5)";
$theme_darker = darkenColor($user_theme_color, 15);

// Generate initials for avatar
function getInitials($name) {
    $words = explode(' ', trim($name));
    if (count($words) >= 2) {
        return strtoupper(substr($words[0], 0, 1) . substr($words[count($words) - 1], 0, 1));
    } else {
        return strtoupper(substr($name, 0, 2));
    }
}
$user_initials = getInitials($user_name);

// Handle logout
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: login.php");
    exit();
}

// --- Stats helpers ---
function tableExists(mysqli $conn, $table) {
    $table = $conn->real_escape_string($table);
    $res = $conn->query("SHOW TABLES LIKE '{$table}'");
    return $res && $res->num_rows > 0;
}

function formatRelativeTime(?string $datetime): string {
    if (empty($datetime)) {
        return '';
    }
    try {
        $time = new DateTime($datetime);
    } catch (Exception $e) {
        return '';
    }
    $now = new DateTime();
    $diff = $now->getTimestamp() - $time->getTimestamp();

    if ($diff < 60) {
        return $diff <= 1 ? 'just now' : $diff . 's ago';
    }
    if ($diff < 3600) {
        $mins = floor($diff / 60);
        return $mins . 'm ago';
    }
    if ($diff < 86400) {
        $hours = floor($diff / 3600);
        return $hours . 'h ago';
    }
    if ($diff < 604800) {
        $days = floor($diff / 86400);
        return $days . 'd ago';
    }
    return $time->format('M j');
}

// Handle notification dismissal
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['dismiss_notification'])) {
    $notif_id = $_POST['notif_id'] ?? '';
    if (!empty($notif_id)) {
        if (!isset($_SESSION['dismissed_notifications'])) {
            $_SESSION['dismissed_notifications'] = [];
        }
        if (!in_array($notif_id, $_SESSION['dismissed_notifications'])) {
            $_SESSION['dismissed_notifications'][] = $notif_id;
        }
        
        if (isset($_POST['ajax'])) {
            // Explicitly save session before sending AJAX response
            session_write_close();
            header('Content-Type: application/json');
            echo json_encode(['success' => true]);
            exit();
        }
        header("Location: " . strtok($_SERVER['REQUEST_URI'], '?'));
        exit();
    }
}

$notifications = [];
$dismissed_notifications = $_SESSION['dismissed_notifications'] ?? [];

if (tableExists($conn, 'friends')) {
    $stmt = $conn->prepare("
        SELECT f.created_at, u.full_name
        FROM friends f
        INNER JOIN users u ON f.user_id = u.id
        WHERE f.friend_id = ? AND f.status = 'pending'
        ORDER BY f.created_at DESC
        LIMIT 5
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $name = $row['full_name'] ?? 'Someone';
        $notif_id = 'friend_request_' . md5($row['created_at'] . $name);
        if (!in_array($notif_id, $dismissed_notifications)) {
            $notifications[] = [
                'id' => $notif_id,
                'title' => 'Friend request',
                'message' => "{$name} wants to connect with you.",
                'time' => formatRelativeTime($row['created_at'] ?? null),
                'icon' => '👥',
                'timestamp' => $row['created_at'] ?? date('Y-m-d H:i:s'),
                'type' => 'friend_request',
                'url' => 'friends.php'
            ];
        }
    }
    $stmt->close();
}

// 2. Deck shares received
if (tableExists($conn, 'deck_shares')) {
    $stmt = $conn->prepare("
        SELECT ds.id, ds.created_at, ds.message, d.title, u.full_name AS sender_name
        FROM deck_shares ds
        INNER JOIN decks d ON ds.deck_id = d.id
        INNER JOIN users u ON ds.sender_id = u.id
        WHERE ds.recipient_id = ? AND ds.status = 'pending'
        ORDER BY ds.created_at DESC
        LIMIT 5
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $sender = $row['sender_name'] ?? 'Someone';
        $deckTitle = $row['title'] ?? 'a deck';
        $share_id = $row['id'] ?? 0;
        $notif_id = 'deck_share_' . $share_id;
        if (!in_array($notif_id, $dismissed_notifications)) {
            $notifications[] = [
                'id' => $notif_id,
                'title' => 'Deck shared with you',
                'message' => "{$sender} shared \"{$deckTitle}\" with you.",
                'time' => formatRelativeTime($row['created_at'] ?? null),
                'icon' => '📤',
                'timestamp' => $row['created_at'] ?? date('Y-m-d H:i:s'),
                'type' => 'deck_share',
                'url' => 'friends.php'
            ];
        }
    }
    $stmt->close();
}

// 3. Report status updates (enhanced)
if (tableExists($conn, 'reports')) {
    $stmt = $conn->prepare("
        SELECT id, subject, status, updated_at
        FROM reports
        WHERE user_id = ? 
        AND status IN ('resolved', 'in_progress', 'rejected')
        AND updated_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        ORDER BY updated_at DESC
        LIMIT 5
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $subject = $row['subject'] ?? 'Your report';
        $status = $row['status'] ?? 'updated';
        $report_id = $row['id'] ?? 0;
        $statusText = ucfirst(str_replace('_', ' ', $status));
        $notif_id = 'report_update_' . $report_id;
        if (!in_array($notif_id, $dismissed_notifications)) {
            $notifications[] = [
                'id' => $notif_id,
                'title' => 'Report status updated',
                'message' => "\"{$subject}\" is now {$statusText}.",
                'time' => formatRelativeTime($row['updated_at'] ?? null),
                'icon' => '📋',
                'timestamp' => $row['updated_at'] ?? date('Y-m-d H:i:s'),
                'type' => 'report_update',
                'url' => 'reports.php'
            ];
        }
    }
    $stmt->close();
}

// 4. Favorite deck updates
if (tableExists($conn, 'favorites') && tableExists($conn, 'decks')) {
    $stmt = $conn->prepare("
        SELECT d.id, d.title, d.updated_at, f.created_at AS favorited_at
        FROM favorites f
        INNER JOIN decks d ON f.deck_id = d.id
        WHERE f.user_id = ? 
        AND d.updated_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
        AND d.updated_at > f.created_at
        ORDER BY d.updated_at DESC
        LIMIT 5
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $title = $row['title'] ?? 'Untitled deck';
        $deck_id = $row['id'] ?? 0;
        $notif_id = 'favorite_update_' . $deck_id . '_' . md5($row['updated_at']);
        if (!in_array($notif_id, $dismissed_notifications)) {
            $notifications[] = [
                'id' => $notif_id,
                'title' => 'Favorite deck updated',
                'message' => "\"{$title}\" has been updated.",
                'time' => formatRelativeTime($row['updated_at'] ?? null),
                'icon' => '⭐',
                'timestamp' => $row['updated_at'] ?? date('Y-m-d H:i:s'),
                'type' => 'favorite_update',
                'url' => 'deck.php?id=' . $deck_id
            ];
        }
    }
    $stmt->close();
}

usort($notifications, function ($a, $b) {
    return strtotime($b['timestamp']) <=> strtotime($a['timestamp']);
});
$notifications = array_slice($notifications, 0, 10);
$has_notifications = !empty($notifications);

// Handle clear all notifications (after notifications are built)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['clear_all_notifications'])) {
    $all_notif_ids = array_column($notifications, 'id');
    if (!isset($_SESSION['dismissed_notifications'])) {
        $_SESSION['dismissed_notifications'] = [];
    }
    foreach ($all_notif_ids as $notif_id) {
        if (!empty($notif_id) && !in_array($notif_id, $_SESSION['dismissed_notifications'])) {
            $_SESSION['dismissed_notifications'][] = $notif_id;
        }
    }
    if (isset($_POST['ajax'])) {
        session_write_close();
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'count' => count($all_notif_ids)]);
        exit();
    }
    header("Location: " . strtok($_SERVER['REQUEST_URI'], '?'));
    exit();
}

// Form submission handling
$submit_success = '';
$submit_error = '';
$allowed_categories = ['bug','feature','performance','ui','security','other'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $subject = trim($_POST['subject'] ?? '');
    $category = strtolower(trim($_POST['category'] ?? ''));
    $message = trim($_POST['message'] ?? '');
    
    // Validation
    if ($subject === '') {
        $submit_error = 'Please provide a subject for your report.';
    } elseif ($category === '' || !in_array($category, $allowed_categories, true)) {
        $submit_error = 'Please select a valid category.';
    } elseif ($message === '') {
        $submit_error = 'Please provide a detailed message.';
    } elseif (strlen($message) < 10) {
        $submit_error = 'Please provide more details (at least 10 characters).';
    } else {
        if ($user_id <= 0) {
            $submit_error = 'Your session has expired. Please log in again.';
        } else {
            $initial_status = 'pending';
            $stmt = $conn->prepare("INSERT INTO reports (user_id, subject, category, message, status) VALUES (?, ?, ?, ?, ?)");
            if (!$stmt) {
                $submit_error = 'Failed to prepare the report. Please try again later.';
            } else {
                $stmt->bind_param("issss", $user_id, $subject, $category, $message, $initial_status);
                if ($stmt->execute()) {
                    $submit_success = 'Your report has been submitted successfully! Our admin team will review it shortly.';
                    // Clear form fields
                    $_POST = [];
                } else {
                    $submit_error = 'Failed to submit report. Please try again later.';
                }
                $stmt->close();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bizmo – Submit Report</title>
    <meta name="description" content="Submit a report to the admin team">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #0b0b12;
            --text: #ffffff;
            --muted: #a2a3ad;
            --accent: <?php echo $user_theme_color; ?>;
            --accent-700: <?php echo $theme_darker; ?>;
            --surface: #111118;
            --border: rgba(255,255,255,0.08);
            --soft-accent: <?php echo $theme_rgba_15; ?>;
        }

        * { box-sizing: border-box; }
        html, body { height: 100%; }
        body {
            margin: 0;
            font-family: 'Inter', ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial;
            background: linear-gradient(180deg, #0c0c14 0%, #0c0c14 55%, #0c0c14 100%);
            color: var(--text);
        }

        /* Header */
        .header {
            position: sticky; top: 0; z-index: 30;
            backdrop-filter: saturate(180%) blur(20px);
            background: rgba(10,10,15,0.8);
            border-bottom: 1px solid var(--border);
            box-shadow: 0 4px 24px rgba(0,0,0,0.2);
        }
        .header-content {
            max-width: 1400px; margin: 0 auto; padding: 0 24px;
            display: flex; align-items: center; justify-content: space-between;
            padding-top: 18px; padding-bottom: 18px;
        }
        .brand {
            display: inline-flex; align-items: center; gap: 12px;
            font-weight: 800; font-size: 18px; color: var(--text);
            text-decoration: none; transition: transform .2s ease;
        }
        .brand:hover { transform: scale(1.02); }
        .logo {
            background: linear-gradient(135deg, <?php echo $theme_rgba_10; ?>, <?php echo $theme_rgba_05; ?>);
            box-shadow: 0 4px 12px <?php echo $theme_rgba_15; ?>;
            border: 1px solid <?php echo $theme_rgba_20; ?>;
            width: 50px; height: 50px; border-radius: 12px;
            display: grid; place-items: center;
            transition: all .3s ease;
        }
        .logo:hover { transform: rotate(5deg) scale(1.05); }
        .logo svg, .logo img { width: 50px; height: 50px; display: block; }

        .header-right { display: flex; align-items: center; gap: 12px; }
        .notif-btn {
            width: 44px; height: 44px; border-radius: 12px;
            background: rgba(255,255,255,0.04);
            border: 1px solid var(--border);
            display: grid; place-items: center; cursor: pointer;
            color: var(--text); transition: all .25s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
        }
        .notif-btn:hover {
            background: rgba(255,255,255,0.08);
            border-color: var(--accent);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px <?php echo $theme_rgba_20; ?>;
        }
        .notif-btn::after {
            content: ''; position: absolute; top: 8px; right: 8px;
            width: 8px; height: 8px; border-radius: 50%;
            background: var(--accent); box-shadow: 0 0 8px var(--accent);
            opacity: 0; transform: scale(0.4);
            transition: opacity 0.2s ease, transform 0.2s ease;
        }
        .notif-btn.has-alert::after {
            opacity: 1;
            transform: scale(1);
        }
        .notif-dropdown {
            position: absolute;
            top: calc(100% + 12px);
            right: 0;
            width: min(340px, 90vw);
            background: rgba(10,10,15,0.98);
            border: 1px solid var(--border);
            border-radius: 16px;
            box-shadow: 0 16px 40px rgba(0,0,0,0.45);
            padding: 0;
            display: none;
            z-index: 1000;
            overflow: hidden;
        }
        .notif-dropdown.show { display: block; }
        .notif-dropdown h4 {
            margin: 0;
            padding: 16px 16px 12px;
            font-size: 16px;
            font-weight: 700;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .notif-clear-all {
            font-size: 13px;
            font-weight: 600;
            color: var(--muted);
            background: none;
            border: none;
            cursor: pointer;
            padding: 4px 8px;
            border-radius: 6px;
            transition: all 0.2s ease;
            text-decoration: none;
            display: inline-block;
        }
        .notif-clear-all:hover {
            color: var(--text);
            background: rgba(255,255,255,0.05);
        }
        .notif-clear-all:active {
            transform: scale(0.95);
        }
        .notif-list {
            display: flex;
            flex-direction: column;
            gap: 0;
            max-height: 420px;
            overflow-y: auto;
            overflow-x: hidden;
            padding: 8px;
        }
        .notif-list::-webkit-scrollbar {
            width: 6px;
        }
        .notif-list::-webkit-scrollbar-track {
            background: transparent;
        }
        .notif-list::-webkit-scrollbar-thumb {
            background: rgba(255,255,255,0.15);
            border-radius: 3px;
        }
        .notif-list::-webkit-scrollbar-thumb:hover {
            background: rgba(255,255,255,0.25);
        }
        .notif-item {
            display: flex;
            gap: 12px;
            padding: 14px 40px 14px 14px;
            border-radius: 10px;
            border: 1px solid rgba(255,255,255,0.05);
            background: rgba(255,255,255,0.02);
            transition: all 0.2s ease;
            position: relative;
            cursor: pointer;
            margin-bottom: 8px;
        }
        .notif-item:last-child {
            margin-bottom: 0;
        }
        .notif-item:hover {
            border-color: rgba(255,255,255,0.15);
            background: rgba(255,255,255,0.06);
            transform: translateX(2px);
        }
        .notif-item-link {
            display: flex;
            gap: 12px;
            flex: 1;
            text-decoration: none;
            color: inherit;
        }
        .notif-dismiss {
            position: absolute;
            top: 50%;
            right: 12px;
            transform: translateY(-50%);
            width: 28px;
            height: 28px;
            border: none;
            background: rgba(255,255,255,0.08);
            border-radius: 8px;
            color: rgba(255,255,255,0.6);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: 600;
            line-height: 1;
            opacity: 0.6;
            transition: all 0.2s ease;
            z-index: 20;
            flex-shrink: 0;
        }
        .notif-item:hover .notif-dismiss {
            opacity: 1;
            background: rgba(239,68,68,0.15);
            color: #fca5a5;
        }
        .notif-dismiss:hover {
            background: rgba(239,68,68,0.25);
            color: #f87171;
            transform: translateY(-50%) scale(1.1);
        }
        .notif-dismiss:active {
            transform: translateY(-50%) scale(0.95);
        }
        .notif-icon {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            background: rgba(255,255,255,0.06);
            display: grid;
            place-items: center;
            font-size: 22px;
            flex-shrink: 0;
        }
        .notif-body { 
            flex: 1; 
            min-width: 0;
            overflow: hidden;
        }
        .notif-title {
            margin: 0;
            font-size: 14px;
            font-weight: 700;
            color: var(--text);
            line-height: 1.4;
        }
        .notif-message {
            margin: 6px 0 0;
            font-size: 13px;
            color: var(--muted);
            line-height: 1.5;
            word-wrap: break-word;
        }
        .notif-time {
            margin: 8px 0 0;
            font-size: 12px;
            color: rgba(255,255,255,0.5);
            font-weight: 500;
        }
        .notif-empty {
            padding: 40px 20px;
            text-align: center;
        }
        .notif-empty p {
            margin: 0;
            font-weight: 600;
            font-size: 15px;
            color: var(--text);
        }
        .notif-empty span {
            display: block;
            margin-top: 8px;
            font-size: 13px;
            color: var(--muted);
        }
        .user-menu {
            display: flex; align-items: center; gap: 12px; cursor: pointer;
            padding: 8px 14px 8px 8px; border-radius: 999px;
            background: rgba(255,255,255,0.04);
            border: 1px solid var(--border);
            transition: all .25s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
        }
        .user-menu:hover {
            background: rgba(255,255,255,0.08);
            border-color: var(--accent);
            transform: translateY(-1px);
        }
        .user-avatar {
            width: 36px; height: 36px; border-radius: 999px;
            background: linear-gradient(135deg, var(--accent), var(--accent-700));
            display: grid; place-items: center;
            font-weight: 700; font-size: 14px;
            box-shadow: 0 4px 12px <?php echo $theme_rgba_30; ?>;
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            overflow: hidden;
        }
        .user-avatar img {
            width: 100%; height: 100%; object-fit: cover; display: block;
        }

        /* Layout */
        .dashboard-layout {
            display: grid; grid-template-columns: 280px 1fr;
            max-width: 1400px; margin: 0 auto;
            min-height: calc(100vh - 74px);
        }

        /* Sidebar */
        .sidebar {
            padding: 28px 20px; border-right: 1px solid var(--border);
            background: rgba(10,10,15,0.6);
            backdrop-filter: blur(10px);
        }
        .sidebar-nav { display: flex; flex-direction: column; gap: 4px; }
        .nav-item {
            display: flex; align-items: center; gap: 14px;
            padding: 14px 16px; border-radius: 14px;
            color: var(--muted); text-decoration: none;
            font-weight: 600; font-size: 15px;
            transition: all .25s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
        }
        .nav-item:hover {
            background: rgba(255,255,255,0.05);
            color: var(--text);
            transform: translateX(4px);
        }
        .nav-item.active {
            background: linear-gradient(135deg, <?php echo $theme_rgba_20; ?>, <?php echo $theme_rgba_10; ?>);
            color: var(--text);
            border: 1px solid <?php echo $theme_rgba_30; ?>;
            box-shadow: 0 4px 12px <?php echo $theme_rgba_15; ?>;
        }
        .nav-item.active::before {
            content: ''; position: absolute; left: 0; top: 50%;
            transform: translateY(-50%);
            width: 3px; height: 60%; border-radius: 0 4px 4px 0;
            background: var(--accent);
        }
        .nav-icon {
            width: 22px; height: 22px; display: grid; place-items: center;
            font-size: 20px;
        }
        .nav-icon img,
        .nav-icon svg {
            width: 20px;
            height: 20px;
            display: block;
            object-fit: contain;
            filter: brightness(0) invert(1);
            opacity: 0.75;
            transition: opacity 0.2s ease, filter 0.2s ease;
        }
        .nav-item:hover .nav-icon img,
        .nav-item:hover .nav-icon svg,
        .nav-item.active .nav-icon img,
        .nav-item.active .nav-icon svg {
            opacity: 1;
        }
        .nav-item.active .nav-icon img,
        .nav-item.active .nav-icon svg {
            filter: brightness(0) invert(1) drop-shadow(0 0 6px <?php echo $theme_rgba_25; ?>);
        }

        /* Main Content */
        .main-content { padding: 40px; }
        .page-header { margin-bottom: 40px; }
        .page-title {
            font-size: 36px; font-weight: 900; margin: 0 0 10px;
            background: linear-gradient(135deg, #fff, rgba(255,255,255,0.8));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .page-subtitle {
            color: var(--muted); font-size: 17px; margin: 0;
            font-weight: 500;
        }

        /* Report Form Card */
        .report-card {
            background: linear-gradient(135deg, rgba(255,255,255,0.05), rgba(255,255,255,0.02));
            border: 1px solid var(--border);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.3);
        }

        .form-group {
            margin-bottom: 28px;
        }
        .form-label {
            display: block;
            font-size: 14px;
            font-weight: 700;
            color: var(--text);
            margin-bottom: 10px;
        }
        .form-label .required {
            color: var(--accent);
            margin-left: 4px;
        }
        .form-input,
        .form-select,
        .form-textarea {
            width: 100%;
            padding: 14px 18px;
            background: rgba(255,255,255,0.04);
            border: 1px solid var(--border);
            border-radius: 12px;
            color: var(--text);
            font-size: 15px;
            font-family: inherit;
            transition: all .25s ease;
        }
        .form-input:focus,
        .form-select:focus,
        .form-textarea:focus {
            outline: none;
            border-color: var(--accent);
            background: rgba(255,255,255,0.06);
            box-shadow: 0 0 0 3px <?php echo $theme_rgba_10; ?>;
        }
        .form-textarea {
            min-height: 180px;
            resize: vertical;
            line-height: 1.6;
        }
        .form-select {
            cursor: pointer;
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23a2a3ad' d='M6 9L1 4h10z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 18px center;
            padding-right: 45px;
        }
        .form-select option {
            background: var(--surface);
            color: var(--text);
        }

        .form-help {
            font-size: 13px;
            color: var(--muted);
            margin-top: 8px;
        }

        /* Alert Messages */
        .alert {
            padding: 16px 20px;
            border-radius: 12px;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 14px;
            font-weight: 600;
        }
        .alert-success {
            background: rgba(34, 197, 94, 0.15);
            border: 1px solid rgba(34, 197, 94, 0.3);
            color: #4ade80;
        }
        .alert-error {
            background: rgba(239, 68, 68, 0.15);
            border: 1px solid rgba(239, 68, 68, 0.3);
            color: #f87171;
        }
        .alert-icon {
            width: 20px;
            height: 20px;
            flex-shrink: 0;
        }

        /* Submit Button */
        .submit-btn {
            width: 100%;
            padding: 16px 24px;
            background: linear-gradient(135deg, var(--accent), var(--accent-700));
            border: none;
            border-radius: 12px;
            color: white;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: all .3s ease;
            box-shadow: 0 4px 16px <?php echo $theme_rgba_25; ?>;
        }
        .submit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 24px <?php echo $theme_rgba_30; ?>;
        }
        .submit-btn:active {
            transform: translateY(0);
        }
        .submit-btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }

        /* Info Section */
        .info-section {
            margin-top: 32px;
            padding: 24px;
            background: rgba(255,255,255,0.03);
            border: 1px solid var(--border);
            border-radius: 16px;
        }
        .info-title {
            font-size: 16px;
            font-weight: 700;
            margin: 0 0 12px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .info-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .info-list li {
            padding: 8px 0;
            font-size: 14px;
            color: var(--muted);
            display: flex;
            align-items: start;
            gap: 10px;
        }
        .info-list li::before {
            content: '•';
            color: var(--accent);
            font-weight: 700;
            font-size: 18px;
            line-height: 1;
        }

        .user-dropdown {
            position: absolute;
            top: calc(100% + 8px);
            right: 0;
            background: rgba(10,10,15,0.95);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 8px;
            min-width: 200px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.4);
            display: none;
            z-index: 1000;
            color: var(--text);
        }
        .user-dropdown > div {
            padding: 12px;
            border-bottom: 1px solid var(--border);
        }
        .user-dropdown > div > div:first-child {
            font-weight: 600;
            font-size: 14px;
            margin-bottom: 4px;
            color: var(--text);
        }
        .user-dropdown > div > div:last-child {
            font-size: 12px;
            color: var(--muted);
        }
        .user-dropdown a {
            display: block;
            padding: 12px;
            color: var(--text);
            text-decoration: none;
            border-radius: 8px;
            transition: background 0.2s ease;
            font-size: 14px;
            font-weight: 600;
        }
        .user-dropdown a:hover {
            background: rgba(255,255,255,0.05);
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .dashboard-layout { grid-template-columns: 1fr; }
            .sidebar { display: none; }
        }
        @media (max-width: 720px) {
            .main-content { padding: 24px; }
            .page-title { font-size: 28px; }
            .report-card { padding: 28px 20px; }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-content">
            <a href="dashboard.php" class="brand">
                <div class="logo" aria-label="Bizmo logo">
                    <img src="icons/bizmo.png" alt="" width="50" height="50" />
                </div>
                <span>Bizmo</span>
            </a>
            <div class="header-right">
                <div style="position: relative;">
                    <button class="notif-btn<?php echo $has_notifications ? ' has-alert' : ''; ?>" aria-label="Notifications" id="notifBtn">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/>
                        </svg>
                    </button>
                    <div class="notif-dropdown" id="notifDropdown">
                        <h4>
                            <span>Notifications</span>
                            <?php if (!empty($notifications)): ?>
                                <button type="button" class="notif-clear-all" onclick="clearAllNotifications(event)" aria-label="Clear all notifications">
                                    Clear all
                                </button>
                            <?php endif; ?>
                        </h4>
                        <?php if (!empty($notifications)): ?>
                            <div class="notif-list">
                                <?php foreach ($notifications as $notification): ?>
                                    <div class="notif-item" data-notif-id="<?php echo htmlspecialchars($notification['id'] ?? ''); ?>">
                                        <a href="<?php echo htmlspecialchars($notification['url'] ?? '#'); ?>" class="notif-item-link">
                                            <div class="notif-icon"><?php echo htmlspecialchars($notification['icon']); ?></div>
                                            <div class="notif-body">
                                                <p class="notif-title"><?php echo htmlspecialchars($notification['title']); ?></p>
                                                <p class="notif-message"><?php echo htmlspecialchars($notification['message']); ?></p>
                                                <p class="notif-time"><?php echo htmlspecialchars($notification['time']); ?></p>
                                            </div>
                                        </a>
                                        <button type="button" class="notif-dismiss" aria-label="Dismiss notification" onclick="dismissNotification(event, '<?php echo htmlspecialchars($notification['id'] ?? ''); ?>')">
                                            ×
                                        </button>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="notif-empty">
                                <p>You're all caught up</p>
                                <span>We'll let you know when something new happens.</span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="user-menu" id="userMenu">
                    <div class="user-avatar" style="<?php if ($profile_picture_path): ?>background-image: url('<?php echo htmlspecialchars($profile_picture_path); ?>');<?php endif; ?>">
                        <?php if (!$profile_picture_path): ?>
                            <?php echo htmlspecialchars($user_initials); ?>
                        <?php endif; ?>
                    </div>
                    <span style="font-weight: 600; font-size: 14px;"><?php echo htmlspecialchars($user_name); ?></span>
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                    </svg>
                    <div class="user-dropdown" id="userDropdown">
                        <div>
                            <div><?php echo htmlspecialchars($user_name); ?></div>
                            <div><?php echo htmlspecialchars($user_email); ?></div>
                        </div>
                        <a href="#" id="logoutBtn">
                            <span style="margin-right: 8px;">🚪</span> Logout
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <div class="dashboard-layout">
        <aside class="sidebar">
            <nav class="sidebar-nav">
                <a href="dashboard.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/dashboard.png" alt="" loading="lazy">
                    </span>
                    <span>Dashboard</span>
                </a>
                <a href="decks.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/cards.png" alt="" loading="lazy">
                    </span>
                    <span>My Decks</span>
                </a>
                <a href="progress.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/progress.png" alt="" loading="lazy">
                    </span>
                    <span>Progress</span>
                </a>
                <a href="favorites.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/favorite.png" alt="" loading="lazy">
                    </span>
                    <span>Favorites</span>
                </a>
                <a href="friends.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/friends.png" alt="" loading="lazy">
                    </span>
                    <span>Friends</span>
                </a>
                <a href="reports.php" class="nav-item active">
                    <span class="nav-icon" aria-hidden="true">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                        </svg>
                    </span>
                    <span>Reports</span>
                </a>
                <a href="planner.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/planner.png" alt="" loading="lazy">
                    </span>
                    <span>Study Planner</span>
                </a>
                <a href="settings.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/settings.png" alt="" loading="lazy">
                    </span>
                    <span>Settings</span>
                </a>
            </nav>
        </aside>

        <main class="main-content">
            <div class="page-header">
                <h1 class="page-title">Submit a Report</h1>
                <p class="page-subtitle">Help us improve by reporting issues, bugs, or sharing your feedback</p>
            </div>

            <div class="report-card">
                <?php if ($submit_success): ?>
                    <div class="alert alert-success" id="successMessage">
                        <svg class="alert-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                        <span><?php echo htmlspecialchars($submit_success); ?></span>
                    </div>
                <?php endif; ?>

                <?php if ($submit_error): ?>
                    <div class="alert alert-error">
                        <svg class="alert-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                        <span><?php echo htmlspecialchars($submit_error); ?></span>
                    </div>
                <?php endif; ?>

                <form method="POST" action="" id="reportForm">
                    <div class="form-group">
                        <label class="form-label" for="subject">
                            Subject
                            <span class="required">*</span>
                        </label>
                        <input 
                            type="text" 
                            id="subject" 
                            name="subject" 
                            class="form-input" 
                            placeholder="Brief description of your report"
                            value="<?php echo isset($_POST['subject']) ? htmlspecialchars($_POST['subject']) : ''; ?>"
                            required
                        >
                        <div class="form-help">Provide a clear, concise subject line</div>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="category">
                            Category
                            <span class="required">*</span>
                        </label>
                        <select id="category" name="category" class="form-select" required>
                            <option value="">Select a category</option>
                            <option value="bug" <?php echo (isset($_POST['category']) && $_POST['category'] === 'bug') ? 'selected' : ''; ?>>Bug Report</option>
                            <option value="feature" <?php echo (isset($_POST['category']) && $_POST['category'] === 'feature') ? 'selected' : ''; ?>>Feature Request</option>
                            <option value="performance" <?php echo (isset($_POST['category']) && $_POST['category'] === 'performance') ? 'selected' : ''; ?>>Performance Issue</option>
                            <option value="ui" <?php echo (isset($_POST['category']) && $_POST['category'] === 'ui') ? 'selected' : ''; ?>>UI/UX Issue</option>
                            <option value="security" <?php echo (isset($_POST['category']) && $_POST['category'] === 'security') ? 'selected' : ''; ?>>Security Concern</option>
                            <option value="other" <?php echo (isset($_POST['category']) && $_POST['category'] === 'other') ? 'selected' : ''; ?>>Other</option>
                        </select>
                        <div class="form-help">Choose the category that best fits your report</div>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="message">
                            Message
                            <span class="required">*</span>
                        </label>
                        <textarea 
                            id="message" 
                            name="message" 
                            class="form-textarea" 
                            placeholder="Please provide detailed information about your report. Include steps to reproduce if it's a bug, or describe your feature request in detail..."
                            required
                        ><?php echo isset($_POST['message']) ? htmlspecialchars($_POST['message']) : ''; ?></textarea>
                        <div class="form-help">Minimum 10 characters. Be as detailed as possible to help us understand and address your concern.</div>
                    </div>

                    <button type="submit" name="submit_report" class="submit-btn">
                        Submit Report
                    </button>
                </form>

                <div class="info-section">
                    <h3 class="info-title">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                        What happens next?
                    </h3>
                    <ul class="info-list">
                        <li>Your report will be reviewed by our admin team</li>
                        <li>We'll respond to your report as soon as possible</li>
                        <li>You can track the status of your report in your dashboard</li>
                        <li>We appreciate your feedback and will use it to improve Bizmo</li>
                    </ul>
                </div>
            </div>
        </main>
    </div>

    <script>
        // Notifications dropdown
        const notifBtn = document.getElementById('notifBtn');
        const notifDropdown = document.getElementById('notifDropdown');

        if (notifBtn && notifDropdown) {
            notifBtn.addEventListener('click', function (e) {
                e.stopPropagation();
                notifDropdown.classList.toggle('show');
            });

            document.addEventListener('click', function (e) {
                if (!notifDropdown.contains(e.target) && e.target !== notifBtn) {
                    notifDropdown.classList.remove('show');
                }
            });
        }

        // Clear all notifications function
        function clearAllNotifications(event) {
            event.preventDefault();
            event.stopPropagation();
            
            if (!confirm('Clear all notifications?')) {
                return;
            }
            
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            
            const inputAction = document.createElement('input');
            inputAction.type = 'hidden';
            inputAction.name = 'clear_all_notifications';
            inputAction.value = '1';
            
            const inputAjax = document.createElement('input');
            inputAjax.type = 'hidden';
            inputAjax.name = 'ajax';
            inputAjax.value = '1';
            
            form.appendChild(inputAction);
            form.appendChild(inputAjax);
            document.body.appendChild(form);
            
            fetch(window.location.href, {
                method: 'POST',
                body: new FormData(form)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const notifList = document.querySelector('.notif-list');
                    if (notifList) {
                        const items = notifList.querySelectorAll('.notif-item');
                        items.forEach((item, index) => {
                            setTimeout(() => {
                                item.style.opacity = '0';
                                item.style.transform = 'translateX(-10px)';
                                setTimeout(() => item.remove(), 200);
                            }, index * 50);
                        });
                        
                        setTimeout(() => {
                            const notifDropdown = document.getElementById('notifDropdown');
                            if (notifDropdown) {
                                notifDropdown.innerHTML = '<h4><span>Notifications</span></h4><div class="notif-empty"><p>You\'re all caught up</p><span>We\'ll let you know when something new happens.</span></div>';
                            }
                            const notifBtn = document.getElementById('notifBtn');
                            if (notifBtn) {
                                notifBtn.classList.remove('has-alert');
                            }
                        }, items.length * 50 + 200);
                    }
                }
            })
            .catch(error => {
                console.error('Error clearing notifications:', error);
                form.submit();
            });
            
            document.body.removeChild(form);
        }

        // Dismiss notification function
        function dismissNotification(event, notifId) {
            event.preventDefault();
            event.stopPropagation();
            
            if (!notifId) return;
            
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            
            const inputAction = document.createElement('input');
            inputAction.type = 'hidden';
            inputAction.name = 'dismiss_notification';
            inputAction.value = '1';
            
            const inputId = document.createElement('input');
            inputId.type = 'hidden';
            inputId.name = 'notif_id';
            inputId.value = notifId;
            
            const inputAjax = document.createElement('input');
            inputAjax.type = 'hidden';
            inputAjax.name = 'ajax';
            inputAjax.value = '1';
            
            form.appendChild(inputAction);
            form.appendChild(inputId);
            form.appendChild(inputAjax);
            document.body.appendChild(form);
            
            fetch(window.location.href, {
                method: 'POST',
                body: new FormData(form)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const notifItem = document.querySelector(`[data-notif-id="${notifId}"]`);
                    if (notifItem) {
                        notifItem.style.opacity = '0';
                        notifItem.style.transform = 'translateX(-10px)';
                        setTimeout(() => {
                            notifItem.remove();
                            const notifList = document.querySelector('.notif-list');
                            if (notifList && notifList.children.length === 0) {
                                const notifDropdown = document.getElementById('notifDropdown');
                                if (notifDropdown) {
                                    notifDropdown.innerHTML = '<h4>Notifications</h4><div class="notif-empty"><p>You\'re all caught up</p><span>We\'ll let you know when something new happens.</span></div>';
                                }
                                const notifBtn = document.getElementById('notifBtn');
                                if (notifBtn) {
                                    notifBtn.classList.remove('has-alert');
                                }
                            }
                        }, 200);
                    }
                }
            })
            .catch(error => {
                console.error('Error dismissing notification:', error);
                form.submit();
            });
            
            document.body.removeChild(form);
        }

        // User menu dropdown
        const userMenu = document.getElementById('userMenu');
        const userDropdown = document.getElementById('userDropdown');

        if (userMenu && userDropdown) {
            userMenu.addEventListener('click', function (e) {
                e.stopPropagation();
                const isVisible = userDropdown.style.display === 'block';
                userDropdown.style.display = isVisible ? 'none' : 'block';
            });

            // Close dropdown when clicking outside
            document.addEventListener('click', function (e) {
                if (!userMenu.contains(e.target)) {
                    userDropdown.style.display = 'none';
                }
            });
        }

        // Form validation
        const form = document.getElementById('reportForm');
        const submitBtn = form.querySelector('.submit-btn');
        
        form.addEventListener('submit', function(e) {
            const subject = document.getElementById('subject').value.trim();
            const category = document.getElementById('category').value;
            const message = document.getElementById('message').value.trim();
            
            if (!subject || !category || !message) {
                e.preventDefault();
                alert('Please fill in all required fields.');
                return false;
            }
            
            if (message.length < 10) {
                e.preventDefault();
                alert('Message must be at least 10 characters long.');
                return false;
            }
            
            // Disable button to prevent double submission
            submitBtn.disabled = true;
            submitBtn.textContent = 'Submitting...';
        });

        // Auto-hide success message after 3 seconds
        const successMessage = document.getElementById('successMessage');
        if (successMessage) {
            setTimeout(function() {
                successMessage.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
                successMessage.style.opacity = '0';
                successMessage.style.transform = 'translateY(-10px)';
                setTimeout(function() {
                    successMessage.remove();
                }, 300);
            }, 3000);
        }

    </script>

    <!-- Logout Confirmation Modal -->
    <div class="logout-modal-overlay" id="logoutModal">
        <div class="logout-modal">
            <div class="logout-modal-icon">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                </svg>
            </div>
            <div class="logout-modal-header">
                <h3 class="logout-modal-title">Confirm Logout</h3>
                <p class="logout-modal-message">Are you sure you want to logout? You will need to login again to access your account.</p>
            </div>
            <div class="logout-modal-actions">
                <button class="btn-modal btn-modal-cancel" id="logoutCancelBtn">Cancel</button>
                <button class="btn-modal btn-modal-logout" id="logoutConfirmBtn">Logout</button>
            </div>
        </div>
    </div>

    <script>
        // Logout Modal - Initialize after modal HTML is in DOM
        document.addEventListener('DOMContentLoaded', function() {
            const logoutBtn = document.getElementById('logoutBtn');
            const logoutModal = document.getElementById('logoutModal');
            const logoutConfirmBtn = document.getElementById('logoutConfirmBtn');
            const logoutCancelBtn = document.getElementById('logoutCancelBtn');

            if (logoutBtn) {
                logoutBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    if (logoutModal) {
                        logoutModal.classList.add('active');
                    }
                    // Close user dropdown when opening logout modal
                    const userDropdown = document.getElementById('userDropdown');
                    if (userDropdown) {
                        userDropdown.style.display = 'none';
                    }
                });
            }

            if (logoutCancelBtn) {
                logoutCancelBtn.addEventListener('click', function() {
                    if (logoutModal) {
                        logoutModal.classList.remove('active');
                    }
                });
            }

            if (logoutConfirmBtn) {
                logoutConfirmBtn.addEventListener('click', function() {
                    window.location.href = 'dashboard.php?logout=1';
                });
            }

            if (logoutModal) {
                logoutModal.addEventListener('click', function(e) {
                    if (e.target === logoutModal) {
                        logoutModal.classList.remove('active');
                    }
                });
            }

            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && logoutModal && logoutModal.classList.contains('active')) {
                    logoutModal.classList.remove('active');
                }
            });
        });
    </script>
</body>
</html>

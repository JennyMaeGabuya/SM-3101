<?php
session_start();
require_once '../config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

if (!isset($_GET['id'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'Email ID required']);
    exit();
}

$email_id = (int)$_GET['id'];

try {
    // Allow viewing deleted emails (for trash tab)
    $stmt = $conn->prepare("SELECT * FROM incoming_emails WHERE id = ?");
    $stmt->bind_param("i", $email_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($email = $result->fetch_assoc()) {
        // Mark as read if unread
        if ($email['read_status'] === 'unread') {
            $update_stmt = $conn->prepare("UPDATE incoming_emails SET read_status = 'read' WHERE id = ?");
            $update_stmt->bind_param("i", $email_id);
            $update_stmt->execute();
            $update_stmt->close();
            $email['read_status'] = 'read';
        }
        
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'email' => $email]);
    } else {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Email not found']);
    }
    
    $stmt->close();
} catch (Exception $e) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>


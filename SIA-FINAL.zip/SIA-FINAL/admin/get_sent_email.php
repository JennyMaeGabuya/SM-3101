<?php
session_start();
require_once '../config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

if (!isset($_GET['id'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'Email ID required']);
    exit();
}

$email_id = (int)$_GET['id'];

try {
    $stmt = $conn->prepare("
        SELECT e.*, a.full_name as admin_name, a.email as admin_email
        FROM emails e
        LEFT JOIN admin a ON e.admin_id = a.id
        WHERE e.id = ?
    ");
    $stmt->bind_param("i", $email_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($email = $result->fetch_assoc()) {
        // Fetch replies to this email
        $replies = [];
        try {
            // Check if reply_to_email_id column exists
            $replies_stmt = $conn->prepare("
                SELECT * FROM incoming_emails 
                WHERE reply_to_email_id = ? AND deleted = 0
                ORDER BY created_at ASC
            ");
            $replies_stmt->bind_param("i", $email_id);
            $replies_stmt->execute();
            $replies_result = $replies_stmt->get_result();
            while ($reply = $replies_result->fetch_assoc()) {
                $replies[] = $reply;
            }
            $replies_stmt->close();
        } catch (Exception $e) {
            // Column might not exist yet, that's okay
            // Replies will be empty array
        }
        
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true, 
            'email' => $email,
            'replies' => $replies
        ]);
    } else {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Email not found']);
    }
    
    $stmt->close();
} catch (Exception $e) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>


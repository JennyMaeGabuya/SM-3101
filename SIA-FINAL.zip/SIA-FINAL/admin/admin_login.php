<?php
session_start();
require_once '../config.php';

// If already logged in, redirect to dashboard
if (isset($_SESSION['admin_id'])) {
    header("Location: admin_dashboard.php");
    exit();
}

$login_error = '';

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $email_or_username = trim($_POST['email_or_username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($email_or_username) || empty($password)) {
        $login_error = "Please enter both email/username and password.";
    } else {
        // First, get the admin table structure to determine available columns
        $columns_result = $conn->query("SHOW COLUMNS FROM admin");
        $available_columns = [];
        if ($columns_result) {
            while ($col = $columns_result->fetch_assoc()) {
                $available_columns[] = $col['Field'];
            }
        }
        
        // Build dynamic query based on available columns
        $username_col = in_array('username', $available_columns) ? 'username' : (in_array('name', $available_columns) ? 'name' : null);
        $email_col = in_array('email', $available_columns) ? 'email' : null;
        $full_name_col = in_array('full_name', $available_columns) ? 'full_name' : (in_array('name', $available_columns) ? 'name' : null);
        $status_col = in_array('status', $available_columns) ? 'status' : (in_array('is_active', $available_columns) ? 'is_active' : (in_array('active', $available_columns) ? 'active' : null));
        
        // Build WHERE clause
        $where_conditions = [];
        $where_params = [];
        if ($username_col && $email_col) {
            $where_conditions[] = "({$username_col} = ? OR {$email_col} = ?)";
            $where_params[] = $email_or_username;
            $where_params[] = $email_or_username;
        } elseif ($username_col) {
            $where_conditions[] = "{$username_col} = ?";
            $where_params[] = $email_or_username;
        } elseif ($email_col) {
            $where_conditions[] = "{$email_col} = ?";
            $where_params[] = $email_or_username;
        } else {
            $login_error = "Admin table structure error. Please contact administrator.";
        }
        
        if (empty($login_error)) {
            // Build SELECT clause
            $select_fields = ['id', 'password'];
            if ($username_col) $select_fields[] = $username_col . ' as username';
            if ($email_col) $select_fields[] = $email_col . ' as email';
            if ($full_name_col) $select_fields[] = $full_name_col . ' as full_name';
            if ($status_col) $select_fields[] = $status_col . ' as status';
            
            $query = "SELECT " . implode(', ', $select_fields) . " FROM admin WHERE " . implode(' AND ', $where_conditions) . " LIMIT 1";
            
            $stmt = $conn->prepare($query);
            if ($stmt) {
                // Bind parameters
                $types = str_repeat('s', count($where_params));
                $stmt->bind_param($types, ...$where_params);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($result->num_rows > 0) {
                    $admin = $result->fetch_assoc();
                    
                    // Check status if available
                    $is_active = true;
                    if (isset($admin['status'])) {
                        $is_active = ($admin['status'] === 'active' || $admin['status'] === 1 || $admin['status'] === '1');
                    }
                    
                    if (!$is_active) {
                        $login_error = "Your admin account is inactive. Please contact administrator.";
                    } else {
                        // Verify password - try password_verify first (for hashed passwords)
                        $password_valid = false;
                        if (password_verify($password, $admin['password'])) {
                            $password_valid = true;
                        } elseif ($password === $admin['password']) {
                            // Plain text password match - upgrade to hashed
                            $password_valid = true;
                            $new_hash = password_hash($password, PASSWORD_DEFAULT);
                            $update_stmt = $conn->prepare("UPDATE admin SET password = ? WHERE id = ?");
                            $update_stmt->bind_param("si", $new_hash, $admin['id']);
                            $update_stmt->execute();
                            $update_stmt->close();
                        }
                        
                        if ($password_valid) {
                            // Login successful
                            $_SESSION['admin_id'] = $admin['id'];
                            $_SESSION['admin_name'] = $admin['full_name'] ?? 'Administrator';
                            $_SESSION['admin_email'] = $admin['email'] ?? '';
                            $_SESSION['admin_username'] = $admin['username'] ?? '';
                            
                            header("Location: admin_dashboard.php");
                            exit();
                        } else {
                            $login_error = "Invalid username or password.";
                        }
                    }
                } else {
                    $login_error = "Invalid username or password.";
                }
                $stmt->close();
            } else {
                $login_error = "Database error. Please try again.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bizmo – Admin Login</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #0b0b12;
            --surface: #111118;
            --surface-light: rgba(255,255,255,0.03);
            --text: #ffffff;
            --text-muted: #a2a3ad;
            --accent: #dc2626;
            --accent-purple: #9333ea;
            --accent-purple-light: rgba(147, 51, 234, 0.1);
            --border: rgba(255,255,255,0.08);
            --success: #22c55e;
            --warning: #f59e0b;
            --danger: #ef4444;
        }

        /* Light Theme Variables */
        body.light-theme {
            --bg: #f8f9fa;
            --surface: #ffffff;
            --surface-light: rgba(0,0,0,0.05);
            --text: #0f172a;
            --text-muted: #475569;
            --accent: #dc2626;
            --accent-purple: #9333ea;
            --accent-purple-light: rgba(147, 51, 234, 0.15);
            --border: rgba(0,0,0,0.15);
            --success: #16a34a;
            --warning: #d97706;
            --danger: #dc2626;
            background: var(--bg);
        }

        /* Enhanced contrast for light theme */
        body.light-theme .login-card {
            background: #ffffff;
            border: 1px solid rgba(0,0,0,0.12);
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }

        body.light-theme .form-input {
            background: #ffffff;
            border: 1px solid rgba(0,0,0,0.15);
            color: #0f172a;
        }

        body.light-theme .form-input:focus {
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(220,38,38,0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', ui-sans-serif, system-ui, -apple-system, sans-serif;
            background: var(--bg);
            color: var(--text);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        .login-container {
            width: 100%;
            max-width: 440px;
        }

        .login-card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 40px;
            position: relative;
        }

        .login-header {
            text-align: center;
            margin-bottom: 32px;
        }

        .login-logo {
            width: 64px;
            height: 64px;
            margin: 0 auto 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--accent-purple-light);
            border-radius: 16px;
        }

        .login-logo img {
            width: 40px;
            height: 40px;
        }

        .login-title {
            font-size: 28px;
            font-weight: 800;
            margin-bottom: 8px;
            color: var(--text);
        }

        .admin-badge {
            display: inline-block;
            padding: 4px 12px;
            background: var(--accent-purple-light);
            color: var(--accent-purple);
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
            margin-top: 8px;
        }

        .login-subtitle {
            font-size: 14px;
            color: var(--text-muted);
            margin-top: 8px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 8px;
            color: var(--text);
        }

        .form-input {
            width: 100%;
            padding: 12px 16px;
            background: var(--surface-light);
            border: 1px solid var(--border);
            border-radius: 8px;
            color: var(--text);
            font-size: 14px;
            font-family: inherit;
            transition: all 0.2s;
        }

        .form-input:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(220, 38, 38, 0.1);
        }

        .form-input::placeholder {
            color: var(--text-muted);
        }

        .password-input-wrapper {
            position: relative;
        }

        .password-toggle {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: var(--text-muted);
            cursor: pointer;
            padding: 4px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: color 0.2s;
        }

        .password-toggle:hover {
            color: var(--text);
        }

        .password-toggle svg {
            width: 20px;
            height: 20px;
        }

        .btn-primary {
            width: 100%;
            padding: 12px 24px;
            background: var(--accent);
            border: none;
            border-radius: 8px;
            color: white;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            margin-top: 8px;
        }

        .btn-primary:hover {
            background: #b91c1c;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(220, 38, 38, 0.3);
        }

        .btn-primary:active {
            transform: translateY(0);
        }

        .alert {
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
            font-weight: 500;
        }

        .alert-error {
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.3);
            color: var(--danger);
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: var(--text-muted);
            text-decoration: none;
            font-size: 14px;
            margin-top: 24px;
            transition: color 0.2s;
        }

        .back-link:hover {
            color: var(--text);
        }

        .back-link svg {
            width: 16px;
            height: 16px;
        }

        @media (max-width: 480px) {
            .login-card {
                padding: 24px;
            }

            .login-title {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <div class="login-logo">
                    <img src="../icons/bizmo.png" alt="Bizmo">
                </div>
                <h1 class="login-title">Admin Access</h1>
                <span class="admin-badge">Administrator</span>
                <p class="login-subtitle">Sign in to access the admin panel</p>
            </div>

            <?php if ($login_error): ?>
                <div class="alert alert-error">
                    <?php echo htmlspecialchars($login_error); ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="" id="loginForm">
                <div class="form-group">
                    <label class="form-label" for="email_or_username">Email or Username</label>
                    <input 
                        type="text" 
                        class="form-input" 
                        id="email_or_username" 
                        name="email_or_username" 
                        placeholder="Enter your email or username"
                        required
                        autofocus
                    >
                </div>

                <div class="form-group">
                    <label class="form-label" for="password">Password</label>
                    <div class="password-input-wrapper">
                        <input 
                            type="password" 
                            class="form-input" 
                            id="password" 
                            name="password" 
                            placeholder="Enter your password"
                            required
                        >
                        <button type="button" class="password-toggle" id="passwordToggle" aria-label="Toggle password visibility">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                            </svg>
                        </button>
                    </div>
                </div>

                <button type="submit" class="btn-primary" name="login">Sign In</button>
            </form>

        </div>
    </div>

    <script>
        // Password visibility toggle
        const passwordToggle = document.getElementById('passwordToggle');
        const passwordInput = document.getElementById('password');

        if (passwordToggle && passwordInput) {
            passwordToggle.addEventListener('click', function() {
                const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordInput.setAttribute('type', type);
                
                // Update icon
                if (type === 'text') {
                    passwordToggle.innerHTML = `
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"/>
                        </svg>
                    `;
                } else {
                    passwordToggle.innerHTML = `
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                        </svg>
                    `;
                }
            });
        }
    </script>
</body>
</html>







<?php
session_start();
require_once '../config.php';

// Handle logout
if (isset($_GET['logout'])) {
    session_unset();
    session_destroy();
    header("Location: admin_login.php");
    exit();
}

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

$admin_name = $_SESSION['admin_name'] ?? 'Administrator';
$admin_email = $_SESSION['admin_email'] ?? '';
$admin_username = $_SESSION['admin_username'] ?? '';

$unread_email_count = 0;
$unread_query = $conn->query("SELECT COUNT(*) AS total FROM incoming_emails WHERE read_status = 'unread' AND deleted = 0");
if ($unread_query) {
    $row = $unread_query->fetch_assoc();
    $unread_email_count = (int)($row['total'] ?? 0);
    $unread_query->free();
}

$pending_reports_count = 0;
$pending_reports_query = $conn->query("SELECT COUNT(*) AS total FROM reports WHERE status = 'pending'");
if ($pending_reports_query) {
    $row = $pending_reports_query->fetch_assoc();
    $pending_reports_count = (int)($row['total'] ?? 0);
    $pending_reports_query->free();
}

// Fetch all users from database
$users = [];
$total_users = 0;
$verified_users = 0;
$unverified_users = 0;

try {
    // Get total count
    $count_result = $conn->query("SELECT COUNT(*) as total FROM users");
    if ($count_result) {
        $total_users = $count_result->fetch_assoc()['total'];
    }
    
    // Get verified count
    $verified_result = $conn->query("SELECT COUNT(*) as total FROM users WHERE status = 'verified'");
    if ($verified_result) {
        $verified_users = $verified_result->fetch_assoc()['total'];
    }
    
    // Get unverified count
    $unverified_users = $total_users - $verified_users;
    
    // Fetch all users with profile pictures
    $result = $conn->query("
        SELECT u.id, u.full_name, u.email, u.username, u.status, u.created_at, p.profile_picture 
        FROM users u 
        LEFT JOIN profiles p ON u.id = p.user_id 
        ORDER BY u.created_at DESC
    ");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            // Get profile picture path if exists
            $profile_picture_path = null;
            if (!empty($row['profile_picture'])) {
                $upload_dir = '../uploads/profiles/';
                $profile_filename = $row['profile_picture'];
                $filesystem_path = __DIR__ . '/../uploads/profiles/' . $profile_filename;
                if (file_exists($filesystem_path)) {
                    $profile_picture_path = $upload_dir . $profile_filename;
                }
            }
            $row['profile_picture_path'] = $profile_picture_path;
            $users[] = $row;
        }
    }
} catch (Exception $e) {
    $error_message = "Error fetching users: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bizmo – Admin Users</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #0b0b12;
            --surface: #111118;
            --surface-light: rgba(255,255,255,0.03);
            --text: #ffffff;
            --text-muted: #a2a3ad;
            --accent: #dc2626;
            --accent-purple: #9333ea;
            --accent-purple-light: rgba(147, 51, 234, 0.1);
            --border: rgba(255,255,255,0.08);
            --success: #22c55e;
            --warning: #f59e0b;
            --danger: #ef4444;
        }

        /* Light Theme Variables */
        body.light-theme {
            --bg: #f8f9fa;
            --surface: #ffffff;
            --surface-light: rgba(0,0,0,0.05);
            --text: #0f172a;
            --text-muted: #475569;
            --accent: #dc2626;
            --accent-purple: #9333ea;
            --accent-purple-light: rgba(147, 51, 234, 0.15);
            --border: rgba(0,0,0,0.15);
            --success: #16a34a;
            --warning: #d97706;
            --danger: #dc2626;
            background: var(--bg);
        }

        /* Enhanced contrast for light theme */
        body.light-theme .sidebar {
            background: #ffffff;
            border-right: 1px solid rgba(0,0,0,0.12);
            box-shadow: 2px 0 8px rgba(0,0,0,0.05);
        }

        body.light-theme .table-card {
            background: #ffffff;
            border: 1px solid rgba(0,0,0,0.12);
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }

        body.light-theme .nav-link:hover {
            background: rgba(0,0,0,0.06);
        }

        body.light-theme .nav-link.active {
            background: rgba(147, 51, 234, 0.12);
            color: var(--accent-purple);
        }

        body.light-theme .btn-icon,
        body.light-theme .dark-mode-toggle-top {
            background: #f1f5f9;
            border: 1px solid rgba(0,0,0,0.12);
        }

        body.light-theme .btn-icon:hover {
            background: #e2e8f0;
        }

        body.light-theme .user-menu:hover {
            background: rgba(0,0,0,0.05);
        }

        body.light-theme .user-dropdown {
            background: #ffffff;
            border: 1px solid rgba(0,0,0,0.15);
            box-shadow: 0 10px 40px rgba(0,0,0,0.15);
        }

        body.light-theme table thead {
            background: #f8f9fa;
        }

        body.light-theme table td {
            border-bottom: 1px solid rgba(0,0,0,0.08);
        }

        body.light-theme .status-badge {
            font-weight: 600;
        }

        body.light-theme .modal-overlay {
            background: rgba(0, 0, 0, 0.5);
        }

        body.light-theme .logout-modal {
            background: #ffffff;
            border: 1px solid rgba(0,0,0,0.15);
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', ui-sans-serif, system-ui, -apple-system, sans-serif;
            background: var(--bg);
            color: var(--text);
            overflow-x: hidden;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 260px;
            background: var(--surface);
            border-right: 1px solid var(--border);
            padding: 24px;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            z-index: 100;
            display: flex;
            flex-direction: column;
        }

        .sidebar-logo {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 40px;
            font-size: 24px;
            font-weight: 900;
            color: var(--text);
        }

        .sidebar-logo img {
            width: 40px;
            height: 40px;
        }

        .nav-menu {
            list-style: none;
        }

        .nav-item {
            margin-bottom: 8px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            color: var(--text-muted);
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.2s;
            font-weight: 500;
            position: relative;
        }

        .nav-link:hover {
            background: var(--surface-light);
            color: var(--text);
        }

        .nav-link.active {
            background: var(--accent-purple-light);
            color: var(--accent-purple);
        }

        .nav-icon {
            width: 20px;
            height: 20px;
        }

        .nav-badge {
            margin-left: auto;
            padding: 2px 8px;
            border-radius: 999px;
            background: var(--danger);
            color: #fff;
            font-size: 11px;
            font-weight: 700;
            min-width: 24px;
            text-align: center;
        }

        .sidebar-footer {
            margin-top: auto;
            padding-top: 40px;
        }

        .dark-mode-toggle-top {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 8px 12px;
            background: var(--surface-light);
            border: 1px solid var(--border);
            border-radius: 8px;
        }

        .toggle-switch {
            width: 44px;
            height: 24px;
            background: var(--accent-purple);
            border-radius: 12px;
            position: relative;
            cursor: pointer;
            flex-shrink: 0;
            transition: all 0.3s;
        }

        .toggle-switch::after {
            content: '';
            position: absolute;
            width: 18px;
            height: 18px;
            background: white;
            border-radius: 50%;
            top: 3px;
            right: 3px;
            transition: all 0.3s;
        }

        body.light-theme .toggle-switch {
            background: #d1d5db;
        }

        body.light-theme .toggle-switch::after {
            right: 23px;
            background: white;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 260px;
            padding: 24px;
        }

        /* Top Bar */
        .top-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 32px;
            gap: 16px;
            flex-wrap: wrap;
        }

        .search-box {
            flex: 1;
            min-width: 300px;
            position: relative;
        }

        .search-box input {
            width: 100%;
            padding: 12px 16px 12px 44px;
            background: var(--surface-light);
            border: 1px solid var(--border);
            border-radius: 8px;
            color: var(--text);
            font-size: 14px;
        }

        .search-box input::placeholder {
            color: var(--text-muted);
        }

        .search-icon {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            width: 20px;
            height: 20px;
            color: var(--text-muted);
        }

        .top-actions {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .date-picker {
            padding: 12px 16px;
            background: var(--surface-light);
            border: 1px solid var(--border);
            border-radius: 8px;
            color: var(--text);
            font-size: 14px;
            cursor: default;
            user-select: none;
        }

        .user-menu {
            position: relative;
            display: flex;
            align-items: center;
            gap: 12px;
            cursor: pointer;
            padding: 8px;
            border-radius: 8px;
            transition: all 0.2s;
        }

        .user-menu:hover {
            background: var(--surface-light);
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--accent-purple);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            color: white;
        }

        .user-dropdown {
            position: absolute;
            top: calc(100% + 8px);
            right: 0;
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 8px;
            min-width: 200px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: all 0.2s;
            z-index: 1000;
        }

        .user-menu.active .user-dropdown {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }

        .user-dropdown-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            color: var(--text);
            text-decoration: none;
            transition: all 0.2s;
            border-bottom: 1px solid var(--border);
        }

        .user-dropdown-item:last-child {
            border-bottom: none;
        }

        .user-dropdown-item:hover {
            background: var(--surface-light);
        }

        /* Metrics Cards */
        .metrics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 32px;
        }

        .metric-card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 24px;
            position: relative;
        }

        .metric-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 16px;
        }

        .metric-title {
            font-size: 14px;
            color: var(--text-muted);
            font-weight: 500;
        }

        .metric-value {
            font-size: 32px;
            font-weight: 800;
            margin-bottom: 8px;
        }

        .metric-icon {
            position: absolute;
            top: 24px;
            right: 24px;
            width: 48px;
            height: 48px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0.1;
        }

        /* Table Card */
        .table-card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 24px;
        }

        .table-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 24px;
        }

        .table-title {
            font-size: 18px;
            font-weight: 700;
        }

        .table-actions {
            display: flex;
            gap: 12px;
        }

        .btn-secondary {
            padding: 10px 16px;
            background: var(--surface-light);
            border: 1px solid var(--border);
            border-radius: 8px;
            color: var(--text);
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
        }

        .btn-secondary:hover {
            background: var(--surface);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            border-bottom: 1px solid var(--border);
        }

        th {
            text-align: left;
            padding: 12px;
            font-size: 12px;
            font-weight: 600;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        td {
            padding: 16px 12px;
            border-bottom: 1px solid var(--border);
            font-size: 14px;
        }

        .status-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }

        .status-verified {
            background: rgba(34, 197, 94, 0.1);
            color: var(--success);
        }

        .status-unverified {
            background: rgba(245, 158, 11, 0.1);
            color: var(--warning);
        }

        .user-avatar-small {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--accent-purple);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            color: white;
            font-size: 14px;
            margin-right: 12px;
            flex-shrink: 0;
            overflow: hidden;
        }

        .user-avatar-small img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .user-row:hover {
            background: var(--surface-light);
        }

        /* User Details Modal */
        .user-details-modal {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 0;
            max-width: 900px;
            width: 100%;
            max-height: 90vh;
            position: relative;
            box-shadow: 0 40px 120px rgba(0,0,0,0.5);
            animation: slideUp 0.3s ease;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }

        .user-details-header {
            padding: 32px;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .user-details-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: var(--accent-purple);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            color: white;
            font-size: 32px;
            flex-shrink: 0;
            overflow: hidden;
        }

        .user-details-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .user-details-info h3 {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 8px;
            color: var(--text);
        }

        .user-details-info p {
            color: var(--text-muted);
            font-size: 14px;
            margin: 4px 0;
        }

        .user-details-body {
            padding: 32px;
            overflow-y: auto;
            flex: 1;
        }

        .user-details-section {
            margin-bottom: 32px;
        }

        .user-details-section h4 {
            font-size: 18px;
            font-weight: 700;
            margin-bottom: 16px;
            color: var(--text);
        }

        .user-details-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 24px;
        }

        .user-detail-item {
            padding: 16px;
            background: var(--surface-light);
            border: 1px solid var(--border);
            border-radius: 8px;
        }

        .user-detail-label {
            font-size: 12px;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 4px;
        }

        .user-detail-value {
            font-size: 16px;
            font-weight: 600;
            color: var(--text);
        }

        .decks-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 16px;
        }

        .deck-card {
            background: var(--surface-light);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 16px;
            transition: all 0.2s;
        }

        .deck-card:hover {
            background: var(--surface);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }

        .deck-icon {
            width: 48px;
            height: 48px;
            border-radius: 8px;
            background: var(--accent-purple);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 12px;
            overflow: hidden;
        }

        .deck-icon img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .deck-title {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 4px;
            color: var(--text);
        }

        .deck-description {
            font-size: 12px;
            color: var(--text-muted);
            margin-bottom: 8px;
        }

        .deck-meta {
            display: flex;
            align-items: center;
            justify-content: space-between;
            font-size: 12px;
            color: var(--text-muted);
        }

        .deck-card-count {
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .loading-spinner {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid var(--border);
            border-top-color: var(--accent-purple);
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        .no-decks {
            text-align: center;
            padding: 40px;
            color: var(--text-muted);
        }

        /* Logout Modal */
        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.75);
            backdrop-filter: blur(4px);
            z-index: 2000;
            align-items: center;
            justify-content: center;
            padding: 20px;
            animation: fadeIn 0.3s ease;
        }

        .modal-overlay.active {
            display: flex;
        }

        .logout-modal {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 32px;
            max-width: 400px;
            width: 100%;
            position: relative;
            box-shadow: 0 40px 120px rgba(0,0,0,0.5);
            animation: slideUp 0.3s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .modal-header {
            margin-bottom: 20px;
        }

        .modal-title {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 8px;
            color: var(--text);
        }

        .modal-message {
            color: var(--text-muted);
            font-size: 14px;
            line-height: 1.6;
        }

        .modal-actions {
            display: flex;
            gap: 12px;
            margin-top: 24px;
        }

        .btn-modal {
            flex: 1;
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
        }

        .btn-modal-cancel {
            background: var(--surface-light);
            border: 1px solid var(--border);
            color: var(--text);
        }

        .btn-modal-cancel:hover {
            background: var(--surface);
        }

        .btn-modal-logout {
            background: var(--danger);
            color: white;
        }

        .btn-modal-logout:hover {
            background: #dc2626;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
        }

        .modal-icon {
            width: 64px;
            height: 64px;
            margin: 0 auto 20px;
            background: rgba(239, 68, 68, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .modal-icon svg {
            width: 32px;
            height: 32px;
            color: var(--danger);
        }

        /* Custom Scrollbar Styles */
        /* Webkit browsers (Chrome, Safari, Edge) */
        ::-webkit-scrollbar {
            width: 12px;
            height: 12px;
        }

        ::-webkit-scrollbar-track {
            background: var(--surface);
            border-radius: 6px;
        }

        ::-webkit-scrollbar-thumb {
            background: var(--border);
            border-radius: 6px;
            border: 2px solid var(--surface);
            transition: background 0.2s ease;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: var(--accent-purple);
        }

        /* Light theme scrollbar */
        body.light-theme ::-webkit-scrollbar-track {
            background: #f1f5f9;
        }

        body.light-theme ::-webkit-scrollbar-thumb {
            background: rgba(0,0,0,0.2);
            border: 2px solid #f1f5f9;
        }

        body.light-theme ::-webkit-scrollbar-thumb:hover {
            background: var(--accent-purple);
        }

        /* Firefox */
        * {
            scrollbar-width: thin;
            scrollbar-color: var(--border) var(--surface);
        }

        body.light-theme * {
            scrollbar-color: rgba(0,0,0,0.2) #f1f5f9;
        }

        /* Sidebar scrollbar */
        .sidebar::-webkit-scrollbar {
            width: 8px;
        }

        .sidebar::-webkit-scrollbar-track {
            background: transparent;
        }

        .sidebar::-webkit-scrollbar-thumb {
            background: var(--border);
            border-radius: 4px;
            border: none;
        }

        .sidebar::-webkit-scrollbar-thumb:hover {
            background: var(--accent-purple);
        }

        body.light-theme .sidebar::-webkit-scrollbar-thumb {
            background: rgba(0,0,0,0.2);
        }

        body.light-theme .sidebar::-webkit-scrollbar-thumb:hover {
            background: var(--accent-purple);
        }

        /* Modal scrollbar */
        .deck-details-modal::-webkit-scrollbar,
        .logout-modal::-webkit-scrollbar {
            width: 8px;
        }

        .deck-details-modal::-webkit-scrollbar-track,
        .logout-modal::-webkit-scrollbar-track {
            background: var(--surface-light);
            border-radius: 4px;
        }

        .deck-details-modal::-webkit-scrollbar-thumb,
        .logout-modal::-webkit-scrollbar-thumb {
            background: var(--border);
            border-radius: 4px;
        }

        .deck-details-modal::-webkit-scrollbar-thumb:hover,
        .logout-modal::-webkit-scrollbar-thumb:hover {
            background: var(--accent-purple);
        }

        body.light-theme .deck-details-modal::-webkit-scrollbar-thumb,
        body.light-theme .logout-modal::-webkit-scrollbar-thumb {
            background: rgba(0,0,0,0.2);
        }

        body.light-theme .deck-details-modal::-webkit-scrollbar-thumb:hover,
        body.light-theme .logout-modal::-webkit-scrollbar-thumb:hover {
            background: var(--accent-purple);
        }

        /* User details content scrollbar */
        #userDetailsContent::-webkit-scrollbar {
            width: 8px;
        }

        #userDetailsContent::-webkit-scrollbar-track {
            background: var(--surface-light);
            border-radius: 4px;
        }

        #userDetailsContent::-webkit-scrollbar-thumb {
            background: var(--border);
            border-radius: 4px;
        }

        #userDetailsContent::-webkit-scrollbar-thumb:hover {
            background: var(--accent-purple);
        }

        body.light-theme #userDetailsContent::-webkit-scrollbar-track {
            background: #f1f5f9;
        }

        body.light-theme #userDetailsContent::-webkit-scrollbar-thumb {
            background: rgba(0,0,0,0.2);
        }

        body.light-theme #userDetailsContent::-webkit-scrollbar-thumb:hover {
            background: var(--accent-purple);
        }

        /* Table container scrollbar (if tables are scrollable) */
        .table-card::-webkit-scrollbar,
        table::-webkit-scrollbar {
            height: 8px;
        }

        .table-card::-webkit-scrollbar-track,
        table::-webkit-scrollbar-track {
            background: var(--surface-light);
            border-radius: 4px;
        }

        .table-card::-webkit-scrollbar-thumb,
        table::-webkit-scrollbar-thumb {
            background: var(--border);
            border-radius: 4px;
        }

        .table-card::-webkit-scrollbar-thumb:hover,
        table::-webkit-scrollbar-thumb:hover {
            background: var(--accent-purple);
        }

        body.light-theme .table-card::-webkit-scrollbar-track,
        body.light-theme table::-webkit-scrollbar-track {
            background: #f1f5f9;
        }

        body.light-theme .table-card::-webkit-scrollbar-thumb,
        body.light-theme table::-webkit-scrollbar-thumb {
            background: rgba(0,0,0,0.2);
        }

        body.light-theme .table-card::-webkit-scrollbar-thumb:hover,
        body.light-theme table::-webkit-scrollbar-thumb:hover {
            background: var(--accent-purple);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s;
            }

            .sidebar.open {
                transform: translateX(0);
            }

            .main-content {
                margin-left: 0;
            }

            .top-bar {
                flex-direction: column;
            }

            .search-box {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-logo">
                <img src="../icons/bizmo.png" alt="Bizmo">
                <span>Bizmo Admin</span>
            </div>

            <nav>
                <ul class="nav-menu">
                    <li class="nav-item">
                        <a href="admin_dashboard.php" class="nav-link">
                            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>
                            </svg>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="admin_users.php" class="nav-link active">
                            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/>
                            </svg>
                            <span>Users</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="users_decks.php" class="nav-link">
                            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/>
                            </svg>
                            <span>Decks</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="admin_email.php" class="nav-link">
                            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                            </svg>
                            <span>Emails</span>
                            <?php if ($unread_email_count > 0): ?>
                                <span class="nav-badge"><?php echo $unread_email_count > 99 ? '99+' : $unread_email_count; ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="admin_reports.php" class="nav-link">
                            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                            </svg>
                            <span>Reports</span>
                            <?php if ($pending_reports_count > 0): ?>
                                <span class="nav-badge"><?php echo $pending_reports_count > 99 ? '99+' : $pending_reports_count; ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                </ul>
            </nav>

            <div class="sidebar-footer">
                <a href="#" class="nav-link" id="logoutBtn" style="color: var(--danger);">
                    <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                    </svg>
                    Logout
                </a>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Top Bar -->
            <div class="top-bar">
                <div class="search-box">
                    <svg class="search-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                    </svg>
                    <input type="text" id="searchInput" placeholder="Search users by name, email, or username...">
                </div>

                <div class="top-actions">
                    <div class="date-picker" id="realtimeClock"></div>
                    <div class="dark-mode-toggle-top">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: var(--text-muted);">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/>
                        </svg>
                        <div class="toggle-switch" id="darkModeToggle"></div>
                    </div>
                    <div class="user-menu" id="userMenu">
                        <div class="user-avatar"><?php echo strtoupper(substr($admin_name, 0, 1)); ?></div>
                        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: var(--text-muted);">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                        </svg>
                        <div class="user-dropdown">
                            <div class="user-dropdown-item" style="pointer-events: none; border-bottom: 1px solid var(--border);">
                                <div>
                                    <div style="font-weight: 600; margin-bottom: 4px;"><?php echo htmlspecialchars($admin_name); ?></div>
                                    <div style="font-size: 12px; color: var(--text-muted);"><?php echo htmlspecialchars($admin_email); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Metrics Cards -->
            <div class="metrics-grid">
                <div class="metric-card">
                    <div class="metric-icon" style="background: rgba(147, 51, 234, 0.1);">
                        <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: var(--accent-purple);">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/>
                        </svg>
                    </div>
                    <div class="metric-header">
                        <span class="metric-title">Total Users</span>
                    </div>
                    <div class="metric-value"><?php echo number_format($total_users); ?></div>
                </div>

                <div class="metric-card">
                    <div class="metric-icon" style="background: rgba(34, 197, 94, 0.1);">
                        <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: var(--success);">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                    </div>
                    <div class="metric-header">
                        <span class="metric-title">Verified Users</span>
                    </div>
                    <div class="metric-value"><?php echo number_format($verified_users); ?></div>
                </div>

                <div class="metric-card">
                    <div class="metric-icon" style="background: rgba(245, 158, 11, 0.1);">
                        <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: var(--warning);">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
                        </svg>
                    </div>
                    <div class="metric-header">
                        <span class="metric-title">Unverified Users</span>
                    </div>
                    <div class="metric-value"><?php echo number_format($unverified_users); ?></div>
                </div>
            </div>

            <!-- Users Table -->
            <div class="table-card">
                <div class="table-header">
                    <h3 class="table-title">All Users</h3>
                    <div class="table-actions">
                        <button class="btn-secondary">Export</button>
                    </div>
                </div>
                <?php if (isset($error_message)): ?>
                    <div style="padding: 16px; background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); border-radius: 8px; color: var(--danger); margin-bottom: 20px;">
                        <?php echo htmlspecialchars($error_message); ?>
                    </div>
                <?php endif; ?>
                <table>
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>Email</th>
                            <th>Username</th>
                            <th>Status</th>
                            <th>Joined</th>
                        </tr>
                    </thead>
                    <tbody id="usersTableBody">
                        <?php if (empty($users)): ?>
                            <tr>
                                <td colspan="5" style="text-align: center; padding: 40px; color: var(--text-muted);">
                                    No users found in the database.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($users as $user): ?>
                                <tr class="user-row" 
                                    data-user-id="<?php echo $user['id']; ?>"
                                    data-name="<?php echo htmlspecialchars(strtolower($user['full_name'])); ?>" 
                                    data-email="<?php echo htmlspecialchars(strtolower($user['email'])); ?>" 
                                    data-username="<?php echo htmlspecialchars(strtolower($user['username'])); ?>"
                                    style="cursor: pointer;">
                                    <td>
                                        <div style="display: flex; align-items: center;">
                                            <div class="user-avatar-small">
                                                <?php if (!empty($user['profile_picture_path'])): ?>
                                                    <img src="<?php echo htmlspecialchars($user['profile_picture_path']); ?>" alt="<?php echo htmlspecialchars($user['full_name']); ?>">
                                                <?php else: ?>
                                                    <?php echo strtoupper(substr($user['full_name'], 0, 1)); ?>
                                                <?php endif; ?>
                                            </div>
                                            <strong><?php echo htmlspecialchars($user['full_name']); ?></strong>
                                        </div>
                                    </td>
                                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                                    <td><?php echo htmlspecialchars($user['username']); ?></td>
                                    <td>
                                        <span class="status-badge <?php echo $user['status'] === 'verified' ? 'status-verified' : 'status-unverified'; ?>">
                                            <?php echo ucfirst($user['status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>

    <!-- User Details Modal -->
    <div class="modal-overlay" id="userDetailsModal">
        <div class="user-details-modal">
            <div style="display: flex; align-items: center; justify-content: space-between; padding: 24px 32px; border-bottom: 1px solid var(--border); flex-shrink: 0;">
                <h2 style="font-size: 24px; font-weight: 700; color: var(--text); margin: 0;">User Details</h2>
                <button id="closeUserModal" style="width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; background: var(--surface-light); border: 1px solid var(--border); border-radius: 8px; color: var(--text); cursor: pointer; transition: all 0.2s;">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                    </svg>
                </button>
            </div>
            <div id="userDetailsContent" style="flex: 1; overflow-y: auto;">
                <div style="text-align: center; padding: 40px;">
                    <div class="loading-spinner" style="margin: 0 auto 16px;"></div>
                    <p style="color: var(--text-muted);">Loading user details...</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Logout Confirmation Modal -->
    <div class="modal-overlay" id="logoutModal">
        <div class="logout-modal">
            <div class="modal-icon">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                </svg>
            </div>
            <div class="modal-header">
                <h3 class="modal-title">Confirm Logout</h3>
                <p class="modal-message">Are you sure you want to logout? You will need to login again to access the admin panel.</p>
            </div>
            <div class="modal-actions">
                <button class="btn-modal btn-modal-cancel" id="logoutCancelBtn">Cancel</button>
                <button class="btn-modal btn-modal-logout" id="logoutConfirmBtn">Logout</button>
            </div>
        </div>
    </div>

    <script>
        // Theme Management
        function initTheme() {
            const savedTheme = localStorage.getItem('admin-theme') || 'dark';
            const body = document.body;
            
            if (savedTheme === 'light') {
                body.classList.add('light-theme');
            } else {
                body.classList.remove('light-theme');
            }
            
            updateToggleSwitch(savedTheme);
        }

        function updateToggleSwitch(theme) {
            const darkModeToggle = document.getElementById('darkModeToggle');
            if (darkModeToggle) {
                if (theme === 'light') {
                    darkModeToggle.classList.add('active');
                } else {
                    darkModeToggle.classList.remove('active');
                }
            }
        }

        function toggleTheme() {
            const body = document.body;
            const isLightTheme = body.classList.contains('light-theme');
            
            if (isLightTheme) {
                body.classList.remove('light-theme');
                localStorage.setItem('admin-theme', 'dark');
                updateToggleSwitch('dark');
            } else {
                body.classList.add('light-theme');
                localStorage.setItem('admin-theme', 'light');
                updateToggleSwitch('light');
            }
        }

        initTheme();

        const darkModeToggle = document.getElementById('darkModeToggle');
        if (darkModeToggle) {
            darkModeToggle.addEventListener('click', function(e) {
                e.stopPropagation();
                toggleTheme();
            });
        }

        // User menu dropdown
        const userMenu = document.getElementById('userMenu');
        if (userMenu) {
            userMenu.addEventListener('click', function(e) {
                e.stopPropagation();
                this.classList.toggle('active');
            });

            document.addEventListener('click', function(e) {
                if (!userMenu.contains(e.target)) {
                    userMenu.classList.remove('active');
                }
            });
        }

        // Search functionality
        const searchInput = document.getElementById('searchInput');
        const userRows = document.querySelectorAll('.user-row');
        
        if (searchInput) {
            searchInput.addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase().trim();
                
                userRows.forEach(row => {
                    const name = row.getAttribute('data-name') || '';
                    const email = row.getAttribute('data-email') || '';
                    const username = row.getAttribute('data-username') || '';
                    
                    if (name.includes(searchTerm) || email.includes(searchTerm) || username.includes(searchTerm)) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            });
        }

        // Logout Modal
        const logoutBtn = document.getElementById('logoutBtn');
        const logoutModal = document.getElementById('logoutModal');
        const logoutConfirmBtn = document.getElementById('logoutConfirmBtn');
        const logoutCancelBtn = document.getElementById('logoutCancelBtn');

        if (logoutBtn) {
            logoutBtn.addEventListener('click', function(e) {
                e.preventDefault();
                if (logoutModal) {
                    logoutModal.classList.add('active');
                    document.body.style.overflow = 'hidden';
                }
            });
        }

        if (logoutCancelBtn) {
            logoutCancelBtn.addEventListener('click', function() {
                if (logoutModal) {
                    logoutModal.classList.remove('active');
                    document.body.style.overflow = '';
                }
            });
        }

        if (logoutConfirmBtn) {
            logoutConfirmBtn.addEventListener('click', function() {
                window.location.href = '?logout=1';
            });
        }

        if (logoutModal) {
            logoutModal.addEventListener('click', function(e) {
                if (e.target === logoutModal) {
                    logoutModal.classList.remove('active');
                    document.body.style.overflow = '';
                }
            });
        }

        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && logoutModal && logoutModal.classList.contains('active')) {
                logoutModal.classList.remove('active');
                document.body.style.overflow = '';
            }
            if (e.key === 'Escape' && userDetailsModal && userDetailsModal.classList.contains('active')) {
                userDetailsModal.classList.remove('active');
                document.body.style.overflow = '';
            }
        });

        // User Details Modal
        const userDetailsModal = document.getElementById('userDetailsModal');
        const userDetailsContent = document.getElementById('userDetailsContent');
        const closeUserModal = document.getElementById('closeUserModal');

        // Function to load user details
        function loadUserDetails(userId) {
            userDetailsContent.innerHTML = `
                <div style="text-align: center; padding: 40px;">
                    <div class="loading-spinner" style="margin: 0 auto 16px;"></div>
                    <p style="color: var(--text-muted);">Loading user details...</p>
                </div>
            `;
            
            fetch(`get_user_details.php?user_id=${userId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        displayUserDetails(data);
                    } else {
                        userDetailsContent.innerHTML = `
                            <div style="text-align: center; padding: 40px; color: var(--danger);">
                                <p>Error: ${data.error || 'Failed to load user details'}</p>
                            </div>
                        `;
                    }
                })
                .catch(error => {
                    userDetailsContent.innerHTML = `
                        <div style="text-align: center; padding: 40px; color: var(--danger);">
                            <p>Error loading user details. Please try again.</p>
                        </div>
                    `;
                });
        }

        // Function to display user details in modal
        function displayUserDetails(data) {
            const user = data.user;
            const decks = data.decks || [];
            const stats = data.stats || {};
            
            const profileImg = user.profile_picture_path 
                ? `<img src="${user.profile_picture_path}" alt="${user.full_name}">`
                : user.full_name.charAt(0).toUpperCase();
            
            let decksHtml = '';
            if (decks.length > 0) {
                decksHtml = decks.map(deck => {
                    const deckIcon = deck.icon_src 
                        ? `<img src="${deck.icon_src}" alt="${deck.title}">`
                        : `<svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: ${deck.color || '#9333ea'}"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>`;
                    
                    return `
                        <div class="deck-card">
                            <div class="deck-icon" style="background: ${deck.color || '#9333ea'}20;">
                                ${deckIcon}
                            </div>
                            <div class="deck-title">${deck.title || 'Untitled Deck'}</div>
                            <div class="deck-description">${deck.description || 'No description'}</div>
                            <div class="deck-meta">
                                <div class="deck-card-count">
                                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/>
                                    </svg>
                                    ${deck.card_count || 0} cards
                                </div>
                                <div>${new Date(deck.updated_at).toLocaleDateString()}</div>
                            </div>
                        </div>
                    `;
                }).join('');
            } else {
                decksHtml = '<div class="no-decks">No decks created yet</div>';
            }
            
            userDetailsContent.innerHTML = `
                <div style="padding: 32px;">
                    <div class="user-details-header">
                        <div class="user-details-avatar">
                            ${profileImg}
                        </div>
                        <div class="user-details-info">
                            <h3>${user.full_name}</h3>
                            <p>${user.email}</p>
                            <p>@${user.username}</p>
                            <span class="status-badge ${user.status === 'verified' ? 'status-verified' : 'status-unverified'}" style="margin-top: 8px; display: inline-block;">
                                ${user.status.charAt(0).toUpperCase() + user.status.slice(1)}
                            </span>
                        </div>
                    </div>
                    <div class="user-details-section">
                        <h4>User Information</h4>
                        <div class="user-details-grid">
                            <div class="user-detail-item">
                                <div class="user-detail-label">User ID</div>
                                <div class="user-detail-value">#${user.id}</div>
                            </div>
                            <div class="user-detail-item">
                                <div class="user-detail-label">Full Name</div>
                                <div class="user-detail-value">${user.full_name}</div>
                            </div>
                            <div class="user-detail-item">
                                <div class="user-detail-label">Email</div>
                                <div class="user-detail-value">${user.email}</div>
                            </div>
                            <div class="user-detail-item">
                                <div class="user-detail-label">Username</div>
                                <div class="user-detail-value">@${user.username}</div>
                            </div>
                            <div class="user-detail-item">
                                <div class="user-detail-label">Status</div>
                                <div class="user-detail-value">
                                    <span class="status-badge ${user.status === 'verified' ? 'status-verified' : 'status-unverified'}">
                                        ${user.status.charAt(0).toUpperCase() + user.status.slice(1)}
                                    </span>
                                </div>
                            </div>
                            <div class="user-detail-item">
                                <div class="user-detail-label">Joined</div>
                                <div class="user-detail-value">${new Date(user.created_at).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</div>
                            </div>
                            <div class="user-detail-item">
                                <div class="user-detail-label">Total Decks</div>
                                <div class="user-detail-value">${stats.total_decks || 0}</div>
                            </div>
                            <div class="user-detail-item">
                                <div class="user-detail-label">Total Cards</div>
                                <div class="user-detail-value">${stats.total_cards || 0}</div>
                            </div>
                        </div>
                    </div>
                    <div class="user-details-section">
                        <h4>User Decks (${decks.length})</h4>
                        <div class="decks-grid">
                            ${decksHtml}
                        </div>
                    </div>
                </div>
            `;
        }

        // Add click handlers to user rows
        userRows.forEach(row => {
            row.addEventListener('click', function(e) {
                const userId = this.getAttribute('data-user-id');
                if (userId) {
                    userDetailsModal.classList.add('active');
                    document.body.style.overflow = 'hidden';
                    loadUserDetails(userId);
                }
            });
        });

        // Close user details modal
        if (closeUserModal) {
            closeUserModal.addEventListener('click', function() {
                userDetailsModal.classList.remove('active');
                document.body.style.overflow = '';
            });
        }

        // Close modal when clicking outside
        if (userDetailsModal) {
            userDetailsModal.addEventListener('click', function(e) {
                if (e.target === userDetailsModal) {
                    userDetailsModal.classList.remove('active');
                    document.body.style.overflow = '';
                }
            });
        }

        // Real-time clock
        function updateClock() {
            const clockElement = document.getElementById('realtimeClock');
            if (clockElement) {
                const now = new Date();
                let hours = now.getHours();
                const minutes = String(now.getMinutes()).padStart(2, '0');
                const seconds = String(now.getSeconds()).padStart(2, '0');
                const ampm = hours >= 12 ? 'PM' : 'AM';
                hours = hours % 12;
                hours = hours ? hours : 12; // the hour '0' should be '12'
                hours = String(hours).padStart(2, '0');
                clockElement.textContent = `${hours}:${minutes}:${seconds} ${ampm}`;
            }
        }

        // Update clock immediately and then every second
        updateClock();
        setInterval(updateClock, 1000);
    </script>
</body>
</html>


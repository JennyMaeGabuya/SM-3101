<?php
session_start();
require_once '../config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

if (!isset($_GET['user_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'User ID required']);
    exit();
}

$user_id = (int)$_GET['user_id'];

try {
    // Fetch user details with profile picture
    $stmt = $conn->prepare("
        SELECT u.id, u.full_name, u.email, u.username, u.status, u.created_at, p.profile_picture 
        FROM users u 
        LEFT JOIN profiles p ON u.id = p.user_id 
        WHERE u.id = ?
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($user = $result->fetch_assoc()) {
        // Get profile picture path if exists
        $profile_picture_path = null;
        if (!empty($user['profile_picture'])) {
            $upload_dir = '../uploads/profiles/';
            $profile_filename = $user['profile_picture'];
            $filesystem_path = __DIR__ . '/../uploads/profiles/' . $profile_filename;
            if (file_exists($filesystem_path)) {
                $profile_picture_path = $upload_dir . $profile_filename;
            }
        }
        $user['profile_picture_path'] = $profile_picture_path;
        
        // Fetch user's decks
        $decks_stmt = $conn->prepare("
            SELECT d.id, d.title, d.description, d.color, d.icon, d.updated_at,
                   COUNT(c.id) as card_count
            FROM decks d
            LEFT JOIN cards c ON d.id = c.deck_id
            WHERE d.user_id = ?
            GROUP BY d.id
            ORDER BY d.updated_at DESC, d.title ASC
        ");
        $decks_stmt->bind_param("i", $user_id);
        $decks_stmt->execute();
        $decks_result = $decks_stmt->get_result();
        
        $decks = [];
        while ($deck = $decks_result->fetch_assoc()) {
            // Build deck icon source
            $icon_src = '';
            if (!empty($deck['icon'])) {
                if (strpos($deck['icon'], 'data:') === 0) {
                    $icon_src = $deck['icon'];
                } else {
                    // Try to detect MIME type
                    $finfo = finfo_open(FILEINFO_MIME_TYPE);
                    $mime = $finfo ? finfo_buffer($finfo, $deck['icon']) : 'image/png';
                    if ($finfo) {
                        finfo_close($finfo);
                    }
                    $icon_src = 'data:' . $mime . ';base64,' . base64_encode($deck['icon']);
                }
            }
            $deck['icon_src'] = $icon_src;
            $deck['card_count'] = (int)$deck['card_count'];
            $decks[] = $deck;
        }
        $decks_stmt->close();
        
        // Calculate statistics
        $total_decks = count($decks);
        $total_cards = array_sum(array_column($decks, 'card_count'));
        
        $stats = [
            'total_decks' => $total_decks,
            'total_cards' => $total_cards
        ];
        
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true,
            'user' => $user,
            'decks' => $decks,
            'stats' => $stats
        ]);
    } else {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'User not found']);
    }
    
    $stmt->close();
} catch (Exception $e) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>











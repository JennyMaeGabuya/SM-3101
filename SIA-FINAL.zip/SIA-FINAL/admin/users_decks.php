<?php
session_start();
require_once '../config.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../phpmailer/src/Exception.php';
require '../phpmailer/src/PHPMailer.php';
require '../phpmailer/src/SMTP.php';

// Handle logout
if (isset($_GET['logout'])) {
    session_unset();
    session_destroy();
    header("Location: admin_login.php");
    exit();
}

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

$admin_name = $_SESSION['admin_name'] ?? 'Administrator';
$admin_email = $_SESSION['admin_email'] ?? '';
$admin_username = $_SESSION['admin_username'] ?? '';

$unread_email_count = 0;
$unread_query = $conn->query("SELECT COUNT(*) AS total FROM incoming_emails WHERE read_status = 'unread' AND deleted = 0");
if ($unread_query) {
    $row = $unread_query->fetch_assoc();
    $unread_email_count = (int)($row['total'] ?? 0);
    $unread_query->free();
}

$pending_reports_count = 0;
$pending_reports_query = $conn->query("SELECT COUNT(*) AS total FROM reports WHERE status = 'pending'");
if ($pending_reports_query) {
    $row = $pending_reports_query->fetch_assoc();
    $pending_reports_count = (int)($row['total'] ?? 0);
    $pending_reports_query->free();
}

// Create remove_decks table if it doesn't exist
$table_check = $conn->query("SHOW TABLES LIKE 'remove_decks'");
if ($table_check->num_rows == 0) {
    $conn->query("CREATE TABLE IF NOT EXISTS `remove_decks` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `deck_id` INT NOT NULL,
        `user_id` INT NOT NULL,
        `deck_title` VARCHAR(255) NOT NULL,
        `removal_reason` TEXT NOT NULL,
        `admin_id` INT NOT NULL,
        `admin_name` VARCHAR(255) NOT NULL,
        `removed_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `idx_remove_decks_deck` (`deck_id`),
        KEY `idx_remove_decks_user` (`user_id`),
        KEY `idx_remove_decks_admin` (`admin_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

$admin_id = $_SESSION['admin_id'] ?? 0;
$remove_success = '';
$remove_error = '';

// Handle deck removal
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_deck'])) {
    $deck_id = (int)($_POST['deck_id'] ?? 0);
    $removal_reason = trim($_POST['removal_reason'] ?? '');
    
    if ($deck_id <= 0) {
        $remove_error = 'Invalid deck selected.';
    } elseif (empty($removal_reason)) {
        $remove_error = 'Please provide a reason for removing this deck.';
    } else {
        // Get deck information before deletion
        $deck_stmt = $conn->prepare("
            SELECT d.id, d.user_id, d.title, u.full_name, u.email
            FROM decks d
            INNER JOIN users u ON d.user_id = u.id
            WHERE d.id = ?
        ");
        $deck_stmt->bind_param("i", $deck_id);
        $deck_stmt->execute();
        $deck_result = $deck_stmt->get_result();
        $deck_data = $deck_result->fetch_assoc();
        $deck_stmt->close();
        
        if (!$deck_data) {
            $remove_error = 'Deck not found.';
        } else {
            // Start transaction
            $conn->begin_transaction();
            
            try {
                // Delete all cards associated with the deck
                $delete_cards_stmt = $conn->prepare("DELETE FROM cards WHERE deck_id = ?");
                $delete_cards_stmt->bind_param("i", $deck_id);
                $delete_cards_stmt->execute();
                $delete_cards_stmt->close();
                
                // Delete the deck
                $delete_deck_stmt = $conn->prepare("DELETE FROM decks WHERE id = ?");
                $delete_deck_stmt->bind_param("i", $deck_id);
                $delete_deck_stmt->execute();
                $delete_deck_stmt->close();
                
                // Record the removal
                $record_stmt = $conn->prepare("
                    INSERT INTO remove_decks (deck_id, user_id, deck_title, removal_reason, admin_id, admin_name)
                    VALUES (?, ?, ?, ?, ?, ?)
                ");
                $record_stmt->bind_param("iissis", 
                    $deck_id,
                    $deck_data['user_id'],
                    $deck_data['title'],
                    $removal_reason,
                    $admin_id,
                    $admin_name
                );
                $record_stmt->execute();
                $record_stmt->close();
                
                // Commit transaction
                $conn->commit();
                
                // Send email to user
                $user_name = $deck_data['full_name'];
                $user_email = $deck_data['email'];
                $deck_title = $deck_data['title'];
                
                $email_subject = "Your deck has been removed from Bizmo";
                $email_body = "
                    <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;'>
                        <h2 style='color: #dc2626; margin-bottom: 20px;'>Hello {$user_name},</h2>
                        <p>We regret to inform you that your deck <strong>\"{$deck_title}\"</strong> has been removed from Bizmo.</p>
                        <div style='background: #0f172a; padding: 20px; border-radius: 10px; color: #e2e8f0; margin: 20px 0;'>
                            <h3 style='margin-top: 0; color: #fbbf24;'>Reason for removal:</h3>
                            " . nl2br(htmlspecialchars($removal_reason)) . "
                        </div>
                        <p style='color: #94a3b8;'>If you have any questions or concerns about this action, please contact our support team.</p>
                        <p style='margin-top: 30px;'>— Bizmo Admin Team</p>
                    </div>
                ";
                
                try {
                    $mail = new PHPMailer(true);
                    $mail->isSMTP();
                    $mail->Host = 'smtp.gmail.com';
                    $mail->SMTPAuth = true;
                    $mail->Username = 'bizmobsu@gmail.com';
                    $mail->Password = 'cohrugzxdhsjqybd';
                    $mail->SMTPSecure = 'tls';
                    $mail->Port = 587;
                    $mail->SMTPOptions = [
                        'ssl' => [
                            'verify_peer' => false,
                            'verify_peer_name' => false,
                            'allow_self_signed' => true
                        ]
                    ];
                    
                    $mail->setFrom('bizmobsu@gmail.com', 'Bizmo Admin');
                    $mail->addAddress($user_email, $user_name);
                    $mail->isHTML(true);
                    $mail->Subject = $email_subject;
                    $mail->Body = $email_body;
                    $mail->AltBody = "Hello {$user_name},\n\nYour deck \"{$deck_title}\" has been removed from Bizmo.\n\nReason: {$removal_reason}\n\n— Bizmo Admin Team";
                    $mail->send();
                } catch (Exception $e) {
                    // Email failed but deck was removed, so we continue
                    error_log("Failed to send deck removal email: " . $e->getMessage());
                }
                
                // Create notification for user (stored in session or database notification system)
                // Check if notifications table exists
                $notif_check = $conn->query("SHOW TABLES LIKE 'notifications'");
                if ($notif_check->num_rows > 0) {
                    $notif_stmt = $conn->prepare("
                        INSERT INTO notifications (user_id, type, title, message, created_at)
                        VALUES (?, 'deck_removed', 'Deck Removed', ?, NOW())
                    ");
                    $notif_message = "Your deck \"{$deck_title}\" has been removed. Please check your email for details.";
                    $notif_stmt->bind_param("is", $deck_data['user_id'], $notif_message);
                    $notif_stmt->execute();
                    $notif_stmt->close();
                }
                
                $remove_success = 'Deck removed successfully. The user has been notified via email.';
                header("Location: users_decks.php?success=1");
                exit();
                
            } catch (Exception $e) {
                $conn->rollback();
                $remove_error = 'Failed to remove deck: ' . $e->getMessage();
            }
        }
    }
}

// Function to build deck icon src
if (!function_exists('buildDeckIconSrc')) {
    function buildDeckIconSrc($iconValue) {
        if ($iconValue === null || $iconValue === '') {
            return '';
        }
        if (strpos($iconValue, 'data:') === 0) {
            return $iconValue;
        }
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = $finfo ? finfo_buffer($finfo, $iconValue) : null;
        if ($finfo) {
            finfo_close($finfo);
        }
        if (!$mime) {
            $mime = 'image/png';
        }
        return 'data:' . $mime . ';base64,' . base64_encode($iconValue);
    }
}

// Fetch all decks from database
$decks = [];
$total_decks = 0;
$total_cards = 0;
$total_users_with_decks = 0;

try {
    // Get total count
    $count_result = $conn->query("SELECT COUNT(*) as total FROM decks");
    if ($count_result) {
        $total_decks = $count_result->fetch_assoc()['total'];
    }
    
    // Get total cards
    $cards_result = $conn->query("SELECT COUNT(*) as total FROM cards");
    if ($cards_result) {
        $total_cards = $cards_result->fetch_assoc()['total'];
    }
    
    // Get unique users with decks
    $users_result = $conn->query("SELECT COUNT(DISTINCT user_id) as total FROM decks");
    if ($users_result) {
        $total_users_with_decks = $users_result->fetch_assoc()['total'];
    }
    
    // Fetch all decks with user information and card counts
    $result = $conn->query("
        SELECT d.id, d.user_id, d.title, d.description, d.color, d.icon, d.created_at, d.updated_at,
               u.full_name, u.email, u.username,
               COUNT(c.id) as card_count
        FROM decks d
        LEFT JOIN users u ON d.user_id = u.id
        LEFT JOIN cards c ON d.id = c.deck_id
        GROUP BY d.id, d.user_id, d.title, d.description, d.color, d.icon, d.created_at, d.updated_at, u.full_name, u.email, u.username
        ORDER BY d.updated_at DESC
    ");
    
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            // Process deck icon
            $deck_icon_src = null;
            if (!empty($row['icon'])) {
                $deck_icon_src = buildDeckIconSrc($row['icon']);
            }
            $row['icon_src'] = $deck_icon_src;
            $decks[] = $row;
        }
    }
} catch (Exception $e) {
    $error_message = "Error fetching decks: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bizmo – Admin Decks</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #0b0b12;
            --surface: #111118;
            --surface-light: rgba(255,255,255,0.03);
            --text: #ffffff;
            --text-muted: #a2a3ad;
            --accent: #dc2626;
            --accent-purple: #9333ea;
            --accent-purple-light: rgba(147, 51, 234, 0.1);
            --border: rgba(255,255,255,0.08);
            --success: #22c55e;
            --warning: #f59e0b;
            --danger: #ef4444;
        }

        /* Light Theme Variables */
        body.light-theme {
            --bg: #f8f9fa;
            --surface: #ffffff;
            --surface-light: rgba(0,0,0,0.05);
            --text: #0f172a;
            --text-muted: #475569;
            --accent: #dc2626;
            --accent-purple: #9333ea;
            --accent-purple-light: rgba(147, 51, 234, 0.15);
            --border: rgba(0,0,0,0.15);
            --success: #16a34a;
            --warning: #d97706;
            --danger: #dc2626;
            background: var(--bg);
        }

        /* Enhanced contrast for light theme */
        body.light-theme .sidebar {
            background: #ffffff;
            border-right: 1px solid rgba(0,0,0,0.12);
            box-shadow: 2px 0 8px rgba(0,0,0,0.05);
        }

        body.light-theme .table-card {
            background: #ffffff;
            border: 1px solid rgba(0,0,0,0.12);
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }

        body.light-theme .nav-link:hover {
            background: rgba(0,0,0,0.06);
        }

        body.light-theme .nav-link.active {
            background: rgba(147, 51, 234, 0.12);
            color: var(--accent-purple);
        }

        body.light-theme .btn-icon,
        body.light-theme .dark-mode-toggle-top {
            background: #f1f5f9;
            border: 1px solid rgba(0,0,0,0.12);
        }

        body.light-theme .btn-icon:hover {
            background: #e2e8f0;
        }

        body.light-theme .user-menu:hover {
            background: rgba(0,0,0,0.05);
        }

        body.light-theme .user-dropdown {
            background: #ffffff;
            border: 1px solid rgba(0,0,0,0.15);
            box-shadow: 0 10px 40px rgba(0,0,0,0.15);
        }

        body.light-theme table thead {
            background: #f8f9fa;
        }

        body.light-theme table td {
            border-bottom: 1px solid rgba(0,0,0,0.08);
        }

        body.light-theme .status-badge {
            font-weight: 600;
        }

        body.light-theme .modal-overlay {
            background: rgba(0, 0, 0, 0.5);
        }

        body.light-theme .logout-modal {
            background: #ffffff;
            border: 1px solid rgba(0,0,0,0.15);
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', ui-sans-serif, system-ui, -apple-system, sans-serif;
            background: var(--bg);
            color: var(--text);
            overflow-x: hidden;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 260px;
            background: var(--surface);
            border-right: 1px solid var(--border);
            padding: 24px;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            z-index: 100;
            display: flex;
            flex-direction: column;
        }

        .sidebar-logo {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 40px;
            font-size: 24px;
            font-weight: 900;
            color: var(--text);
        }

        .sidebar-logo img {
            width: 40px;
            height: 40px;
        }

        .nav-menu {
            list-style: none;
        }

        .nav-item {
            margin-bottom: 8px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            color: var(--text-muted);
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.2s;
            font-weight: 500;
            position: relative;
        }

        .nav-link:hover {
            background: var(--surface-light);
            color: var(--text);
        }

        .nav-link.active {
            background: var(--accent-purple-light);
            color: var(--accent-purple);
        }

        .nav-icon {
            width: 20px;
            height: 20px;
        }

        .nav-badge {
            margin-left: auto;
            padding: 2px 8px;
            border-radius: 999px;
            background: var(--danger);
            color: #fff;
            font-size: 11px;
            font-weight: 700;
            min-width: 24px;
            text-align: center;
        }

        .sidebar-footer {
            margin-top: auto;
            padding-top: 40px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 260px;
            padding: 24px;
        }

        /* Top Bar */
        .top-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 32px;
            gap: 16px;
            flex-wrap: wrap;
        }

        .search-box {
            flex: 1;
            min-width: 300px;
            position: relative;
        }

        .search-box input {
            width: 100%;
            padding: 12px 16px 12px 44px;
            background: var(--surface-light);
            border: 1px solid var(--border);
            border-radius: 8px;
            color: var(--text);
            font-size: 14px;
        }

        .search-box input::placeholder {
            color: var(--text-muted);
        }

        .search-icon {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            width: 20px;
            height: 20px;
            color: var(--text-muted);
        }

        .top-actions {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .date-picker {
            padding: 12px 16px;
            background: var(--surface-light);
            border: 1px solid var(--border);
            border-radius: 8px;
            color: var(--text);
            font-size: 14px;
            cursor: default;
            user-select: none;
        }

        .dark-mode-toggle-top {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 8px 12px;
            background: var(--surface-light);
            border: 1px solid var(--border);
            border-radius: 8px;
        }

        .toggle-switch {
            width: 44px;
            height: 24px;
            background: var(--accent-purple);
            border-radius: 12px;
            position: relative;
            cursor: pointer;
            flex-shrink: 0;
            transition: all 0.3s;
        }

        .toggle-switch::after {
            content: '';
            position: absolute;
            width: 18px;
            height: 18px;
            background: white;
            border-radius: 50%;
            top: 3px;
            right: 3px;
            transition: all 0.3s;
        }

        body.light-theme .toggle-switch {
            background: #d1d5db;
        }

        body.light-theme .toggle-switch::after {
            right: 23px;
            background: white;
        }

        .user-menu {
            position: relative;
            display: flex;
            align-items: center;
            gap: 12px;
            cursor: pointer;
            padding: 8px;
            border-radius: 8px;
            transition: all 0.2s;
        }

        .user-menu:hover {
            background: var(--surface-light);
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--accent-purple);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            color: white;
        }

        .user-dropdown {
            position: absolute;
            top: calc(100% + 8px);
            right: 0;
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 8px;
            min-width: 200px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: all 0.2s;
            z-index: 1000;
        }

        .user-menu.active .user-dropdown {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }

        .user-dropdown-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            color: var(--text);
            text-decoration: none;
            transition: all 0.2s;
            border-bottom: 1px solid var(--border);
        }

        .user-dropdown-item:last-child {
            border-bottom: none;
        }

        .user-dropdown-item:hover {
            background: var(--surface-light);
        }


        /* Metrics Cards */
        .metrics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 32px;
        }

        .metric-card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 24px;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .metric-icon {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .metric-header {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .metric-title {
            font-size: 14px;
            color: var(--text-muted);
            font-weight: 500;
        }

        .metric-value {
            font-size: 32px;
            font-weight: 800;
            color: var(--text);
        }

        /* Table Card */
        .table-card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 24px;
        }

        .table-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 24px;
        }

        .table-title {
            font-size: 20px;
            font-weight: 700;
            color: var(--text);
        }

        .table-actions {
            display: flex;
            gap: 12px;
        }

        .btn-secondary {
            padding: 10px 16px;
            background: var(--surface-light);
            border: 1px solid var(--border);
            border-radius: 8px;
            color: var(--text);
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
        }

        .btn-secondary:hover {
            background: var(--surface);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            border-bottom: 1px solid var(--border);
        }

        th {
            text-align: left;
            padding: 12px;
            font-size: 12px;
            font-weight: 600;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        td {
            padding: 16px 12px;
            border-bottom: 1px solid var(--border);
            font-size: 14px;
        }

        .deck-row {
            cursor: pointer;
            transition: all 0.2s;
        }

        .deck-row:hover {
            background: var(--surface-light);
        }

        .deck-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .deck-icon-small {
            width: 48px;
            height: 48px;
            border-radius: 8px;
            background: var(--accent-purple);
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            overflow: hidden;
        }

        .deck-icon-small img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .deck-icon-small svg {
            width: 24px;
            height: 24px;
            color: white;
        }

        .deck-title-text {
            font-weight: 600;
            color: var(--text);
            margin-bottom: 4px;
        }

        .deck-description-text {
            font-size: 12px;
            color: var(--text-muted);
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .user-avatar-small {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: var(--accent-purple);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            color: white;
            font-size: 12px;
            flex-shrink: 0;
        }

        .user-avatar-small img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .card-count {
            display: flex;
            align-items: center;
            gap: 6px;
            color: var(--text-muted);
            font-size: 14px;
        }

        /* Logout Modal */
        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.75);
            backdrop-filter: blur(4px);
            z-index: 2000;
            align-items: center;
            justify-content: center;
            padding: 20px;
            animation: fadeIn 0.3s ease;
        }

        .modal-overlay.active {
            display: flex;
        }

        .logout-modal {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 32px;
            max-width: 400px;
            width: 100%;
            position: relative;
            box-shadow: 0 40px 120px rgba(0,0,0,0.5);
            animation: slideUp 0.3s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .modal-header {
            margin-bottom: 20px;
        }

        .modal-title {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 8px;
            color: var(--text);
        }

        .modal-message {
            color: var(--text-muted);
            font-size: 14px;
            line-height: 1.6;
        }

        .modal-actions {
            display: flex;
            gap: 12px;
            margin-top: 24px;
        }

        .btn-modal {
            flex: 1;
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
        }

        .btn-modal-cancel {
            background: var(--surface-light);
            border: 1px solid var(--border);
            color: var(--text);
        }

        .btn-modal-cancel:hover {
            background: var(--surface);
        }

        .btn-modal-logout {
            background: var(--danger);
            color: white;
        }

        .btn-modal-logout:hover {
            background: #dc2626;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
        }

        .modal-icon {
            width: 64px;
            height: 64px;
            margin: 0 auto 20px;
            background: rgba(239, 68, 68, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .modal-icon svg {
            width: 32px;
            height: 32px;
            color: var(--danger);
        }

        /* Deck Details Modal */
        .deck-details-modal {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 32px;
            max-width: 600px;
            width: 100%;
            max-height: 90vh;
            overflow-y: auto;
            position: relative;
            box-shadow: 0 40px 120px rgba(0,0,0,0.5);
            animation: slideUp 0.3s ease;
        }

        .deck-details-header {
            display: flex;
            align-items: center;
            gap: 16px;
            margin-bottom: 24px;
            padding-bottom: 24px;
            border-bottom: 1px solid var(--border);
        }

        .deck-details-icon {
            width: 80px;
            height: 80px;
            border-radius: 12px;
            background: var(--accent-purple);
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            overflow: hidden;
        }

        .deck-details-icon img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .deck-details-icon svg {
            width: 40px;
            height: 40px;
            color: white;
        }

        .deck-details-title-section {
            flex: 1;
        }

        .deck-details-title {
            font-size: 24px;
            font-weight: 700;
            color: var(--text);
            margin-bottom: 8px;
        }

        .deck-details-description {
            font-size: 14px;
            color: var(--text-muted);
            line-height: 1.5;
        }

        .deck-details-content {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .deck-details-section {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .deck-details-section-title {
            font-size: 14px;
            font-weight: 600;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .deck-details-info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 16px;
        }

        .deck-details-info-item {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .deck-details-info-label {
            font-size: 12px;
            color: var(--text-muted);
            font-weight: 500;
        }

        .deck-details-info-value {
            font-size: 14px;
            color: var(--text);
            font-weight: 600;
        }

        .deck-details-user-info {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 16px;
            background: var(--surface-light);
            border-radius: 8px;
            border: 1px solid var(--border);
        }

        .deck-details-user-avatar {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            background: var(--accent-purple);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            color: white;
            font-size: 18px;
            flex-shrink: 0;
        }

        .deck-details-user-details {
            flex: 1;
        }

        .deck-details-user-name {
            font-size: 16px;
            font-weight: 600;
            color: var(--text);
            margin-bottom: 4px;
        }

        .deck-details-user-email {
            font-size: 14px;
            color: var(--text-muted);
        }

        .deck-details-close {
            position: absolute;
            top: 16px;
            right: 16px;
            width: 32px;
            height: 32px;
            border-radius: 8px;
            background: var(--surface-light);
            border: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s;
        }

        .deck-details-close:hover {
            background: var(--surface);
        }

        .deck-details-close svg {
            width: 20px;
            height: 20px;
            color: var(--text-muted);
        }

        /* Remove Deck Button */
        .btn-remove-deck {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.3);
            border-radius: 8px;
            color: #ef4444;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .btn-remove-deck:hover {
            background: rgba(239, 68, 68, 0.2);
            border-color: rgba(239, 68, 68, 0.5);
            transform: translateY(-1px);
        }

        .btn-remove-deck svg {
            width: 16px;
            height: 16px;
        }

        body.light-theme .btn-remove-deck {
            background: rgba(239, 68, 68, 0.08);
            border-color: rgba(239, 68, 68, 0.2);
        }

        body.light-theme .btn-remove-deck:hover {
            background: rgba(239, 68, 68, 0.15);
            border-color: rgba(239, 68, 68, 0.4);
        }

        /* Remove Deck Modal */
        .remove-deck-modal {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 32px;
            max-width: 600px;
            width: 100%;
            max-height: 90vh;
            overflow-y: auto;
            position: relative;
            box-shadow: 0 40px 120px rgba(0,0,0,0.5);
            animation: slideUp 0.3s ease;
        }

        body.light-theme .remove-deck-modal {
            background: #ffffff;
            border-color: rgba(0,0,0,0.12);
        }

        .remove-deck-header {
            display: flex;
            align-items: center;
            gap: 16px;
            margin-bottom: 24px;
            padding-bottom: 24px;
            border-bottom: 1px solid var(--border);
        }

        .remove-deck-icon {
            width: 64px;
            height: 64px;
            border-radius: 12px;
            background: rgba(239, 68, 68, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .remove-deck-icon svg {
            width: 32px;
            height: 32px;
            color: #ef4444;
        }

        .remove-deck-title-section {
            flex: 1;
        }

        .remove-deck-title {
            margin: 0 0 8px;
            font-size: 24px;
            font-weight: 700;
            color: var(--text);
        }

        .remove-deck-subtitle {
            margin: 0;
            font-size: 14px;
            color: var(--text-muted);
            line-height: 1.5;
        }

        .remove-deck-form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .remove-deck-form-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .remove-deck-label {
            font-size: 14px;
            font-weight: 600;
            color: var(--text);
        }

        .remove-deck-textarea {
            width: 100%;
            padding: 12px 14px;
            border-radius: 10px;
            border: 1px solid var(--border);
            background: var(--surface-light);
            color: var(--text);
            font-family: inherit;
            font-size: 14px;
            resize: vertical;
            transition: border-color 0.2s ease;
        }

        .remove-deck-textarea:focus {
            outline: none;
            border-color: var(--accent-purple);
        }

        body.light-theme .remove-deck-textarea {
            background: rgba(0,0,0,0.05);
            border-color: rgba(0,0,0,0.12);
        }

        body.light-theme .remove-deck-textarea:focus {
            border-color: var(--accent-purple);
        }

        .remove-deck-note {
            margin: 0;
            font-size: 12px;
            color: var(--text-muted);
            font-style: italic;
        }

        .remove-deck-actions {
            display: flex;
            gap: 12px;
            justify-content: flex-end;
            margin-top: 8px;
        }

        .btn-remove-cancel,
        .btn-remove-confirm {
            padding: 10px 20px;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            border: 1px solid var(--border);
        }

        .btn-remove-cancel {
            background: var(--surface-light);
            color: var(--text);
        }

        .btn-remove-cancel:hover {
            background: var(--surface);
        }

        .btn-remove-confirm {
            background: #ef4444;
            color: white;
            border-color: #dc2626;
        }

        .btn-remove-confirm:hover {
            background: #dc2626;
            transform: translateY(-1px);
        }

        .remove-deck-close {
            position: absolute;
            top: 16px;
            right: 16px;
            width: 32px;
            height: 32px;
            border-radius: 8px;
            background: var(--surface-light);
            border: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s;
        }

        .remove-deck-close:hover {
            background: var(--surface);
        }

        .remove-deck-close svg {
            width: 20px;
            height: 20px;
            color: var(--text-muted);
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s;
            }

            .main-content {
                margin-left: 0;
                padding: 16px;
            }

            .metrics-grid {
                grid-template-columns: 1fr;
            }

            .deck-details-modal {
                padding: 24px;
                max-width: 95%;
            }

            .deck-details-header {
                flex-direction: column;
                align-items: flex-start;
            }

            .deck-details-info-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-logo">
                <img src="../icons/bizmo.png" alt="Bizmo">
                <span>Bizmo Admin</span>
            </div>

            <nav>
                <ul class="nav-menu">
                    <li class="nav-item">
                        <a href="admin_dashboard.php" class="nav-link">
                            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>
                            </svg>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="admin_users.php" class="nav-link">
                            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/>
                            </svg>
                            <span>Users</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="users_decks.php" class="nav-link active">
                            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/>
                            </svg>
                            <span>Decks</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="admin_email.php" class="nav-link">
                            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                            </svg>
                            <span>Emails</span>
                            <?php if ($unread_email_count > 0): ?>
                                <span class="nav-badge"><?php echo $unread_email_count > 99 ? '99+' : $unread_email_count; ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="admin_reports.php" class="nav-link">
                            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                            </svg>
                            <span>Reports</span>
                            <?php if ($pending_reports_count > 0): ?>
                                <span class="nav-badge"><?php echo $pending_reports_count > 99 ? '99+' : $pending_reports_count; ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                </ul>
            </nav>

            <div class="sidebar-footer">
                <a href="#" class="nav-link" id="logoutBtn" style="color: var(--danger);">
                    <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                    </svg>
                    Logout
                </a>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Top Bar -->
            <div class="top-bar">
                <div class="search-box">
                    <svg class="search-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                    </svg>
                    <input type="text" id="searchInput" placeholder="Search decks by title, description, or owner...">
                </div>

                <div class="top-actions">
                    <div class="date-picker" id="realtimeClock"></div>
                    <div class="dark-mode-toggle-top">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: var(--text-muted);">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/>
                        </svg>
                        <div class="toggle-switch" id="darkModeToggle"></div>
                    </div>
                    <div class="user-menu" id="userMenu">
                        <div class="user-avatar"><?php echo strtoupper(substr($admin_name, 0, 1)); ?></div>
                        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: var(--text-muted);">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                        </svg>
                        <div class="user-dropdown">
                            <div class="user-dropdown-item" style="pointer-events: none; border-bottom: 1px solid var(--border);">
                                <div>
                                    <div style="font-weight: 600; margin-bottom: 4px;"><?php echo htmlspecialchars($admin_name); ?></div>
                                    <div style="font-size: 12px; color: var(--text-muted);"><?php echo htmlspecialchars($admin_email); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Metrics -->
            <div class="metrics-grid">
                <div class="metric-card">
                    <div class="metric-icon" style="background: rgba(147, 51, 234, 0.1);">
                        <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: var(--accent-purple);">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/>
                        </svg>
                    </div>
                    <div class="metric-header">
                        <span class="metric-title">Total Decks</span>
                    </div>
                    <div class="metric-value"><?php echo number_format($total_decks); ?></div>
                </div>

                <div class="metric-card">
                    <div class="metric-icon" style="background: rgba(34, 197, 94, 0.1);">
                        <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: var(--success);">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                        </svg>
                    </div>
                    <div class="metric-header">
                        <span class="metric-title">Total Cards</span>
                    </div>
                    <div class="metric-value"><?php echo number_format($total_cards); ?></div>
                </div>

                <div class="metric-card">
                    <div class="metric-icon" style="background: rgba(59, 130, 246, 0.1);">
                        <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: #3b82f6;">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/>
                        </svg>
                    </div>
                    <div class="metric-header">
                        <span class="metric-title">Users with Decks</span>
                    </div>
                    <div class="metric-value"><?php echo number_format($total_users_with_decks); ?></div>
                </div>
            </div>

            <!-- Decks Table -->
            <div class="table-card">
                <div class="table-header">
                    <h3 class="table-title">All Decks</h3>
                    
                </div>
                <?php if (isset($_GET['success']) && $_GET['success'] == '1'): ?>
                    <div style="padding: 16px; background: rgba(34, 197, 94, 0.1); border: 1px solid rgba(34, 197, 94, 0.3); border-radius: 8px; color: #22c55e; margin-bottom: 20px;">
                        Deck removed successfully. The user has been notified via email.
                    </div>
                <?php endif; ?>
                <?php if (!empty($remove_success)): ?>
                    <div style="padding: 16px; background: rgba(34, 197, 94, 0.1); border: 1px solid rgba(34, 197, 94, 0.3); border-radius: 8px; color: #22c55e; margin-bottom: 20px;">
                        <?php echo htmlspecialchars($remove_success); ?>
                    </div>
                <?php endif; ?>
                <?php if (!empty($remove_error)): ?>
                    <div style="padding: 16px; background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); border-radius: 8px; color: var(--danger); margin-bottom: 20px;">
                        <?php echo htmlspecialchars($remove_error); ?>
                    </div>
                <?php endif; ?>
                <?php if (isset($error_message)): ?>
                    <div style="padding: 16px; background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); border-radius: 8px; color: var(--danger); margin-bottom: 20px;">
                        <?php echo htmlspecialchars($error_message); ?>
                    </div>
                <?php endif; ?>
                <table>
                    <thead>
                        <tr>
                            <th>Deck</th>
                            <th>Owner</th>
                            <th>Cards</th>
                            <th>Created</th>
                            <th>Updated</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="decksTableBody">
                        <?php if (empty($decks)): ?>
                            <tr>
                                <td colspan="6" style="text-align: center; padding: 40px; color: var(--text-muted);">
                                    No decks found in the database.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($decks as $deck): ?>
                                <?php
                                $deckDataJson = json_encode([
                                    'id' => $deck['id'],
                                    'title' => $deck['title'],
                                    'description' => $deck['description'] ?? 'No description',
                                    'color' => $deck['color'] ?? '#9333ea',
                                    'icon_src' => $deck['icon_src'],
                                    'card_count' => $deck['card_count'],
                                    'created_at' => $deck['created_at'],
                                    'updated_at' => $deck['updated_at'],
                                    'user_id' => $deck['user_id'],
                                    'full_name' => $deck['full_name'] ?? 'Unknown User',
                                    'email' => $deck['email'] ?? 'N/A',
                                    'username' => $deck['username'] ?? 'N/A'
                                ]);
                                ?>
                                <tr class="deck-row" 
                                    data-deck-id="<?php echo htmlspecialchars($deck['id']); ?>"
                                    data-title="<?php echo htmlspecialchars(strtolower($deck['title'])); ?>" 
                                    data-description="<?php echo htmlspecialchars(strtolower($deck['description'] ?? '')); ?>"
                                    data-owner="<?php echo htmlspecialchars(strtolower($deck['full_name'] ?? '')); ?>"
                                    data-deck-data="<?php echo htmlspecialchars($deckDataJson, ENT_QUOTES, 'UTF-8'); ?>">
                                    <td>
                                        <div class="deck-info">
                                            <div class="deck-icon-small" style="background: <?php echo htmlspecialchars($deck['color'] ?? '#9333ea'); ?>20;">
                                                <?php if (!empty($deck['icon_src'])): ?>
                                                    <img src="<?php echo htmlspecialchars($deck['icon_src']); ?>" alt="<?php echo htmlspecialchars($deck['title']); ?>">
                                                <?php else: ?>
                                                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: <?php echo htmlspecialchars($deck['color'] ?? '#9333ea'); ?>">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/>
                                                    </svg>
                                                <?php endif; ?>
                                            </div>
                                            <div>
                                                <div class="deck-title-text"><?php echo htmlspecialchars($deck['title']); ?></div>
                                                <div class="deck-description-text"><?php echo htmlspecialchars($deck['description'] ?? 'No description'); ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="user-info">
                                            <div class="user-avatar-small">
                                                <?php echo strtoupper(substr($deck['full_name'] ?? 'U', 0, 1)); ?>
                                            </div>
                                            <span><?php echo htmlspecialchars($deck['full_name'] ?? 'Unknown User'); ?></span>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="card-count">
                                            <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                                            </svg>
                                            <?php echo number_format($deck['card_count']); ?>
                                        </div>
                                    </td>
                                    <td><?php echo date('M d, Y', strtotime($deck['created_at'])); ?></td>
                                    <td><?php echo date('M d, Y', strtotime($deck['updated_at'])); ?></td>
                                    <td>
                                        <button class="btn-remove-deck" data-deck-id="<?php echo htmlspecialchars($deck['id']); ?>" data-deck-title="<?php echo htmlspecialchars($deck['title']); ?>" title="Remove Deck">
                                            <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                                            </svg>
                                            Remove
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>

    <!-- Logout Confirmation Modal -->
    <div class="modal-overlay" id="logoutModal">
        <div class="logout-modal">
            <div class="modal-icon">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                </svg>
            </div>
            <div class="modal-header">
                <h3 class="modal-title">Confirm Logout</h3>
                <p class="modal-message">Are you sure you want to logout? You will need to login again to access the admin panel.</p>
            </div>
            <div class="modal-actions">
                <button class="btn-modal btn-modal-cancel" id="logoutCancelBtn">Cancel</button>
                <button class="btn-modal btn-modal-logout" id="logoutConfirmBtn">Logout</button>
            </div>
        </div>
    </div>

    <!-- Deck Details Modal -->
    <div class="modal-overlay" id="deckDetailsModal">
        <div class="deck-details-modal">
            <div class="deck-details-close" id="deckDetailsCloseBtn">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                </svg>
            </div>
            <div class="deck-details-header">
                <div class="deck-details-icon" id="deckDetailsIcon">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/>
                    </svg>
                </div>
                <div class="deck-details-title-section">
                    <h3 class="deck-details-title" id="deckDetailsTitle">Deck Title</h3>
                    <p class="deck-details-description" id="deckDetailsDescription">Deck description</p>
                </div>
            </div>
            <div class="deck-details-content">
                <div class="deck-details-section">
                    <div class="deck-details-section-title">Deck Information</div>
                    <div class="deck-details-info-grid">
                        <div class="deck-details-info-item">
                            <span class="deck-details-info-label">Deck ID</span>
                            <span class="deck-details-info-value" id="deckDetailsId">-</span>
                        </div>
                        <div class="deck-details-info-item">
                            <span class="deck-details-info-label">Total Cards</span>
                            <span class="deck-details-info-value" id="deckDetailsCardCount">-</span>
                        </div>
                        <div class="deck-details-info-item">
                            <span class="deck-details-info-label">Created</span>
                            <span class="deck-details-info-value" id="deckDetailsCreated">-</span>
                        </div>
                        <div class="deck-details-info-item">
                            <span class="deck-details-info-label">Last Updated</span>
                            <span class="deck-details-info-value" id="deckDetailsUpdated">-</span>
                        </div>
                    </div>
                </div>
                <div class="deck-details-section">
                    <div class="deck-details-section-title">Owner Information</div>
                    <div class="deck-details-user-info">
                        <div class="deck-details-user-avatar" id="deckDetailsUserAvatar">U</div>
                        <div class="deck-details-user-details">
                            <div class="deck-details-user-name" id="deckDetailsUserName">Unknown User</div>
                            <div class="deck-details-user-email" id="deckDetailsUserEmail">N/A</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Remove Deck Modal -->
    <div class="modal-overlay" id="removeDeckModal">
        <div class="remove-deck-modal">
            <div class="remove-deck-close" id="removeDeckCloseBtn">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                </svg>
            </div>
            <div class="remove-deck-header">
                <div class="remove-deck-icon">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                    </svg>
                </div>
                <div class="remove-deck-title-section">
                    <h3 class="remove-deck-title">Remove Deck</h3>
                    <p class="remove-deck-subtitle">You are about to remove: <strong id="removeDeckTitle">Deck Title</strong></p>
                </div>
            </div>
            <form method="post" id="removeDeckForm" class="remove-deck-form">
                <input type="hidden" name="remove_deck" value="1">
                <input type="hidden" name="deck_id" id="removeDeckId">
                <div class="remove-deck-form-group">
                    <label for="removal_reason" class="remove-deck-label">Reason for Removal <span style="color: var(--danger);">*</span></label>
                    <textarea 
                        id="removal_reason" 
                        name="removal_reason" 
                        class="remove-deck-textarea" 
                        placeholder="Please provide a clear reason why this deck is being removed. This reason will be sent to the deck owner via email."
                        required
                        rows="5"></textarea>
                    <p class="remove-deck-note">This action cannot be undone. All cards associated with this deck will also be removed.</p>
                </div>
                <div class="remove-deck-actions">
                    <button type="button" class="btn-remove-cancel" id="removeDeckCancelBtn">Cancel</button>
                    <button type="submit" class="btn-remove-confirm">Remove Deck</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Theme Toggle
        function initTheme() {
            const savedTheme = localStorage.getItem('admin-theme') || 'dark';
            const body = document.body;
            
            if (savedTheme === 'light') {
                body.classList.add('light-theme');
            } else {
                body.classList.remove('light-theme');
            }
            
            updateToggleSwitch(savedTheme);
        }

        function updateToggleSwitch(theme) {
            const darkModeToggle = document.getElementById('darkModeToggle');
            if (darkModeToggle) {
                if (theme === 'light') {
                    darkModeToggle.classList.add('active');
                } else {
                    darkModeToggle.classList.remove('active');
                }
            }
        }

        function toggleTheme() {
            const body = document.body;
            const isLightTheme = body.classList.contains('light-theme');
            
            if (isLightTheme) {
                body.classList.remove('light-theme');
                localStorage.setItem('admin-theme', 'dark');
                updateToggleSwitch('dark');
            } else {
                body.classList.add('light-theme');
                localStorage.setItem('admin-theme', 'light');
                updateToggleSwitch('light');
            }
        }

        initTheme();

        const darkModeToggle = document.getElementById('darkModeToggle');
        if (darkModeToggle) {
            darkModeToggle.addEventListener('click', function(e) {
                e.stopPropagation();
                toggleTheme();
            });
        }

        // Search functionality
        const searchInput = document.getElementById('searchInput');
        const deckRows = document.querySelectorAll('.deck-row');
        
        if (searchInput) {
            searchInput.addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase().trim();
                
                deckRows.forEach(row => {
                    const title = row.getAttribute('data-title') || '';
                    const description = row.getAttribute('data-description') || '';
                    const owner = row.getAttribute('data-owner') || '';
                    
                    if (title.includes(searchTerm) || description.includes(searchTerm) || owner.includes(searchTerm)) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            });
        }

        // Logout Modal
        const logoutBtn = document.getElementById('logoutBtn');
        const logoutModal = document.getElementById('logoutModal');
        const logoutConfirmBtn = document.getElementById('logoutConfirmBtn');
        const logoutCancelBtn = document.getElementById('logoutCancelBtn');

        if (logoutBtn) {
            logoutBtn.addEventListener('click', function(e) {
                e.preventDefault();
                if (logoutModal) {
                    logoutModal.classList.add('active');
                    document.body.style.overflow = 'hidden';
                }
            });
        }

        if (logoutCancelBtn) {
            logoutCancelBtn.addEventListener('click', function() {
                if (logoutModal) {
                    logoutModal.classList.remove('active');
                    document.body.style.overflow = '';
                }
            });
        }

        if (logoutConfirmBtn) {
            logoutConfirmBtn.addEventListener('click', function() {
                window.location.href = '?logout=1';
            });
        }

        if (logoutModal) {
            logoutModal.addEventListener('click', function(e) {
                if (e.target === logoutModal) {
                    logoutModal.classList.remove('active');
                    document.body.style.overflow = '';
                }
            });
        }

        // Deck Details Modal
        function formatDate(dateString) {
            const date = new Date(dateString);
            return date.toLocaleDateString('en-US', { 
                year: 'numeric', 
                month: 'short', 
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
        }

        function openDeckDetailsModal(deckData) {
            const deckDetailsModal = document.getElementById('deckDetailsModal');
            if (!deckDetailsModal) return;

            // Set deck icon
            const deckIcon = document.getElementById('deckDetailsIcon');
            const deckColor = deckData.color || '#9333ea';
            deckIcon.style.background = deckColor + '20';
            
            if (deckData.icon_src) {
                deckIcon.innerHTML = `<img src="${deckData.icon_src}" alt="${deckData.title}">`;
            } else {
                deckIcon.innerHTML = `
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: ${deckColor};">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/>
                    </svg>
                `;
            }

            // Set deck title and description
            document.getElementById('deckDetailsTitle').textContent = deckData.title || 'Untitled Deck';
            document.getElementById('deckDetailsDescription').textContent = deckData.description || 'No description available';

            // Set deck information
            document.getElementById('deckDetailsId').textContent = deckData.id || '-';
            document.getElementById('deckDetailsCardCount').textContent = (deckData.card_count || 0).toLocaleString();
            document.getElementById('deckDetailsCreated').textContent = deckData.created_at ? formatDate(deckData.created_at) : '-';
            document.getElementById('deckDetailsUpdated').textContent = deckData.updated_at ? formatDate(deckData.updated_at) : '-';

            // Set user information
            const userName = deckData.full_name || 'Unknown User';
            const userEmail = deckData.email || 'N/A';
            document.getElementById('deckDetailsUserName').textContent = userName;
            document.getElementById('deckDetailsUserEmail').textContent = userEmail;
            document.getElementById('deckDetailsUserAvatar').textContent = userName.charAt(0).toUpperCase();

            // Show modal
            deckDetailsModal.classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        function closeDeckDetailsModal() {
            const deckDetailsModal = document.getElementById('deckDetailsModal');
            if (deckDetailsModal) {
                deckDetailsModal.classList.remove('active');
                document.body.style.overflow = '';
            }
        }

        // Use event delegation for deck row clicks (more reliable)
        // Since script is at bottom of page, DOM should already be loaded
        const decksTableBody = document.getElementById('decksTableBody');
        if (decksTableBody) {
            decksTableBody.addEventListener('click', function(e) {
                const deckRow = e.target.closest('.deck-row');
                if (!deckRow) return;

                // Don't open modal if clicking on links or buttons inside the row
                if (e.target.closest('a') || e.target.closest('button')) {
                    return;
                }

                // Prevent any default behavior
                e.preventDefault();
                e.stopPropagation();

                const deckDataJson = deckRow.getAttribute('data-deck-data');
                if (deckDataJson) {
                    try {
                        const deckData = JSON.parse(deckDataJson);
                        openDeckDetailsModal(deckData);
                    } catch (error) {
                        console.error('Error parsing deck data:', error);
                        console.error('Raw JSON:', deckDataJson);
                    }
                } else {
                    console.warn('No deck data found for row');
                }
            });
        } else {
            console.error('decksTableBody not found');
        }

        // Close modal handlers
        const deckDetailsModal = document.getElementById('deckDetailsModal');
        const deckDetailsCloseBtn = document.getElementById('deckDetailsCloseBtn');

        if (deckDetailsCloseBtn) {
            deckDetailsCloseBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                closeDeckDetailsModal();
            });
        }

        if (deckDetailsModal) {
            deckDetailsModal.addEventListener('click', function(e) {
                if (e.target === deckDetailsModal) {
                    closeDeckDetailsModal();
                }
            });
        }

        // Close modal on Escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                const deckDetailsModal = document.getElementById('deckDetailsModal');
                if (deckDetailsModal && deckDetailsModal.classList.contains('active')) {
                    closeDeckDetailsModal();
                }
                const logoutModal = document.getElementById('logoutModal');
                if (logoutModal && logoutModal.classList.contains('active')) {
                    logoutModal.classList.remove('active');
                    document.body.style.overflow = '';
                }
            }
        });

        // Real-time clock
        function updateClock() {
            const clockElement = document.getElementById('realtimeClock');
            if (clockElement) {
                const now = new Date();
                let hours = now.getHours();
                const minutes = String(now.getMinutes()).padStart(2, '0');
                const seconds = String(now.getSeconds()).padStart(2, '0');
                const ampm = hours >= 12 ? 'PM' : 'AM';
                hours = hours % 12;
                hours = hours ? hours : 12; // the hour '0' should be '12'
                hours = String(hours).padStart(2, '0');
                clockElement.textContent = `${hours}:${minutes}:${seconds} ${ampm}`;
            }
        }

        // Update clock immediately and then every second
        updateClock();
        setInterval(updateClock, 1000);

        // Remove Deck Modal
        const removeDeckModal = document.getElementById('removeDeckModal');
        const removeDeckCloseBtn = document.getElementById('removeDeckCloseBtn');
        const removeDeckCancelBtn = document.getElementById('removeDeckCancelBtn');
        const removeDeckForm = document.getElementById('removeDeckForm');
        const removeDeckIdInput = document.getElementById('removeDeckId');
        const removeDeckTitleElement = document.getElementById('removeDeckTitle');
        const removeButtons = document.querySelectorAll('.btn-remove-deck');

        function openRemoveDeckModal(deckId, deckTitle) {
            if (removeDeckIdInput) removeDeckIdInput.value = deckId;
            if (removeDeckTitleElement) removeDeckTitleElement.textContent = deckTitle;
            if (removeDeckForm) {
                const textarea = removeDeckForm.querySelector('#removal_reason');
                if (textarea) textarea.value = '';
            }
            if (removeDeckModal) removeDeckModal.classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        function closeRemoveDeckModal() {
            if (removeDeckModal) removeDeckModal.classList.remove('active');
            document.body.style.overflow = '';
        }

        // Open modal when remove button is clicked
        removeButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                e.stopPropagation();
                const deckId = this.getAttribute('data-deck-id');
                const deckTitle = this.getAttribute('data-deck-title');
                openRemoveDeckModal(deckId, deckTitle);
            });
        });

        // Close modal handlers
        if (removeDeckCloseBtn) {
            removeDeckCloseBtn.addEventListener('click', closeRemoveDeckModal);
        }

        if (removeDeckCancelBtn) {
            removeDeckCancelBtn.addEventListener('click', closeRemoveDeckModal);
        }

        // Close on overlay click
        if (removeDeckModal) {
            removeDeckModal.addEventListener('click', function(e) {
                if (e.target === removeDeckModal) {
                    closeRemoveDeckModal();
                }
            });
        }

        // Form submission confirmation
        if (removeDeckForm) {
            removeDeckForm.addEventListener('submit', function(e) {
                const reason = this.querySelector('#removal_reason').value.trim();
                if (!reason) {
                    e.preventDefault();
                    alert('Please provide a reason for removing this deck.');
                    return false;
                }
                if (!confirm('Are you sure you want to remove this deck? This action cannot be undone and all associated cards will be deleted.')) {
                    e.preventDefault();
                    return false;
                }
            });
        }

        // Update Escape key handler to include remove modal
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                if (removeDeckModal && removeDeckModal.classList.contains('active')) {
                    closeRemoveDeckModal();
                }
            }
        });
    </script>
</body>
</html>


<?php
// Check if this is an auto-fetch request - start output buffering early
$is_auto_fetch = isset($_GET['fetch_emails']) && isset($_GET['auto']) && $_GET['auto'] === '1';
if ($is_auto_fetch) {
    // Suppress all errors and warnings for auto-fetch
    @ini_set('display_errors', 0);
    error_reporting(0);
    ob_start();
}

session_start();

// For auto-fetch, handle config.php errors gracefully
if ($is_auto_fetch) {
    ob_start();
    try {
        require_once '../config.php';
    } catch (Exception $e) {
        ob_end_clean();
        header('Content-Type: application/json; charset=utf-8', true);
        echo json_encode([
            'success' => false,
            'fetched' => 0,
            'error' => 'Database connection error'
        ], JSON_UNESCAPED_UNICODE);
        exit(0);
    }
    ob_end_clean();
    
    // Check if database connection failed (config.php might have died)
    if (!isset($conn) || !$conn) {
        header('Content-Type: application/json; charset=utf-8', true);
        echo json_encode([
            'success' => false,
            'fetched' => 0,
            'error' => 'Database connection failed'
        ], JSON_UNESCAPED_UNICODE);
        exit(0);
    }
} else {
    require_once '../config.php';
}

// Include PHPMailer files
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../phpmailer/src/Exception.php';
require '../phpmailer/src/PHPMailer.php';
require '../phpmailer/src/SMTP.php';

// Handle logout
if (isset($_GET['logout'])) {
    session_unset();
    session_destroy();
    header("Location: admin_login.php");
    exit();
}

// Handle email deletion
if (isset($_GET['delete_email'])) {
    $email_id = (int)$_GET['delete_email'];
    if ($email_id > 0) {
        try {
            $stmt = $conn->prepare("DELETE FROM emails WHERE id = ?");
            $stmt->bind_param("i", $email_id);
            $stmt->execute();
            $stmt->close();
            header("Location: admin_email.php?deleted=1");
            exit();
        } catch (Exception $e) {
            $email_error = "Failed to delete email: " . $e->getMessage();
        }
    }
}

// Handle incoming email deletion (soft delete - only marks as deleted, doesn't remove from database)
if (isset($_GET['delete_incoming_email'])) {
    $email_id = (int)$_GET['delete_incoming_email'];
    if ($email_id > 0) {
        try {
            $stmt = $conn->prepare("UPDATE incoming_emails SET deleted = 1 WHERE id = ?");
            $stmt->bind_param("i", $email_id);
            $stmt->execute();
            $stmt->close();
            header("Location: admin_email.php?deleted_incoming=1");
            exit();
        } catch (Exception $e) {
            $email_error = "Failed to delete incoming email: " . $e->getMessage();
        }
    }
}

// Handle mark as read/unread
if (isset($_GET['toggle_read'])) {
    $email_id = (int)$_GET['toggle_read'];
    if ($email_id > 0) {
        try {
            // Get current read status
            $check_stmt = $conn->prepare("SELECT read_status FROM incoming_emails WHERE id = ? AND deleted = 0");
            $check_stmt->bind_param("i", $email_id);
            $check_stmt->execute();
            $result = $check_stmt->get_result();
            if ($row = $result->fetch_assoc()) {
                $new_status = $row['read_status'] === 'read' ? 'unread' : 'read';
                $update_stmt = $conn->prepare("UPDATE incoming_emails SET read_status = ? WHERE id = ?");
                $update_stmt->bind_param("si", $new_status, $email_id);
                $update_stmt->execute();
                $update_stmt->close();
            }
            $check_stmt->close();
            header("Location: admin_email.php");
            exit();
        } catch (Exception $e) {
            $email_error = "Failed to update read status: " . $e->getMessage();
        }
    }
}

// Handle reply to incoming email
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reply_email'])) {
    $incoming_email_id = (int)$_POST['incoming_email_id'];
    $recipient_email = trim($_POST['recipient_email'] ?? '');
    $recipient_name = trim($_POST['recipient_name'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');
    $admin_id = $_SESSION['admin_id'];
    
    if (empty($recipient_email) || empty($subject) || empty($message)) {
        $email_error = "Please fill in all required fields.";
    } else {
        // First, save email to database with status 'pending'
        try {
            $stmt = $conn->prepare("INSERT INTO emails (admin_id, recipient_email, recipient_name, subject, message, status) VALUES (?, ?, ?, ?, ?, 'pending')");
            $stmt->bind_param("issss", $admin_id, $recipient_email, $recipient_name, $subject, $message);
            $stmt->execute();
            $email_id = $conn->insert_id;
            $stmt->close();
            
            // Now try to send the email
            try {
                $mail = new PHPMailer(true);
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'bizmobsu@gmail.com';
                $mail->Password = 'cohrugzxdhsjqybd';
                $mail->SMTPSecure = 'tls';
                $mail->Port = 587;
                $mail->SMTPOptions = array(
                    'ssl' => array(
                        'verify_peer' => false,
                        'verify_peer_name' => false,
                        'allow_self_signed' => true
                    )
                );
                
                $mail->setFrom('bizmobsu@gmail.com', 'Bizmo Admin');
                $mail->addAddress($recipient_email, $recipient_name);
                $mail->isHTML(true);
                $mail->Subject = $subject;
                $mail->Body = "
                    <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;'>
                        <h2 style='color: #dc2626; margin-bottom: 20px;'>Message from Bizmo Admin</h2>
                        <p>Hello {$recipient_name},</p>
                        <div style='background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;'>
                            " . nl2br(htmlspecialchars($message)) . "
                        </div>
                        <p style='margin-top: 30px; color: #666; font-size: 14px;'>Best regards,<br><strong>Bizmo Admin Team</strong></p>
                    </div>
                ";
                $mail->AltBody = "Hello {$recipient_name},\n\n" . $message . "\n\nBest regards,\nBizmo Admin Team";
                
                $mail->send();
                
                // Update email status to 'sent' and set sent_at timestamp
                $update_stmt = $conn->prepare("UPDATE emails SET status = 'sent', sent_at = NOW() WHERE id = ?");
                $update_stmt->bind_param("i", $email_id);
                $update_stmt->execute();
                $update_stmt->close();
                
                // Mark the incoming email as read
                if ($incoming_email_id > 0) {
                    $mark_read_stmt = $conn->prepare("UPDATE incoming_emails SET read_status = 'read' WHERE id = ?");
                    $mark_read_stmt->bind_param("i", $incoming_email_id);
                    $mark_read_stmt->execute();
                    $mark_read_stmt->close();
                }
                
                $email_success = "Reply sent successfully to {$recipient_email}";
                
                // Clear form data
                $_POST = array();
                header("Location: admin_email.php?replied=1");
                exit();
            } catch (Exception $e) {
                // Update email status to 'failed'
                $update_stmt = $conn->prepare("UPDATE emails SET status = 'failed' WHERE id = ?");
                $update_stmt->bind_param("i", $email_id);
                $update_stmt->execute();
                $update_stmt->close();
                
                $email_error = "Failed to send reply: " . $mail->ErrorInfo;
            }
        } catch (Exception $e) {
            $email_error = "Failed to save reply: " . $e->getMessage();
        }
    }
}

// Handle manual add incoming email
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_incoming_email'])) {
    $from_email = trim($_POST['from_email'] ?? '');
    $from_name = trim($_POST['from_name'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');
    
    if (empty($from_email) || empty($subject) || empty($message)) {
        $email_error = "Please fill in all required fields.";
    } else {
        try {
            $stmt = $conn->prepare("INSERT INTO incoming_emails (from_email, from_name, subject, message, read_status) VALUES (?, ?, ?, ?, 'unread')");
            $stmt->bind_param("ssss", $from_email, $from_name, $subject, $message);
            $stmt->execute();
            $stmt->close();
            $email_success = "Incoming email added successfully.";
            header("Location: admin_email.php?added=1");
            exit();
        } catch (Exception $e) {
            $email_error = "Failed to add incoming email: " . $e->getMessage();
        }
    }
}

// Check session first - but handle auto-fetch requests specially
if ($is_auto_fetch && !isset($_SESSION['admin_id'])) {
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    @ini_set('display_errors', 0);
    error_reporting(0);
    header('Content-Type: application/json; charset=utf-8', true);
    header('Cache-Control: no-cache, must-revalidate', true);
    header('X-Content-Type-Options: nosniff', true);
    header_remove('X-Powered-By');
    echo json_encode([
        'success' => false,
        'fetched' => 0,
        'error' => 'Session expired. Please refresh the page.'
    ], JSON_UNESCAPED_UNICODE);
    if (function_exists('fastcgi_finish_request')) {
        fastcgi_finish_request();
    }
    exit(0);
}

// Handle fetch emails from Gmail
if (isset($_GET['fetch_emails'])) {
    
    // Set up error handling early for AJAX requests
    $is_ajax = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    
    // Function to send JSON error response
    $sendJsonError = function($error_msg) use ($is_ajax, $is_auto_fetch) {
        if ($is_auto_fetch || $is_ajax) {
            while (ob_get_level() > 0) {
                ob_end_clean();
            }
            @ini_set('display_errors', 0);
            error_reporting(0);
            if (!headers_sent()) {
                header_remove();
                header('Content-Type: application/json; charset=utf-8', true);
                header('Cache-Control: no-cache, must-revalidate', true);
                http_response_code(200); // Set 200 to avoid 500 error in browser
            }
            echo json_encode([
                'success' => false,
                'fetched' => 0,
                'error' => $error_msg
            ], JSON_UNESCAPED_UNICODE);
            exit(0);
        }
    };
    
    // Set error handler to catch fatal errors
    if ($is_auto_fetch || $is_ajax) {
        set_error_handler(function($errno, $errstr, $errfile, $errline) use ($sendJsonError) {
            if ($errno === E_ERROR || $errno === E_PARSE || $errno === E_CORE_ERROR || $errno === E_COMPILE_ERROR) {
                $sendJsonError("Fatal error: " . $errstr . " in " . basename($errfile) . " on line " . $errline);
                return true;
            }
            return false;
        });
    }
    
    $fetch_success = false;
    $fetch_error = '';
    $fetched_count = 0;
    
    // Check if IMAP extension is available
    if (!function_exists('imap_open')) {
        $fetch_error = "PHP IMAP extension is not enabled. Please enable it in php.ini or use the 'Add Incoming Email' form to manually add emails.";
        if ($is_auto_fetch || $is_ajax) {
            $sendJsonError($fetch_error);
        }
        if (!$is_auto_fetch) {
            $email_error = $fetch_error;
        }
    } else {
        try {
            // Connect to Gmail IMAP
            $imap_host = '{imap.gmail.com:993/imap/ssl}INBOX';
            $imap_username = 'bizmobsu@gmail.com';
            $imap_password = 'cohrugzxdhsjqybd';
            
            // Suppress IMAP errors for auto-fetch
            if ($is_auto_fetch) {
                $old_error_handler = set_error_handler(function() { return true; });
            }
            
            $inbox = @imap_open($imap_host, $imap_username, $imap_password);
            
            // Restore error handler
            if ($is_auto_fetch && isset($old_error_handler)) {
                restore_error_handler();
            }
            
            if ($inbox) {
                // Get all emails from inbox (not just unread)
                // Fetch recent emails - you can change 'ALL' to 'UNSEEN' if you only want unread emails
                $emails = imap_search($inbox, 'ALL');
                
                // If imap_search returns false, try to get email count another way
                if ($emails === false) {
                    $emails = [];
                    // Try to get total number of messages
                    $total_messages = imap_num_msg($inbox);
                    if ($total_messages > 0) {
                        // Create array of message numbers
                        for ($i = 1; $i <= min($total_messages, 100); $i++) {
                            $emails[] = $i;
                        }
                    }
                }
                
                if ($emails && count($emails) > 0) {
                    // Sort emails by date (newest first)
                    rsort($emails);
                    
                    // Limit to last 100 emails to avoid performance issues
                    // The duplicate check will prevent re-inserting existing emails
                    $emails = array_slice($emails, 0, 100);
                    
                    // Check if reply_to_email_id column exists (only once, not per email)
                    $reply_to_column_exists = false;
                    try {
                        $check_column = $conn->query("SHOW COLUMNS FROM incoming_emails LIKE 'reply_to_email_id'");
                        $reply_to_column_exists = ($check_column && $check_column->num_rows > 0);
                        if ($check_column) {
                            $check_column->close();
                        }
                    } catch (Exception $e) {
                        // If we can't check, assume it doesn't exist
                        $reply_to_column_exists = false;
                    }
                    
                    foreach ($emails as $email_number) {
                        try {
                            // Get email header
                            $header = @imap_headerinfo($inbox, $email_number);
                            
                            if (!$header) {
                                continue; // Skip if header can't be read
                            }
                            
                            // Check if from field exists and has valid data
                            if (!isset($header->from) || !is_array($header->from) || empty($header->from) || !isset($header->from[0])) {
                                continue; // Skip if no sender info
                            }
                            
                            // Skip if already exists (check by subject and from email and date)
                            $check_stmt = $conn->prepare("SELECT id FROM incoming_emails WHERE from_email = ? AND subject = ? AND created_at = ?");
                            
                            // Safely extract from email
                            $from_mailbox = isset($header->from[0]->mailbox) ? $header->from[0]->mailbox : '';
                            $from_host = isset($header->from[0]->host) ? $header->from[0]->host : '';
                            if (empty($from_mailbox) || empty($from_host)) {
                                continue; // Skip if invalid email address
                            }
                            $from_email = $from_mailbox . '@' . $from_host;
                            
                            $subject = isset($header->subject) ? trim($header->subject) : '(No Subject)';
                            if (empty($subject)) {
                                $subject = '(No Subject)';
                            }
                            
                            // Safely parse date
                            $date_str = isset($header->date) ? $header->date : date('Y-m-d H:i:s');
                            $date_timestamp = @strtotime($date_str);
                            if ($date_timestamp === false) {
                                $date = date('Y-m-d H:i:s');
                            } else {
                                $date = date('Y-m-d H:i:s', $date_timestamp);
                            }
                            
                            $check_stmt->bind_param("sss", $from_email, $subject, $date);
                            $check_stmt->execute();
                            $result = $check_stmt->get_result();
                            
                            if ($result->num_rows == 0) {
                            // Get email structure
                            $structure = imap_fetchstructure($inbox, $email_number);
                            $html_body = '';
                            $text_body = '';
                            
                            // Function to recursively extract email parts
                            $extractParts = function($structure, $inbox, $email_number, $part_number = '') use (&$extractParts) {
                                $html = '';
                                $text = '';
                                
                                if (isset($structure->parts) && is_array($structure->parts)) {
                                    // Multipart message
                                    foreach ($structure->parts as $part_num => $part) {
                                        $current_part = $part_number ? $part_number . '.' . ($part_num + 1) : ($part_num + 1);
                                        
                                        // Check if this part has nested parts
                                        if (isset($part->parts) && is_array($part->parts)) {
                                            $nested = $extractParts($part, $inbox, $email_number, $current_part);
                                            // Prefer HTML over text, but keep both
                                            if (!empty($nested['html'])) {
                                                $html = $nested['html'];
                                            }
                                            if (!empty($nested['text']) && empty($html)) {
                                                $text = $nested['text'];
                                            }
                                        } else {
                                            // Get the part body
                                            $part_body = imap_fetchbody($inbox, $email_number, $current_part);
                                            
                                            // Decode based on encoding
                                            $encoding = isset($part->encoding) ? $part->encoding : 0;
                                            if ($encoding == 3) { // base64
                                                $part_body = base64_decode($part_body);
                                            } elseif ($encoding == 4) { // quoted-printable
                                                $part_body = quoted_printable_decode($part_body);
                                            } elseif ($encoding == 1) { // 8bit
                                                // No decoding needed
                                            } elseif ($encoding == 2) { // binary
                                                // No decoding needed
                                            }
                                            
                                            // Check content type
                                            $type = strtolower(isset($part->type) ? $part->type : 0);
                                            $subtype = isset($part->subtype) ? strtoupper($part->subtype) : '';
                                            
                                            if ($type == 0 && $subtype == 'HTML') {
                                                $html = $part_body;
                                            } elseif ($type == 0 && $subtype == 'PLAIN') {
                                                $text = $part_body;
                                            } elseif ($type == 0 && $subtype == 'ALTERNATIVE') {
                                                // Handle alternative parts
                                                if (isset($part->parts)) {
                                                    foreach ($part->parts as $alt_num => $alt_part) {
                                                        $alt_subtype = isset($alt_part->subtype) ? strtoupper($alt_part->subtype) : '';
                                                        $alt_part_num = $current_part . '.' . ($alt_num + 1);
                                                        $alt_body = imap_fetchbody($inbox, $email_number, $alt_part_num);
                                                        
                                                        $alt_encoding = isset($alt_part->encoding) ? $alt_part->encoding : 0;
                                                        if ($alt_encoding == 3) {
                                                            $alt_body = base64_decode($alt_body);
                                                        } elseif ($alt_encoding == 4) {
                                                            $alt_body = quoted_printable_decode($alt_body);
                                                        }
                                                        
                                                        if ($alt_subtype == 'HTML') {
                                                            $html = $alt_body;
                                                        } elseif ($alt_subtype == 'PLAIN') {
                                                            $text = $alt_body;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                } else {
                                    // Simple message without multipart
                                    $body = imap_body($inbox, $email_number);
                                    $encoding = isset($structure->encoding) ? $structure->encoding : 0;
                                    
                                    if ($encoding == 3) {
                                        $body = base64_decode($body);
                                    } elseif ($encoding == 4) {
                                        $body = quoted_printable_decode($body);
                                    }
                                    
                                    $subtype = isset($structure->subtype) ? strtoupper($structure->subtype) : '';
                                    if ($subtype == 'HTML') {
                                        $html = $body;
                                    } else {
                                        $text = $body;
                                    }
                                }
                                
                                return ['html' => $html, 'text' => $text];
                            };
                            
                            // Extract email parts
                            $parts = $extractParts($structure, $inbox, $email_number);
                            $html_body = $parts['html'];
                            $text_body = $parts['text'];
                            
                            // If no body found, try to get raw body
                            if (empty($html_body) && empty($text_body)) {
                                $body = imap_body($inbox, $email_number);
                                $text_body = $body;
                            }
                            
                            // Use HTML body if available, otherwise use text body
                            $message = !empty($html_body) ? $html_body : $text_body;
                            
                            // Get from name
                            $from_name = isset($header->from[0]->personal) ? $header->from[0]->personal : $from_email;
                            
                            // Check if this is a reply to a sent email
                            $reply_to_email_id = null;
                            if (stripos($subject, 'Re:') === 0) {
                                // Remove "Re:" prefix and try to match with sent emails
                                $original_subject = trim(substr($subject, 3));
                                
                                // Try to find matching sent email by subject and recipient email
                                $match_stmt = $conn->prepare("
                                    SELECT id FROM emails 
                                    WHERE subject = ? 
                                    AND recipient_email = ? 
                                    AND status = 'sent'
                                    ORDER BY created_at DESC 
                                    LIMIT 1
                                ");
                                $match_stmt->bind_param("ss", $original_subject, $from_email);
                                $match_stmt->execute();
                                $match_result = $match_stmt->get_result();
                                if ($match_row = $match_result->fetch_assoc()) {
                                    $reply_to_email_id = $match_row['id'];
                                }
                                $match_stmt->close();
                                
                                // If not found, try without "Re:" prefix variations
                                if (!$reply_to_email_id) {
                                    // Try with different "Re:" variations
                                    $variations = [
                                        trim($original_subject),
                                        trim(str_ireplace('Re:', '', $subject)),
                                        trim(str_ireplace('RE:', '', $subject)),
                                        trim(str_ireplace('re:', '', $subject))
                                    ];
                                    
                                    foreach ($variations as $var_subject) {
                                        $match_stmt2 = $conn->prepare("
                                            SELECT id FROM emails 
                                            WHERE (subject = ? OR subject LIKE ?)
                                            AND recipient_email = ? 
                                            AND status = 'sent'
                                            ORDER BY created_at DESC 
                                            LIMIT 1
                                        ");
                                        $like_subject = '%' . $var_subject . '%';
                                        $match_stmt2->bind_param("sss", $var_subject, $like_subject, $from_email);
                                        $match_stmt2->execute();
                                        $match_result2 = $match_stmt2->get_result();
                                        if ($match_row2 = $match_result2->fetch_assoc()) {
                                            $reply_to_email_id = $match_row2['id'];
                                            $match_stmt2->close();
                                            break;
                                        }
                                        $match_stmt2->close();
                                    }
                                }
                            }
                            
                            // Insert into database - use cached column check result
                            if ($reply_to_column_exists && $reply_to_email_id !== null) {
                                try {
                                    $insert_stmt = $conn->prepare("INSERT INTO incoming_emails (from_email, from_name, subject, message, message_html, read_status, created_at, reply_to_email_id) VALUES (?, ?, ?, ?, ?, 'unread', ?, ?)");
                                    $insert_stmt->bind_param("ssssssi", $from_email, $from_name, $subject, $text_body, $html_body, $date, $reply_to_email_id);
                                    $insert_stmt->execute();
                                    $insert_stmt->close();
                                } catch (Exception $e) {
                                    // Fallback to insert without reply_to_email_id
                                    $insert_stmt = $conn->prepare("INSERT INTO incoming_emails (from_email, from_name, subject, message, message_html, read_status, created_at) VALUES (?, ?, ?, ?, ?, 'unread', ?)");
                                    $insert_stmt->bind_param("ssssss", $from_email, $from_name, $subject, $text_body, $html_body, $date);
                                    $insert_stmt->execute();
                                    $insert_stmt->close();
                                }
                            } else {
                                // Column doesn't exist or reply_to_email_id is null, insert without it
                                $insert_stmt = $conn->prepare("INSERT INTO incoming_emails (from_email, from_name, subject, message, message_html, read_status, created_at) VALUES (?, ?, ?, ?, ?, 'unread', ?)");
                                $insert_stmt->bind_param("ssssss", $from_email, $from_name, $subject, $text_body, $html_body, $date);
                                $insert_stmt->execute();
                                $insert_stmt->close();
                            }
                            
                            $fetched_count++;
                            }
                            
                            if (isset($check_stmt)) {
                                $check_stmt->close();
                            }
                        } catch (Exception $email_error) {
                            // Log error but continue with next email
                            error_log("Error processing email #{$email_number}: " . $email_error->getMessage());
                            if (isset($check_stmt)) {
                                $check_stmt->close();
                            }
                            continue;
                        } catch (Error $email_error) {
                            // Log PHP 7+ errors
                            error_log("Error processing email #{$email_number}: " . $email_error->getMessage());
                            if (isset($check_stmt)) {
                                $check_stmt->close();
                            }
                            continue;
                        }
                    }
                }
                
                if (isset($inbox) && $inbox) {
                    @imap_close($inbox);
                }
                $fetch_success = true;
                if ($fetched_count > 0) {
                    $email_success = "Fetched {$fetched_count} new email(s) from inbox.";
                }
            } else {
                $imap_error = @imap_last_error();
                $fetch_error = "Failed to connect to Gmail. Error: " . ($imap_error ? $imap_error : 'Unknown IMAP error. Please check your Gmail credentials and IMAP settings.');
            }
        } catch (Exception $e) {
            $fetch_error = "Error fetching emails: " . $e->getMessage();
            error_log("Fetch emails exception: " . $e->getMessage() . "\n" . $e->getTraceAsString());
        } catch (Error $e) {
            // Handle PHP 7+ errors
            $fetch_error = "Error fetching emails: " . $e->getMessage();
            error_log("Fetch emails error: " . $e->getMessage() . "\n" . $e->getTraceAsString());
        } catch (Throwable $e) {
            // Catch any other throwable
            $fetch_error = "Error fetching emails: " . $e->getMessage();
            error_log("Fetch emails throwable: " . $e->getMessage() . "\n" . $e->getTraceAsString());
        }
    }
    
    // Check if this is an AJAX request
    $is_ajax = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    
    if ($fetch_error && !$is_auto_fetch && !$is_ajax) {
        $email_error = $fetch_error;
    }
    
    // Return JSON response for auto-fetch requests OR AJAX requests
    if ($is_auto_fetch || ($is_ajax && isset($_GET['fetch_emails']))) {
        // Clear ALL output buffers first
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        
        // Suppress any errors/warnings that might output
        @ini_set('display_errors', 0);
        error_reporting(0);
        
        // Remove any previous headers and send JSON headers
        if (!headers_sent()) {
            header_remove();
            // Always return 200 status to prevent 500 error in browser
            http_response_code(200);
            header('Content-Type: application/json; charset=utf-8', true);
            header('Cache-Control: no-cache, must-revalidate', true);
            header('X-Content-Type-Options: nosniff', true);
        }
        
        // Build response
        $response = [
            'success' => $fetch_success,
            'fetched' => $fetched_count,
            'error' => $fetch_error ?: null
        ];
        
        // Encode and send
        $json = json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR);
        
        if ($json === false) {
            // Fallback if JSON encoding fails
            $json = json_encode([
                'success' => false,
                'fetched' => 0,
                'error' => 'Server error: JSON encoding failed - ' . json_last_error_msg()
            ], JSON_UNESCAPED_UNICODE);
        }
        
        // Ensure no output before this
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        
        echo $json;
        
        // Force exit - don't let any code after this run
        if (function_exists('fastcgi_finish_request')) {
            fastcgi_finish_request();
        }
        exit(0);
    }
}

// Check if admin is logged in (skip for auto-fetch as it's already handled)
if (!$is_auto_fetch && !isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

$admin_name = $_SESSION['admin_name'] ?? 'Administrator';
$admin_email = $_SESSION['admin_email'] ?? '';
$admin_username = $_SESSION['admin_username'] ?? '';

$unread_email_count = 0;
$unread_query = $conn->query("SELECT COUNT(*) AS total FROM incoming_emails WHERE read_status = 'unread' AND deleted = 0");
if ($unread_query) {
    $row = $unread_query->fetch_assoc();
    $unread_email_count = (int)($row['total'] ?? 0);
    $unread_query->free();
}

$pending_reports_count = 0;
$pending_reports_query = $conn->query("SELECT COUNT(*) AS total FROM reports WHERE status = 'pending'");
if ($pending_reports_query) {
    $row = $pending_reports_query->fetch_assoc();
    $pending_reports_count = (int)($row['total'] ?? 0);
    $pending_reports_query->free();
}

// Handle email sending
$email_success = '';
$email_error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_email'])) {
    $recipient_email = trim($_POST['recipient_email'] ?? '');
    $recipient_name = trim($_POST['recipient_name'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');
    $admin_id = $_SESSION['admin_id'];
    
    if (empty($recipient_email) || empty($subject) || empty($message)) {
        $email_error = "Please fill in all required fields.";
    } else {
        // First, save email to database with status 'pending'
        try {
            $stmt = $conn->prepare("INSERT INTO emails (admin_id, recipient_email, recipient_name, subject, message, status) VALUES (?, ?, ?, ?, ?, 'pending')");
            $stmt->bind_param("issss", $admin_id, $recipient_email, $recipient_name, $subject, $message);
            $stmt->execute();
            $email_id = $conn->insert_id;
            $stmt->close();
            
            // Now try to send the email
            try {
                $mail = new PHPMailer(true);
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'bizmobsu@gmail.com';
                $mail->Password = 'cohrugzxdhsjqybd';
                $mail->SMTPSecure = 'tls';
                $mail->Port = 587;
                $mail->SMTPOptions = array(
                    'ssl' => array(
                        'verify_peer' => false,
                        'verify_peer_name' => false,
                        'allow_self_signed' => true
                    )
                );
                
                $mail->setFrom('bizmobsu@gmail.com', 'Bizmo Admin');
                $mail->addAddress($recipient_email, $recipient_name);
                $mail->isHTML(true);
                $mail->Subject = $subject;
                $mail->Body = "
                    <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;'>
                        <h2 style='color: #dc2626; margin-bottom: 20px;'>Message from Bizmo Admin</h2>
                        <p>Hello {$recipient_name},</p>
                        <div style='background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;'>
                            " . nl2br(htmlspecialchars($message)) . "
                        </div>
                        <p style='margin-top: 30px; color: #666; font-size: 14px;'>Best regards,<br><strong>Bizmo Admin Team</strong></p>
                    </div>
                ";
                $mail->AltBody = "Hello {$recipient_name},\n\n" . $message . "\n\nBest regards,\nBizmo Admin Team";
                
                $mail->send();
                
                // Update email status to 'sent' and set sent_at timestamp
                $update_stmt = $conn->prepare("UPDATE emails SET status = 'sent', sent_at = NOW() WHERE id = ?");
                $update_stmt->bind_param("i", $email_id);
                $update_stmt->execute();
                $update_stmt->close();
                
                $email_success = "Email sent successfully to {$recipient_email}";
                
                // Clear form data
                $_POST = array();
            } catch (Exception $e) {
                // Update email status to 'failed'
                $update_stmt = $conn->prepare("UPDATE emails SET status = 'failed' WHERE id = ?");
                $update_stmt->bind_param("i", $email_id);
                $update_stmt->execute();
                $update_stmt->close();
                
                $email_error = "Failed to send email: " . $mail->ErrorInfo;
            }
        } catch (Exception $e) {
            $email_error = "Failed to save email: " . $e->getMessage();
        }
    }
}

// Fetch all users for recipient selection
$users = [];
try {
    $result = $conn->query("SELECT id, full_name, email FROM users ORDER BY full_name ASC");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $users[] = $row;
        }
    }
} catch (Exception $e) {
    // Error fetching users
}

// Fetch sent emails from database
$sent_emails = [];
$total_emails = 0;
$sent_count = 0;
$failed_count = 0;
$pending_count = 0;

try {
    // Get email statistics
    $stats_result = $conn->query("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status = 'sent' THEN 1 ELSE 0 END) as sent,
            SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed,
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending
        FROM emails
    ");
    if ($stats_result && $row = $stats_result->fetch_assoc()) {
        $total_emails = (int)$row['total'];
        $sent_count = (int)$row['sent'];
        $failed_count = (int)$row['failed'];
        $pending_count = (int)$row['pending'];
    }
    
    // Fetch sent emails with admin info
    $emails_result = $conn->query("
        SELECT e.*, a.full_name as admin_name, a.email as admin_email
        FROM emails e
        LEFT JOIN admin a ON e.admin_id = a.id
        ORDER BY e.created_at DESC
        LIMIT 100
    ");
    if ($emails_result) {
        while ($row = $emails_result->fetch_assoc()) {
            $sent_emails[] = $row;
        }
    }
} catch (Exception $e) {
    // Error fetching emails - table might not exist yet
    $email_error = "Email table not found. Please run the migration: migrations/20250122-create-emails-table.sql";
}

// Fetch incoming emails from database
$incoming_emails = [];
$incoming_unread_count = 0;
$trash_emails = [];

try {
    // Get incoming email statistics
    $incoming_stats = $conn->query("
        SELECT COUNT(*) as total, 
               SUM(CASE WHEN read_status = 'unread' THEN 1 ELSE 0 END) as unread
        FROM incoming_emails
        WHERE deleted = 0
    ");
    if ($incoming_stats && $row = $incoming_stats->fetch_assoc()) {
        $incoming_unread_count = (int)$row['unread'];
    }
    
    // Fetch incoming emails (excluding deleted ones)
    $incoming_result = $conn->query("
        SELECT * FROM incoming_emails
        WHERE deleted = 0
        ORDER BY created_at DESC
        LIMIT 100
    ");
    if ($incoming_result) {
        while ($row = $incoming_result->fetch_assoc()) {
            $incoming_emails[] = $row;
        }
    }
    
    // Fetch deleted emails for trash tab
    $trash_result = $conn->query("
        SELECT * FROM incoming_emails
        WHERE deleted = 1
        ORDER BY updated_at DESC
        LIMIT 100
    ");
    if ($trash_result) {
        while ($row = $trash_result->fetch_assoc()) {
            $trash_emails[] = $row;
        }
    }
} catch (Exception $e) {
    // Table might not exist yet - that's okay
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bizmo – Admin Emails</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #0b0b12;
            --surface: #111118;
            --surface-light: rgba(255,255,255,0.03);
            --text: #ffffff;
            --text-muted: #a2a3ad;
            --accent: #dc2626;
            --accent-purple: #9333ea;
            --accent-purple-light: rgba(147, 51, 234, 0.1);
            --border: rgba(255,255,255,0.08);
            --success: #22c55e;
            --warning: #f59e0b;
            --danger: #ef4444;
        }

        /* Light Theme Variables */
        body.light-theme {
            --bg: #f8f9fa;
            --surface: #ffffff;
            --surface-light: rgba(0,0,0,0.05);
            --text: #0f172a;
            --text-muted: #475569;
            --accent: #dc2626;
            --accent-purple: #9333ea;
            --accent-purple-light: rgba(147, 51, 234, 0.15);
            --border: rgba(0,0,0,0.15);
            --success: #16a34a;
            --warning: #d97706;
            --danger: #dc2626;
            background: var(--bg);
        }

        /* Enhanced contrast for light theme */
        body.light-theme .sidebar {
            background: #ffffff;
            border-right: 1px solid rgba(0,0,0,0.12);
            box-shadow: 2px 0 8px rgba(0,0,0,0.05);
        }

        body.light-theme .table-card,
        body.light-theme .email-card,
        body.light-theme .compose-modal {
            background: #ffffff;
            border: 1px solid rgba(0,0,0,0.12);
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }

        body.light-theme .form-input,
        body.light-theme .form-select,
        body.light-theme .form-textarea {
            background: #ffffff;
            border: 1px solid rgba(0,0,0,0.15);
            color: #0f172a;
        }

        body.light-theme .form-input:focus,
        body.light-theme .form-select:focus,
        body.light-theme .form-textarea:focus {
            border-color: var(--accent-purple);
            box-shadow: 0 0 0 3px rgba(147, 51, 234, 0.15);
        }

        body.light-theme .nav-link:hover {
            background: rgba(0,0,0,0.06);
        }

        body.light-theme .nav-link.active {
            background: rgba(147, 51, 234, 0.12);
            color: var(--accent-purple);
        }

        body.light-theme .btn-icon,
        body.light-theme .dark-mode-toggle-top {
            background: #f1f5f9;
            border: 1px solid rgba(0,0,0,0.12);
        }

        body.light-theme .btn-icon:hover {
            background: #e2e8f0;
        }

        body.light-theme .user-menu:hover {
            background: rgba(0,0,0,0.05);
        }

        body.light-theme .user-dropdown {
            background: #ffffff;
            border: 1px solid rgba(0,0,0,0.15);
            box-shadow: 0 10px 40px rgba(0,0,0,0.15);
        }

        body.light-theme table thead {
            background: #f8f9fa;
        }

        body.light-theme table td {
            border-bottom: 1px solid rgba(0,0,0,0.08);
        }

        body.light-theme .status-badge {
            font-weight: 600;
        }

        body.light-theme .modal-overlay {
            background: rgba(0, 0, 0, 0.5);
        }

        body.light-theme .logout-modal {
            background: #ffffff;
            border: 1px solid rgba(0,0,0,0.15);
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Custom Scrollbar Styles - Dark Theme */
        ::-webkit-scrollbar {
            width: 10px;
            height: 10px;
        }

        ::-webkit-scrollbar-track {
            background: var(--surface);
            border-radius: 5px;
        }

        ::-webkit-scrollbar-thumb {
            background: rgba(255, 255, 255, 0.15);
            border-radius: 5px;
            border: 2px solid var(--surface);
            transition: background 0.2s ease;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: rgba(147, 51, 234, 0.5);
        }

        ::-webkit-scrollbar-thumb:active {
            background: var(--accent-purple);
        }

        ::-webkit-scrollbar-corner {
            background: var(--surface);
        }

        /* Light Theme Scrollbar */
        body.light-theme ::-webkit-scrollbar-track {
            background: #f1f5f9;
        }

        body.light-theme ::-webkit-scrollbar-thumb {
            background: rgba(0, 0, 0, 0.2);
            border: 2px solid #f1f5f9;
        }

        body.light-theme ::-webkit-scrollbar-thumb:hover {
            background: rgba(147, 51, 234, 0.4);
        }

        body.light-theme ::-webkit-scrollbar-thumb:active {
            background: var(--accent-purple);
        }

        body.light-theme ::-webkit-scrollbar-corner {
            background: #f1f5f9;
        }

        /* Firefox Scrollbar - Dark Theme (applied to html for global) */
        html {
            scrollbar-width: thin;
            scrollbar-color: rgba(255, 255, 255, 0.15) var(--surface);
        }

        /* Firefox Scrollbar - Light Theme */
        body.light-theme {
            scrollbar-color: rgba(0, 0, 0, 0.2) #f1f5f9;
        }
        
        /* Ensure scrollable containers inherit scrollbar styles */
        .sidebar::-webkit-scrollbar,
        .email-list-panel::-webkit-scrollbar,
        .email-list-items::-webkit-scrollbar,
        .email-viewer-content::-webkit-scrollbar,
        .email-autocomplete-dropdown::-webkit-scrollbar {
            width: 10px;
            height: 10px;
        }
        
        .sidebar::-webkit-scrollbar-track,
        .email-list-panel::-webkit-scrollbar-track,
        .email-list-items::-webkit-scrollbar-track,
        .email-viewer-content::-webkit-scrollbar-track,
        .email-autocomplete-dropdown::-webkit-scrollbar-track {
            background: var(--surface);
            border-radius: 5px;
        }
        
        .sidebar::-webkit-scrollbar-thumb,
        .email-list-panel::-webkit-scrollbar-thumb,
        .email-list-items::-webkit-scrollbar-thumb,
        .email-viewer-content::-webkit-scrollbar-thumb,
        .email-autocomplete-dropdown::-webkit-scrollbar-thumb {
            background: rgba(255, 255, 255, 0.15);
            border-radius: 5px;
            border: 2px solid var(--surface);
            transition: background 0.2s ease;
        }
        
        .sidebar::-webkit-scrollbar-thumb:hover,
        .email-list-panel::-webkit-scrollbar-thumb:hover,
        .email-list-items::-webkit-scrollbar-thumb:hover,
        .email-viewer-content::-webkit-scrollbar-thumb:hover,
        .email-autocomplete-dropdown::-webkit-scrollbar-thumb:hover {
            background: rgba(147, 51, 234, 0.5);
        }
        
        body.light-theme .sidebar::-webkit-scrollbar-track,
        body.light-theme .email-list-panel::-webkit-scrollbar-track,
        body.light-theme .email-list-items::-webkit-scrollbar-track,
        body.light-theme .email-viewer-content::-webkit-scrollbar-track,
        body.light-theme .email-autocomplete-dropdown::-webkit-scrollbar-track {
            background: #f1f5f9;
        }
        
        body.light-theme .sidebar::-webkit-scrollbar-thumb,
        body.light-theme .email-list-panel::-webkit-scrollbar-thumb,
        body.light-theme .email-list-items::-webkit-scrollbar-thumb,
        body.light-theme .email-viewer-content::-webkit-scrollbar-thumb,
        body.light-theme .email-autocomplete-dropdown::-webkit-scrollbar-thumb {
            background: rgba(0, 0, 0, 0.2);
            border: 2px solid #f1f5f9;
        }
        
        body.light-theme .sidebar::-webkit-scrollbar-thumb:hover,
        body.light-theme .email-list-panel::-webkit-scrollbar-thumb:hover,
        body.light-theme .email-list-items::-webkit-scrollbar-thumb:hover,
        body.light-theme .email-viewer-content::-webkit-scrollbar-thumb:hover,
        body.light-theme .email-autocomplete-dropdown::-webkit-scrollbar-thumb:hover {
            background: rgba(147, 51, 234, 0.4);
        }

        body {
            font-family: 'Inter', ui-sans-serif, system-ui, -apple-system, sans-serif;
            background: var(--bg);
            color: var(--text);
            overflow-x: hidden;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        /* Smooth Scrolling */
        html {
            scroll-behavior: smooth;
        }

        /* Enhanced scrollbar for specific scrollable containers */
        .sidebar,
        .email-list-panel,
        .email-list-items,
        .email-viewer-content,
        .email-autocomplete-dropdown {
            scrollbar-width: thin;
            scrollbar-color: rgba(255, 255, 255, 0.15) var(--surface);
        }

        body.light-theme .sidebar,
        body.light-theme .email-list-panel,
        body.light-theme .email-list-items,
        body.light-theme .email-viewer-content,
        body.light-theme .email-autocomplete-dropdown {
            scrollbar-color: rgba(0, 0, 0, 0.2) #f1f5f9;
        }

        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 260px;
            background: var(--surface);
            border-right: 1px solid var(--border);
            padding: 24px;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            z-index: 100;
            display: flex;
            flex-direction: column;
        }

        .sidebar-logo {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 40px;
            font-size: 24px;
            font-weight: 900;
            color: var(--text);
        }

        .sidebar-logo img {
            width: 40px;
            height: 40px;
        }

        .nav-menu {
            list-style: none;
        }

        .nav-item {
            margin-bottom: 8px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            color: var(--text-muted);
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.2s;
            font-weight: 500;
            position: relative;
        }

        .nav-link:hover {
            background: var(--surface-light);
            color: var(--text);
        }

        .nav-link.active {
            background: var(--accent-purple-light);
            color: var(--accent-purple);
        }

        .nav-icon {
            width: 20px;
            height: 20px;
        }

        .nav-badge {
            margin-left: auto;
            padding: 2px 8px;
            border-radius: 999px;
            background: var(--danger);
            color: #fff;
            font-size: 11px;
            font-weight: 700;
            min-width: 24px;
            text-align: center;
        }

        .sidebar-footer {
            margin-top: auto;
            padding-top: 40px;
        }

        .dark-mode-toggle-top {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 8px 12px;
            background: var(--surface-light);
            border: 1px solid var(--border);
            border-radius: 8px;
        }

        .toggle-switch {
            width: 44px;
            height: 24px;
            background: var(--accent-purple);
            border-radius: 12px;
            position: relative;
            cursor: pointer;
            flex-shrink: 0;
            transition: all 0.3s;
        }

        .toggle-switch::after {
            content: '';
            position: absolute;
            width: 18px;
            height: 18px;
            background: white;
            border-radius: 50%;
            top: 3px;
            right: 3px;
            transition: all 0.3s;
        }

        body.light-theme .toggle-switch {
            background: #d1d5db;
        }

        body.light-theme .toggle-switch::after {
            right: 23px;
            background: white;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 260px;
            padding: 24px;
        }

        /* Top Bar */
        .top-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 32px;
            gap: 16px;
            flex-wrap: wrap;
        }

        .search-box {
            flex: 1;
            min-width: 300px;
            position: relative;
        }

        .search-box input {
            width: 100%;
            padding: 12px 16px 12px 44px;
            background: var(--surface-light);
            border: 1px solid var(--border);
            border-radius: 8px;
            color: var(--text);
            font-size: 14px;
        }

        .search-box input::placeholder {
            color: var(--text-muted);
        }

        .search-icon {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            width: 20px;
            height: 20px;
            color: var(--text-muted);
        }

        .top-actions {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .date-picker {
            padding: 12px 16px;
            background: var(--surface-light);
            border: 1px solid var(--border);
            border-radius: 8px;
            color: var(--text);
            font-size: 14px;
            cursor: default;
            user-select: none;
        }

        .user-menu {
            position: relative;
            display: flex;
            align-items: center;
            gap: 12px;
            cursor: pointer;
            padding: 8px;
            border-radius: 8px;
            transition: all 0.2s;
        }

        .user-menu:hover {
            background: var(--surface-light);
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--accent-purple);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            color: white;
        }

        .user-dropdown {
            position: absolute;
            top: calc(100% + 8px);
            right: 0;
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 8px;
            min-width: 200px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: all 0.2s;
            z-index: 1000;
        }

        .user-menu.active .user-dropdown {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }

        .user-dropdown-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            color: var(--text);
            text-decoration: none;
            transition: all 0.2s;
            border-bottom: 1px solid var(--border);
        }

        .user-dropdown-item:last-child {
            border-bottom: none;
        }

        .user-dropdown-item:hover {
            background: var(--surface-light);
        }

        /* Metrics Cards */
        .metrics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 32px;
        }

        .metric-card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 24px;
            position: relative;
        }

        .metric-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 16px;
        }

        .metric-title {
            font-size: 14px;
            color: var(--text-muted);
            font-weight: 500;
        }

        .metric-value {
            font-size: 32px;
            font-weight: 800;
            margin-bottom: 8px;
        }

        .metric-icon {
            position: absolute;
            top: 24px;
            right: 24px;
            width: 48px;
            height: 48px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0.1;
        }

        /* Email Cards Grid */
        .emails-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 20px;
            margin-bottom: 32px;
        }

        .email-card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 24px;
            transition: all 0.2s;
            cursor: pointer;
        }

        .email-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }

        .email-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 16px;
        }

        .email-sender {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .email-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--accent-purple);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            color: white;
            font-size: 16px;
        }

        .email-sender-info h4 {
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 2px;
            color: var(--text);
        }

        .email-sender-info p {
            font-size: 12px;
            color: var(--text-muted);
        }

        .email-date {
            font-size: 12px;
            color: var(--text-muted);
        }

        .email-subject {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 8px;
            color: var(--text);
        }

        .email-preview {
            font-size: 14px;
            color: var(--text-muted);
            line-height: 1.5;
            margin-bottom: 16px;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .email-footer {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .email-tags {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        .email-tag {
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
        }

        .tag-inbox {
            background: rgba(59, 130, 246, 0.1);
            color: #3b82f6;
        }

        .tag-sent {
            background: rgba(34, 197, 94, 0.1);
            color: var(--success);
        }

        .tag-draft {
            background: rgba(245, 158, 11, 0.1);
            color: var(--warning);
        }

        .tag-important {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
        }

        .email-actions {
            display: flex;
            gap: 8px;
        }

        .email-action-btn {
            width: 32px;
            height: 32px;
            border-radius: 6px;
            background: var(--surface-light);
            border: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s;
            color: var(--text-muted);
        }

        .email-action-btn:hover {
            background: var(--surface);
            color: var(--text);
        }

        /* Table Card */
        .table-card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 24px;
        }

        .table-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 24px;
        }

        .table-title {
            font-size: 18px;
            font-weight: 700;
        }

        .table-actions {
            display: flex;
            gap: 12px;
        }

        .btn-secondary {
            padding: 10px 16px;
            background: var(--surface-light);
            border: 1px solid var(--border);
            border-radius: 8px;
            color: var(--text);
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
        }

        .btn-secondary:hover {
            background: var(--surface);
        }

        .btn-primary {
            padding: 10px 16px;
            background: var(--accent-purple);
            border: none;
            border-radius: 8px;
            color: white;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
        }

        .btn-primary:hover {
            background: #7c3aed;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            border-bottom: 1px solid var(--border);
        }

        th {
            text-align: left;
            padding: 12px;
            font-size: 12px;
            font-weight: 600;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        td {
            padding: 16px 12px;
            border-bottom: 1px solid var(--border);
            font-size: 14px;
        }

        /* Clickable Email Rows */
        tbody tr.email-row {
            cursor: pointer;
            transition: background-color 0.2s ease;
        }

        tbody tr.email-row:hover {
            background: var(--surface-light) !important;
        }

        tbody tr.email-row:hover td {
            background: transparent;
        }

        tbody tr.email-row td:last-child {
            cursor: default;
        }

        tbody tr.email-row td:last-child * {
            cursor: pointer;
        }

        .status-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }

        .status-read {
            background: rgba(34, 197, 94, 0.1);
            color: var(--success);
        }

        .status-unread {
            background: rgba(59, 130, 246, 0.1);
            color: #3b82f6;
        }

        .status-processing {
            background: rgba(245, 158, 11, 0.1);
            color: var(--warning);
        }

        .status-declined {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
        }

        /* Logout Modal */
        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.75);
            backdrop-filter: blur(4px);
            z-index: 2000;
            align-items: center;
            justify-content: center;
            padding: 20px;
            animation: fadeIn 0.3s ease;
        }

        .modal-overlay.active {
            display: flex;
        }

        .logout-modal {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 32px;
            max-width: 400px;
            width: 100%;
            position: relative;
            box-shadow: 0 40px 120px rgba(0,0,0,0.5);
            animation: slideUp 0.3s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .modal-header {
            margin-bottom: 20px;
        }

        .modal-title {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 8px;
            color: var(--text);
        }

        .modal-message {
            color: var(--text-muted);
            font-size: 14px;
            line-height: 1.6;
        }

        .modal-actions {
            display: flex;
            gap: 12px;
            margin-top: 24px;
        }

        .btn-modal {
            flex: 1;
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
        }

        .btn-modal-cancel {
            background: var(--surface-light);
            border: 1px solid var(--border);
            color: var(--text);
        }

        .btn-modal-cancel:hover {
            background: var(--surface);
        }

        .btn-modal-logout {
            background: var(--danger);
            color: white;
        }

        .btn-modal-logout:hover {
            background: #dc2626;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
        }

        .modal-icon {
            width: 64px;
            height: 64px;
            margin: 0 auto 20px;
            background: rgba(239, 68, 68, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .modal-icon svg {
            width: 32px;
            height: 32px;
            color: var(--danger);
        }

        /* Delete Confirmation Modal */
        .delete-modal {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 32px;
            max-width: 450px;
            width: 100%;
            position: relative;
            box-shadow: 0 40px 120px rgba(0,0,0,0.5);
            animation: slideUp 0.3s ease;
        }

        .delete-modal-icon {
            width: 64px;
            height: 64px;
            margin: 0 auto 20px;
            background: rgba(239, 68, 68, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .delete-modal-icon svg {
            width: 32px;
            height: 32px;
            color: var(--danger);
        }

        .delete-modal-title {
            font-size: 22px;
            font-weight: 700;
            margin-bottom: 12px;
            color: var(--text);
            text-align: center;
        }

        .delete-modal-message {
            color: var(--text-muted);
            font-size: 14px;
            line-height: 1.6;
            text-align: center;
            margin-bottom: 24px;
        }

        .delete-modal-actions {
            display: flex;
            gap: 12px;
            margin-top: 24px;
        }

        .btn-modal-delete {
            flex: 1;
            padding: 12px 24px;
            background: var(--danger);
            border: none;
            border-radius: 8px;
            color: white;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
        }

        .btn-modal-delete:hover {
            background: #dc2626;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
        }

        body.light-theme .delete-modal {
            background: #ffffff;
            border: 1px solid rgba(0,0,0,0.15);
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }

        /* Email Autocomplete */
        .email-autocomplete-container {
            position: relative;
        }

        .email-autocomplete-dropdown {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 8px;
            margin-top: 4px;
            max-height: 300px;
            overflow-y: auto;
            z-index: 1000;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            display: none;
        }

        .email-autocomplete-dropdown.show {
            display: block;
        }

        .email-autocomplete-item {
            padding: 12px 16px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: background-color 0.2s;
            border-bottom: 1px solid var(--border);
        }

        .email-autocomplete-item:last-child {
            border-bottom: none;
        }

        .email-autocomplete-item:hover,
        .email-autocomplete-item.highlighted {
            background: var(--surface-light);
        }

        .email-autocomplete-avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: var(--accent-purple);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            color: white;
            font-size: 14px;
            flex-shrink: 0;
        }

        .email-autocomplete-info {
            flex: 1;
            min-width: 0;
        }

        .email-autocomplete-name {
            font-size: 14px;
            font-weight: 600;
            color: var(--text);
            margin-bottom: 2px;
        }

        .email-autocomplete-email {
            font-size: 12px;
            color: var(--text-muted);
        }

        body.light-theme .email-autocomplete-dropdown {
            background: #ffffff;
            border: 1px solid rgba(0,0,0,0.15);
            box-shadow: 0 10px 40px rgba(0,0,0,0.15);
        }

        /* Compose Email Modal */
        .compose-modal {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 32px;
            max-width: 600px;
            width: 100%;
            max-height: 90vh;
            overflow-y: auto;
            position: relative;
            box-shadow: 0 40px 120px rgba(0,0,0,0.5);
            animation: slideUp 0.3s ease;
        }

        .compose-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 24px;
            padding-bottom: 16px;
            border-bottom: 1px solid var(--border);
        }

        .compose-title {
            font-size: 24px;
            font-weight: 700;
            color: var(--text);
        }

        .close-compose {
            width: 32px;
            height: 32px;
            border-radius: 8px;
            background: var(--surface-light);
            border: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s;
            color: var(--text);
        }

        .close-compose:hover {
            background: var(--surface);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 8px;
            color: var(--text);
        }

        .form-input,
        .form-select,
        .form-textarea {
            width: 100%;
            padding: 12px 16px;
            background: var(--surface-light);
            border: 1px solid var(--border);
            border-radius: 8px;
            color: var(--text);
            font-size: 14px;
            font-family: inherit;
            transition: all 0.2s;
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
        }

        .form-select {
            background-image: url("data:image/svg+xml,%3Csvg width='12' height='8' viewBox='0 0 12 8' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M1 1L6 6L11 1' stroke='%23a2a3ad' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 16px center;
            padding-right: 40px;
            cursor: pointer;
        }

        body.light-theme .form-select {
            background-image: url("data:image/svg+xml,%3Csvg width='12' height='8' viewBox='0 0 12 8' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M1 1L6 6L11 1' stroke='%23475569' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");
        }

        .form-select option {
            background: var(--surface);
            color: var(--text);
            padding: 12px;
        }

        body.light-theme .form-select option {
            background: #ffffff;
            color: #0f172a;
        }

        .form-input:focus,
        .form-select:focus,
        .form-textarea:focus {
            outline: none;
            border-color: var(--accent-purple);
            box-shadow: 0 0 0 3px rgba(147, 51, 234, 0.1);
        }

        .form-textarea {
            min-height: 200px;
            resize: vertical;
        }

        .form-actions {
            display: flex;
            gap: 12px;
            margin-top: 24px;
        }

        .btn-send {
            flex: 1;
            padding: 12px 24px;
            background: var(--accent-purple);
            border: none;
            border-radius: 8px;
            color: white;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
        }

        .btn-send:hover {
            background: #7c3aed;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(147, 51, 234, 0.3);
        }

        .alert {
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
            font-weight: 500;
        }

        .alert-success {
            background: rgba(34, 197, 94, 0.1);
            border: 1px solid rgba(34, 197, 94, 0.3);
            color: var(--success);
        }

        .alert-error {
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.3);
            color: var(--danger);
        }

        /* Toast Notification */
        .toast-container {
            position: fixed;
            top: 24px;
            right: 24px;
            z-index: 10000;
            display: flex;
            flex-direction: column;
            gap: 12px;
            pointer-events: none;
        }

        .toast {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 16px 20px;
            min-width: 320px;
            max-width: 400px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            display: flex;
            align-items: center;
            gap: 12px;
            pointer-events: auto;
            animation: slideInRight 0.3s ease, fadeOut 0.3s ease 4.7s forwards;
            position: relative;
            overflow: hidden;
        }

        .toast::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            width: 4px;
            background: var(--accent-purple);
        }

        .toast-success::before {
            background: var(--success);
        }

        .toast-error::before {
            background: var(--danger);
        }

        .toast-icon {
            width: 24px;
            height: 24px;
            flex-shrink: 0;
        }

        .toast-content {
            flex: 1;
        }

        .toast-title {
            font-weight: 600;
            font-size: 14px;
            color: var(--text);
            margin-bottom: 4px;
        }

        .toast-message {
            font-size: 13px;
            color: var(--text-muted);
            line-height: 1.4;
        }

        .toast-close {
            width: 20px;
            height: 20px;
            border: none;
            background: transparent;
            color: var(--text-muted);
            cursor: pointer;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 4px;
            transition: all 0.2s;
            flex-shrink: 0;
        }

        .toast-close:hover {
            background: var(--surface-light);
            color: var(--text);
        }

        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        @keyframes fadeOut {
            from {
                opacity: 1;
                transform: translateX(0);
            }
            to {
                opacity: 0;
                transform: translateX(100%);
            }
        }

        @keyframes pulse {
            0%, 100% {
                transform: scale(1);
                box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            }
            50% {
                transform: scale(1.02);
                box-shadow: 0 15px 50px rgba(147, 51, 234, 0.4);
            }
        }

        /* Gmail-like Split Layout */
        .email-split-container {
            display: flex;
            gap: 0;
            height: calc(100vh - 200px);
            min-height: 600px;
            border: 1px solid var(--border);
            border-radius: 12px;
            overflow: hidden;
            background: var(--surface);
        }

        .email-list-panel {
            width: 45%;
            min-width: 400px;
            max-width: 600px;
            border-right: 1px solid var(--border);
            overflow-y: auto;
            background: var(--surface);
            display: flex;
            flex-direction: column;
        }

        .email-tabs {
            display: flex;
            border-bottom: 1px solid var(--border);
            background: var(--surface);
            padding: 0 16px;
        }

        .email-tab {
            padding: 12px 24px;
            border: none;
            background: transparent;
            color: var(--text-muted);
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            border-bottom: 2px solid transparent;
            transition: all 0.2s;
            position: relative;
        }

        .email-tab:hover {
            color: var(--text);
            background: var(--surface-light);
        }

        .email-tab.active {
            color: var(--accent-purple);
            border-bottom-color: var(--accent-purple);
        }

        .email-viewer-panel {
            flex: 1;
            min-width: 400px;
            display: flex;
            flex-direction: column;
            background: var(--surface);
            overflow: hidden;
        }

        .email-viewer-empty {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100%;
            color: var(--text-muted);
            padding: 40px;
        }

        .email-viewer-empty svg {
            width: 64px;
            height: 64px;
            opacity: 0.3;
            margin-bottom: 20px;
        }

        .email-viewer-header {
            padding: 16px 24px;
            border-bottom: 1px solid var(--border);
            background: var(--surface);
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-shrink: 0;
        }

        .email-viewer-title-section {
            display: flex;
            align-items: center;
            gap: 12px;
            flex: 1;
        }

        .email-viewer-title {
            font-size: 22px;
            font-weight: 400;
            color: var(--text);
            margin: 0;
        }

        .email-viewer-label {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 4px 12px;
            background: var(--surface-light);
            border: 1px solid var(--border);
            border-radius: 16px;
            font-size: 12px;
            color: var(--text-muted);
            cursor: pointer;
        }

        .email-viewer-label:hover {
            background: var(--surface);
        }

        .email-viewer-header-actions {
            display: flex;
            gap: 8px;
            align-items: center;
        }

        .email-viewer-header-icon {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            color: var(--text-muted);
            transition: all 0.2s;
        }

        .email-viewer-header-icon:hover {
            background: var(--surface-light);
            color: var(--text);
        }

        .email-viewer-content {
            flex: 1;
            overflow-y: auto;
            padding: 0;
            background: var(--surface);
        }

        .email-thread {
            display: flex;
            flex-direction: column;
        }

        .email-thread-item {
            padding: 16px 24px;
            border-bottom: 1px solid var(--border);
            transition: background-color 0.2s;
        }

        .email-thread-item:hover {
            background: var(--surface-light);
        }

        .email-thread-item-header {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            margin-bottom: 12px;
        }

        .email-thread-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--accent-purple);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            color: white;
            font-size: 16px;
            flex-shrink: 0;
        }

        .email-thread-info {
            flex: 1;
            min-width: 0;
        }

        .email-thread-sender-row {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 4px;
        }

        .email-thread-sender {
            font-size: 14px;
            font-weight: 600;
            color: var(--text);
        }

        .email-thread-to {
            font-size: 13px;
            color: var(--text-muted);
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .email-thread-to-arrow {
            width: 16px;
            height: 16px;
            color: var(--text-muted);
        }

        .email-thread-date-row {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-top: 4px;
        }

        .email-thread-date {
            font-size: 12px;
            color: var(--text-muted);
        }

        .email-thread-actions {
            display: flex;
            gap: 8px;
            margin-left: auto;
        }

        .email-thread-action-icon {
            width: 20px;
            height: 20px;
            cursor: pointer;
            color: var(--text-muted);
            transition: color 0.2s;
        }

        .email-thread-action-icon:hover {
            color: var(--text);
        }

        .email-thread-body {
            margin-left: 52px;
            color: var(--text);
            line-height: 1.6;
            font-size: 14px;
            white-space: pre-wrap;
            word-wrap: break-word;
        }

        .email-thread-body * {
            color: var(--text) !important;
        }

        .email-thread-body img {
            max-width: 100%;
            height: auto;
        }

        .email-viewer-footer {
            padding: 16px 24px;
            border-top: 1px solid var(--border);
            background: var(--surface);
            display: flex;
            align-items: center;
            gap: 12px;
            flex-shrink: 0;
        }

        .email-viewer-footer-btn {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 10px 16px;
            background: transparent;
            border: 1px solid var(--border);
            border-radius: 24px;
            color: var(--text);
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
        }

        .email-viewer-footer-btn:hover {
            background: var(--surface-light);
        }

        .email-viewer-footer-btn-primary {
            background: var(--accent-purple);
            border-color: var(--accent-purple);
            color: white;
        }

        .email-viewer-footer-btn-primary:hover {
            background: #7c3aed;
        }

        .email-viewer-footer-icon {
            width: 20px;
            height: 20px;
        }

        .email-list-header {
            padding: 16px 20px;
            border-bottom: 1px solid var(--border);
            background: var(--surface);
            flex-shrink: 0;
        }

        .email-list-items {
            flex: 1;
            overflow-y: auto;
        }

        .email-list-item {
            padding: 12px 16px;
            border-bottom: 1px solid var(--border);
            cursor: pointer;
            transition: background-color 0.2s, box-shadow 0.2s;
            display: flex;
            align-items: center;
            gap: 12px;
            position: relative;
        }

        .email-list-item:hover {
            background: var(--surface-light);
            box-shadow: inset 0 -1px 0 0 var(--border);
        }

        .email-list-item.active {
            background: var(--accent-purple-light);
        }

        .email-list-item.unread {
            font-weight: 600;
            background: var(--surface);
        }

        .email-list-item.selected {
            background: var(--accent-purple-light);
        }

        .email-list-item.selected:hover {
            background: var(--accent-purple-light);
        }

        .email-list-item.unread .email-list-item-from {
            font-weight: 700;
        }

        .email-checkbox {
            width: 18px;
            height: 18px;
            cursor: pointer;
            flex-shrink: 0;
            accent-color: var(--accent-purple);
        }

        .email-star {
            width: 20px;
            height: 20px;
            cursor: pointer;
            flex-shrink: 0;
            color: var(--text-muted);
            transition: color 0.2s;
            padding: 2px;
        }

        .email-star:hover {
            color: var(--warning);
        }

        .email-star.starred {
            color: var(--warning);
            fill: var(--warning);
        }

        .email-list-item-content {
            flex: 1;
            min-width: 0;
            display: flex;
            flex-direction: column;
            gap: 2px;
        }

        .email-list-item-from {
            font-size: 14px;
            font-weight: 500;
            color: var(--text);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .email-list-item-subject-preview {
            font-size: 14px;
            color: var(--text-muted);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .email-list-item-subject {
            font-weight: 500;
            color: var(--text);
        }

        .email-list-item-preview {
            color: var(--text-muted);
        }

        .email-list-item-date {
            font-size: 12px;
            color: var(--text-muted);
            white-space: nowrap;
            flex-shrink: 0;
            min-width: 80px;
            text-align: right;
        }

        .email-list-item-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--accent-purple);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            color: white;
            font-size: 16px;
            flex-shrink: 0;
        }

        body.light-theme .toast {
            background: #ffffff;
            border: 1px solid rgba(0,0,0,0.15);
            box-shadow: 0 10px 40px rgba(0,0,0,0.15);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s;
            }

            .sidebar.open {
                transform: translateX(0);
            }

            .main-content {
                margin-left: 0;
            }

            .top-bar {
                flex-direction: column;
            }

            .search-box {
                width: 100%;
            }

            .emails-grid {
                grid-template-columns: 1fr;
            }

            .email-split-container {
                flex-direction: column;
                height: auto;
                min-height: auto;
            }

            .email-list-panel {
                width: 100%;
                max-width: 100%;
                min-width: 100%;
                border-right: none;
                border-bottom: 1px solid var(--border);
                max-height: 400px;
            }

            .email-viewer-panel {
                min-height: 400px;
                min-width: 100%;
            }

            .email-tabs {
                overflow-x: auto;
            }

            .email-list-item {
                padding: 10px 12px;
            }

            .email-list-item-avatar {
                width: 32px;
                height: 32px;
                font-size: 14px;
            }
        }
    </style>
</head>
<body>
    <!-- Toast Notification Container -->
    <div class="toast-container" id="toastContainer"></div>

    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-logo">
                <img src="../icons/bizmo.png" alt="Bizmo">
                <span>Bizmo Admin</span>
            </div>

            <nav>
                <ul class="nav-menu">
                    <li class="nav-item">
                        <a href="admin_dashboard.php" class="nav-link">
                            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>
                            </svg>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="admin_users.php" class="nav-link">
                            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/>
                            </svg>
                            <span>Users</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="users_decks.php" class="nav-link">
                            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/>
                            </svg>
                            <span>Decks</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="admin_email.php" class="nav-link active">
                            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                            </svg>
                            <span>Emails</span>
                            <?php if ($unread_email_count > 0): ?>
                                <span class="nav-badge"><?php echo $unread_email_count > 99 ? '99+' : $unread_email_count; ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="admin_reports.php" class="nav-link">
                            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                            </svg>
                            <span>Reports</span>
                            <?php if ($pending_reports_count > 0): ?>
                                <span class="nav-badge"><?php echo $pending_reports_count > 99 ? '99+' : $pending_reports_count; ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                </ul>
            </nav>

            <div class="sidebar-footer">
                <a href="#" class="nav-link" id="logoutBtn" style="color: var(--danger);">
                    <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                    </svg>
                    Logout
                </a>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Top Bar -->
            <div class="top-bar">
                <div class="search-box">
                    <svg class="search-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                    </svg>
                    <input type="text" id="searchInput" placeholder="Search emails by subject, sender, or content...">
                </div>

                <div class="top-actions">
                    <div class="date-picker" id="realtimeClock"></div>
                    <div class="dark-mode-toggle-top">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: var(--text-muted);">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/>
                        </svg>
                        <div class="toggle-switch" id="darkModeToggle"></div>
                    </div>
                    <div class="user-menu" id="userMenu">
                        <div class="user-avatar"><?php echo strtoupper(substr($admin_name, 0, 1)); ?></div>
                        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: var(--text-muted);">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                        </svg>
                        <div class="user-dropdown">
                            <div class="user-dropdown-item" style="pointer-events: none; border-bottom: 1px solid var(--border);">
                                <div>
                                    <div style="font-weight: 600; margin-bottom: 4px;"><?php echo htmlspecialchars($admin_name); ?></div>
                                    <div style="font-size: 12px; color: var(--text-muted);"><?php echo htmlspecialchars($admin_email); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Metrics Cards -->
            <div class="metrics-grid">
                <div class="metric-card">
                    <div class="metric-icon" style="background: rgba(59, 130, 246, 0.1);">
                        <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: #3b82f6;">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                        </svg>
                    </div>
                    <div class="metric-header">
                        <span class="metric-title">Total Emails</span>
                    </div>
                    <div class="metric-value"><?php echo number_format($total_emails); ?></div>
                </div>

                <div class="metric-card">
                    <div class="metric-icon" style="background: rgba(34, 197, 94, 0.1);">
                        <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: var(--success);">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                    </div>
                    <div class="metric-header">
                        <span class="metric-title">Sent</span>
                    </div>
                    <div class="metric-value"><?php echo number_format($sent_count); ?></div>
                </div>

                <div class="metric-card">
                    <div class="metric-icon" style="background: rgba(239, 68, 68, 0.1);">
                        <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: var(--danger);">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                        </svg>
                    </div>
                    <div class="metric-header">
                        <span class="metric-title">Failed</span>
                    </div>
                    <div class="metric-value"><?php echo number_format($failed_count); ?></div>
                </div>

                <div class="metric-card">
                    <div class="metric-icon" style="background: rgba(245, 158, 11, 0.1);">
                        <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: var(--warning);">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                    </div>
                    <div class="metric-header">
                        <span class="metric-title">Pending</span>
                    </div>
                    <div class="metric-value"><?php echo number_format($pending_count); ?></div>
                </div>
            </div>

            <!-- Incoming Emails Section - Gmail-like Split Layout -->
            <div style="margin-bottom: 32px;">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px;">
                    <h3 style="font-size: 18px; font-weight: 700; color: var(--text);">
                        Incoming Emails 
                        <?php if ($incoming_unread_count > 0): ?>
                            <span style="background: var(--accent-purple); color: white; padding: 2px 8px; border-radius: 12px; font-size: 12px; margin-left: 8px;">
                                <?php echo $incoming_unread_count; ?> unread
                            </span>
                        <?php endif; ?>
                    </h3>
                   
                </div>
                
                <div class="email-split-container">
                    <!-- Left Panel: Email List -->
                    <div class="email-list-panel">
                        <div class="email-list-header" style="padding: 12px 16px; border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between;">
                            <div style="display: flex; align-items: center; gap: 16px;">
                                <input type="checkbox" id="selectAllCheckbox" class="email-checkbox" style="margin: 0;" onchange="toggleSelectAll(this);">
                                <h4 style="font-size: 16px; font-weight: 600; color: var(--text); margin: 0;" id="emailListTitle">Inbox</h4>
                                <span style="font-size: 12px; color: var(--text-muted);" id="emailListCount"><?php echo count($incoming_emails); ?> emails</span>
                                <div id="bulkDeleteContainer" style="display: none; margin-left: 12px;">
                                    <button class="btn-primary" id="bulkDeleteBtn" style="padding: 6px 12px; font-size: 13px; background: var(--danger);" onclick="bulkDeleteEmails();">
                                        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="margin-right: 4px; vertical-align: middle;">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                                        </svg>
                                        Delete (<span id="selectedCount">0</span>)
                                    </button>
                                </div>
                            </div>
                            <div style="display: flex; align-items: center; gap: 12px;">
                                <button class="btn-primary" id="fetchEmailsBtn" style="padding: 8px 16px; font-size: 14px; background: var(--accent-purple);" onclick="manualFetchEmails();" title="Fetch new emails from Gmail">
                                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="margin-right: 4px; vertical-align: middle; display: inline-block;">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
                                    </svg>
                                    <span id="fetchEmailsBtnText">Refresh</span>
                                </button>
                                <button class="btn-primary" id="composeBtn" style="padding: 8px 16px; font-size: 14px;">Compose</button>
                            </div>
                        </div>
                        <div class="email-tabs">
                            <button class="email-tab active" data-tab="primary" onclick="switchEmailTab('primary')">Primary</button>
                            <button class="email-tab" data-tab="all" onclick="switchEmailTab('all')">Sent</button>
                            <button class="email-tab" data-tab="trash" onclick="switchEmailTab('trash')">Trash</button>
                        </div>
                        <div class="email-list-items" id="primaryEmailList">
                            <?php if (empty($incoming_emails)): ?>
                                <div style="text-align: center; padding: 60px 20px; color: var(--text-muted);">
                                    <svg width="64" height="64" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="margin: 0 auto 20px; opacity: 0.3;">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                                    </svg>
                                    <p style="font-size: 16px; font-weight: 600; margin-bottom: 8px;">No incoming emails found</p>
                                
                                </div>
                            <?php else: ?>
                                <?php foreach ($incoming_emails as $email): ?>
                                    <?php
                                    $initials = strtoupper(substr($email['from_name'], 0, 1));
                                    $is_unread = $email['read_status'] === 'unread';
                                    
                                    $time_ago = '';
                                    $timestamp = strtotime($email['created_at']);
                                    
                                    if ($timestamp) {
                                        $diff = time() - $timestamp;
                                        
                                        if ($diff < 60) {
                                            $time_ago = 'Just now';
                                        } elseif ($diff < 3600) {
                                            $minutes = floor($diff / 60);
                                            $time_ago = $minutes . ($minutes == 1 ? ' min ago' : ' min ago');
                                        } elseif ($diff < 86400) {
                                            $hours = floor($diff / 3600);
                                            if ($hours < 12) {
                                                $time_ago = date('g:i A', $timestamp);
                                            } else {
                                                $time_ago = date('g:i A', $timestamp);
                                            }
                                        } elseif ($diff < 604800) {
                                            $time_ago = date('M d', $timestamp);
                                        } else {
                                            $time_ago = date('M d, Y', $timestamp);
                                        }
                                    } else {
                                        $time_ago = date('M d, Y', strtotime($email['created_at']));
                                    }
                                    
                                    $preview = substr(strip_tags($email['message']), 0, 80);
                                    if (strlen($email['message']) > 80) {
                                        $preview .= '...';
                                    }
                                    $subject = htmlspecialchars($email['subject']);
                                    ?>
                                    <div class="email-list-item <?php echo $is_unread ? 'unread' : ''; ?>" data-email-id="<?php echo $email['id']; ?>" data-email-type="incoming" onclick="viewIncomingEmail(<?php echo $email['id']; ?>)">
                                        <input type="checkbox" class="email-checkbox email-item-checkbox" data-email-id="<?php echo $email['id']; ?>" data-email-type="incoming" onclick="event.stopPropagation();" onchange="updateBulkDeleteButton();">
                                        <div class="email-list-item-avatar"><?php echo $initials; ?></div>
                                        <div class="email-list-item-content">
                                            <div class="email-list-item-from"><?php echo htmlspecialchars($email['from_name']); ?></div>
                                            <div class="email-list-item-subject-preview">
                                                <span class="email-list-item-subject"><?php echo $subject ?: '(No Subject)'; ?></span>
                                                <span class="email-list-item-preview">- <?php echo htmlspecialchars($preview); ?></span>
                                            </div>
                                        </div>
                                        <div class="email-list-item-date"><?php echo $time_ago; ?></div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                        <div class="email-list-items" id="allEmailList" style="display: none;">
                            <?php if (empty($sent_emails)): ?>
                                <div style="text-align: center; padding: 60px 20px; color: var(--text-muted);">
                                    <svg width="64" height="64" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="margin: 0 auto 20px; opacity: 0.3;">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                                    </svg>
                                    <p style="font-size: 16px; font-weight: 600; margin-bottom: 8px;">No sent emails found</p>
                                    <p style="font-size: 14px;">Click "Compose" to send your first email.</p>
                                </div>
                            <?php else: ?>
                                <?php foreach ($sent_emails as $email): ?>
                                    <?php
                                    $initials = strtoupper(substr($email['recipient_name'], 0, 1));
                                    $status_class = '';
                                    if ($email['status'] === 'sent') {
                                        $status_class = 'tag-sent';
                                    } elseif ($email['status'] === 'failed') {
                                        $status_class = 'tag-important';
                                    } else {
                                        $status_class = 'tag-draft';
                                    }
                                    
                                    $time_ago = '';
                                    $display_date = $email['sent_at'] ? $email['sent_at'] : $email['created_at'];
                                    $timestamp = strtotime($display_date);
                                    
                                    if ($timestamp) {
                                        $diff = time() - $timestamp;
                                        
                                        if ($diff < 60) {
                                            $time_ago = 'Just now';
                                        } elseif ($diff < 3600) {
                                            $minutes = floor($diff / 60);
                                            $time_ago = $minutes . ($minutes == 1 ? ' min ago' : ' min ago');
                                        } elseif ($diff < 86400) {
                                            $hours = floor($diff / 3600);
                                            $time_ago = date('g:i A', $timestamp);
                                        } elseif ($diff < 604800) {
                                            $time_ago = date('M d', $timestamp);
                                        } else {
                                            $time_ago = date('M d, Y', $timestamp);
                                        }
                                    } else {
                                        $time_ago = date('M d, Y', strtotime($email['created_at']));
                                    }
                                    
                                    $preview = substr(strip_tags($email['message']), 0, 80);
                                    if (strlen($email['message']) > 80) {
                                        $preview .= '...';
                                    }
                                    $subject = htmlspecialchars($email['subject']);
                                    ?>
                                    <div class="email-list-item" data-email-id="<?php echo $email['id']; ?>" data-email-type="sent" onclick="viewEmail(<?php echo $email['id']; ?>)">
                                        <input type="checkbox" class="email-checkbox email-item-checkbox" data-email-id="<?php echo $email['id']; ?>" data-email-type="sent" onclick="event.stopPropagation();" onchange="updateBulkDeleteButton();">
                                        <div class="email-list-item-avatar"><?php echo $initials; ?></div>
                                        <div class="email-list-item-content">
                                            <div class="email-list-item-from"><?php echo htmlspecialchars($email['recipient_name']); ?></div>
                                            <div class="email-list-item-subject-preview">
                                                <span class="email-list-item-subject"><?php echo $subject ?: '(No Subject)'; ?></span>
                                                <span class="email-list-item-preview">- <?php echo htmlspecialchars($preview); ?></span>
                                            </div>
                                        </div>
                                        <div class="email-list-item-date"><?php echo $time_ago; ?></div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                        <div class="email-list-items" id="trashEmailList" style="display: none;">
                            <?php if (empty($trash_emails)): ?>
                                <div style="text-align: center; padding: 60px 20px; color: var(--text-muted);">
                                    <svg width="64" height="64" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="margin: 0 auto 20px; opacity: 0.3;">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                                    </svg>
                                    <p style="font-size: 16px; font-weight: 600; margin-bottom: 8px;">Trash is empty</p>
                                    <p style="font-size: 14px;">Deleted emails will appear here</p>
                                </div>
                            <?php else: ?>
                                <?php foreach ($trash_emails as $email): ?>
                                    <?php
                                    $initials = strtoupper(substr($email['from_name'], 0, 1));
                                    $is_unread = $email['read_status'] === 'unread';
                                    
                                    $time_ago = '';
                                    $timestamp = strtotime($email['updated_at']); // Use updated_at for when it was deleted
                                    
                                    if ($timestamp) {
                                        $diff = time() - $timestamp;
                                        
                                        if ($diff < 60) {
                                            $time_ago = 'Just now';
                                        } elseif ($diff < 3600) {
                                            $minutes = floor($diff / 60);
                                            $time_ago = $minutes . ($minutes == 1 ? ' min ago' : ' min ago');
                                        } elseif ($diff < 86400) {
                                            $hours = floor($diff / 3600);
                                            if ($hours < 12) {
                                                $time_ago = date('g:i A', $timestamp);
                                            } else {
                                                $time_ago = date('g:i A', $timestamp);
                                            }
                                        } elseif ($diff < 604800) {
                                            $time_ago = date('M d', $timestamp);
                                        } else {
                                            $time_ago = date('M d, Y', $timestamp);
                                        }
                                    } else {
                                        $time_ago = date('M d, Y', strtotime($email['updated_at']));
                                    }
                                    
                                    $preview = substr(strip_tags($email['message']), 0, 80);
                                    if (strlen($email['message']) > 80) {
                                        $preview .= '...';
                                    }
                                    $subject = htmlspecialchars($email['subject']);
                                    ?>
                                    <div class="email-list-item <?php echo $is_unread ? 'unread' : ''; ?>" data-email-id="<?php echo $email['id']; ?>" data-email-type="incoming" onclick="viewIncomingEmail(<?php echo $email['id']; ?>)">
                                        <input type="checkbox" class="email-checkbox email-item-checkbox" data-email-id="<?php echo $email['id']; ?>" data-email-type="incoming" onclick="event.stopPropagation();" onchange="updateBulkDeleteButton();">
                                        <div class="email-list-item-avatar"><?php echo $initials; ?></div>
                                        <div class="email-list-item-content">
                                            <div class="email-list-item-from"><?php echo htmlspecialchars($email['from_name']); ?></div>
                                            <div class="email-list-item-subject-preview">
                                                <span class="email-list-item-subject"><?php echo $subject ?: '(No Subject)'; ?></span>
                                                <span class="email-list-item-preview">- <?php echo htmlspecialchars($preview); ?></span>
                                            </div>
                                        </div>
                                        <div class="email-list-item-date"><?php echo $time_ago; ?></div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- Right Panel: Email Viewer -->
                    <div class="email-viewer-panel">
                        <div class="email-viewer-empty" id="emailViewerEmpty">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                            </svg>
                            <p style="font-size: 16px; font-weight: 600; margin-bottom: 8px;">Select an email to view</p>
                            <p style="font-size: 14px;">Click on any email from the list to read it</p>
                        </div>
                        <div id="emailViewer" style="display: none; flex-direction: column; flex: 1; overflow: hidden;">
                            <div class="email-viewer-header">
                                <div class="email-viewer-title-section">
                                    <h3 class="email-viewer-title" id="emailViewerTitle"></h3>
                                    <span class="email-viewer-label">
                                        Inbox
                                        <svg width="12" height="12" fill="none" stroke="currentColor" viewBox="0 0 24 24" onclick="event.stopPropagation(); document.getElementById('emailViewer').style.display='none'; document.getElementById('emailViewerEmpty').style.display='flex';">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                                        </svg>
                                    </span>
                                </div>
                                <div class="email-viewer-header-actions">
                                    <div class="email-viewer-header-icon" title="Expand/Collapse">
                                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 15l7-7 7 7"/>
                                        </svg>
                                    </div>
                                    <div class="email-viewer-header-icon" title="Print">
                                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/>
                                        </svg>
                                    </div>
                                    <div class="email-viewer-header-icon" title="Open in new window">
                                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                            <div class="email-viewer-content">
                                <div class="email-thread" id="emailThread"></div>
                            </div>
                            <div class="email-viewer-footer">
                                <button class="email-viewer-footer-btn email-viewer-footer-btn-primary" id="emailReplyBtn">
                                    <svg class="email-viewer-footer-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6"/>
                                    </svg>
                                    Reply
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </main>
    </div>

    <!-- Compose Email Modal -->
    <div class="modal-overlay" id="composeModal">
        <div class="compose-modal">
            <div class="compose-header">
                <h3 class="compose-title">Compose Email</h3>
                <button class="close-compose" id="closeComposeModal">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                    </svg>
                </button>
            </div>
            
            <?php if ($email_success): ?>
                <div class="alert alert-success">
                    <?php echo htmlspecialchars($email_success); ?>
                </div>
            <?php endif; ?>
            
            <?php if ($email_error): ?>
                <div class="alert alert-error">
                    <?php echo htmlspecialchars($email_error); ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="" id="composeForm">
                <div class="form-group">
                    <label class="form-label" for="recipient_email">To (Email Address) *</label>
                    <div class="email-autocomplete-container">
                        <input type="text" class="form-input" id="recipient_email" name="recipient_email" placeholder="Type email address or name..." autocomplete="off" required>
                        <div class="email-autocomplete-dropdown" id="emailAutocompleteDropdown"></div>
                    </div>
                    <input type="hidden" id="recipient_name" name="recipient_name">
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="subject">Subject *</label>
                    <input type="text" class="form-input" id="subject" name="subject" placeholder="Enter email subject" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="message">Message *</label>
                    <textarea class="form-textarea" id="message" name="message" placeholder="Enter your message here..." required></textarea>
                </div>
                
                <div class="form-actions">
                    <button type="button" class="btn-modal btn-modal-cancel" id="cancelCompose">Cancel</button>
                    <button type="submit" class="btn-send" name="send_email">Send Email</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Reply Email Modal -->
    <div class="modal-overlay" id="replyEmailModal">
        <div class="compose-modal">
            <div class="compose-header">
                <h3 class="compose-title">Reply to Email</h3>
                <button class="close-compose" id="closeReplyModal">
                    <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                    </svg>
                </button>
            </div>
            
            <?php if ($email_error && isset($_POST['reply_email'])): ?>
                <div class="alert alert-error">
                    <?php echo htmlspecialchars($email_error); ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="" id="replyEmailForm">
                <input type="hidden" id="incoming_email_id" name="incoming_email_id" value="">
                <div class="form-group">
                    <label class="form-label" for="reply_recipient_email">To (Email Address) *</label>
                    <input type="email" class="form-input" id="reply_recipient_email" name="recipient_email" placeholder="user@example.com" required readonly>
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="reply_recipient_name">To (Name)</label>
                    <input type="text" class="form-input" id="reply_recipient_name" name="recipient_name" placeholder="User Name" readonly>
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="reply_subject">Subject *</label>
                    <input type="text" class="form-input" id="reply_subject" name="subject" placeholder="Re: Email subject" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="reply_message">Message *</label>
                    <textarea class="form-textarea" id="reply_message" name="message" placeholder="Enter your reply message here..." required></textarea>
                </div>
                
                <div class="form-actions">
                    <button type="button" class="btn-modal btn-modal-cancel" id="cancelReply">Cancel</button>
                    <button type="submit" class="btn-send" name="reply_email">Send Reply</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Logout Confirmation Modal -->
    <div class="modal-overlay" id="logoutModal">
        <div class="logout-modal">
            <div class="modal-icon">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                </svg>
            </div>
            <div class="modal-header">
                <h3 class="modal-title">Confirm Logout</h3>
                <p class="modal-message">Are you sure you want to logout? You will need to login again to access the admin panel.</p>
            </div>
            <div class="modal-actions">
                <button class="btn-modal btn-modal-cancel" id="logoutCancelBtn">Cancel</button>
                <button class="btn-modal btn-modal-logout" id="logoutConfirmBtn">Logout</button>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div class="modal-overlay" id="deleteModal">
        <div class="delete-modal">
            <div class="delete-modal-icon">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                </svg>
            </div>
            <h3 class="delete-modal-title" id="deleteModalTitle">Delete Emails</h3>
            <p class="delete-modal-message" id="deleteModalMessage">Are you sure you want to delete these emails? This action cannot be undone.</p>
            <div class="delete-modal-actions">
                <button class="btn-modal btn-modal-cancel" id="deleteCancelBtn">Cancel</button>
                <button class="btn-modal-delete" id="deleteConfirmBtn">Delete</button>
            </div>
        </div>
    </div>

    <script>
        // Theme Management
        function initTheme() {
            const savedTheme = localStorage.getItem('admin-theme') || 'dark';
            const body = document.body;
            
            if (savedTheme === 'light') {
                body.classList.add('light-theme');
            } else {
                body.classList.remove('light-theme');
            }
            
            // Update toggle switch position
            updateToggleSwitch(savedTheme);
        }

        function updateToggleSwitch(theme) {
            const darkModeToggle = document.getElementById('darkModeToggle');
            if (darkModeToggle) {
                if (theme === 'light') {
                    darkModeToggle.classList.add('active');
                } else {
                    darkModeToggle.classList.remove('active');
                }
            }
        }

        function toggleTheme() {
            const body = document.body;
            const isLightTheme = body.classList.contains('light-theme');
            
            if (isLightTheme) {
                body.classList.remove('light-theme');
                localStorage.setItem('admin-theme', 'dark');
                updateToggleSwitch('dark');
            } else {
                body.classList.add('light-theme');
                localStorage.setItem('admin-theme', 'light');
                updateToggleSwitch('light');
            }
        }

        // Initialize theme on page load
        initTheme();

        // Toggle dark/light mode
        const darkModeToggle = document.getElementById('darkModeToggle');
        if (darkModeToggle) {
            darkModeToggle.addEventListener('click', function(e) {
                e.stopPropagation();
                toggleTheme();
            });
        }

        // User menu dropdown
        const userMenu = document.getElementById('userMenu');
        if (userMenu) {
            userMenu.addEventListener('click', function(e) {
                e.stopPropagation();
                this.classList.toggle('active');
            });

            // Close dropdown when clicking outside
            document.addEventListener('click', function(e) {
                if (!userMenu.contains(e.target)) {
                    userMenu.classList.remove('active');
                }
            });
        }

        // Logout Modal
        const logoutBtn = document.getElementById('logoutBtn');
        const logoutModal = document.getElementById('logoutModal');
        const logoutConfirmBtn = document.getElementById('logoutConfirmBtn');
        const logoutCancelBtn = document.getElementById('logoutCancelBtn');

        if (logoutBtn) {
            logoutBtn.addEventListener('click', function(e) {
                e.preventDefault();
                if (logoutModal) {
                    logoutModal.classList.add('active');
                    document.body.style.overflow = 'hidden';
                }
            });
        }

        if (logoutCancelBtn) {
            logoutCancelBtn.addEventListener('click', function() {
                if (logoutModal) {
                    logoutModal.classList.remove('active');
                    document.body.style.overflow = '';
                }
            });
        }

        if (logoutConfirmBtn) {
            logoutConfirmBtn.addEventListener('click', function() {
                window.location.href = '?logout=1';
            });
        }

        // Close modal when clicking outside
        if (logoutModal) {
            logoutModal.addEventListener('click', function(e) {
                if (e.target === logoutModal) {
                    logoutModal.classList.remove('active');
                    document.body.style.overflow = '';
                }
            });
        }

        // Delete Modal handlers
        const deleteModal = document.getElementById('deleteModal');
        const deleteConfirmBtn = document.getElementById('deleteConfirmBtn');
        const deleteCancelBtn = document.getElementById('deleteCancelBtn');

        if (deleteConfirmBtn) {
            deleteConfirmBtn.addEventListener('click', function() {
                confirmBulkDelete();
            });
        }

        if (deleteCancelBtn) {
            deleteCancelBtn.addEventListener('click', function() {
                closeDeleteModal();
            });
        }

        // Close delete modal when clicking outside
        if (deleteModal) {
            deleteModal.addEventListener('click', function(e) {
                if (e.target === deleteModal) {
                    closeDeleteModal();
                }
            });
        }

        // Close modal with Escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && logoutModal && logoutModal.classList.contains('active')) {
                logoutModal.classList.remove('active');
                document.body.style.overflow = '';
            }
            if (e.key === 'Escape' && deleteModal && deleteModal.classList.contains('active')) {
                closeDeleteModal();
            }
            if (e.key === 'Escape' && composeModal && composeModal.classList.contains('active')) {
                composeModal.classList.remove('active');
                document.body.style.overflow = '';
            }
            if (e.key === 'Escape' && addIncomingEmailModal && addIncomingEmailModal.classList.contains('active')) {
                addIncomingEmailModal.classList.remove('active');
                document.body.style.overflow = '';
            }
            if (e.key === 'Escape' && replyEmailModal && replyEmailModal.classList.contains('active')) {
                replyEmailModal.classList.remove('active');
                document.body.style.overflow = '';
            }
        });

        // Add Incoming Email Modal
        const addIncomingEmailBtn = document.getElementById('addIncomingEmailBtn');
        const addIncomingEmailModal = document.getElementById('addIncomingEmailModal');
        const closeAddIncomingModal = document.getElementById('closeAddIncomingModal');
        const cancelAddIncoming = document.getElementById('cancelAddIncoming');

        if (addIncomingEmailBtn) {
            addIncomingEmailBtn.addEventListener('click', function() {
                if (addIncomingEmailModal) {
                    addIncomingEmailModal.classList.add('active');
                    document.body.style.overflow = 'hidden';
                }
            });
        }

        if (closeAddIncomingModal) {
            closeAddIncomingModal.addEventListener('click', function() {
                if (addIncomingEmailModal) {
                    addIncomingEmailModal.classList.remove('active');
                    document.body.style.overflow = '';
                }
            });
        }

        if (cancelAddIncoming) {
            cancelAddIncoming.addEventListener('click', function() {
                if (addIncomingEmailModal) {
                    addIncomingEmailModal.classList.remove('active');
                    document.body.style.overflow = '';
                }
            });
        }

        // Close add incoming email modal when clicking outside
        if (addIncomingEmailModal) {
            addIncomingEmailModal.addEventListener('click', function(e) {
                if (e.target === addIncomingEmailModal) {
                    addIncomingEmailModal.classList.remove('active');
                    document.body.style.overflow = '';
                }
            });
        }

        // Toast Notification System
        function showToast(title, message, type = 'success', playSound = false) {
            const container = document.getElementById('toastContainer');
            if (!container) return;

            const toast = document.createElement('div');
            toast.className = `toast toast-${type}`;
            
            const icon = type === 'success' 
                ? '<svg class="toast-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: var(--success);"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>'
                : '<svg class="toast-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: var(--danger);"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>';
            
            toast.innerHTML = `
                ${icon}
                <div class="toast-content">
                    <div class="toast-title">${title}</div>
                    <div class="toast-message">${message}</div>
                </div>
                <button class="toast-close" onclick="this.parentElement.remove()">
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                    </svg>
                </button>
            `;
            
            container.appendChild(toast);
            
            // Play notification sound if requested (using Web Audio API for a simple beep)
            if (playSound && type === 'success') {
                try {
                    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
                    const oscillator = audioContext.createOscillator();
                    const gainNode = audioContext.createGain();
                    
                    oscillator.connect(gainNode);
                    gainNode.connect(audioContext.destination);
                    
                    oscillator.frequency.value = 800;
                    oscillator.type = 'sine';
                    
                    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
                    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
                    
                    oscillator.start(audioContext.currentTime);
                    oscillator.stop(audioContext.currentTime + 0.3);
                } catch (e) {
                    // Sound not supported or blocked, ignore
                    console.log('Sound notification not available');
                }
            }
            
            // Add a subtle pulse animation for new email notifications
            if (type === 'success' && playSound) {
                toast.style.animation = 'slideInRight 0.3s ease, pulse 0.5s ease 0.3s';
            }
            
            // Auto-remove after 5 seconds
            setTimeout(() => {
                if (toast.parentElement) {
                    toast.style.animation = 'fadeOut 0.3s ease forwards';
                    setTimeout(() => toast.remove(), 300);
                }
            }, 5000);
        }

        // Fetch Emails helpers
        const AUTO_FETCH_INTERVAL_MS = 30 * 1000; // 30 seconds (like Gmail)

        function runFetchEmails(isAuto = false) {
            const params = new URLSearchParams({ fetch_emails: '1' });
            if (isAuto) {
                params.set('auto', '1');
            }

            const url = window.location.pathname + '?' + params.toString();
            
            return fetch(url, {
                headers: { 'X-Requested-With': 'XMLHttpRequest' },
                credentials: 'same-origin'
            })
            .then(response => {
                if (!response.ok) {
                    return response.text().then(text => {
                        console.error('HTTP error response:', response.status, text.substring(0, 200));
                        throw new Error(`HTTP error! status: ${response.status}`);
                    });
                }
                const contentType = response.headers.get('content-type') || '';
                if (contentType.includes('application/json')) {
                    return response.json().catch(err => {
                        console.error('JSON parse error:', err);
                        return response.text().then(text => {
                            console.error('Response text:', text.substring(0, 500));
                            return {
                                success: false,
                                fetched: 0,
                                error: 'Invalid JSON response: ' + text.substring(0, 100)
                            };
                        });
                    });
                }
                // If not JSON, try to parse as text first to see what we got
                return response.text().then(text => {
                    console.error('Non-JSON response received. Content-Type:', contentType);
                    console.error('Response preview:', text.substring(0, 500));
                    return {
                        success: false,
                        fetched: 0,
                        error: 'Unexpected response format. Expected JSON but got: ' + contentType
                    };
                });
            })
            .then(data => {
                if (data) {
                    if (data.success && data.fetched > 0) {
                        // Show notification for new emails with sound
                        const emailText = data.fetched === 1 ? 'email' : 'emails';
                        showToast(
                            'New Email' + (data.fetched > 1 ? 's' : '') + ' Received!',
                            `You have ${data.fetched} new ${emailText} from your Gmail inbox.`,
                            'success',
                            true // Play sound notification
                        );
                        
                        // Update unread count badge if it exists
                        const unreadBadge = document.querySelector('.nav-badge');
                        if (unreadBadge) {
                            const currentCount = parseInt(unreadBadge.textContent) || 0;
                            const newCount = currentCount + data.fetched;
                            unreadBadge.textContent = newCount > 99 ? '99+' : newCount;
                            unreadBadge.style.display = 'flex';
                        }
                        
                        // Reload to show the new messages after a short delay
                        setTimeout(() => window.location.reload(), isAuto ? 1500 : 800);
                    } else if (data.error) {
                        // Show error notification for auto-fetch
                        if (isAuto && data.error) {
                            showToast(
                                'Email Fetch Error',
                                data.error,
                                'error'
                            );
                        }
                    }
                }
            })
            .catch(error => {
                console.error('Fetch Emails Error:', error);
                // Return a proper error object so the rest of the chain works
                return {
                    success: false,
                    fetched: 0,
                    error: error.message || 'Network error occurred'
                };
            });
        }

        // Manual fetch function with loading state
        function manualFetchEmails() {
            const fetchBtn = document.getElementById('fetchEmailsBtn');
            const fetchBtnText = document.getElementById('fetchEmailsBtnText');
            
            if (fetchBtn.disabled) {
                return; // Already fetching
            }
            
            // Disable button and show loading state
            fetchBtn.disabled = true;
            fetchBtn.style.opacity = '0.6';
            fetchBtn.style.cursor = 'not-allowed';
            fetchBtnText.textContent = 'Fetching...';
            
            // Show loading toast
            showToast(
                'Fetching Emails',
                'Loading messages from Gmail...',
                'info'
            );
            
            // Call fetch function with auto=1 to get JSON response
            runFetchEmails(true).then(data => {
                // Re-enable button
                fetchBtn.disabled = false;
                fetchBtn.style.opacity = '1';
                fetchBtn.style.cursor = 'pointer';
                fetchBtnText.textContent = 'Refresh';
                
                if (data) {
                    if (data.success) {
                        if (data.fetched > 0) {
                            showToast(
                                'Success!',
                                `Fetched ${data.fetched} new email${data.fetched > 1 ? 's' : ''} from Gmail.`,
                                'success',
                                true
                            );
                            // Reload page to show new emails
                            setTimeout(() => {
                                // Remove fetch_emails and auto parameters from URL before reloading
                                const url = new URL(window.location.href);
                                url.searchParams.delete('fetch_emails');
                                url.searchParams.delete('auto');
                                window.location.href = url.toString();
                            }, 1000);
                        } else {
                            showToast(
                                'No New Emails',
                                'All emails are up to date.',
                                'info'
                            );
                        }
                    } else if (data.error) {
                        showToast(
                            'Fetch Error',
                            data.error || 'Failed to fetch emails. Please check IMAP settings.',
                            'error'
                        );
                        console.error('Fetch error:', data.error);
                    }
                } else {
                    showToast(
                        'Fetch Error',
                        'No response from server. Please try again.',
                        'error'
                    );
                }
            }).catch(error => {
                // Re-enable button on error
                fetchBtn.disabled = false;
                fetchBtn.style.opacity = '1';
                fetchBtn.style.cursor = 'pointer';
                fetchBtnText.textContent = 'Refresh';
                
                showToast(
                    'Fetch Error',
                    error.message || 'Failed to fetch emails. Please check your connection and IMAP settings.',
                    'error'
                );
                console.error('Fetch error:', error);
            });
        }

        // Kick off automatic fetching immediately, then every 30 seconds
        setTimeout(() => runFetchEmails(true), 1000);

        setInterval(() => {
            if (!document.hidden) {
                runFetchEmails(true);
            }
        }, AUTO_FETCH_INTERVAL_MS);

        document.addEventListener('visibilitychange', () => {
            if (!document.hidden) {
                runFetchEmails(true);
            }
        });

        // Compose Email Modal
        const composeBtn = document.getElementById('composeBtn');
        const composeModal = document.getElementById('composeModal');
        const closeComposeModal = document.getElementById('closeComposeModal');
        const cancelCompose = document.getElementById('cancelCompose');
        const recipientEmail = document.getElementById('recipient_email');
        const recipientName = document.getElementById('recipient_name');
        const emailAutocompleteDropdown = document.getElementById('emailAutocompleteDropdown');

        // Store users data for autocomplete
        const usersData = <?php echo json_encode($users); ?>;

        // Email Autocomplete Functionality
        let selectedUser = null;
        let highlightedIndex = -1;

        function filterUsers(query) {
            if (!query || query.length < 1) {
                return [];
            }
            const lowerQuery = query.toLowerCase();
            return usersData.filter(user => {
                const name = (user.full_name || '').toLowerCase();
                const email = (user.email || '').toLowerCase();
                return name.includes(lowerQuery) || email.includes(lowerQuery);
            }).slice(0, 10); // Limit to 10 results
        }

        function renderAutocompleteSuggestions(users) {
            if (users.length === 0) {
                emailAutocompleteDropdown.classList.remove('show');
                return;
            }

            emailAutocompleteDropdown.innerHTML = users.map((user, index) => {
                const initials = (user.full_name || user.email || '').charAt(0).toUpperCase();
                const name = user.full_name || '';
                const email = user.email || '';
                return `
                    <div class="email-autocomplete-item" data-index="${index}" data-email="${email}" data-name="${name}">
                        <div class="email-autocomplete-avatar">${initials}</div>
                        <div class="email-autocomplete-info">
                            <div class="email-autocomplete-name">${name}</div>
                            <div class="email-autocomplete-email">${email}</div>
                        </div>
                    </div>
                `;
            }).join('');

            emailAutocompleteDropdown.classList.add('show');
            highlightedIndex = -1;
        }

        function selectUser(user) {
            if (user) {
                recipientEmail.value = user.email;
                recipientName.value = user.full_name || '';
                selectedUser = user;
                emailAutocompleteDropdown.classList.remove('show');
            }
        }

        function highlightSuggestion(index) {
            const items = emailAutocompleteDropdown.querySelectorAll('.email-autocomplete-item');
            items.forEach((item, i) => {
                item.classList.toggle('highlighted', i === index);
            });
        }

        // Handle input typing
        if (recipientEmail) {
            recipientEmail.addEventListener('input', function(e) {
                const query = e.target.value.trim();
                
                // Check if it's a valid email format (allows manual entry)
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (emailRegex.test(query)) {
                    // If it's a valid email, try to find matching user
                    const matchedUser = usersData.find(u => u.email.toLowerCase() === query.toLowerCase());
                    if (matchedUser) {
                        recipientName.value = matchedUser.full_name || '';
                        selectedUser = matchedUser;
                    } else {
                        // Valid email but not in users list - allow manual entry
                        recipientName.value = query.split('@')[0]; // Use email prefix as name
                        selectedUser = null;
                    }
                    emailAutocompleteDropdown.classList.remove('show');
                } else {
                    selectedUser = null;
                    recipientName.value = '';

                    if (query.length >= 1) {
                        const filteredUsers = filterUsers(query);
                        renderAutocompleteSuggestions(filteredUsers);
                    } else {
                        emailAutocompleteDropdown.classList.remove('show');
                    }
                }
            });

            recipientEmail.addEventListener('keydown', function(e) {
                const items = emailAutocompleteDropdown.querySelectorAll('.email-autocomplete-item');
                
                if (e.key === 'ArrowDown') {
                    e.preventDefault();
                    highlightedIndex = Math.min(highlightedIndex + 1, items.length - 1);
                    highlightSuggestion(highlightedIndex);
                } else if (e.key === 'ArrowUp') {
                    e.preventDefault();
                    highlightedIndex = Math.max(highlightedIndex - 1, -1);
                    highlightSuggestion(highlightedIndex);
                } else if (e.key === 'Enter' && highlightedIndex >= 0 && items[highlightedIndex]) {
                    e.preventDefault();
                    const item = items[highlightedIndex];
                    const email = item.dataset.email;
                    const name = item.dataset.name;
                    selectUser({ email, full_name: name });
                } else if (e.key === 'Escape') {
                    emailAutocompleteDropdown.classList.remove('show');
                }
            });

            // Handle click on suggestion
            emailAutocompleteDropdown.addEventListener('click', function(e) {
                const item = e.target.closest('.email-autocomplete-item');
                if (item) {
                    const email = item.dataset.email;
                    const name = item.dataset.name;
                    selectUser({ email, full_name: name });
                }
            });

            // Close dropdown when clicking outside
            document.addEventListener('click', function(e) {
                if (!recipientEmail.contains(e.target) && !emailAutocompleteDropdown.contains(e.target)) {
                    emailAutocompleteDropdown.classList.remove('show');
                }
            });
        }

        // Form validation
        const composeForm = document.getElementById('composeForm');
        if (composeForm) {
            composeForm.addEventListener('submit', function(e) {
                const emailValue = recipientEmail.value.trim();
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                
                if (!emailRegex.test(emailValue)) {
                    e.preventDefault();
                    alert('Please enter a valid email address.');
                    recipientEmail.focus();
                    return false;
                }
                
                // If no name was set, use email prefix
                if (!recipientName.value.trim()) {
                    recipientName.value = emailValue.split('@')[0];
                }
            });
        }

        // Open compose modal
        if (composeBtn) {
            composeBtn.addEventListener('click', function() {
                if (composeModal) {
                    composeModal.classList.add('active');
                    document.body.style.overflow = 'hidden';
                }
            });
        }

        // Function to reset autocomplete
        function resetAutocomplete() {
            if (emailAutocompleteDropdown) {
                emailAutocompleteDropdown.classList.remove('show');
                emailAutocompleteDropdown.innerHTML = '';
            }
            highlightedIndex = -1;
            selectedUser = null;
        }

        // Close compose modal
        if (closeComposeModal) {
            closeComposeModal.addEventListener('click', function() {
                if (composeModal) {
                    composeModal.classList.remove('active');
                    document.body.style.overflow = '';
                    resetAutocomplete();
                }
            });
        }

        if (cancelCompose) {
            cancelCompose.addEventListener('click', function() {
                if (composeModal) {
                    composeModal.classList.remove('active');
                    document.body.style.overflow = '';
                    resetAutocomplete();
                }
            });
        }

        // Close compose modal when clicking outside
        if (composeModal) {
            composeModal.addEventListener('click', function(e) {
                if (e.target === composeModal) {
                    composeModal.classList.remove('active');
                    document.body.style.overflow = '';
                    resetAutocomplete();
                }
            });
        }

        // Auto-close success message after 5 seconds
        <?php if ($email_success): ?>
        setTimeout(function() {
            const successAlert = document.querySelector('.alert-success');
            if (successAlert) {
                successAlert.style.transition = 'opacity 0.3s';
                successAlert.style.opacity = '0';
                setTimeout(function() {
                    successAlert.remove();
                }, 300);
            }
        }, 5000);
        <?php endif; ?>

        // View Email Function (for sent emails)
        function viewEmail(emailId) {
            // Update active state in list
            document.querySelectorAll('.email-list-item').forEach(item => {
                item.classList.remove('active');
            });
            const listItem = document.querySelector(`.email-list-item[data-email-id="${emailId}"]`);
            if (listItem) {
                listItem.classList.add('active');
            }
            
            // Show loading state
            const viewerEmpty = document.getElementById('emailViewerEmpty');
            const viewer = document.getElementById('emailViewer');
            viewerEmpty.style.display = 'none';
            viewer.style.display = 'flex';
            viewer.style.flexDirection = 'column';
            document.getElementById('emailViewerTitle').textContent = 'Loading...';
            document.getElementById('emailThread').innerHTML = '<div style="padding: 40px; text-align: center; color: var(--text-muted);">Loading email...</div>';
            
            // Fetch email details via AJAX
            fetch('get_sent_email.php?id=' + emailId)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const email = data.email;
                        
                        // Update viewer title
                        document.getElementById('emailViewerTitle').textContent = email.subject || '(No Subject)';
                        
                        // Format date - use sent_at if available, otherwise created_at
                        const displayDate = email.sent_at || email.created_at;
                        const emailDate = new Date(displayDate);
                        const now = new Date();
                        const diffTime = Math.abs(now - emailDate);
                        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                        
                        let formattedDate = '';
                        if (diffDays === 1) {
                            formattedDate = 'Yesterday, ' + emailDate.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
                        } else if (diffDays < 7) {
                            const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
                            const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                            formattedDate = `${days[emailDate.getDay()]}, ${months[emailDate.getMonth()]} ${emailDate.getDate()}, ${emailDate.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })} (${diffDays} days ago)`;
                        } else {
                            const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                            formattedDate = `${months[emailDate.getMonth()]} ${emailDate.getDate()}, ${emailDate.getFullYear()}`;
                        }
                        
                        // Get recipient initials
                        const recipientInitials = email.recipient_name ? email.recipient_name.charAt(0).toUpperCase() : email.recipient_email.charAt(0).toUpperCase();
                        
                        // Clean and display email content
                        let emailContent = email.message.replace(/\n/g, '<br>');
                        
                        // Remove inline styles that cause white backgrounds
                        emailContent = emailContent.replace(/style="[^"]*background[^"]*white[^"]*"/gi, '');
                        emailContent = emailContent.replace(/style="[^"]*background[^"]*#fff[^"]*"/gi, '');
                        emailContent = emailContent.replace(/style="[^"]*background[^"]*#ffffff[^"]*"/gi, '');
                        emailContent = emailContent.replace(/style="[^"]*background-color[^"]*white[^"]*"/gi, '');
                        emailContent = emailContent.replace(/style="[^"]*background-color[^"]*#fff[^"]*"/gi, '');
                        emailContent = emailContent.replace(/style="[^"]*background-color[^"]*#ffffff[^"]*"/gi, '');
                        
                        // Get status badge
                        let statusBadge = '';
                        if (email.status === 'sent') {
                            statusBadge = '<span class="status-badge status-read" style="margin-left: 8px;">Sent</span>';
                        } else if (email.status === 'failed') {
                            statusBadge = '<span class="status-badge status-declined" style="margin-left: 8px;">Failed</span>';
                        } else if (email.status === 'pending') {
                            statusBadge = '<span class="status-badge status-processing" style="margin-left: 8px;">Pending</span>';
                        }
                        
                        // Helper function to format date
                        function formatEmailDate(dateString) {
                            const emailDate = new Date(dateString);
                            const now = new Date();
                            const diffTime = Math.abs(now - emailDate);
                            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                            
                            if (diffDays === 1) {
                                return 'Yesterday, ' + emailDate.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
                            } else if (diffDays < 7) {
                                const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
                                const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                                return `${days[emailDate.getDay()]}, ${months[emailDate.getMonth()]} ${emailDate.getDate()}, ${emailDate.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })} (${diffDays} days ago)`;
                            } else {
                                const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                                return `${months[emailDate.getMonth()]} ${emailDate.getDate()}, ${emailDate.getFullYear()}`;
                            }
                        }
                        
                        // Helper function to clean email content
                        function cleanEmailContent(content) {
                            if (!content) return '';
                            let cleaned = content.replace(/\n/g, '<br>');
                            cleaned = cleaned.replace(/style="[^"]*background[^"]*white[^"]*"/gi, '');
                            cleaned = cleaned.replace(/style="[^"]*background[^"]*#fff[^"]*"/gi, '');
                            cleaned = cleaned.replace(/style="[^"]*background[^"]*#ffffff[^"]*"/gi, '');
                            cleaned = cleaned.replace(/style="[^"]*background-color[^"]*white[^"]*"/gi, '');
                            cleaned = cleaned.replace(/style="[^"]*background-color[^"]*#fff[^"]*"/gi, '');
                            cleaned = cleaned.replace(/style="[^"]*background-color[^"]*#ffffff[^"]*"/gi, '');
                            return cleaned;
                        }
                        
                        // Create thread item HTML for sent email
                        let threadHTML = `
                            <div class="email-thread-item">
                                <div class="email-thread-item-header">
                                    <div class="email-thread-avatar">${recipientInitials}</div>
                                    <div class="email-thread-info">
                                        <div class="email-thread-sender-row">
                                            <span class="email-thread-sender">${email.recipient_name || email.recipient_email}</span>
                                            <span class="email-thread-to">
                                                ${email.recipient_email}
                                                <svg class="email-thread-to-arrow" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                                                </svg>
                                            </span>
                                            ${statusBadge}
                                        </div>
                                        <div class="email-thread-date-row">
                                            <span class="email-thread-date">${formattedDate}</span>
                                            <div class="email-thread-actions">
                                                <svg class="email-thread-action-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" onclick="deleteEmail(${email.id});" title="Delete">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="email-thread-body">${emailContent}</div>
                            </div>
                        `;
                        
                        // Add replies if any
                        if (data.replies && data.replies.length > 0) {
                            data.replies.forEach(reply => {
                                const replyInitials = reply.from_name ? reply.from_name.charAt(0).toUpperCase() : reply.from_email.charAt(0).toUpperCase();
                                const replyDate = formatEmailDate(reply.created_at);
                                const replyContent = cleanEmailContent(reply.message_html || reply.message);
                                const isUnread = reply.read_status === 'unread';
                                
                                threadHTML += `
                                    <div class="email-thread-item" ${isUnread ? 'style="background: var(--accent-purple-light);"' : ''}>
                                        <div class="email-thread-item-header">
                                            <div class="email-thread-avatar">${replyInitials}</div>
                                            <div class="email-thread-info">
                                                <div class="email-thread-sender-row">
                                                    <span class="email-thread-sender">${reply.from_name || reply.from_email}</span>
                                                    <span class="email-thread-to">
                                                        to me
                                                        <svg class="email-thread-to-arrow" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                                                        </svg>
                                                    </span>
                                                    ${isUnread ? '<span class="status-badge status-unread" style="margin-left: 8px;">Unread</span>' : ''}
                                                </div>
                                                <div class="email-thread-date-row">
                                                    <span class="email-thread-date">${replyDate}</span>
                                                    <div class="email-thread-actions">
                                                        <svg class="email-thread-action-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" onclick="replyToEmail(${reply.id}, '${(reply.from_email || '').replace(/'/g, "\\'")}', '${(reply.from_name || '').replace(/'/g, "\\'")}', '${(reply.subject || '').replace(/'/g, "\\'")}');">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6"/>
                                                        </svg>
                                                        <svg class="email-thread-action-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" onclick="deleteIncomingEmail(${reply.id});" title="Delete">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="email-thread-body">${replyContent}</div>
                                    </div>
                                `;
                            });
                        }
                        
                        document.getElementById('emailThread').innerHTML = threadHTML;
                        
                        // Update viewer label to "Sent"
                        const viewerLabel = document.querySelector('.email-viewer-label');
                        if (viewerLabel) {
                            viewerLabel.innerHTML = 'Sent <svg width="12" height="12" fill="none" stroke="currentColor" viewBox="0 0 24 24" onclick="event.stopPropagation(); document.getElementById(\'emailViewer\').style.display=\'none\'; document.getElementById(\'emailViewerEmpty\').style.display=\'flex\';"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>';
                        }
                        
                        // Update footer buttons - show reply if there are replies
                        const replyBtn = document.getElementById('emailReplyBtn');
                        if (replyBtn) {
                            if (data.replies && data.replies.length > 0) {
                                // Show reply button to reply to the latest reply
                                const latestReply = data.replies[data.replies.length - 1];
                                replyBtn.style.display = 'flex';
                                replyBtn.onclick = () => replyToEmail(
                                    latestReply.id, 
                                    latestReply.from_email, 
                                    latestReply.from_name, 
                                    latestReply.subject || ''
                                );
                            } else {
                                replyBtn.style.display = 'none';
                            }
                        }
                    } else {
                        document.getElementById('emailThread').innerHTML = '<div style="padding: 40px; text-align: center; color: var(--danger);">Failed to load email details.</div>';
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    document.getElementById('emailThread').innerHTML = '<div style="padding: 40px; text-align: center; color: var(--danger);">Failed to load email details.</div>';
                });
        }

        // Delete Email Function
        function deleteEmail(emailId) {
            if (confirm('Are you sure you want to delete this email record?')) {
                window.location.href = '?delete_email=' + emailId;
            }
        }

        // View Incoming Email Function - Gmail-like conversation thread
        function viewIncomingEmail(emailId) {
            // Update active state in list
            document.querySelectorAll('.email-list-item').forEach(item => {
                item.classList.remove('active');
            });
            const listItem = document.querySelector(`.email-list-item[data-email-id="${emailId}"]`);
            if (listItem) {
                listItem.classList.add('active');
            }
            
            // Show loading state
            const viewerEmpty = document.getElementById('emailViewerEmpty');
            const viewer = document.getElementById('emailViewer');
            viewerEmpty.style.display = 'none';
            viewer.style.display = 'flex';
            viewer.style.flexDirection = 'column';
            document.getElementById('emailViewerTitle').textContent = 'Loading...';
            document.getElementById('emailThread').innerHTML = '<div style="padding: 40px; text-align: center; color: var(--text-muted);">Loading email...</div>';
            
            // Fetch email details via AJAX
            fetch('get_incoming_email.php?id=' + emailId)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const email = data.email;
                        
                        // Update viewer title
                        document.getElementById('emailViewerTitle').textContent = email.subject || '(No Subject)';
                        
                        // Format date
                        const emailDate = new Date(email.created_at);
                        const now = new Date();
                        const diffTime = Math.abs(now - emailDate);
                        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                        
                        let formattedDate = '';
                        if (diffDays === 1) {
                            formattedDate = 'Yesterday, ' + emailDate.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
                        } else if (diffDays < 7) {
                            const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
                            const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                            formattedDate = `${days[emailDate.getDay()]}, ${months[emailDate.getMonth()]} ${emailDate.getDate()}, ${emailDate.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })} (${diffDays} days ago)`;
                        } else {
                            const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                            formattedDate = `${months[emailDate.getMonth()]} ${emailDate.getDate()}, ${emailDate.getFullYear()}`;
                        }
                        
                        // Get sender initials
                        const senderInitials = email.from_name ? email.from_name.charAt(0).toUpperCase() : email.from_email.charAt(0).toUpperCase();
                        
                        // Clean and display email content
                        let emailContent = email.message_html || email.message.replace(/\n/g, '<br>');
                        
                        // Remove inline styles that cause white backgrounds
                        emailContent = emailContent.replace(/style="[^"]*background[^"]*white[^"]*"/gi, '');
                        emailContent = emailContent.replace(/style="[^"]*background[^"]*#fff[^"]*"/gi, '');
                        emailContent = emailContent.replace(/style="[^"]*background[^"]*#ffffff[^"]*"/gi, '');
                        emailContent = emailContent.replace(/style="[^"]*background-color[^"]*white[^"]*"/gi, '');
                        emailContent = emailContent.replace(/style="[^"]*background-color[^"]*#fff[^"]*"/gi, '');
                        emailContent = emailContent.replace(/style="[^"]*background-color[^"]*#ffffff[^"]*"/gi, '');
                        
                        // Create thread item HTML
                        const threadHTML = `
                            <div class="email-thread-item">
                                <div class="email-thread-item-header">
                                    <div class="email-thread-avatar">${senderInitials}</div>
                                    <div class="email-thread-info">
                                        <div class="email-thread-sender-row">
                                            <span class="email-thread-sender">${email.from_name || email.from_email}</span>
                                            <span class="email-thread-to">
                                                to me
                                                <svg class="email-thread-to-arrow" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                                                </svg>
                                            </span>
                                        </div>
                                        <div class="email-thread-date-row">
                                            <span class="email-thread-date">${formattedDate}</span>
                                            <div class="email-thread-actions">
                                                <svg class="email-thread-action-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" onclick="replyToEmail(${email.id}, '${email.from_email.replace(/'/g, "\\'")}', '${email.from_name.replace(/'/g, "\\'")}', '${(email.subject || '').replace(/'/g, "\\'")}');">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6"/>
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="email-thread-body">${emailContent}</div>
                            </div>
                        `;
                        
                        document.getElementById('emailThread').innerHTML = threadHTML;
                        
                        // Update viewer label to "Inbox"
                        const viewerLabel = document.querySelector('.email-viewer-label');
                        if (viewerLabel) {
                            viewerLabel.innerHTML = 'Inbox <svg width="12" height="12" fill="none" stroke="currentColor" viewBox="0 0 24 24" onclick="event.stopPropagation(); document.getElementById(\'emailViewer\').style.display=\'none\'; document.getElementById(\'emailViewerEmpty\').style.display=\'flex\';"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>';
                        }
                        
                        // Update footer reply button - show for incoming emails
                        const replyBtn = document.getElementById('emailReplyBtn');
                        if (replyBtn) {
                            replyBtn.style.display = 'flex';
                            replyBtn.onclick = () => replyToEmail(email.id, email.from_email, email.from_name, email.subject || '');
                        }
                        
                        // Update UI to reflect read status (email is already marked as read by get_incoming_email.php)
                        // Check if the list item was marked as unread before opening
                        const wasUnread = listItem && listItem.classList.contains('unread');
                        
                        // Always update list item styling to remove unread styling
                        if (listItem) {
                            listItem.classList.remove('unread');
                            listItem.style.fontWeight = 'normal';
                            
                            // Also update the visual indicator in the list
                            const unreadIndicator = listItem.querySelector('.unread-indicator');
                            if (unreadIndicator) {
                                unreadIndicator.style.display = 'none';
                            }
                        }
                        
                        // Update badge count if email was unread
                        if (wasUnread) {
                            // Update navigation badge
                            const badge = document.querySelector('.nav-badge');
                            if (badge) {
                                const currentCount = parseInt(badge.textContent) || 0;
                                if (currentCount > 0) {
                                    const newCount = currentCount - 1;
                                    badge.textContent = newCount > 0 ? (newCount > 99 ? '99+' : newCount) : '';
                                    if (newCount === 0) {
                                        badge.style.display = 'none';
                                    }
                                }
                            }
                            
                            // Update the unread count in the "Incoming Emails" header
                            const incomingHeader = document.querySelector('h3');
                            if (incomingHeader) {
                                const unreadCountSpan = incomingHeader.querySelector('span[style*="background"]');
                                if (unreadCountSpan) {
                                    const currentUnread = parseInt(unreadCountSpan.textContent.trim()) || 0;
                                    if (currentUnread > 0) {
                                        const newUnread = currentUnread - 1;
                                        if (newUnread > 0) {
                                            unreadCountSpan.textContent = newUnread + ' unread';
                                        } else {
                                            unreadCountSpan.remove();
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        document.getElementById('emailThread').innerHTML = '<div style="padding: 40px; text-align: center; color: var(--danger);">Failed to load email details.</div>';
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    document.getElementById('emailThread').innerHTML = '<div style="padding: 40px; text-align: center; color: var(--danger);">Failed to load email details.</div>';
                });
        }

        // Toggle Star Function
        function toggleStar(emailId, starElement) {
            starElement.classList.toggle('starred');
            // You can add AJAX call here to save star status to database
            // For now, just toggles visually
        }

        // Get currently visible email list container
        function getVisibleEmailList() {
            const primaryList = document.getElementById('primaryEmailList');
            const allList = document.getElementById('allEmailList');
            const trashList = document.getElementById('trashEmailList');
            
            // Check which tab is active
            const activeTab = document.querySelector('.email-tab.active');
            if (activeTab) {
                const tabName = activeTab.getAttribute('data-tab');
                if (tabName === 'primary' && primaryList) {
                    return primaryList;
                } else if (tabName === 'all' && allList) {
                    return allList;
                } else if (tabName === 'trash' && trashList) {
                    return trashList;
                }
            }
            
            // Fallback: check display style
            if (primaryList && primaryList.style.display !== 'none' && window.getComputedStyle(primaryList).display !== 'none') {
                return primaryList;
            } else if (allList && allList.style.display !== 'none' && window.getComputedStyle(allList).display !== 'none') {
                return allList;
            } else if (trashList && trashList.style.display !== 'none' && window.getComputedStyle(trashList).display !== 'none') {
                return trashList;
            }
            // Default to primary if none are visible
            return primaryList || allList || trashList;
        }

        // Toggle Select All Function
        function toggleSelectAll(selectAllCheckbox) {
            const visibleList = getVisibleEmailList();
            if (!visibleList) return;
            
            const checkboxes = visibleList.querySelectorAll('.email-item-checkbox');
            checkboxes.forEach(checkbox => {
                checkbox.checked = selectAllCheckbox.checked;
            });
            updateBulkDeleteButton();
        }

        // Update Bulk Delete Button
        function updateBulkDeleteButton() {
            const visibleList = getVisibleEmailList();
            if (!visibleList) return;
            
            const checkboxes = visibleList.querySelectorAll('.email-item-checkbox');
            const checkedCheckboxes = visibleList.querySelectorAll('.email-item-checkbox:checked');
            const bulkDeleteContainer = document.getElementById('bulkDeleteContainer');
            const selectedCount = document.getElementById('selectedCount');
            const selectAllCheckbox = document.getElementById('selectAllCheckbox');
            
            const checkedCount = checkedCheckboxes.length;
            const totalCheckboxes = checkboxes.length;
            
            // Update row highlighting (only for visible list)
            checkboxes.forEach(checkbox => {
                const listItem = checkbox.closest('.email-list-item');
                if (listItem) {
                    if (checkbox.checked) {
                        listItem.classList.add('selected');
                    } else {
                        listItem.classList.remove('selected');
                    }
                }
            });
            
            // Update select all checkbox state
            if (selectAllCheckbox) {
                if (checkedCount === 0) {
                    selectAllCheckbox.checked = false;
                    selectAllCheckbox.indeterminate = false;
                } else if (checkedCount === totalCheckboxes && totalCheckboxes > 0) {
                    selectAllCheckbox.checked = true;
                    selectAllCheckbox.indeterminate = false;
                } else {
                    selectAllCheckbox.checked = false;
                    selectAllCheckbox.indeterminate = true;
                }
            }
            
            // Show/hide bulk delete button
            if (bulkDeleteContainer && selectedCount) {
                if (checkedCount > 0) {
                    bulkDeleteContainer.style.display = 'block';
                    selectedCount.textContent = checkedCount;
                } else {
                    bulkDeleteContainer.style.display = 'none';
                }
            }
        }

        // Bulk Delete Emails Function - Show Modal
        function bulkDeleteEmails() {
            const visibleList = getVisibleEmailList();
            if (!visibleList) return;
            
            const checkboxes = visibleList.querySelectorAll('.email-item-checkbox:checked');
            const selectedEmails = Array.from(checkboxes).map(cb => ({
                id: cb.dataset.emailId,
                type: cb.dataset.emailType
            }));
            
            if (selectedEmails.length === 0) {
                return;
            }
            
            // Store selected emails for deletion
            window.selectedEmailsForDeletion = selectedEmails;
            
            // Show delete modal
            const deleteModal = document.getElementById('deleteModal');
            const deleteModalTitle = document.getElementById('deleteModalTitle');
            const deleteModalMessage = document.getElementById('deleteModalMessage');
            
            const emailText = selectedEmails.length === 1 ? 'email' : 'emails';
            deleteModalTitle.textContent = `Delete ${selectedEmails.length} ${emailText}?`;
            deleteModalMessage.textContent = `Are you sure you want to delete ${selectedEmails.length} ${emailText}? This action cannot be undone.`;
            
            if (deleteModal) {
                deleteModal.classList.add('active');
                document.body.style.overflow = 'hidden';
            }
        }

        // Confirm Bulk Delete - Actually perform deletion
        function confirmBulkDelete() {
            const selectedEmails = window.selectedEmailsForDeletion || [];
            
            if (selectedEmails.length === 0) {
                closeDeleteModal();
                return;
            }
            
            // Delete emails
            let deletePromises = [];
            selectedEmails.forEach(email => {
                if (email.type === 'incoming') {
                    deletePromises.push(fetch(`?delete_incoming_email=${email.id}`));
                } else if (email.type === 'sent') {
                    deletePromises.push(fetch(`?delete_email=${email.id}`));
                }
            });
            
            // Wait for all deletions to complete
            Promise.all(deletePromises)
                .then(() => {
                    // Reload page to show updated list
                    window.location.reload();
                })
                .catch(error => {
                    console.error('Error deleting emails:', error);
                    closeDeleteModal();
                    alert('Some emails could not be deleted. Please try again.');
                });
        }

        // Close Delete Modal
        function closeDeleteModal() {
            const deleteModal = document.getElementById('deleteModal');
            if (deleteModal) {
                deleteModal.classList.remove('active');
                document.body.style.overflow = '';
            }
            window.selectedEmailsForDeletion = null;
        }

        // Switch Email Tab Function
        function switchEmailTab(tab) {
            const primaryList = document.getElementById('primaryEmailList');
            const allList = document.getElementById('allEmailList');
            const tabs = document.querySelectorAll('.email-tab');
            const title = document.getElementById('emailListTitle');
            const count = document.getElementById('emailListCount');
            
            // Update tab active state
            tabs.forEach(t => t.classList.remove('active'));
            document.querySelector(`[data-tab="${tab}"]`).classList.add('active');
            
            const trashList = document.getElementById('trashEmailList');
            const bulkDeleteContainer = document.getElementById('bulkDeleteContainer');
            const fetchEmailsBtn = document.getElementById('fetchEmailsBtn');
            const composeBtn = document.getElementById('composeBtn');
            
            // Show/hide email lists
            if (tab === 'primary') {
                primaryList.style.display = 'block';
                allList.style.display = 'none';
                if (trashList) trashList.style.display = 'none';
                title.textContent = 'Inbox';
                count.textContent = '<?php echo count($incoming_emails); ?> emails';
                if (bulkDeleteContainer) bulkDeleteContainer.style.display = 'none';
                if (fetchEmailsBtn) fetchEmailsBtn.style.display = 'inline-flex';
                if (composeBtn) composeBtn.style.display = 'inline-flex';
            } else if (tab === 'all') {
                primaryList.style.display = 'none';
                allList.style.display = 'block';
                if (trashList) trashList.style.display = 'none';
                title.textContent = 'Sent Emails';
                count.textContent = '<?php echo count($sent_emails); ?> emails';
                if (bulkDeleteContainer) bulkDeleteContainer.style.display = 'none';
                if (fetchEmailsBtn) fetchEmailsBtn.style.display = 'inline-flex';
                if (composeBtn) composeBtn.style.display = 'inline-flex';
            } else if (tab === 'trash') {
                primaryList.style.display = 'none';
                allList.style.display = 'none';
                if (trashList) trashList.style.display = 'block';
                title.textContent = 'Trash';
                count.textContent = '<?php echo count($trash_emails); ?> emails';
                if (bulkDeleteContainer) bulkDeleteContainer.style.display = 'none';
                if (fetchEmailsBtn) fetchEmailsBtn.style.display = 'none';
                if (composeBtn) composeBtn.style.display = 'none';
            }
            
            // Reset checkboxes and bulk delete button
            const selectAllCheckbox = document.getElementById('selectAllCheckbox');
            const checkboxes = document.querySelectorAll('.email-item-checkbox');
            checkboxes.forEach(cb => cb.checked = false);
            if (selectAllCheckbox) {
                selectAllCheckbox.checked = false;
                selectAllCheckbox.indeterminate = false;
            }
            updateBulkDeleteButton();
            
            // Clear email viewer when switching tabs
            const viewerEmpty = document.getElementById('emailViewerEmpty');
            const viewer = document.getElementById('emailViewer');
            if (viewerEmpty && viewer) {
                viewerEmpty.style.display = 'flex';
                viewer.style.display = 'none';
            }
            
            // Restore reply button visibility
            const replyBtn = document.getElementById('emailReplyBtn');
            if (replyBtn) {
                replyBtn.style.display = 'flex';
            }
            
            // Reset viewer label
            const viewerLabel = document.querySelector('.email-viewer-label');
            if (viewerLabel) {
                viewerLabel.innerHTML = 'Inbox <svg width="12" height="12" fill="none" stroke="currentColor" viewBox="0 0 24 24" onclick="event.stopPropagation(); document.getElementById(\'emailViewer\').style.display=\'none\'; document.getElementById(\'emailViewerEmpty\').style.display=\'flex\';"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>';
            }
        }

        // Toggle Read Status Function
        function toggleReadStatus(emailId) {
            window.location.href = '?toggle_read=' + emailId;
        }

        // Delete Incoming Email Function
        function deleteIncomingEmail(emailId) {
            if (confirm('Are you sure you want to delete this incoming email?')) {
                window.location.href = '?delete_incoming_email=' + emailId;
            }
        }

        // Reply to Email Function
        function replyToEmail(emailId, fromEmail, fromName, originalSubject) {
            const replyModal = document.getElementById('replyEmailModal');
            const incomingEmailId = document.getElementById('incoming_email_id');
            const recipientEmail = document.getElementById('reply_recipient_email');
            const recipientName = document.getElementById('reply_recipient_name');
            const subject = document.getElementById('reply_subject');
            
            if (replyModal && incomingEmailId && recipientEmail && recipientName && subject) {
                // Set form values
                incomingEmailId.value = emailId;
                recipientEmail.value = fromEmail;
                recipientName.value = fromName || fromEmail;
                
                // Set subject with "Re:" prefix if not already present
                if (originalSubject && !originalSubject.toLowerCase().startsWith('re:')) {
                    subject.value = 'Re: ' + originalSubject;
                } else {
                    subject.value = originalSubject || '';
                }
                
                // Clear message
                document.getElementById('reply_message').value = '';
                
                // Show modal
                replyModal.classList.add('active');
                document.body.style.overflow = 'hidden';
            }
        }

        // Reply Modal handlers
        const replyEmailModal = document.getElementById('replyEmailModal');
        const closeReplyModal = document.getElementById('closeReplyModal');
        const cancelReply = document.getElementById('cancelReply');

        if (closeReplyModal) {
            closeReplyModal.addEventListener('click', function() {
                if (replyEmailModal) {
                    replyEmailModal.classList.remove('active');
                    document.body.style.overflow = '';
                }
            });
        }

        if (cancelReply) {
            cancelReply.addEventListener('click', function() {
                if (replyEmailModal) {
                    replyEmailModal.classList.remove('active');
                    document.body.style.overflow = '';
                }
            });
        }

        // Close reply modal when clicking outside
        if (replyEmailModal) {
            replyEmailModal.addEventListener('click', function(e) {
                if (e.target === replyEmailModal) {
                    replyEmailModal.classList.remove('active');
                    document.body.style.overflow = '';
                }
            });
        }

        // Real-time clock
        function updateClock() {
            const clockElement = document.getElementById('realtimeClock');
            if (clockElement) {
                const now = new Date();
                let hours = now.getHours();
                const minutes = String(now.getMinutes()).padStart(2, '0');
                const seconds = String(now.getSeconds()).padStart(2, '0');
                const ampm = hours >= 12 ? 'PM' : 'AM';
                hours = hours % 12;
                hours = hours ? hours : 12; // the hour '0' should be '12'
                hours = String(hours).padStart(2, '0');
                clockElement.textContent = `${hours}:${minutes}:${seconds} ${ampm}`;
            }
        }

        // Update clock immediately and then every second
        updateClock();
        setInterval(updateClock, 1000);
    </script>
</body>
</html>


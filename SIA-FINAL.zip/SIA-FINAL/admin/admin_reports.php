<?php
session_start();
require_once '../config.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../phpmailer/src/Exception.php';
require '../phpmailer/src/PHPMailer.php';
require '../phpmailer/src/SMTP.php';

// Handle logout
if (isset($_GET['logout'])) {
    session_unset();
    session_destroy();
    header("Location: admin_login.php");
    exit();
}

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

$admin_name = $_SESSION['admin_name'] ?? 'Administrator';
$admin_email = $_SESSION['admin_email'] ?? '';
$admin_id = $_SESSION['admin_id'];

$unread_email_count = 0;
$unread_query = $conn->query("SELECT COUNT(*) AS total FROM incoming_emails WHERE read_status = 'unread' AND deleted = 0");
if ($unread_query) {
    $row = $unread_query->fetch_assoc();
    $unread_email_count = (int)($row['total'] ?? 0);
    $unread_query->free();
}

$allowed_statuses = ['pending', 'reviewed', 'resolved', 'closed'];
$filter_status = $_GET['status'] ?? 'all';
$search_query = trim($_GET['q'] ?? '');

$update_success = '';
$update_error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_report'])) {
    $report_id = (int)($_POST['report_id'] ?? 0);
    $new_status = $_POST['status'] ?? '';
    $admin_response = trim($_POST['admin_response'] ?? '');

    if ($report_id <= 0 || !in_array($new_status, $allowed_statuses, true)) {
        $update_error = 'Invalid request. Please try again.';
    } else {
        $stmt = $conn->prepare("UPDATE reports SET status = ?, admin_response = ?, updated_at = NOW() WHERE id = ?");
        $stmt->bind_param("ssi", $new_status, $admin_response, $report_id);
        if ($stmt->execute()) {
            $update_success = 'Report updated successfully.';

            $details_stmt = $conn->prepare("
                SELECT r.subject, u.full_name, u.email
                FROM reports r
                INNER JOIN users u ON r.user_id = u.id
                WHERE r.id = ?
            ");
            if ($details_stmt) {
                $details_stmt->bind_param("i", $report_id);
                $details_stmt->execute();
                $details_stmt->bind_result($report_subject, $user_name, $user_email);
                if ($details_stmt->fetch() && !empty($admin_response)) {
                    $details_stmt->close();

                    $email_subject = "Update on your Bizmo report: " . ($report_subject ?: 'Report');
                    $email_body = "
                        <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;'>
                            <h2 style='color: #7c3aed; margin-bottom: 20px;'>Hello {$user_name},</h2>
                            <p>Your report has been updated to <strong>" . ucfirst($new_status) . "</strong>.</p>
                            <div style='background: #0f172a; padding: 20px; border-radius: 10px; color: #e2e8f0; margin: 20px 0;'>
                                " . nl2br(htmlspecialchars($admin_response)) . "
                            </div>
                            <p style='color: #94a3b8;'>If you have additional questions, feel free to reply to this email.</p>
                            <p style='margin-top: 30px;'>— Bizmo Admin Team</p>
                        </div>
                    ";

                    try {
                        $log_stmt = $conn->prepare("INSERT INTO emails (admin_id, recipient_email, recipient_name, subject, message, status) VALUES (?, ?, ?, ?, ?, 'pending')");
                        $log_id = null;
                        if ($log_stmt) {
                            $log_stmt->bind_param("issss", $admin_id, $user_email, $user_name, $email_subject, $admin_response);
                            $log_stmt->execute();
                            $log_id = $conn->insert_id;
                            $log_stmt->close();
                        }

                        $mail = new PHPMailer(true);
                        $mail->isSMTP();
                        $mail->Host = 'smtp.gmail.com';
                        $mail->SMTPAuth = true;
                        $mail->Username = 'bizmobsu@gmail.com';
                        $mail->Password = 'cohrugzxdhsjqybd';
                        $mail->SMTPSecure = 'tls';
                        $mail->Port = 587;
                        $mail->SMTPOptions = [
                            'ssl' => [
                                'verify_peer' => false,
                                'verify_peer_name' => false,
                                'allow_self_signed' => true
                            ]
                        ];

                        $mail->setFrom('bizmobsu@gmail.com', 'Bizmo Admin');
                        $mail->addAddress($user_email, $user_name);
                        $mail->isHTML(true);
                        $mail->Subject = $email_subject;
                        $mail->Body = $email_body;
                        $mail->AltBody = "Hello {$user_name},\n\nYour report status is now " . ucfirst($new_status) . ".\n\n{$admin_response}\n\n— Bizmo Admin Team";
                        $mail->send();

                        if ($log_id) {
                            $upd_stmt = $conn->prepare("UPDATE emails SET status = 'sent', sent_at = NOW() WHERE id = ?");
                            if ($upd_stmt) {
                                $upd_stmt->bind_param("i", $log_id);
                                $upd_stmt->execute();
                                $upd_stmt->close();
                            }
                        }
                    } catch (Exception $e) {
                        if (!empty($log_id)) {
                            $fail_stmt = $conn->prepare("UPDATE emails SET status = 'failed' WHERE id = ?");
                            if ($fail_stmt) {
                                $fail_stmt->bind_param("i", $log_id);
                                $fail_stmt->execute();
                                $fail_stmt->close();
                            }
                        }
                        $update_error = 'Report updated, but email failed to send. Error: ' . $e->getMessage();
                    }
                } else {
                    $details_stmt->close();
                }
            }
        } else {
            $update_error = 'Failed to update report. Please try again.';
        }
        $stmt->close();
    }
}

// Fetch summary counts
$report_counts = [
    'all' => 0,
    'pending' => 0,
    'reviewed' => 0,
    'resolved' => 0,
    'closed' => 0
];

$count_result = $conn->query("SELECT status, COUNT(*) as total FROM reports GROUP BY status");
if ($count_result) {
    while ($row = $count_result->fetch_assoc()) {
        $status = $row['status'];
        $count = (int)$row['total'];
        if (isset($report_counts[$status])) {
            $report_counts[$status] = $count;
        }
        $report_counts['all'] += $count;
    }
}

$reports = [];
$query = "
    SELECT r.*, u.full_name, u.email, u.username
    FROM reports r
    INNER JOIN users u ON r.user_id = u.id
    WHERE 1 = 1
";
$params = [];
$types = '';

if ($filter_status !== 'all' && in_array($filter_status, $allowed_statuses, true)) {
    $query .= " AND r.status = ? ";
    $types .= 's';
    $params[] = $filter_status;
}

if ($search_query !== '') {
    $query .= " AND (r.subject LIKE ? OR r.category LIKE ? OR u.full_name LIKE ? OR u.email LIKE ?) ";
    $types .= 'ssss';
    $like = '%' . $search_query . '%';
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
}

$query .= " ORDER BY r.created_at DESC";

$stmt = $conn->prepare($query);
if ($stmt) {
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $reports[] = $row;
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bizmo – Admin Reports</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #0b0b12;
            --surface: #111118;
            --surface-light: rgba(255,255,255,0.03);
            --text: #ffffff;
            --text-muted: #a2a3ad;
            --accent: #dc2626;
            --border: rgba(255,255,255,0.08);
            --danger: #ef4444;
            --success: #22c55e;
            --warning: #f59e0b;
            --info: #3b82f6;
        }

        /* Light theme overrides */
        body.light-theme {
            --bg: #f8f9fa;
            --surface: #ffffff;
            --surface-light: rgba(0,0,0,0.05);
            --text: #0f172a;
            --text-muted: #475569;
            --accent: #dc2626;
            --border: rgba(0,0,0,0.12);
            --danger: #dc2626;
            --success: #16a34a;
            --warning: #d97706;
            --info: #2563eb;
            background: var(--bg);
        }

        body.light-theme .sidebar {
            background: #ffffff;
            border-right: 1px solid rgba(0,0,0,0.12);
            box-shadow: 2px 0 8px rgba(0,0,0,0.05);
        }

        body.light-theme .card,
        body.light-theme table,
        body.light-theme .alert {
            background: #ffffff;
            border-color: rgba(0,0,0,0.12);
        }

        * { box-sizing: border-box; }
        html, body { height: 100%; }
        body {
            margin: 0;
            font-family: 'Inter', ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial;
            background: var(--bg);
            color: var(--text);
        }

        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 260px;
            background: var(--surface);
            border-right: 1px solid var(--border);
            padding: 24px;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
        }

        .sidebar-logo {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 40px;
            font-size: 24px;
            font-weight: 900;
            color: var(--text);
        }

        .sidebar-logo img {
            width: 40px;
            height: 40px;
        }

        .nav-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .nav-item {
            margin-bottom: 8px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            color: var(--text-muted);
            text-decoration: none;
            border-radius: 10px;
            font-weight: 500;
            transition: background 0.2s, color 0.2s;
            position: relative;
        }

        .nav-link:hover {
            background: var(--surface-light);
            color: var(--text);
        }

        .nav-link.active {
            background: rgba(147, 51, 234, 0.12);
            color: #c084fc;
        }

        .nav-icon {
            width: 20px;
            height: 20px;
            color: currentColor;
        }

        .nav-badge {
            margin-left: auto;
            padding: 2px 8px;
            border-radius: 999px;
            background: var(--danger);
            color: #fff;
            font-size: 11px;
            font-weight: 700;
            min-width: 24px;
            text-align: center;
        }

        .sidebar-footer {
            margin-top: auto;
            padding-top: 32px;
        }

        .main-content {
            flex: 1;
            margin-left: 260px;
            padding: 32px;
        }

        .top-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 32px;
            gap: 16px;
            flex-wrap: wrap;
        }

        .search-box {
            flex: 1;
            min-width: 280px;
            position: relative;
        }

        .search-box input {
            width: 100%;
            padding: 12px 16px 12px 44px;
            border-radius: 10px;
            border: 1px solid var(--border);
            background: var(--surface-light);
            color: var(--text);
            font-size: 14px;
        }

        .search-box input::placeholder {
            color: var(--text-muted);
        }

        .search-icon {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            width: 20px;
            height: 20px;
            color: var(--text-muted);
        }

        .top-actions {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .date-picker {
            padding: 12px 16px;
            background: var(--surface-light);
            border: 1px solid var(--border);
            border-radius: 10px;
            color: var(--text);
            font-size: 14px;
            cursor: pointer;
        }

        .dark-mode-toggle-top {
            display: inline-flex;
            align-items: center;
            gap: 12px;
            padding: 10px 14px;
            background: var(--surface-light);
            border: 1px solid var(--border);
            border-radius: 10px;
            cursor: pointer;
            transition: background 0.2s;
        }

        .dark-mode-toggle-top svg {
            width: 18px;
            height: 18px;
            color: var(--text-muted);
        }

        .toggle-switch {
            width: 44px;
            height: 24px;
            background: #c084fc;
            border-radius: 12px;
            position: relative;
            flex-shrink: 0;
            transition: background 0.3s ease;
        }

        .toggle-switch::after {
            content: '';
            position: absolute;
            width: 18px;
            height: 18px;
            background: #fff;
            border-radius: 50%;
            top: 3px;
            right: 3px;
            transition: all 0.3s ease;
        }

        body.light-theme .toggle-switch {
            background: #d1d5db;
        }

        body.light-theme .toggle-switch::after {
            right: 23px;
        }

        .user-menu {
            position: relative;
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 8px;
            border-radius: 10px;
            cursor: pointer;
            transition: background 0.2s;
        }

        .user-menu:hover {
            background: var(--surface-light);
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #c084fc;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            color: white;
        }

        .user-dropdown {
            position: absolute;
            top: calc(100% + 8px);
            right: 0;
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 12px;
            min-width: 220px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.35);
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: all 0.2s ease;
            z-index: 100;
        }

        .user-menu.active .user-dropdown {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }

        .user-dropdown-item {
            padding: 16px;
            border-bottom: 1px solid var(--border);
        }

        .user-dropdown-item:last-child {
            border-bottom: none;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            flex-wrap: wrap;
            gap: 16px;
        }

        .page-header h1 {
            margin: 0 0 6px;
            font-size: 28px;
            font-weight: 800;
        }

        .page-header p {
            margin: 0;
            color: var(--text-muted);
            font-size: 14px;
        }

        .status-pills {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        }

        .status-pill {
            padding: 10px 16px;
            border-radius: 999px;
            border: 1px solid var(--border);
            color: var(--text);
            text-decoration: none;
            font-size: 14px;
            font-weight: 600;
            background: rgba(255,255,255,0.03);
            transition: all 0.2s ease;
        }

        .status-pill.active {
            background: var(--accent);
            border-color: var(--accent);
            color: #fff;
            box-shadow: 0 6px 16px rgba(220, 38, 38, 0.35);
        }

        .status-pill span {
            margin-left: 8px;
            opacity: 0.75;
        }

        .card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 24px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            border-bottom: 1px solid var(--border);
        }

        th {
            text-align: left;
            padding: 14px;
            font-size: 12px;
            font-weight: 600;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.6px;
        }

        td {
            padding: 18px 14px;
            border-bottom: 1px solid var(--border);
            vertical-align: top;
        }

        .reports-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 20px;
            margin-top: 24px;
        }

        .report-card {
            background: rgba(255,255,255,0.02);
            border: 1px solid var(--border);
            border-radius: 18px;
            padding: 24px;
            box-shadow: 0 12px 30px rgba(0,0,0,0.25);
            transition: transform 0.15s ease, border-color 0.15s ease, box-shadow 0.15s ease;
            cursor: pointer;
            display: flex;
            flex-direction: column;
            gap: 16px;
        }

        body.light-theme .report-card {
            background: #ffffff;
            box-shadow: 0 12px 24px rgba(15, 23, 42, 0.08);
        }

        .report-card:hover {
            transform: translateY(-4px);
            border-color: rgba(255,255,255,0.25);
            box-shadow: 0 16px 40px rgba(0,0,0,0.35);
        }

        body.light-theme .report-card:hover {
            box-shadow: 0 16px 32px rgba(15, 23, 42, 0.12);
        }

        .report-card-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 12px;
        }

        .report-card-user {
            flex: 1;
        }

        .report-card-user strong {
            display: block;
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 4px;
            color: var(--text);
        }

        .report-card-user .report-meta {
            font-size: 12px;
            color: var(--text-muted);
            line-height: 1.5;
        }

        .report-card-subject {
            font-size: 18px;
            font-weight: 700;
            margin: 0;
            color: var(--text);
            line-height: 1.4;
        }

        .report-card-message {
            color: var(--text);
            font-size: 14px;
            line-height: 1.6;
            white-space: pre-wrap;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .report-card-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
            padding-top: 12px;
            border-top: 1px solid var(--border);
        }

        .report-card-response {
            width: 100%;
            margin-top: 8px;
            padding: 12px 16px;
            border-radius: 12px;
            border: 1px solid var(--border);
            background: rgba(255,255,255,0.03);
            font-size: 13px;
            color: var(--text);
        }

        body.light-theme .report-card-response {
            background: rgba(15, 23, 42, 0.05);
        }

        .report-card-response strong {
            display: block;
            margin-bottom: 6px;
            color: var(--text);
        }

        .report-subject {
            font-weight: 600;
            margin: 0 0 6px;
        }

        .report-meta {
            font-size: 13px;
            color: var(--text-muted);
            display: flex;
            flex-direction: column;
            gap: 4px;
            margin-top: 4px;
        }

        .report-meta-item {
            line-height: 1.5;
        }

        .report-message {
            min-width: 280px;
            color: var(--text);
            font-size: 14px;
            line-height: 1.6;
            white-space: pre-wrap;
            text-align: left;
        }

        .report-row {
            cursor: pointer;
        }

        .report-row:focus-within {
            outline: 2px solid var(--accent);
            outline-offset: 2px;
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 600;
        }

        .status-pending { background: rgba(255, 184, 34, 0.15); color: #fbbf24; }
        .status-reviewed { background: rgba(59, 130, 246, 0.15); color: #93c5fd; }
        .status-resolved { background: rgba(34, 197, 94, 0.15); color: #86efac; }
        .status-closed { background: rgba(148, 163, 184, 0.2); color: #cbd5f5; }

        .category-chip {
            display: inline-flex;
            align-items: center;
            padding: 6px 14px;
            border-radius: 999px;
            background: rgba(255,255,255,0.08);
            color: var(--text-muted);
            font-size: 13px;
            font-weight: 600;
        }

        body.light-theme .category-chip {
            background: rgba(15, 23, 42, 0.08);
            color: var(--text);
        }

        .response-inline {
            margin-top: 10px;
            padding: 12px 16px;
            border-radius: 12px;
            border: 1px solid var(--border);
            background: rgba(255,255,255,0.03);
            font-size: 13px;
            color: var(--text);
        }

        body.light-theme .response-inline {
            background: rgba(15, 23, 42, 0.05);
        }

        .modal-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.75);
            display: none;
            align-items: stretch;
            justify-content: flex-end;
            z-index: 2000;
            padding: 0;
            opacity: 0;
            transition: opacity 0.25s ease;
        }

        .modal-overlay.active {
            display: flex;
            opacity: 1;
        }

        .report-modal {
            width: min(500px, 90vw);
            max-width: 500px;
            height: 100vh;
            max-height: 100vh;
            background: var(--surface);
            border: none;
            border-left: 1px solid var(--border);
            border-radius: 0;
            padding: 0;
            box-shadow: -10px 0 40px rgba(0,0,0,0.4);
            transform: translateX(100%);
            opacity: 1;
            transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }

        body.light-theme .report-modal {
            background: #fff;
        }

        .modal-overlay.active .report-modal {
            transform: translateX(0);
        }

        .modal-container {
            display: flex;
            width: 100%;
            position: relative;
            height: 100%;
            min-height: auto;
        }

        .modal-left-panel {
            width: 100%;
            padding: 20px;
            transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            overflow-y: auto;
            flex-shrink: 0;
            display: flex;
            flex-direction: column;
        }

        .modal-right-panel {
            position: absolute;
            top: 0;
            right: 0;
            width: 100%;
            height: 100%;
            background: var(--surface);
            border-left: 1px solid var(--border);
            padding: 20px;
            transform: translateX(100%);
            transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            flex-shrink: 0;
        }

        body.light-theme .modal-right-panel {
            background: #fff;
        }

        .modal-container.response-active .modal-left-panel {
            transform: translateX(-100%);
        }

        .modal-container.response-active .modal-right-panel {
            transform: translateX(0);
        }

        .modal-back-btn {
            display: none;
            align-items: center;
            gap: 8px;
            padding: 8px 2px;
            background: var(--surface-light);
            border: 1px solid var(--border);
            border-radius: 10px;
            color: var(--text);
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            margin-bottom: 16px;
            transition: background 0.2s ease;
        }

        .modal-back-btn:hover {
            background: rgba(255,255,255,0.08);
        }

        .modal-container.response-active .modal-back-btn {
            display: flex;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 20px;
            padding-bottom: 16px;
            border-bottom: 1px solid var(--border);
        }

        .modal-title {
            margin: 0 0 4px;
            font-size: 20px;
            font-weight: 700;
        }

        .modal-close {
            background: transparent;
            border: none;
            color: var(--text-muted);
            font-size: 24px;
            cursor: pointer;
            line-height: 1;
        }

        .modal-section {
            margin-bottom: 16px;
        }

        .modal-section:last-child {
            margin-bottom: 0;
        }

        .modal-section h4 {
            margin: 0 0 6px;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: var(--text-muted);
        }

        .modal-section p {
            margin: 0;
            color: var(--text);
            white-space: pre-wrap;
            font-size: 14px;
        }

        .modal-actions {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            margin-top: 20px;
        }

        .btn-secondary {
            padding: 10px 16px;
            border-radius: 10px;
            border: 1px solid var(--border);
            background: var(--surface-light);
            color: var(--text);
            font-weight: 600;
            cursor: pointer;
            transition: border 0.2s ease, background 0.2s ease;
        }

        .btn-secondary:hover {
            border-color: rgba(255,255,255,0.25);
        }
        .action-form {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .action-select,
        .action-textarea {
            width: 100%;
            padding: 12px 14px;
            border-radius: 12px;
            border: 1px solid rgba(255,255,255,0.15);
            background: rgba(17, 24, 39, 0.85);
            color: var(--text);
            font-size: 14px;
            transition: border 0.2s ease, background 0.2s ease, color 0.2s ease;
        }

        .action-textarea {
            min-height: 90px;
            resize: vertical;
            background: rgba(17, 24, 39, 0.75);
        }

        .action-select {
            appearance: none;
            background-image:
                linear-gradient(45deg, transparent 50%, rgba(255,255,255,0.5) 50%),
                linear-gradient(135deg, rgba(255,255,255,0.5) 50%, transparent 50%);
            background-position:
                calc(100% - 20px) calc(50% - 3px),
                calc(100% - 14px) calc(50% - 3px);
            background-size: 6px 6px;
            background-repeat: no-repeat;
            padding-right: 36px;
        }

        .action-select:focus,
        .action-textarea:focus {
            border-color: rgba(147, 51, 234, 0.8);
            outline: none;
            background: rgba(31, 41, 72, 0.95);
        }

        body.light-theme .action-select,
        body.light-theme .action-textarea {
            background: rgba(248, 250, 252, 0.9);
            border-color: rgba(15,23,42,0.15);
            color: var(--text);
        }

        body.light-theme .action-select:focus,
        body.light-theme .action-textarea:focus {
            background: #ffffff;
            border-color: rgba(147, 51, 234, 0.4);
        }

        .btn {
            padding: 10px 16px;
            border-radius: 10px;
            border: none;
            cursor: pointer;
            font-size: 13px;
            font-weight: 600;
            transition: all 0.2s ease;
        }

        .btn-primary {
            background: linear-gradient(135deg, #7c3aed, #ec4899);
            color: #fff;
            box-shadow: 0 10px 20px rgba(124, 58, 237, 0.35);
            border: 1px solid rgba(255,255,255,0.08);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 14px 26px rgba(124, 58, 237, 0.45);
        }

        body.light-theme .btn-primary {
            box-shadow: 0 10px 20px rgba(236, 72, 153, 0.25);
            border-color: rgba(124, 58, 237, 0.25);
        }

        .alert {
            padding: 14px 16px;
            border-radius: 12px;
            margin-bottom: 20px;
            font-size: 14px;
            font-weight: 600;
        }

        .alert-success {
            background: rgba(34, 197, 94, 0.12);
            border: 1px solid rgba(34, 197, 94, 0.3);
            color: #bbf7d0;
        }

        .alert-error {
            background: rgba(239, 68, 68, 0.12);
            border: 1px solid rgba(239, 68, 68, 0.3);
            color: #fecaca;
        }

        @media (max-width: 1024px) {
            .sidebar {
                position: fixed;
                width: 220px;
            }
            .main-content {
                margin-left: 220px;
            }
        }

        @media (max-width: 820px) {
            .dashboard-container {
                flex-direction: column;
            }
            .sidebar {
                position: relative;
                width: 100%;
                height: auto;
            }
            .main-content {
                margin-left: 0;
            }
            .top-bar {
                flex-direction: column;
                align-items: stretch;
                gap: 16px;
            }
            .search-box {
                width: 100%;
            }
            .reports-grid {
                grid-template-columns: 1fr;
            }
            .report-modal {
                width: 100%;
                max-width: 100%;
            }
            .modal-container {
                min-height: 100vh;
            }
        }

        /* Logout Modal */
        .logout-modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.75);
            backdrop-filter: blur(4px);
            z-index: 3000;
            align-items: center;
            justify-content: center;
            padding: 20px;
            animation: fadeIn 0.3s ease;
        }

        .logout-modal-overlay.active {
            display: flex;
        }

        .logout-modal {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 32px;
            max-width: 400px;
            width: 100%;
            position: relative;
            box-shadow: 0 40px 120px rgba(0,0,0,0.5);
            animation: slideUp 0.3s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .logout-modal-icon {
            width: 64px;
            height: 64px;
            margin: 0 auto 20px;
            background: rgba(239, 68, 68, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #ef4444;
        }

        .logout-modal-icon svg {
            width: 32px;
            height: 32px;
        }

        .logout-modal-header {
            margin-bottom: 20px;
            text-align: center;
        }

        .logout-modal-title {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 8px;
            color: var(--text);
        }

        .logout-modal-message {
            color: var(--text-muted);
            font-size: 14px;
            line-height: 1.6;
        }

        .logout-modal-actions {
            display: flex;
            gap: 12px;
            margin-top: 24px;
        }

        .btn-modal {
            flex: 1;
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
        }

        .btn-modal-cancel {
            background: var(--surface-light);
            border: 1px solid var(--border);
            color: var(--text);
        }

        .btn-modal-cancel:hover {
            background: var(--surface);
        }

        .btn-modal-logout {
            background: #ef4444;
            color: white;
        }

        .btn-modal-logout:hover {
            background: #dc2626;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
            <div class="sidebar-logo">
                <img src="../icons/bizmo.png" alt="Bizmo">
                <span>Bizmo</span>
            </div>
            <nav>
                <ul class="nav-menu">
                    <li class="nav-item">
                        <a href="admin_dashboard.php" class="nav-link">
                            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>
                            </svg>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="admin_users.php" class="nav-link">
                            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/>
                            </svg>
                            <span>Users</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="users_decks.php" class="nav-link">
                            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/>
                            </svg>
                            <span>Decks</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="admin_email.php" class="nav-link">
                            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                            </svg>
                            <span>Emails</span>
                            <?php if ($unread_email_count > 0): ?>
                                <span class="nav-badge"><?php echo $unread_email_count > 99 ? '99+' : $unread_email_count; ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="admin_reports.php" class="nav-link active">
                            <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                            </svg>
                            <span>Reports</span>
                            <?php if (($report_counts['pending'] ?? 0) > 0): ?>
                                <span class="nav-badge"><?php echo $report_counts['pending'] > 99 ? '99+' : $report_counts['pending']; ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                </ul>
            </nav>
            <div class="sidebar-footer">
                <a href="#" id="logoutBtn" class="nav-link" style="color: var(--danger);">
                    <svg class="nav-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                    </svg>
                    Logout
                </a>
            </div>
        </aside>

        <main class="main-content">
            <div class="top-bar">
                <form method="get" class="search-box">
                    <svg class="search-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                    </svg>
                    <?php if ($filter_status !== 'all'): ?>
                        <input type="hidden" name="status" value="<?php echo htmlspecialchars($filter_status); ?>">
                    <?php endif; ?>
                    <input type="search" name="q" placeholder="Search reports, users, emails..." value="<?php echo htmlspecialchars($search_query); ?>">
                </form>
                <div class="top-actions">
                    <div class="date-picker" id="realtimeClock" style="cursor: default; user-select: none;"></div>
                    <div class="dark-mode-toggle-top" id="darkModeToggle">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/>
                        </svg>
                        <div class="toggle-switch"></div>
                    </div>
                    <div class="user-menu" id="userMenu">
                        <div class="user-avatar"><?php echo strtoupper(substr($admin_name, 0, 1)); ?></div>
                        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: var(--text-muted);">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                        </svg>
                        <div class="user-dropdown">
                            <div class="user-dropdown-item" style="pointer-events: none;">
                                <div style="font-weight: 600; margin-bottom: 4px;"><?php echo htmlspecialchars($admin_name); ?></div>
                                <div style="font-size: 12px; color: var(--text-muted);"><?php echo htmlspecialchars($admin_email); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="page-header">
                <div>
                    <h1>User Reports</h1>
                    <p>Review and respond to reports submitted by users.</p>
                </div>
            </div>

            <div class="status-pills">
                <?php
                $filters = ['all' => 'All', 'pending' => 'Pending', 'reviewed' => 'Reviewed', 'resolved' => 'Resolved', 'closed' => 'Closed'];
                foreach ($filters as $key => $label):
                    $query_params = ['status' => $key];
                    if ($search_query !== '') {
                        $query_params['q'] = $search_query;
                    }
                    $link = '?' . http_build_query($query_params);
                ?>
                    <a href="<?php echo $link; ?>" class="status-pill <?php echo $filter_status === $key ? 'active' : ''; ?>">
                        <?php echo $label; ?>
                        <span><?php echo number_format($report_counts[$key] ?? 0); ?></span>
                    </a>
                <?php endforeach; ?>
            </div>

            <?php if ($update_success): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($update_success); ?></div>
            <?php endif; ?>
            <?php if ($update_error): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($update_error); ?></div>
            <?php endif; ?>

            <?php if (empty($reports)): ?>
                <div class="card" style="margin-top: 24px;">
                    <p style="text-align: center; color: var(--text-muted); margin: 40px 0;">No reports found for the selected filters.</p>
                </div>
            <?php else: ?>
                <div class="reports-grid">
                    <?php foreach ($reports as $report): ?>
                        <div class="report-card report-row"
                            data-report-id="<?php echo (int)$report['id']; ?>"
                            data-report-status="<?php echo htmlspecialchars($report['status'], ENT_QUOTES, 'UTF-8'); ?>"
                            data-report-response="<?php echo htmlspecialchars($report['admin_response'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                            data-report-subject="<?php echo htmlspecialchars($report['subject'], ENT_QUOTES, 'UTF-8'); ?>"
                            data-report-category="<?php echo htmlspecialchars($report['category'], ENT_QUOTES, 'UTF-8'); ?>"
                            data-report-message="<?php echo htmlspecialchars($report['message'], ENT_QUOTES, 'UTF-8'); ?>"
                            data-report-user="<?php echo htmlspecialchars($report['full_name'], ENT_QUOTES, 'UTF-8'); ?>"
                            data-report-email="<?php echo htmlspecialchars($report['email'], ENT_QUOTES, 'UTF-8'); ?>"
                            data-report-created="<?php echo htmlspecialchars(date('M d, Y g:i A', strtotime($report['created_at'])), ENT_QUOTES, 'UTF-8'); ?>"
                        >
                            <div class="report-card-header">
                                <div class="report-card-user">
                                    <strong><?php echo htmlspecialchars($report['full_name']); ?></strong>
                                    <span class="report-meta"><?php echo htmlspecialchars($report['email']); ?></span>
                                    <span class="report-meta"><?php echo date('M d, Y g:i A', strtotime($report['created_at'])); ?></span>
                                </div>
                                <span class="status-badge status-<?php echo htmlspecialchars($report['status']); ?>">
                                    <?php echo ucfirst($report['status']); ?>
                                </span>
                            </div>
                            
                            <h3 class="report-card-subject"><?php echo htmlspecialchars($report['subject']); ?></h3>
                            
                            <div>
                                <span class="category-chip">
                                    <?php echo htmlspecialchars(ucfirst($report['category'])); ?>
                                </span>
                            </div>
                            
                            <div>
                                <h4 style="margin: 0 0 8px; font-size: 12px; text-transform: uppercase; letter-spacing: 0.08em; color: var(--text-muted); font-weight: 600;">Message</h4>
                                <div class="report-card-message">
                                    <?php echo nl2br(htmlspecialchars($report['message'])); ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </main>
    </div>

    <div class="modal-overlay" id="reportModal">
        <div class="report-modal">
            <div class="modal-container" id="modalContainer">
                <div class="modal-left-panel">
                    <div class="modal-header">
                        <div>
                            <h3 class="modal-title" id="modalReportSubject">Report Details</h3>
                            <div class="report-meta" id="modalReportMeta"></div>
                        </div>
                        <button class="modal-close" id="modalCloseBtn">&times;</button>
                    </div>

                    <div class="modal-section">
                        <h4>Message</h4>
                        <p id="modalReportMessage"></p>
                    </div>

                    <div class="modal-section">
                        <h4>Category</h4>
                        <span class="category-chip" id="modalReportCategory"></span>
                    </div>

                    <div class="modal-actions">
                        <button type="button" class="btn btn-primary" id="respondButton">Respond</button>
                    </div>
                </div>

                <div class="modal-right-panel">
                    <button type="button" class="modal-back-btn" id="modalBackBtn">
                        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
                        </svg>
                        Back
                    </button>
                    <div class="modal-header" style="margin-bottom: 20px;">
                        <div>
                            <h3 class="modal-title">Respond to Report</h3>
                            <div class="report-meta" id="modalResponseMeta"></div>
                        </div>
                    </div>

                    <form method="post" class="action-form" id="reportUpdateForm" style="flex: 1; display: flex; flex-direction: column; gap: 0;">
                        <input type="hidden" name="update_report" value="1">
                        <input type="hidden" name="report_id" id="modalReportId">
                        <div class="modal-section">
                            <h4>Status</h4>
                            <select name="status" class="action-select" id="modalStatus" required>
                                <?php foreach ($allowed_statuses as $status): ?>
                                    <option value="<?php echo $status; ?>"><?php echo ucfirst($status); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="modal-section" style="flex: 1; display: flex; flex-direction: column;">
                            <h4>Admin Response</h4>
                            <textarea name="admin_response" class="action-textarea" id="modalResponse" placeholder="Add an optional response..." style="flex: 1; min-height: 200px;"></textarea>
                        </div>

                        <div class="modal-actions" style="margin-top: auto;">
                            <button type="submit" class="btn btn-primary">Save Changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        function initTheme() {
            const savedTheme = localStorage.getItem('admin-theme') || 'dark';
            if (savedTheme === 'light') {
                document.body.classList.add('light-theme');
            } else {
                document.body.classList.remove('light-theme');
            }
            updateToggleSwitch(savedTheme);
        }

        function updateToggleSwitch(theme) {
            const toggleSwitch = document.querySelector('.toggle-switch');
            if (!toggleSwitch) return;
            if (theme === 'light') {
                toggleSwitch.classList.add('active');
            } else {
                toggleSwitch.classList.remove('active');
            }
        }

        function toggleTheme() {
            const isLight = document.body.classList.toggle('light-theme');
            localStorage.setItem('admin-theme', isLight ? 'light' : 'dark');
            updateToggleSwitch(isLight ? 'light' : 'dark');
        }

        document.addEventListener('DOMContentLoaded', function() {
            initTheme();
            const darkModeToggle = document.getElementById('darkModeToggle');
            if (darkModeToggle) {
                darkModeToggle.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    toggleTheme();
                });
            }

            const userMenu = document.getElementById('userMenu');
            if (userMenu) {
                userMenu.addEventListener('click', function(e) {
                    e.stopPropagation();
                    this.classList.toggle('active');
                });

                document.addEventListener('click', function(e) {
                    if (!userMenu.contains(e.target)) {
                        userMenu.classList.remove('active');
                    }
                });
            }

            const reportModal = document.getElementById('reportModal');
            const modalContainer = document.getElementById('modalContainer');
            const modalCloseBtn = document.getElementById('modalCloseBtn');
            const modalBackBtn = document.getElementById('modalBackBtn');
            const modalReportSubject = document.getElementById('modalReportSubject');
            const modalReportMeta = document.getElementById('modalReportMeta');
            const modalResponseMeta = document.getElementById('modalResponseMeta');
            const modalReportMessage = document.getElementById('modalReportMessage');
            const modalReportCategory = document.getElementById('modalReportCategory');
            const modalStatus = document.getElementById('modalStatus');
            const modalResponse = document.getElementById('modalResponse');
            const modalReportId = document.getElementById('modalReportId');
            const respondButton = document.getElementById('respondButton');

            function openReportModal(row) {
                modalReportId.value = row.dataset.reportId;
                modalReportSubject.textContent = row.dataset.reportSubject;
                const metaHTML = `
                    <div class="report-meta-item">${row.dataset.reportUser}</div>
                    <div class="report-meta-item">${row.dataset.reportEmail}</div>
                    <div class="report-meta-item">Submitted ${row.dataset.reportCreated}</div>
                `;
                modalReportMeta.innerHTML = metaHTML;
                modalResponseMeta.innerHTML = metaHTML;
                modalReportMessage.textContent = row.dataset.reportMessage;
                modalReportCategory.textContent = row.dataset.reportCategory.charAt(0).toUpperCase() + row.dataset.reportCategory.slice(1);
                modalStatus.value = row.dataset.reportStatus;
                modalResponse.value = row.dataset.reportResponse || '';
                modalContainer.classList.remove('response-active');
                reportModal.classList.add('active');
                document.body.style.overflow = 'hidden';
            }

            function closeReportModal() {
                reportModal.classList.remove('active');
                modalContainer.classList.remove('response-active');
                document.body.style.overflow = '';
            }

            function showResponsePanel() {
                modalContainer.classList.add('response-active');
            }

            function hideResponsePanel() {
                modalContainer.classList.remove('response-active');
            }

            if (respondButton) {
                respondButton.addEventListener('click', showResponsePanel);
            }

            if (modalBackBtn) {
                modalBackBtn.addEventListener('click', hideResponsePanel);
            }

            document.querySelectorAll('.report-row').forEach(row => {
                row.addEventListener('click', () => openReportModal(row));
                row.addEventListener('keypress', (e) => {
                    if (e.key === 'Enter') {
                        e.preventDefault();
                        openReportModal(row);
                    }
                });
                row.setAttribute('tabindex', '0');
            });

            if (modalCloseBtn) {
                modalCloseBtn.addEventListener('click', closeReportModal);
            }

            if (reportModal) {
                reportModal.addEventListener('click', function(e) {
                    if (e.target === reportModal) {
                        closeReportModal();
                    }
                });
            }

            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && reportModal && reportModal.classList.contains('active')) {
                    closeReportModal();
                }
            });

            // Logout Modal
            const logoutBtn = document.getElementById('logoutBtn');
            const logoutModal = document.getElementById('logoutModal');
            const logoutConfirmBtn = document.getElementById('logoutConfirmBtn');
            const logoutCancelBtn = document.getElementById('logoutCancelBtn');

            if (logoutBtn) {
                logoutBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    if (logoutModal) {
                        logoutModal.classList.add('active');
                    }
                });
            }

            if (logoutCancelBtn) {
                logoutCancelBtn.addEventListener('click', function() {
                    if (logoutModal) {
                        logoutModal.classList.remove('active');
                    }
                });
            }

            if (logoutConfirmBtn) {
                logoutConfirmBtn.addEventListener('click', function() {
                    window.location.href = '?logout=1';
                });
            }

            if (logoutModal) {
                logoutModal.addEventListener('click', function(e) {
                    if (e.target === logoutModal) {
                        logoutModal.classList.remove('active');
                    }
                });
            }

            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && logoutModal && logoutModal.classList.contains('active')) {
                    logoutModal.classList.remove('active');
                }
            });

            // Real-time clock
            function updateClock() {
                const clockElement = document.getElementById('realtimeClock');
                if (clockElement) {
                    const now = new Date();
                    let hours = now.getHours();
                    const minutes = String(now.getMinutes()).padStart(2, '0');
                    const seconds = String(now.getSeconds()).padStart(2, '0');
                    const ampm = hours >= 12 ? 'PM' : 'AM';
                    hours = hours % 12;
                    hours = hours ? hours : 12; // the hour '0' should be '12'
                    hours = String(hours).padStart(2, '0');
                    clockElement.textContent = `${hours}:${minutes}:${seconds} ${ampm}`;
                }
            }

            // Update clock immediately and then every second
            updateClock();
            setInterval(updateClock, 1000);
        });
    </script>

    <!-- Logout Confirmation Modal -->
    <div class="logout-modal-overlay" id="logoutModal">
        <div class="logout-modal">
            <div class="logout-modal-icon">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                </svg>
            </div>
            <div class="logout-modal-header">
                <h3 class="logout-modal-title">Confirm Logout</h3>
                <p class="logout-modal-message">Are you sure you want to logout? You will need to login again to access the admin panel.</p>
            </div>
            <div class="logout-modal-actions">
                <button class="btn-modal btn-modal-cancel" id="logoutCancelBtn">Cancel</button>
                <button class="btn-modal btn-modal-logout" id="logoutConfirmBtn">Logout</button>
            </div>
        </div>
    </div>
</body>
</html>


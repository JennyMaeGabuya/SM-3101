<?php
session_start();
require_once 'config.php';

if (!function_exists('resolveProfilePictureSrc')) {
    function resolveProfilePictureSrc($value, $upload_dir = 'uploads/profiles/') {
        if ($value === null || $value === '') {
            return null;
        }

        if (strpos($value, 'data:') === 0 || preg_match('#^https?://#i', $value)) {
            return $value;
        }

        $candidate_path = $value;
        if (!preg_match('#^/#', $candidate_path) && strpos($candidate_path, 'uploads/') !== 0) {
            $candidate_path = rtrim($upload_dir, '/') . '/' . ltrim($candidate_path, '/');
        }

        $filesystem_path = __DIR__ . '/' . ltrim($candidate_path, '/');
        if (file_exists($filesystem_path)) {
            $mtime = filemtime($filesystem_path);
            return $candidate_path . '?v=' . $mtime;
        }

        if (preg_match('/[^\x20-\x7E]/', $value)) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime = $finfo ? finfo_buffer($finfo, $value) : null;
            if ($finfo) {
                finfo_close($finfo);
            }
            if (!$mime) {
                $mime = 'image/png';
            }
            return 'data:' . $mime . ';base64,' . base64_encode($value);
        }

        return null;
    }
}

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'] ?? 'Friend';
$user_email = $_SESSION['user_email'] ?? '';

$upload_dir = 'uploads/profiles/';
$profile_picture_src = null;

$stmt = $conn->prepare("SELECT profile_picture FROM profiles WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    $profile_picture_src = resolveProfilePictureSrc($row['profile_picture'] ?? null, $upload_dir);
}
$stmt->close();

$user_theme_color = '#dc2626';
$stmt = $conn->prepare("SELECT theme_color FROM themes WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    $user_theme_color = $row['theme_color'];
}
$stmt->close();

function hexToRgb($hex) {
    $hex = str_replace('#', '', $hex);
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    return [$r, $g, $b];
}

function darkenColor($hex, $percent = 20) {
    $rgb = hexToRgb($hex);
    $r = max(0, min(255, $rgb[0] - ($rgb[0] * $percent / 100)));
    $g = max(0, min(255, $rgb[1] - ($rgb[1] * $percent / 100)));
    $b = max(0, min(255, $rgb[2] - ($rgb[2] * $percent / 100)));
    return sprintf("#%02x%02x%02x", round($r), round($g), round($b));
}

$theme_rgb = hexToRgb($user_theme_color);
$theme_rgba_15 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.15)";
$theme_rgba_10 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.1)";
$theme_rgba_05 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.05)";
$theme_rgba_20 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.2)";
$theme_rgba_25 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.25)";
$theme_rgba_30 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.3)";
$theme_darker = darkenColor($user_theme_color, 15);

function getInitials($name) {
    $words = explode(' ', trim($name));
    if (count($words) >= 2) {
        return strtoupper(substr($words[0], 0, 1) . substr($words[count($words) - 1], 0, 1));
    } else {
        return strtoupper(substr($name, 0, 2));
    }
}
$user_initials = getInitials($user_name);

// Fetch decks owned by current user for sharing
$user_decks = [];
$stmt = $conn->prepare("SELECT id, title, description, color, updated_at FROM decks WHERE user_id = ? ORDER BY updated_at DESC, title ASC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$deck_result = $stmt->get_result();
while ($deck_row = $deck_result->fetch_assoc()) {
    $user_decks[] = [
        'id' => (int)$deck_row['id'],
        'title' => $deck_row['title'] ?? 'Untitled Deck',
        'description' => $deck_row['description'] ?? '',
        'color' => $deck_row['color'] ?? $user_theme_color,
        'updated_at' => $deck_row['updated_at'] ?? null
    ];
}
$stmt->close();

// Create friends table if it doesn't exist
$table_check = $conn->query("SHOW TABLES LIKE 'friends'");
if ($table_check->num_rows == 0) {
    $conn->query("CREATE TABLE IF NOT EXISTS `friends` (
        `id` INT(11) NOT NULL AUTO_INCREMENT,
        `user_id` INT(11) NOT NULL,
        `friend_id` INT(11) NOT NULL,
        `status` ENUM('pending', 'accepted', 'blocked') NOT NULL DEFAULT 'pending',
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `unique_friendship` (`user_id`, `friend_id`),
        KEY `idx_user_id` (`user_id`),
        KEY `idx_friend_id` (`friend_id`),
        KEY `idx_status` (`status`),
        CONSTRAINT `fk_friends_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
        CONSTRAINT `fk_friends_friend` FOREIGN KEY (`friend_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
        CHECK (`user_id` != `friend_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

// Handle add friend request
$add_friend_message = null;
$add_friend_error = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_friend'])) {
    $friend_id = isset($_POST['friend_id']) ? (int)$_POST['friend_id'] : 0;
    
    if ($friend_id <= 0 || $friend_id == $user_id) {
        $add_friend_error = 'Invalid friend ID.';
    } else {
        // Check if friendship already exists
        $stmt = $conn->prepare("SELECT id, status FROM friends WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)");
        $stmt->bind_param("iiii", $user_id, $friend_id, $friend_id, $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $existing = $result->fetch_assoc();
            if ($existing['status'] === 'accepted') {
                $add_friend_error = 'You are already friends with this user.';
            } elseif ($existing['status'] === 'pending') {
                $add_friend_error = 'Friend request already sent.';
            } elseif ($existing['status'] === 'blocked') {
                $add_friend_error = 'This user is blocked.';
            }
        } else {
            // Create new friend request
            $stmt = $conn->prepare("INSERT INTO friends (user_id, friend_id, status) VALUES (?, ?, 'pending')");
            $stmt->bind_param("ii", $user_id, $friend_id);
            if ($stmt->execute()) {
                $add_friend_message = 'Friend request sent successfully!';
            } else {
                $add_friend_error = 'Failed to send friend request. Please try again.';
            }
        }
        $stmt->close();
    }
}

// Handle accept friend request
$accept_message = null;
$accept_error = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accept_friend'])) {
    $request_id = isset($_POST['request_id']) ? (int)$_POST['request_id'] : 0;
    
    if ($request_id <= 0) {
        $accept_error = 'Invalid request ID.';
    } else {
        // Verify the request exists and belongs to current user
        $stmt = $conn->prepare("SELECT id, user_id, friend_id, status FROM friends WHERE id = ? AND friend_id = ? AND status = 'pending'");
        $stmt->bind_param("ii", $request_id, $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $request_data = $result->fetch_assoc();
            // Update status to accepted
            $stmt = $conn->prepare("UPDATE friends SET status = 'accepted' WHERE id = ?");
            $stmt->bind_param("i", $request_id);
            if ($stmt->execute()) {
                $accept_message = 'Friend request accepted!';
                header("Location: friends.php");
                exit();
            } else {
                $accept_error = 'Failed to accept friend request. Please try again.';
            }
        } else {
            $accept_error = 'Friend request not found or already processed.';
        }
        $stmt->close();
    }
}

// Handle decline friend request
$decline_message = null;
$decline_error = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['decline_friend'])) {
    $request_id = isset($_POST['request_id']) ? (int)$_POST['request_id'] : 0;
    
    if ($request_id <= 0) {
        $decline_error = 'Invalid request ID.';
    } else {
        // Verify the request exists and belongs to current user
        $stmt = $conn->prepare("SELECT id FROM friends WHERE id = ? AND friend_id = ? AND status = 'pending'");
        $stmt->bind_param("ii", $request_id, $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            // Delete the friend request
            $stmt = $conn->prepare("DELETE FROM friends WHERE id = ?");
            $stmt->bind_param("i", $request_id);
            if ($stmt->execute()) {
                $decline_message = 'Friend request declined.';
                header("Location: friends.php");
                exit();
            } else {
                $decline_error = 'Failed to decline friend request. Please try again.';
            }
        } else {
            $decline_error = 'Friend request not found or already processed.';
        }
        $stmt->close();
    }
}

// Handle friend search
$search_results = [];
$search_error = null;

$share_success = null;
$share_error = null;
$share_form_state = [
    'deck_id' => 0,
    'message' => '',
    'recipient_id' => 0,
    'friend_name' => 'your friend'
];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['share_deck'])) {
    $recipient_id = isset($_POST['recipient_id']) ? (int)$_POST['recipient_id'] : 0;
    $deck_id = isset($_POST['deck_id']) ? (int)$_POST['deck_id'] : 0;
    $share_message = trim($_POST['share_message'] ?? '');
    $share_friend_label = trim($_POST['friend_label'] ?? '');
    $share_form_state['deck_id'] = $deck_id;
    $share_form_state['message'] = $share_message;
    $share_form_state['recipient_id'] = $recipient_id;
    if ($share_friend_label !== '') {
        $share_form_state['friend_name'] = $share_friend_label;
    }

    if ($recipient_id <= 0 || $recipient_id === $user_id) {
        $share_error = 'Please choose a valid friend.';
    } elseif ($deck_id <= 0) {
        $share_error = 'Please select a deck to send.';
    } elseif (empty($user_decks)) {
        $share_error = 'You need at least one deck before you can share.';
    } else {
        // Confirm friendship
        $friend_stmt = $conn->prepare("SELECT 1 FROM friends WHERE ((user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)) AND status = 'accepted' LIMIT 1");
        $friend_stmt->bind_param("iiii", $user_id, $recipient_id, $recipient_id, $user_id);
        $friend_stmt->execute();
        $friend_stmt->store_result();
        $is_friend = $friend_stmt->num_rows > 0;
        $friend_stmt->close();

        if (!$is_friend) {
            $share_error = 'You can only send decks to accepted friends.';
        } else {
            // Confirm deck ownership
            $deck_stmt = $conn->prepare("SELECT title FROM decks WHERE id = ? AND user_id = ?");
            $deck_stmt->bind_param("ii", $deck_id, $user_id);
            $deck_stmt->execute();
            $deck_result = $deck_stmt->get_result();
            $deck_row = $deck_result->fetch_assoc();
            $deck_stmt->close();

            if (!$deck_row) {
                $share_error = 'Deck not found or you no longer have access to it.';
            } else {
                $share_message = mb_substr($share_message, 0, 255);
                $share_message = $share_message === '' ? null : $share_message;

                $existing_stmt = $conn->prepare("SELECT id, status FROM deck_shares WHERE sender_id = ? AND recipient_id = ? AND deck_id = ? LIMIT 1");
                $existing_stmt->bind_param("iii", $user_id, $recipient_id, $deck_id);
                $existing_stmt->execute();
                $existing_share = $existing_stmt->get_result()->fetch_assoc();
                $existing_stmt->close();

                if ($existing_share) {
                    if ($existing_share['status'] === 'pending') {
                        $share_error = 'You already sent this deck to that friend.';
                    } elseif ($existing_share['status'] === 'accepted') {
                        $share_error = 'This friend already accepted this deck.';
                    } else {
                        $reactivate_stmt = $conn->prepare("
                            UPDATE deck_shares
                            SET message = ?, status = 'pending', responded_at = NULL, updated_at = CURRENT_TIMESTAMP, recipient_deck_id = NULL
                            WHERE id = ?
                        ");
                        $reactivate_stmt->bind_param("si", $share_message, $existing_share['id']);
                        if ($reactivate_stmt->execute()) {
                            $share_success = 'Deck share request re-sent!';
                            $share_form_state = [
                                'deck_id' => 0,
                                'message' => '',
                                'recipient_id' => 0,
                                'friend_name' => 'your friend'
                            ];
                        } else {
                            $share_error = 'Unable to resend that deck right now.';
                        }
                        $reactivate_stmt->close();
                    }
                } else {
                    $insert_stmt = $conn->prepare("
                        INSERT INTO deck_shares (sender_id, recipient_id, deck_id, message)
                        VALUES (?, ?, ?, ?)
                    ");
                    $insert_stmt->bind_param("iiis", $user_id, $recipient_id, $deck_id, $share_message);

                    if ($insert_stmt->execute()) {
                        $friend_name_stmt = $conn->prepare("SELECT full_name FROM users WHERE id = ?");
                        $friend_name_stmt->bind_param("i", $recipient_id);
                        $friend_name_stmt->execute();
                        $friend_name_result = $friend_name_stmt->get_result();
                        $friend_name_row = $friend_name_result ? $friend_name_result->fetch_assoc() : null;
                        $friend_name = $friend_name_row['full_name'] ?? null;
                        $friend_name_stmt->close();

                        $share_success = sprintf('Deck shared with %s successfully!', $friend_name ?: 'your friend');
                        $share_form_state = [
                            'deck_id' => 0,
                            'message' => '',
                            'recipient_id' => 0,
                            'friend_name' => 'your friend'
                        ];
                    } else {
                        $share_error = 'Unable to send the deck right now. Please try again.';
                    }
                    $insert_stmt->close();
                }
            }
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accept_share'])) {
    $share_id = isset($_POST['share_id']) ? (int)$_POST['share_id'] : 0;
    if ($share_id <= 0) {
        $share_error = 'Invalid deck share request.';
    } else {
        $share_stmt = $conn->prepare("
            SELECT ds.id, ds.deck_id, ds.sender_id, d.title, d.description, d.color, d.icon, u.full_name AS sender_name
            FROM deck_shares ds
            INNER JOIN decks d ON ds.deck_id = d.id
            INNER JOIN users u ON ds.sender_id = u.id
            WHERE ds.id = ? AND ds.recipient_id = ? AND ds.status = 'pending'
            LIMIT 1
        ");
        $share_stmt->bind_param("ii", $share_id, $user_id);
        $share_stmt->execute();
        $share_data = $share_stmt->get_result()->fetch_assoc();
        $share_stmt->close();

        if (!$share_data) {
            $share_error = 'That deck share request is no longer available.';
        } else {
            $conn->begin_transaction();
            try {
                $newDeckStmt = $conn->prepare("INSERT INTO decks (user_id, title, description, color, icon) VALUES (?, ?, ?, ?, ?)");
                $newDeckStmt->bind_param(
                    "issss",
                    $user_id,
                    $share_data['title'],
                    $share_data['description'],
                    $share_data['color'],
                    $share_data['icon']
                );
                if (!$newDeckStmt->execute()) {
                    throw new Exception('Failed to create deck copy.');
                }
                $new_deck_id = $conn->insert_id;
                $newDeckStmt->close();

                $copyCardsStmt = $conn->prepare("
                    INSERT INTO cards (deck_id, user_id, front, back)
                    SELECT ?, ?, front, back FROM cards WHERE deck_id = ? AND user_id = ?
                ");
                $copyCardsStmt->bind_param("iiii", $new_deck_id, $user_id, $share_data['deck_id'], $share_data['sender_id']);
                if (!$copyCardsStmt->execute()) {
                    throw new Exception('Failed to copy deck cards.');
                }
                $copyCardsStmt->close();

                $updateShareStmt = $conn->prepare("
                    UPDATE deck_shares
                    SET status = 'accepted', responded_at = NOW(), recipient_deck_id = ?
                    WHERE id = ?
                ");
                $updateShareStmt->bind_param("ii", $new_deck_id, $share_id);
                if (!$updateShareStmt->execute()) {
                    throw new Exception('Failed to update deck share status.');
                }
                $updateShareStmt->close();

                $conn->commit();
                $share_success = sprintf('Deck copied to your library. (by %s)', $share_data['sender_name'] ?? 'a friend');
            } catch (Exception $e) {
                $conn->rollback();
                $share_error = 'We could not accept that deck share. Please try again.';
            }
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['decline_share'])) {
    $share_id = isset($_POST['share_id']) ? (int)$_POST['share_id'] : 0;
    if ($share_id <= 0) {
        $share_error = 'Invalid deck share request.';
    } else {
        $decline_stmt = $conn->prepare("
            UPDATE deck_shares
            SET status = 'declined', responded_at = NOW()
            WHERE id = ? AND recipient_id = ? AND status = 'pending'
        ");
        $decline_stmt->bind_param("ii", $share_id, $user_id);
        $decline_stmt->execute();
        if ($decline_stmt->affected_rows > 0) {
            $share_success = 'Deck share declined. The sender will be notified.';
        } else {
            $share_error = 'That deck share request has already been processed.';
        }
        $decline_stmt->close();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_share'])) {
    $share_id = isset($_POST['share_id']) ? (int)$_POST['share_id'] : 0;
    if ($share_id <= 0) {
        $share_error = 'Invalid deck share.';
    } else {
        $cancel_stmt = $conn->prepare("
            UPDATE deck_shares
            SET status = 'cancelled', responded_at = NOW()
            WHERE id = ? AND sender_id = ? AND status = 'pending'
        ");
        $cancel_stmt->bind_param("ii", $share_id, $user_id);
        $cancel_stmt->execute();
        if ($cancel_stmt->affected_rows > 0) {
            $share_success = 'Deck share cancelled.';
        } else {
            $share_error = 'Unable to cancel that share (maybe already processed).';
        }
        $cancel_stmt->close();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['search_friends'])) {
    $search_query = trim($_POST['search_query'] ?? '');
    
    if (empty($search_query)) {
        $search_error = 'Please enter a username or email to search.';
    } else {
        // Search for users by username or email (excluding current user)
        $search_pattern = '%' . $search_query . '%';
        $stmt = $conn->prepare("SELECT id, full_name, email, username, status FROM users WHERE (username LIKE ? OR email LIKE ?) AND id != ? AND status = 'verified' LIMIT 20");
        $stmt->bind_param("ssi", $search_pattern, $search_pattern, $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        while ($row = $result->fetch_assoc()) {
            // Get profile picture if available
            $profile_stmt = $conn->prepare("SELECT profile_picture FROM profiles WHERE user_id = ?");
            $profile_stmt->bind_param("i", $row['id']);
            $profile_stmt->execute();
            $profile_result = $profile_stmt->get_result();
        $profile_data = $profile_result->fetch_assoc();
            $profile_stmt->close();
            
            // Check friendship status
            $friendship_stmt = $conn->prepare("SELECT status, user_id FROM friends WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)");
            $friendship_stmt->bind_param("iiii", $user_id, $row['id'], $row['id'], $user_id);
            $friendship_stmt->execute();
            $friendship_result = $friendship_stmt->get_result();
            $friendship_data = $friendship_result->fetch_assoc();
            $friendship_stmt->close();
            
        $row['profile_picture'] = $profile_data['profile_picture'] ?? null;
        $row['profile_picture_src'] = resolveProfilePictureSrc($row['profile_picture'], $upload_dir);
            $row['initials'] = getInitials($row['full_name']);
            $row['friendship_status'] = $friendship_data['status'] ?? null;
            $row['friendship_user_id'] = $friendship_data['user_id'] ?? null;
            $search_results[] = $row;
        }
        $stmt->close();
        
        if (empty($search_results)) {
            $search_error = 'No users found matching your search.';
        }
    }
}

// Fetch user's friends (accepted status)
$friends_list = [];
// Get friends where current user is user_id
$stmt = $conn->prepare("SELECT f.id, f.friend_id, f.created_at, u.full_name, u.email, u.username, u.id as user_id, p.profile_picture 
                        FROM friends f 
                        INNER JOIN users u ON f.friend_id = u.id
                        LEFT JOIN profiles p ON u.id = p.user_id
                        WHERE f.user_id = ? AND f.status = 'accepted'
                        ORDER BY f.updated_at DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $row['initials'] = getInitials($row['full_name']);
    $row['profile_picture_src'] = resolveProfilePictureSrc($row['profile_picture'] ?? null, $upload_dir);
    // Get deck count for this friend
    $deck_stmt = $conn->prepare("SELECT COUNT(*) as deck_count FROM decks WHERE user_id = ?");
    $deck_stmt->bind_param("i", $row['user_id']);
    $deck_stmt->execute();
    $deck_result = $deck_stmt->get_result();
    $deck_data = $deck_result->fetch_assoc();
    $row['deck_count'] = $deck_data['deck_count'] ?? 0;
    $deck_stmt->close();
    
    // Get card count for this friend
    $card_stmt = $conn->prepare("SELECT COUNT(*) as card_count FROM cards WHERE user_id = ?");
    $card_stmt->bind_param("i", $row['user_id']);
    $card_stmt->execute();
    $card_result = $card_stmt->get_result();
    $card_data = $card_result->fetch_assoc();
    $row['card_count'] = $card_data['card_count'] ?? 0;
    $card_stmt->close();
    
    $friends_list[] = $row;
}
$stmt->close();

// Get friends where current user is friend_id
$stmt = $conn->prepare("SELECT f.id, f.user_id as friend_id, f.created_at, u.full_name, u.email, u.username, u.id as user_id, p.profile_picture 
                        FROM friends f 
                        INNER JOIN users u ON f.user_id = u.id
                        LEFT JOIN profiles p ON u.id = p.user_id
                        WHERE f.friend_id = ? AND f.status = 'accepted'
                        ORDER BY f.updated_at DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $row['initials'] = getInitials($row['full_name']);
    $row['profile_picture_src'] = resolveProfilePictureSrc($row['profile_picture'] ?? null, $upload_dir);
    // Get deck count for this friend
    $deck_stmt = $conn->prepare("SELECT COUNT(*) as deck_count FROM decks WHERE user_id = ?");
    $deck_stmt->bind_param("i", $row['user_id']);
    $deck_stmt->execute();
    $deck_result = $deck_stmt->get_result();
    $deck_data = $deck_result->fetch_assoc();
    $row['deck_count'] = $deck_data['deck_count'] ?? 0;
    $deck_stmt->close();
    
    // Get card count for this friend
    $card_stmt = $conn->prepare("SELECT COUNT(*) as card_count FROM cards WHERE user_id = ?");
    $card_stmt->bind_param("i", $row['user_id']);
    $card_stmt->execute();
    $card_result = $card_stmt->get_result();
    $card_data = $card_result->fetch_assoc();
    $row['card_count'] = $card_data['card_count'] ?? 0;
    $card_stmt->close();
    
    $friends_list[] = $row;
}
$stmt->close();

// Fetch pending friend requests (received by current user)
$friend_requests = [];
$stmt = $conn->prepare("SELECT f.id, f.user_id, f.created_at, u.full_name, u.email, u.username, p.profile_picture 
                        FROM friends f 
                        INNER JOIN users u ON f.user_id = u.id
                        LEFT JOIN profiles p ON u.id = p.user_id
                        WHERE f.friend_id = ? AND f.status = 'pending'
                        ORDER BY f.created_at DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $row['initials'] = getInitials($row['full_name']);
    $row['profile_picture_src'] = resolveProfilePictureSrc($row['profile_picture'] ?? null, $upload_dir);
    $friend_requests[] = $row;
}
$stmt->close();

// Deck share inbox (recipient)
$deck_share_inbox = [];
$stmt = $conn->prepare("
    SELECT ds.id, ds.deck_id, ds.message, ds.created_at, d.title, d.description,
           u.full_name AS sender_name, u.id AS sender_id
    FROM deck_shares ds
    INNER JOIN users u ON ds.sender_id = u.id
    INNER JOIN decks d ON ds.deck_id = d.id
    WHERE ds.recipient_id = ? AND ds.status = 'pending'
    ORDER BY ds.created_at DESC
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $deck_share_inbox[] = $row;
}
$stmt->close();
$pending_deck_share_count = count($deck_share_inbox);

// Deck share activity (sender view)
$deck_share_activity = [];
$stmt = $conn->prepare("
    SELECT ds.id, ds.status, ds.message, ds.created_at, ds.responded_at,
           ds.recipient_deck_id,
           recipient.full_name AS recipient_name,
           d.title
    FROM deck_shares ds
    INNER JOIN users recipient ON ds.recipient_id = recipient.id
    INNER JOIN decks d ON ds.deck_id = d.id
    WHERE ds.sender_id = ?
    ORDER BY ds.created_at DESC
    LIMIT 25
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $deck_share_activity[] = $row;
}
$stmt->close();

// Handle notification dismissal
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['dismiss_notification'])) {
    $notif_id = $_POST['notif_id'] ?? '';
    if (!empty($notif_id)) {
        if (!isset($_SESSION['dismissed_notifications'])) {
            $_SESSION['dismissed_notifications'] = [];
        }
        if (!in_array($notif_id, $_SESSION['dismissed_notifications'])) {
            $_SESSION['dismissed_notifications'][] = $notif_id;
        }
        
        if (isset($_POST['ajax'])) {
            // Explicitly save session before sending AJAX response
            session_write_close();
            header('Content-Type: application/json');
            echo json_encode(['success' => true]);
            exit();
        }
        header("Location: " . strtok($_SERVER['REQUEST_URI'], '?'));
        exit();
    }
}

// Notification system
$notifications = [];
$dismissed_notifications = $_SESSION['dismissed_notifications'] ?? [];

function formatRelativeTime(?string $datetime): string {
    if (empty($datetime)) {
        return '';
    }
    try {
        $time = new DateTime($datetime);
    } catch (Exception $e) {
        return '';
    }
    $now = new DateTime();
    $diff = $now->getTimestamp() - $time->getTimestamp();

    if ($diff < 60) {
        return $diff <= 1 ? 'just now' : $diff . 's ago';
    }
    if ($diff < 3600) {
        $mins = floor($diff / 60);
        return $mins . 'm ago';
    }
    if ($diff < 86400) {
        $hours = floor($diff / 3600);
        return $hours . 'h ago';
    }
    if ($diff < 604800) {
        $days = floor($diff / 86400);
        return $days . 'd ago';
    }
    return $time->format('M j');
}

function tableExists(mysqli $conn, $table) {
    $table = $conn->real_escape_string($table);
    $res = $conn->query("SHOW TABLES LIKE '{$table}'");
    return $res && $res->num_rows > 0;
}

// 1. Friend requests (pending)
if (tableExists($conn, 'friends')) {
    $stmt = $conn->prepare("
        SELECT f.created_at, u.full_name
        FROM friends f
        INNER JOIN users u ON f.user_id = u.id
        WHERE f.friend_id = ? AND f.status = 'pending'
        ORDER BY f.created_at DESC
        LIMIT 5
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $name = $row['full_name'] ?? 'Someone';
        $notif_id = 'friend_request_' . md5($row['created_at'] . $name);
        if (!in_array($notif_id, $dismissed_notifications)) {
            $notifications[] = [
                'id' => $notif_id,
                'title' => 'Friend request',
                'message' => "{$name} wants to connect with you.",
                'time' => formatRelativeTime($row['created_at'] ?? null),
                'icon' => '👥',
                'timestamp' => $row['created_at'] ?? date('Y-m-d H:i:s'),
                'type' => 'friend_request',
                'url' => 'friends.php'
            ];
        }
    }
    $stmt->close();
}

// 2. Deck shares received
if (tableExists($conn, 'deck_shares')) {
    $stmt = $conn->prepare("
        SELECT ds.id, ds.created_at, ds.message, d.title, u.full_name AS sender_name
        FROM deck_shares ds
        INNER JOIN decks d ON ds.deck_id = d.id
        INNER JOIN users u ON ds.sender_id = u.id
        WHERE ds.recipient_id = ? AND ds.status = 'pending'
        ORDER BY ds.created_at DESC
        LIMIT 5
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $sender = $row['sender_name'] ?? 'Someone';
        $deckTitle = $row['title'] ?? 'a deck';
        $share_id = $row['id'] ?? 0;
        $notif_id = 'deck_share_' . $share_id;
        if (!in_array($notif_id, $dismissed_notifications)) {
            $notifications[] = [
                'id' => $notif_id,
                'title' => 'Deck shared with you',
                'message' => "{$sender} shared \"{$deckTitle}\" with you.",
                'time' => formatRelativeTime($row['created_at'] ?? null),
                'icon' => '📤',
                'timestamp' => $row['created_at'] ?? date('Y-m-d H:i:s'),
                'type' => 'deck_share',
                'url' => 'friends.php'
            ];
        }
    }
    $stmt->close();
}

// 3. Friend request accepted
if (tableExists($conn, 'friends')) {
    $stmt = $conn->prepare("
        SELECT f.updated_at, u.full_name
        FROM friends f
        INNER JOIN users u ON f.friend_id = u.id
        WHERE f.user_id = ? AND f.status = 'accepted'
        AND f.updated_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
        ORDER BY f.updated_at DESC
        LIMIT 5
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $name = $row['full_name'] ?? 'Someone';
        $notif_id = 'friend_accepted_' . md5($row['updated_at'] . $name);
        if (!in_array($notif_id, $dismissed_notifications)) {
            $notifications[] = [
                'id' => $notif_id,
                'title' => 'Friend request accepted',
                'message' => "{$name} accepted your friend request.",
                'time' => formatRelativeTime($row['updated_at'] ?? null),
                'icon' => '✅',
                'timestamp' => $row['updated_at'] ?? date('Y-m-d H:i:s'),
                'type' => 'friend_accepted',
                'url' => 'friends.php'
            ];
        }
    }
    $stmt->close();
}

usort($notifications, function ($a, $b) {
    return strtotime($b['timestamp']) <=> strtotime($a['timestamp']);
});
$notifications = array_slice($notifications, 0, 10);
$has_notifications = !empty($notifications);

// Handle clear all notifications (after notifications are built)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['clear_all_notifications'])) {
    $all_notif_ids = array_column($notifications, 'id');
    if (!isset($_SESSION['dismissed_notifications'])) {
        $_SESSION['dismissed_notifications'] = [];
    }
    foreach ($all_notif_ids as $notif_id) {
        if (!empty($notif_id) && !in_array($notif_id, $_SESSION['dismissed_notifications'])) {
            $_SESSION['dismissed_notifications'][] = $notif_id;
        }
    }
    if (isset($_POST['ajax'])) {
        session_write_close();
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'count' => count($all_notif_ids)]);
        exit();
    }
    header("Location: " . strtok($_SERVER['REQUEST_URI'], '?'));
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bizmo – Friends</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #0b0b12;
            --text: #ffffff;
            --muted: #a2a3ad;
            --accent: <?php echo $user_theme_color; ?>;
            --accent-700: <?php echo $theme_darker; ?>;
            --surface: #111118;
            --border: rgba(255,255,255,0.08);
            --soft-accent: <?php echo $theme_rgba_15; ?>;
        }
        * { box-sizing: border-box; }
        html, body { height: 100%; }
        body {
            margin: 0;
            font-family: 'Inter', ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial;
            background: linear-gradient(180deg, #0c0c14 0%, #0c0c14 55%, #0c0c14 100%);
            color: var(--text);
        }
        .header {
            position: sticky; top: 0; z-index: 30;
            backdrop-filter: saturate(180%) blur(20px);
            background: rgba(10,10,15,0.8);
            border-bottom: 1px solid var(--border);
            box-shadow: 0 4px 24px rgba(0,0,0,0.2);
        }
        .header-content {
            max-width: 1400px; margin: 0 auto; padding: 0 24px;
            display: flex; align-items: center; justify-content: space-between;
            padding-top: 18px; padding-bottom: 18px;
        }
        .brand {
            display: inline-flex; align-items: center; gap: 12px;
            font-weight: 800; font-size: 18px; color: var(--text);
            text-decoration: none; transition: transform .2s ease;
        }
        .brand:hover { transform: scale(1.02); }
        .logo {
            background: linear-gradient(135deg, <?php echo $theme_rgba_10; ?>, <?php echo $theme_rgba_05; ?>);
            box-shadow: 0 4px 12px <?php echo $theme_rgba_15; ?>;
            border: 1px solid <?php echo $theme_rgba_20; ?>;
            width: 50px; height: 50px; border-radius: 12px;
            display: grid; place-items: center;
            transition: all .3s ease;
        }
        .logo:hover { transform: rotate(5deg) scale(1.05); }
        .logo svg, .logo img { width: 50px; height: 50px; display: block; }
        .header-right { display: flex; align-items: center; gap: 12px; position: relative; }
        .notif-btn {
            width: 44px; height: 44px; border-radius: 12px;
            background: rgba(255,255,255,0.04);
            border: 1px solid var(--border);
            display: grid; place-items: center; cursor: pointer;
            color: var(--text); transition: all .25s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
        }
        .notif-btn:hover {
            background: rgba(255,255,255,0.08);
            border-color: var(--accent);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px <?php echo $theme_rgba_20; ?>;
        }
        .notif-btn::after {
            content: ''; position: absolute; top: 8px; right: 8px;
            width: 8px; height: 8px; border-radius: 50%;
            background: var(--accent);             box-shadow: 0 0 8px var(--accent);
            opacity: 0;
            transform: scale(0.4);
            transition: opacity 0.2s ease, transform 0.2s ease;
        }
        .notif-btn.has-alert::after {
            opacity: 1;
            transform: scale(1);
        }
        .notif-dropdown {
            position: absolute;
            top: calc(100% + 12px);
            right: 0;
            width: min(360px, 90vw);
            max-height: 500px;
            background: rgba(10,10,15,0.98);
            backdrop-filter: blur(20px);
            border: 1px solid var(--border);
            border-radius: 16px;
            box-shadow: 0 16px 40px rgba(0,0,0,0.45);
            padding: 0;
            display: none;
            z-index: 1000;
            overflow: hidden;
        }
        .notif-dropdown.show { display: block; }
        .notif-dropdown h4 {
            margin: 0;
            padding: 16px 16px 12px;
            font-size: 16px;
            font-weight: 700;
            border-bottom: 1px solid var(--border);
        }
        .notif-list {
            display: flex;
            flex-direction: column;
            gap: 0;
            max-height: 420px;
            overflow-y: auto;
            overflow-x: hidden;
            padding: 8px;
        }
        .notif-list::-webkit-scrollbar {
            width: 6px;
        }
        .notif-list::-webkit-scrollbar-track {
            background: transparent;
        }
        .notif-list::-webkit-scrollbar-thumb {
            background: rgba(255,255,255,0.15);
            border-radius: 3px;
        }
        .notif-list::-webkit-scrollbar-thumb:hover {
            background: rgba(255,255,255,0.25);
        }
        .notif-item {
            display: flex;
            gap: 12px;
            padding: 14px 40px 14px 14px;
            border-radius: 10px;
            border: 1px solid rgba(255,255,255,0.05);
            background: rgba(255,255,255,0.02);
            transition: all 0.2s ease;
            position: relative;
            cursor: pointer;
            margin-bottom: 8px;
        }
        .notif-item:last-child {
            margin-bottom: 0;
        }
        .notif-item:hover {
            border-color: rgba(255,255,255,0.15);
            background: rgba(255,255,255,0.06);
            transform: translateX(2px);
        }
        .notif-item-link {
            display: flex;
            gap: 12px;
            flex: 1;
            text-decoration: none;
            color: inherit;
            min-width: 0;
        }
        .notif-dismiss {
            position: absolute;
            top: 50%;
            right: 12px;
            transform: translateY(-50%);
            width: 28px;
            height: 28px;
            border: none;
            background: rgba(255,255,255,0.08);
            border-radius: 8px;
            color: rgba(255,255,255,0.6);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: 600;
            line-height: 1;
            opacity: 0.6;
            transition: all 0.2s ease;
            z-index: 20;
            flex-shrink: 0;
        }
        .notif-item:hover .notif-dismiss {
            opacity: 1;
            background: rgba(239,68,68,0.15);
            color: #fca5a5;
        }
        .notif-dismiss:hover {
            background: rgba(239,68,68,0.25);
            color: #f87171;
            transform: translateY(-50%) scale(1.1);
        }
        .notif-dismiss:active {
            transform: translateY(-50%) scale(0.95);
        }
        .notif-icon {
            width: 44px;
            height: 44px;
            border-radius: 12px;
            background: rgba(255,255,255,0.06);
            display: grid;
            place-items: center;
            font-size: 22px;
            flex-shrink: 0;
        }
        .notif-body { 
            flex: 1; 
            min-width: 0;
            overflow: hidden;
        }
        .notif-title {
            margin: 0;
            font-size: 14px;
            font-weight: 700;
            color: var(--text);
            line-height: 1.4;
        }
        .notif-message {
            margin: 6px 0 0;
            font-size: 13px;
            color: var(--muted);
            line-height: 1.5;
            word-wrap: break-word;
        }
        .notif-time {
            margin: 8px 0 0;
            font-size: 12px;
            color: rgba(255,255,255,0.5);
            font-weight: 500;
        }
        .notif-empty {
            padding: 40px 20px;
            text-align: center;
        }
        .notif-empty p {
            margin: 0;
            font-weight: 600;
            font-size: 15px;
            color: var(--text);
        }
        .notif-empty span {
            display: block;
            margin-top: 8px;
            font-size: 13px;
            color: var(--muted);
        }
        .user-menu {
            display: flex; align-items: center; gap: 12px; cursor: pointer;
            padding: 8px 14px 8px 8px; border-radius: 999px;
            background: rgba(255,255,255,0.04);
            border: 1px solid var(--border);
            transition: all .25s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
        }
        .user-menu:hover {
            background: rgba(255,255,255,0.08);
            border-color: var(--accent);
            transform: translateY(-1px);
        }
        .user-avatar {
            width: 36px; height: 36px; border-radius: 999px;
            background: linear-gradient(135deg, var(--accent), var(--accent-700));
            display: grid; place-items: center;
            font-weight: 700; font-size: 14px;
            box-shadow: 0 4px 12px <?php echo $theme_rgba_30; ?>;
            overflow: hidden;
        }
        .user-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }
        .dashboard-layout {
            display: grid; grid-template-columns: 280px 1fr;
            max-width: 1400px; margin: 0 auto;
            min-height: calc(100vh - 74px);
        }
        .sidebar {
            padding: 28px 20px; border-right: 1px solid var(--border);
            background: rgba(10,10,15,0.6);
            backdrop-filter: blur(10px);
        }
        .sidebar-nav { display: flex; flex-direction: column; gap: 4px; }
        .nav-item {
            display: flex; align-items: center; gap: 14px;
            padding: 14px 16px; border-radius: 14px;
            color: var(--muted); text-decoration: none;
            font-weight: 600; font-size: 15px;
            transition: all .25s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
        }
        .nav-item:hover {
            background: rgba(255,255,255,0.05);
            color: var(--text);
            transform: translateX(4px);
        }
        .nav-item.active {
            background: linear-gradient(135deg, <?php echo $theme_rgba_20; ?>, <?php echo $theme_rgba_10; ?>);
            color: var(--text);
            border: 1px solid <?php echo $theme_rgba_30; ?>;
            box-shadow: 0 4px 12px <?php echo $theme_rgba_15; ?>;
        }
        .nav-item.active::before {
            content: ''; position: absolute; left: 0; top: 50%;
            transform: translateY(-50%);
            width: 3px; height: 60%; border-radius: 0 4px 4px 0;
            background: var(--accent);
        }
        .nav-icon {
            width: 22px; height: 22px; display: grid; place-items: center;
            font-size: 20px;
        }
        .nav-icon img,
        .nav-icon svg {
            width: 20px;
            height: 20px;
            display: block;
            object-fit: contain;
            filter: brightness(0) invert(1);
            opacity: 0.75;
            transition: opacity 0.2s ease, filter 0.2s ease;
        }
        .nav-item:hover .nav-icon img,
        .nav-item:hover .nav-icon svg,
        .nav-item.active .nav-icon img,
        .nav-item.active .nav-icon svg {
            opacity: 1;
        }
        .nav-item.active .nav-icon img,
        .nav-item.active .nav-icon svg {
            filter: brightness(0) invert(1) drop-shadow(0 0 6px <?php echo $theme_rgba_25; ?>);
        }
        .main-content { padding: 40px; }
        .friends-layout {
            max-width: 1200px;
            margin: 0 auto;
            padding: 40px 24px 80px;
        }
        .friends-header {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            margin-bottom: 32px;
        }
        .friends-title {
            margin: 0;
            font-size: 34px;
            font-weight: 800;
            background: linear-gradient(135deg, #fff, rgba(255,255,255,0.75));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .friends-subtitle {
            margin: 4px 0 0;
            font-size: 15px;
            color: var(--muted);
        }
        .friends-actions {
            display: flex;
            gap: 12px;
        }
        .btn {
            border: none;
            border-radius: 12px;
            padding: 12px 20px;
            font-weight: 600;
            cursor: pointer;
            transition: all .25s ease;
            font-size: 14px;
        }
        .btn-primary {
            background: linear-gradient(135deg, var(--accent), var(--accent-700));
            color: #0b0b12;
            border: 1px solid <?php echo $theme_rgba_30; ?>;
            box-shadow: 0 10px 24px <?php echo $theme_rgba_20; ?>;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 14px 32px <?php echo $theme_rgba_25; ?>;
        }
        .btn-secondary {
            background: rgba(255,255,255,0.05);
            color: var(--text);
            border: 1px solid var(--border);
        }
        .btn-secondary:hover {
            border-color: var(--accent);
            transform: translateY(-2px);
        }
        .friends-content {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 24px;
        }
        .card {
            background: rgba(255,255,255,0.03);
            border: 1px solid var(--border);
            border-radius: 22px;
            padding: 24px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.18);
        }
        .card-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 24px;
        }
        .card-title {
            margin: 0;
            font-size: 18px;
            font-weight: 700;
        }
        .friend-list {
            display: grid;
            gap: 16px;
        }
        .friend-item {
            display: flex;
            align-items: center;
            gap: 16px;
            background: rgba(255,255,255,0.03);
            border: 1px solid transparent;
            border-radius: 16px;
            padding: 16px;
            transition: border .2s ease, transform .2s ease;
        }
        .friend-item:hover {
            transform: translateY(-2px);
            border-color: <?php echo $theme_rgba_20; ?>;
        }
        .friend-avatar {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--accent), var(--accent-700));
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            box-shadow: 0 6px 18px <?php echo $theme_rgba_25; ?>;
            overflow: hidden;
        }
        .friend-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }
        .friend-info {
            flex: 1;
        }
        .friend-name {
            font-size: 15px;
            font-weight: 700;
            margin: 0;
        }
        .friend-status {
            font-size: 13px;
            margin: 4px 0 0;
            color: var(--muted);
        }
        .friend-actions {
            display: flex;
            gap: 8px;
        }
        .badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 10px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 600;
            background: rgba(255,255,255,0.05);
            color: var(--muted);
        }
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: var(--muted);
        }
        .empty-icon {
            font-size: 40px;
            margin-bottom: 16px;
        }
        .search-bar {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 24px;
            padding: 14px 16px;
            border-radius: 14px;
            background: rgba(255,255,255,0.03);
            border: 1px solid var(--border);
        }
        .search-bar input {
            flex: 1;
            background: transparent;
            border: none;
            color: var(--text);
            font-size: 14px;
        }
        .search-bar input:focus {
            outline: none;
        }
        .search-bar svg {
            color: rgba(255,255,255,0.5);
        }
        .modal-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.6);
            backdrop-filter: blur(2px);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 10000;
        }
        .modal-overlay.show {
            display: flex;
        }
        .modal {
            background: rgba(10,10,15,0.98);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 24px;
            width: min(600px, 92vw);
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 12px 40px rgba(0,0,0,0.5);
        }
        .modal-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        .modal-title {
            margin: 0;
            font-size: 20px;
            font-weight: 800;
        }
        .modal-close {
            background: transparent;
            border: 1px solid var(--border);
            color: var(--text);
            border-radius: 10px;
            padding: 6px 10px;
            cursor: pointer;
            font-size: 18px;
        }
        .modal-close:hover {
            background: rgba(255,255,255,0.05);
        }
        .search-form {
            margin-bottom: 24px;
        }
        .search-input-group {
            display: flex;
            gap: 12px;
        }
        .search-input-group input {
            flex: 1;
            padding: 12px 16px;
            border-radius: 12px;
            border: 1px solid var(--border);
            background: rgba(10,10,15,0.9);
            color: var(--text);
            font-size: 14px;
        }
        .search-input-group input:focus {
            outline: none;
            border-color: var(--accent);
        }
        .search-results {
            display: grid;
            gap: 12px;
        }
        .search-result-item {
            display: flex;
            align-items: center;
            gap: 16px;
            padding: 16px;
            background: rgba(255,255,255,0.03);
            border: 1px solid var(--border);
            border-radius: 12px;
            transition: all 0.2s ease;
        }
        .search-result-item:hover {
            background: rgba(255,255,255,0.05);
            border-color: var(--accent);
        }
        .result-avatar {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--accent), var(--accent-700));
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 16px;
            flex-shrink: 0;
            overflow: hidden;
        }
        .result-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }
        .result-info {
            flex: 1;
        }
        .result-name {
            font-size: 15px;
            font-weight: 700;
            margin: 0 0 4px;
        }
        .result-details {
            font-size: 13px;
            color: var(--muted);
            margin: 0;
        }
        .result-actions {
            display: flex;
            gap: 8px;
        }
        .error-message {
            padding: 12px;
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.3);
            border-radius: 10px;
            color: #fecaca;
            margin-bottom: 16px;
        }
        .success-message {
            padding: 12px;
            background: rgba(34, 197, 94, 0.1);
            border: 1px solid rgba(34, 197, 94, 0.3);
            border-radius: 10px;
            color: #bbf7d0;
            margin-bottom: 16px;
        }
        .deck-option-grid {
            display: grid;
            gap: 12px;
            grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
            margin-bottom: 16px;
        }
        .deck-option {
            position: relative;
            display: flex;
            align-items: flex-start;
            gap: 12px;
            padding: 16px;
            border-radius: 14px;
            border: 1px solid var(--border);
            background: rgba(255,255,255,0.02);
            color: var(--text);
            text-align: left;
            cursor: pointer;
            transition: border-color 0.2s ease, transform 0.2s ease, background 0.2s ease;
        }
        .deck-option:hover {
            border-color: var(--accent);
            transform: translateY(-2px);
            background: rgba(255,255,255,0.04);
        }
        .deck-option:focus {
            outline: none;
            border-color: var(--accent);
        }
        .deck-option-accent {
            width: 6px;
            border-radius: 999px;
            background: var(--deck-color, var(--accent));
            min-height: 48px;
        }
        .deck-option-body { flex: 1; }
        .deck-option-title { font-weight: 700; font-size: 15px; margin-bottom: 6px; }
        .deck-option-desc { font-size: 13px; color: var(--muted); line-height: 1.4; }
        .deck-option-check {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            border: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: center;
            color: transparent;
            transition: all 0.2s ease;
        }
        .deck-option.active {
            border-color: var(--accent);
            background: rgba(255,255,255,0.05);
        }
        .deck-option.active .deck-option-check {
            background: var(--accent);
            color: #0b0b12;
            border-color: transparent;
        }
        .deck-selection-summary {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 16px;
            border: 1px solid var(--border);
            border-radius: 14px;
            padding: 16px;
            background: rgba(255,255,255,0.02);
            margin-bottom: 16px;
        }
        .deck-selection-label {
            font-size: 12px;
            color: var(--muted);
            letter-spacing: 0.04em;
            text-transform: uppercase;
            margin-bottom: 4px;
        }
        .deck-selection-value {
            font-size: 16px;
            font-weight: 700;
        }
        .share-alert-pill {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            margin-left: 12px;
            padding: 4px 10px;
            border-radius: 999px;
            background: rgba(34, 197, 94, 0.2);
            color: #bbf7d0;
            font-size: 12px;
            font-weight: 600;
        }
        .deck-share-sections {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
            gap: 24px;
            margin-top: 24px;
        }
        .deck-share-item {
            border: 1px solid var(--border);
            border-radius: 14px;
            padding: 16px;
            display: flex;
            flex-direction: column;
            gap: 12px;
            background: rgba(255,255,255,0.02);
        }
        .deck-share-list {
            display: flex;
            flex-direction: column;
            gap: 16px;
        }
        .deck-share-header {
            display: flex;
            justify-content: space-between;
            gap: 12px;
        }
        .deck-share-title {
            font-size: 15px;
            font-weight: 700;
        }
        .deck-share-meta {
            font-size: 13px;
            color: var(--muted);
        }
        .deck-share-message {
            font-size: 13px;
            color: var(--text);
            background: rgba(255,255,255,0.02);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 12px;
            margin: 0;
        }
        .deck-share-actions {
            display: flex;
            gap: 8px;
            justify-content: flex-end;
        }
        .share-status-badge {
            display: inline-flex;
            align-items: center;
            padding: 4px 10px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 600;
        }
        .share-status-badge.pending { background: rgba(251, 191, 36, 0.2); color: #fcd34d; }
        .share-status-badge.accepted { background: rgba(34, 197, 94, 0.2); color: #bbf7d0; }
        .share-status-badge.declined,
        .share-status-badge.cancelled { background: rgba(239, 68, 68, 0.2); color: #fecaca; }
        .profile-modal-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.6);
            backdrop-filter: blur(2px);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 10001;
        }
        .profile-modal-overlay.show {
            display: flex;
        }
        .profile-modal {
            background: rgba(10,10,15,0.98);
            border: 1px solid var(--border);
            border-radius: 20px;
            padding: 32px;
            width: min(500px, 92vw);
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 12px 40px rgba(0,0,0,0.5);
        }
        .profile-modal-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 24px;
        }
        .profile-modal-title {
            margin: 0;
            font-size: 24px;
            font-weight: 800;
        }
        .profile-modal-close {
            background: transparent;
            border: 1px solid var(--border);
            color: var(--text);
            border-radius: 10px;
            padding: 8px 12px;
            cursor: pointer;
            font-size: 18px;
            transition: all 0.2s ease;
        }
        .profile-modal-close:hover {
            background: rgba(255,255,255,0.05);
        }
        .profile-content {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            gap: 20px;
        }
        .profile-avatar-large {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--accent), var(--accent-700));
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 800;
            font-size: 48px;
            box-shadow: 0 8px 24px <?php echo $theme_rgba_30; ?>;
            flex-shrink: 0;
            overflow: hidden;
        }
        .profile-avatar-large img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }
        .profile-name {
            font-size: 28px;
            font-weight: 800;
            margin: 0;
        }
        .profile-username {
            font-size: 16px;
            color: var(--muted);
            margin: 4px 0 0;
        }
        .profile-email {
            font-size: 14px;
            color: var(--muted);
            margin: 8px 0 0;
        }
        .profile-stats {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 16px;
            width: 100%;
            margin-top: 8px;
        }
        .profile-stat {
            background: rgba(255,255,255,0.03);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 16px;
            text-align: center;
        }
        .profile-stat-value {
            font-size: 24px;
            font-weight: 800;
            margin: 0 0 4px;
            color: var(--accent);
        }
        .profile-stat-label {
            font-size: 13px;
            color: var(--muted);
            margin: 0;
        }
        .profile-joined {
            font-size: 13px;
            color: var(--muted);
            margin-top: 8px;
        }
        /* Logout Modal */
        .logout-modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.75);
            backdrop-filter: blur(4px);
            z-index: 10000;
            align-items: center;
            justify-content: center;
            padding: 20px;
            animation: fadeIn 0.3s ease;
        }
        .logout-modal-overlay.active {
            display: flex;
        }
        .logout-modal {
            background: rgba(10,10,15,0.98);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 32px;
            max-width: 400px;
            width: 100%;
            position: relative;
            box-shadow: 0 40px 120px rgba(0,0,0,0.5);
            animation: slideUp 0.3s ease;
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        .logout-modal-icon {
            width: 64px;
            height: 64px;
            margin: 0 auto 20px;
            background: rgba(239, 68, 68, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .logout-modal-icon svg {
            width: 32px;
            height: 32px;
            color: #ef4444;
        }
        .logout-modal-header {
            text-align: center;
            margin-bottom: 20px;
        }
        .logout-modal-title {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 8px;
            color: var(--text);
        }
        .logout-modal-message {
            color: var(--muted);
            font-size: 14px;
            line-height: 1.6;
        }
        .logout-modal-actions {
            display: flex;
            gap: 12px;
            margin-top: 24px;
        }
        .btn-modal {
            flex: 1;
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
        }
        .btn-modal-cancel {
            background: rgba(255,255,255,0.05);
            border: 1px solid var(--border);
            color: var(--text);
        }
        .btn-modal-cancel:hover {
            background: rgba(255,255,255,0.08);
        }
        .btn-modal-logout {
            background: #ef4444;
            color: white;
        }
        .btn-modal-logout:hover {
            background: #dc2626;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
        }

        @media (max-width: 960px) {
            .friends-content {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-content">
            <a href="dashboard.php" class="brand">
                <div class="logo" aria-label="Bizmo logo">
                    <img src="icons/bizmo.png" alt="" width="50" height="50" />
                </div>
                <span>Bizmo</span>
            </a>
            <div class="header-right">
                <div style="position: relative;">
                    <button class="notif-btn<?php echo $has_notifications ? ' has-alert' : ''; ?>" aria-label="Notifications" id="notifBtn">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/>
                        </svg>
                    </button>
                    <div class="notif-dropdown" id="notifDropdown">
                        <h4>
                            <span>Notifications</span>
                            <?php if (!empty($notifications)): ?>
                                <button type="button" class="notif-clear-all" onclick="clearAllNotifications(event)" aria-label="Clear all notifications">
                                    Clear all
                                </button>
                            <?php endif; ?>
                        </h4>
                        <?php if (!empty($notifications)): ?>
                            <div class="notif-list">
                                <?php foreach ($notifications as $notification): ?>
                                    <div class="notif-item" data-notif-id="<?php echo htmlspecialchars($notification['id'] ?? ''); ?>">
                                        <a href="<?php echo htmlspecialchars($notification['url'] ?? '#'); ?>" class="notif-item-link">
                                            <div class="notif-icon"><?php echo htmlspecialchars($notification['icon']); ?></div>
                                            <div class="notif-body">
                                                <p class="notif-title"><?php echo htmlspecialchars($notification['title']); ?></p>
                                                <p class="notif-message"><?php echo htmlspecialchars($notification['message']); ?></p>
                                                <p class="notif-time"><?php echo htmlspecialchars($notification['time']); ?></p>
                                            </div>
                                        </a>
                                        <button type="button" class="notif-dismiss" aria-label="Dismiss notification" onclick="dismissNotification(event, '<?php echo htmlspecialchars($notification['id'] ?? ''); ?>')">
                                            ×
                                        </button>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="notif-empty">
                                <p>You're all caught up</p>
                                <span>We'll let you know when something new happens.</span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="user-menu" id="userMenu">
                    <div class="user-avatar">
                        <?php if ($profile_picture_src): ?>
                            <img src="<?php echo htmlspecialchars($profile_picture_src, ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($user_name); ?> avatar" />
                        <?php else: ?>
                            <span><?php echo htmlspecialchars($user_initials); ?></span>
                        <?php endif; ?>
                    </div>
                    <span style="font-weight: 600; font-size: 14px;"><?php echo htmlspecialchars($user_name); ?></span>
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                    </svg>
                    <div class="user-dropdown" id="userDropdown" style="display: none; position: absolute; top: calc(100% + 8px); right: 0; background: rgba(10,10,15,0.95); border: 1px solid var(--border); border-radius: 12px; padding: 8px; min-width: 200px; box-shadow: 0 8px 24px rgba(0,0,0,0.4); z-index: 1000;">
                        <div style="padding: 12px; border-bottom: 1px solid var(--border);">
                            <div style="font-weight: 600; font-size: 14px; margin-bottom: 4px;"><?php echo htmlspecialchars($user_name); ?></div>
                            <div style="font-size: 12px; color: var(--muted);"><?php echo htmlspecialchars($user_email); ?></div>
                        </div>
                        <a href="#" id="logoutBtn" style="display: block; padding: 12px; color: var(--text); text-decoration: none; border-radius: 8px; transition: background 0.2s ease; font-size: 14px; font-weight: 600;" onmouseover="this.style.background='rgba(255,255,255,0.05)'" onmouseout="this.style.background='transparent'">
                            <span style="margin-right: 8px;">🚪</span> Logout
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <div class="dashboard-layout">
        <aside class="sidebar">
            <nav class="sidebar-nav">
                <a href="dashboard.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/dashboard.png" alt="" loading="lazy">
                    </span>
                    <span>Dashboard</span>
                </a>
                <a href="decks.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/cards.png" alt="" loading="lazy">
                    </span>
                    <span>My Decks</span>
                </a>
                <a href="progress.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/progress.png" alt="" loading="lazy">
                    </span>
                    <span>Progress</span>
                </a>
                <a href="favorites.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/favorite.png" alt="" loading="lazy">
                    </span>
                    <span>Favorites</span>
                </a>
                <a href="friends.php" class="nav-item active">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/friends.png" alt="" loading="lazy">
                    </span>
                    <span>Friends</span>
                </a>
                <a href="reports.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                        </svg>
                    </span>
                    <span>Reports</span>
                </a>
                <a href="planner.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/planner.png" alt="" loading="lazy">
                    </span>
                    <span>Study Planner</span>
                </a>
                <a href="settings.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/settings.png" alt="" loading="lazy">
                    </span>
                    <span>Settings</span>
                </a>
            </nav>
        </aside>

        <main class="main-content">
            <div class="friends-layout">
                <header class="friends-header">
                    <div>
                        <h1 class="friends-title">
                            Friends
                            <?php if ($pending_deck_share_count > 0): ?>
                                <span class="share-alert-pill"><?php echo $pending_deck_share_count; ?> deck <?php echo $pending_deck_share_count === 1 ? 'request' : 'requests'; ?></span>
                            <?php endif; ?>
                        </h1>
                        <p class="friends-subtitle">Connect with your classmates and keep track of their study progress.</p>
                    </div>
                    <div class="friends-actions">
                        <button class="btn btn-secondary" id="findFriendsBtn">Find Friends</button>
                        
                    </div>
                </header>

                <?php if ($share_success): ?>
                    <div class="success-message"><?php echo htmlspecialchars($share_success); ?></div>
                <?php endif; ?>
                <?php if ($share_error): ?>
                    <div class="error-message"><?php echo htmlspecialchars($share_error); ?></div>
                <?php endif; ?>

                <section class="friends-content">
                    <section class="card">
                        <div class="card-header">
                            <h2 class="card-title">Your Friends</h2>
                            <span class="badge"><?php echo count($friends_list); ?> <?php echo count($friends_list) === 1 ? 'Friend' : 'Friends'; ?></span>
                        </div>
                        <div class="search-bar">
                            <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                            </svg>
                            <input type="search" id="searchFriendsInput" placeholder="Search friends by name or email…" autocomplete="off">
                        </div>
                        <div class="friend-list" id="friendsList">
                            <?php if (!empty($friends_list)): ?>
                                        <?php foreach ($friends_list as $friend): ?>
                                    <article class="friend-item" data-name="<?php echo htmlspecialchars(strtolower($friend['full_name'] . ' ' . $friend['username'] . ' ' . $friend['email'])); ?>">
                                        <div class="friend-avatar">
                                            <?php if (!empty($friend['profile_picture_src'])): ?>
                                                <img src="<?php echo htmlspecialchars($friend['profile_picture_src'], ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($friend['full_name']); ?> avatar" />
                                            <?php else: ?>
                                                <span><?php echo htmlspecialchars($friend['initials']); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="friend-info">
                                            <h3 class="friend-name"><?php echo htmlspecialchars($friend['full_name']); ?></h3>
                                            <p class="friend-status"><?php echo htmlspecialchars($friend['username']); ?> • <?php echo htmlspecialchars($friend['email']); ?></p>
                                        </div>
                                        <div class="friend-actions">
                                            <button class="btn btn-secondary view-profile-btn" style="padding: 8px 14px;" 
                                                    data-friend-id="<?php echo (int)$friend['user_id']; ?>"
                                                    data-friend-name="<?php echo htmlspecialchars($friend['full_name'], ENT_QUOTES); ?>"
                                                    data-friend-username="<?php echo htmlspecialchars($friend['username'], ENT_QUOTES); ?>"
                                                    data-friend-email="<?php echo htmlspecialchars($friend['email'], ENT_QUOTES); ?>"
                                                    data-friend-initials="<?php echo htmlspecialchars($friend['initials'], ENT_QUOTES); ?>"
                                                            data-friend-profile="<?php echo htmlspecialchars($friend['profile_picture_src'] ?? '', ENT_QUOTES); ?>"
                                                    data-friend-decks="<?php echo (int)$friend['deck_count']; ?>"
                                                    data-friend-cards="<?php echo (int)$friend['card_count']; ?>"
                                                    data-friend-joined="<?php echo htmlspecialchars($friend['created_at'] ?? date('Y-m-d'), ENT_QUOTES); ?>">View Profile</button>
                                            <?php if (!empty($user_decks)): ?>
                                                <button class="btn btn-primary share-deck-btn"
                                                        style="padding: 8px 14px;"
                                                        data-friend-id="<?php echo (int)$friend['user_id']; ?>"
                                                        data-friend-name="<?php echo htmlspecialchars($friend['full_name'], ENT_QUOTES); ?>">
                                                    Send Deck
                                                </button>
                                            <?php else: ?>
                                                <button class="btn btn-secondary" style="padding: 8px 14px;" disabled title="Create a deck first">
                                                    Send Deck
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </article>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <div class="empty-state">
                                    <div class="empty-icon">👥</div>
                                    <p>You don't have any friends yet. Use "Find Friends" to search and add friends!</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </section>

                    <aside class="card">
                        <div class="card-header">
                            <h2 class="card-title">Friend Requests</h2>
                            <span class="badge"><?php echo count($friend_requests); ?> <?php echo count($friend_requests) === 1 ? 'Pending' : 'Pending'; ?></span>
                        </div>
                        <?php if ($accept_error): ?>
                            <div class="error-message" style="margin-bottom: 16px;"><?php echo htmlspecialchars($accept_error); ?></div>
                        <?php endif; ?>
                        <?php if ($decline_error): ?>
                            <div class="error-message" style="margin-bottom: 16px;"><?php echo htmlspecialchars($decline_error); ?></div>
                        <?php endif; ?>
                        <div class="friend-list">
                            <?php if (!empty($friend_requests)): ?>
                                <?php foreach ($friend_requests as $request): ?>
                                    <article class="friend-item" style="flex-direction: column; align-items: stretch;">
                                        <div style="display: flex; align-items: center; gap: 16px;">
                                            <div class="friend-avatar">
                                                <?php if (!empty($request['profile_picture_src'])): ?>
                                                    <img src="<?php echo htmlspecialchars($request['profile_picture_src'], ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($request['full_name']); ?> avatar" />
                                                <?php else: ?>
                                                    <span><?php echo htmlspecialchars($request['initials']); ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="friend-info">
                                                <h3 class="friend-name"><?php echo htmlspecialchars($request['full_name']); ?></h3>
                                                <p class="friend-status"><?php echo htmlspecialchars($request['username']); ?> • <?php echo htmlspecialchars($request['email']); ?></p>
                                            </div>
                                        </div>
                                        <div class="friend-actions" style="justify-content: flex-end;">
                                            <form method="post" style="display: inline;">
                                                <input type="hidden" name="decline_friend" value="1">
                                                <input type="hidden" name="request_id" value="<?php echo (int)$request['id']; ?>">
                                                <button type="submit" class="btn btn-secondary" style="padding: 8px 16px;">Decline</button>
                                            </form>
                                            <form method="post" style="display: inline;">
                                                <input type="hidden" name="accept_friend" value="1">
                                                <input type="hidden" name="request_id" value="<?php echo (int)$request['id']; ?>">
                                                <button type="submit" class="btn btn-primary" style="padding: 8px 16px;">Accept</button>
                                            </form>
                                        </div>
                                    </article>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                        <?php if (empty($friend_requests)): ?>
                            <div class="empty-state">
                                <div class="empty-icon">👋</div>
                                <p>No pending friend requests. Use "Find Friends" to search and add friends!</p>
                            </div>
                        <?php endif; ?>
                    </aside>
                </section>

                <div class="deck-share-sections">
                    <section class="card">
                        <div class="card-header">
                            <h2 class="card-title">Deck Share Requests</h2>
                            <span class="badge"><?php echo $pending_deck_share_count; ?> Pending</span>
                        </div>
                        <?php if (!empty($deck_share_inbox)): ?>
                            <div class="deck-share-list">
                                <?php foreach ($deck_share_inbox as $share): ?>
                                    <article class="deck-share-item">
                                        <div class="deck-share-header">
                                            <div>
                                                <div class="deck-share-title"><?php echo htmlspecialchars($share['title']); ?></div>
                                                <div class="deck-share-meta">
                                                    From <?php echo htmlspecialchars($share['sender_name']); ?> •
                                                    <?php echo date('M j, g:i A', strtotime($share['created_at'])); ?>
                                                </div>
                                            </div>
                                            <span class="share-status-badge pending">Pending</span>
                                        </div>
                                        <?php if (!empty($share['message'])): ?>
                                            <p class="deck-share-message"><?php echo nl2br(htmlspecialchars($share['message'])); ?></p>
                                        <?php endif; ?>
                                        <div class="deck-share-actions">
                                            <form method="post">
                                                <input type="hidden" name="decline_share" value="1">
                                                <input type="hidden" name="share_id" value="<?php echo (int)$share['id']; ?>">
                                                <button type="submit" class="btn btn-secondary" style="padding: 8px 16px;">Decline</button>
                                            </form>
                                            <form method="post">
                                                <input type="hidden" name="accept_share" value="1">
                                                <input type="hidden" name="share_id" value="<?php echo (int)$share['id']; ?>">
                                                <button type="submit" class="btn btn-primary" style="padding: 8px 16px;">Accept & Add</button>
                                            </form>
                                        </div>
                                    </article>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="empty-state">
                                <div class="empty-icon">📫</div>
                                <p>No deck share requests right now.</p>
                            </div>
                        <?php endif; ?>
                    </section>

                    <section class="card">
                        <div class="card-header">
                            <h2 class="card-title">Deck Share Activity</h2>
                            <span class="badge"><?php echo count($deck_share_activity); ?> Total</span>
                        </div>
                        <?php if (!empty($deck_share_activity)): ?>
                            <div class="deck-share-list">
                                <?php foreach ($deck_share_activity as $activity): ?>
                                    <article class="deck-share-item">
                                        <div class="deck-share-header">
                                            <div>
                                                <div class="deck-share-title"><?php echo htmlspecialchars($activity['title']); ?></div>
                                                <div class="deck-share-meta">
                                                    To <?php echo htmlspecialchars($activity['recipient_name']); ?> •
                                                    <?php echo date('M j, g:i A', strtotime($activity['created_at'])); ?>
                                                </div>
                                            </div>
                                            <span class="share-status-badge <?php echo htmlspecialchars($activity['status']); ?>">
                                                <?php echo ucfirst($activity['status']); ?>
                                            </span>
                                        </div>
                                        <?php if (!empty($activity['message'])): ?>
                                            <p class="deck-share-message"><?php echo nl2br(htmlspecialchars($activity['message'])); ?></p>
                                        <?php endif; ?>
                                        <?php if ($activity['status'] === 'pending'): ?>
                                            <div class="deck-share-actions">
                                                <form method="post">
                                                    <input type="hidden" name="cancel_share" value="1">
                                                    <input type="hidden" name="share_id" value="<?php echo (int)$activity['id']; ?>">
                                                    <button type="submit" class="btn btn-secondary" style="padding: 8px 16px;">Cancel Request</button>
                                                </form>
                                            </div>
                                        <?php else: ?>
                                            <div class="deck-share-meta">
                                                Updated <?php echo $activity['responded_at'] ? date('M j, g:i A', strtotime($activity['responded_at'])) : date('M j, g:i A', strtotime($activity['created_at'])); ?>
                                            </div>
                                        <?php endif; ?>
                                    </article>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="empty-state">
                                <div class="empty-icon">📤</div>
                                <p>No deck share activity yet.</p>
                            </div>
                        <?php endif; ?>
                    </section>
                </div>
            </div>
        </main>
    </div>

    <!-- Find Friends Modal -->
    <div class="modal-overlay" id="findFriendsModal">
        <div class="modal">
            <div class="modal-header">
                <h2 class="modal-title">Find Friends</h2>
                <button class="modal-close" id="closeFindFriendsModal">✕</button>
            </div>
            <form method="post" class="search-form" id="searchFriendsForm">
                <input type="hidden" name="search_friends" value="1">
                <?php if ($search_error): ?>
                    <div class="error-message"><?php echo htmlspecialchars($search_error); ?></div>
                <?php endif; ?>
                <?php if ($add_friend_message): ?>
                    <div style="padding: 12px; background: rgba(34, 197, 94, 0.1); border: 1px solid rgba(34, 197, 94, 0.3); border-radius: 10px; color: #bbf7d0; margin-bottom: 16px;"><?php echo htmlspecialchars($add_friend_message); ?></div>
                <?php endif; ?>
                <?php if ($add_friend_error): ?>
                    <div class="error-message"><?php echo htmlspecialchars($add_friend_error); ?></div>
                <?php endif; ?>
                <div class="search-input-group">
                    <input type="text" name="search_query" id="searchQuery" placeholder="Search by username or email..." value="<?php echo htmlspecialchars($_POST['search_query'] ?? ''); ?>" required autocomplete="off">
                    <button type="submit" class="btn btn-primary">Search</button>
                </div>
            </form>
            
            <?php if (!empty($search_results)): ?>
                <div class="search-results">
                    <?php foreach ($search_results as $result): ?>
                        <div class="search-result-item">
                            <div class="result-avatar">
                                <?php if (!empty($result['profile_picture_src'])): ?>
                                    <img src="<?php echo htmlspecialchars($result['profile_picture_src'], ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($result['full_name']); ?> avatar" />
                                <?php else: ?>
                                    <span><?php echo htmlspecialchars($result['initials']); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="result-info">
                                <h3 class="result-name"><?php echo htmlspecialchars($result['full_name']); ?></h3>
                                <p class="result-details">
                                    <strong>Username:</strong> <?php echo htmlspecialchars($result['username']); ?><br>
                                    <strong>Email:</strong> <?php echo htmlspecialchars($result['email']); ?>
                                </p>
                            </div>
                            <div class="result-actions">
                                <?php if ($result['friendship_status'] === 'accepted'): ?>
                                    <button type="button" class="btn btn-secondary" style="padding: 8px 16px;" disabled>Friends</button>
                                <?php elseif ($result['friendship_status'] === 'pending'): ?>
                                    <?php if ($result['friendship_user_id'] == $user_id): ?>
                                        <button type="button" class="btn btn-secondary" style="padding: 8px 16px;" disabled>Request Sent</button>
                                    <?php else: ?>
                                        <button type="button" class="btn btn-secondary" style="padding: 8px 16px;" disabled>Pending</button>
                                    <?php endif; ?>
                                <?php elseif ($result['friendship_status'] === 'blocked'): ?>
                                    <button type="button" class="btn btn-secondary" style="padding: 8px 16px;" disabled>Blocked</button>
                                <?php else: ?>
                                    <form method="post" style="display: inline;">
                                        <input type="hidden" name="add_friend" value="1">
                                        <input type="hidden" name="friend_id" value="<?php echo (int)$result['id']; ?>">
                                        <input type="hidden" name="search_friends" value="1">
                                        <input type="hidden" name="search_query" value="<?php echo htmlspecialchars($_POST['search_query'] ?? ''); ?>">
                                        <button type="submit" class="btn btn-primary" style="padding: 8px 16px;">Add Friend</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['search_friends']) && empty($search_error)): ?>
                <div style="text-align: center; padding: 40px 20px; color: var(--muted);">
                    <div style="font-size: 48px; margin-bottom: 16px;">🔍</div>
                    <p>No users found. Try a different search term.</p>
                </div>
            <?php else: ?>
                <div style="text-align: center; padding: 40px 20px; color: var(--muted);">
                    <div style="font-size: 48px; margin-bottom: 16px;">👥</div>
                    <p>Enter a username or email to search for friends.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Share Deck Modal -->
    <div class="modal-overlay" id="shareDeckModal">
        <div class="modal">
            <div class="modal-header">
                <h2 class="modal-title">Send Deck to <span id="shareFriendName"><?php echo htmlspecialchars($share_form_state['friend_name']); ?></span></h2>
                <button class="modal-close" id="closeShareDeckModal">✕</button>
            </div>
            <?php if (empty($user_decks)): ?>
                <div class="error-message">You need to create a deck before you can share.</div>
            <?php else: ?>
                <form method="post" id="shareDeckForm" class="search-form">
                    <input type="hidden" name="share_deck" value="1">
                    <input type="hidden" name="recipient_id" id="shareRecipientId" value="<?php echo $share_form_state['recipient_id'] ?: ''; ?>">
                    <input type="hidden" name="friend_label" id="shareFriendLabelInput" value="<?php echo htmlspecialchars($share_form_state['friend_name']); ?>">
                    <?php if (isset($_POST['share_deck']) && $share_error): ?>
                        <div class="error-message"><?php echo htmlspecialchars($share_error); ?></div>
                    <?php endif; ?>
                    <input type="hidden" name="deck_id" id="shareDeckInput" value="<?php echo $share_form_state['deck_id'] ?: ''; ?>">
                    <div class="deck-selection-summary">
                        <div>
                            <div class="deck-selection-label">Selected deck</div>
                            <div class="deck-selection-value" id="selectedDeckTitle">
                                <?php
                                    $selectedDeckTitle = 'No deck selected';
                                    foreach ($user_decks as $deck) {
                                        if ($share_form_state['deck_id'] === (int)$deck['id']) {
                                            $selectedDeckTitle = $deck['title'] ?: 'Untitled Deck';
                                            break;
                                        }
                                    }
                                    echo htmlspecialchars($selectedDeckTitle);
                                ?>
                            </div>
                        </div>
                        <button type="button" class="btn btn-secondary" id="openDeckPickerBtn" style="white-space:nowrap;">Choose Deck</button>
                    </div>
                    <label for="shareMessage" style="display:block;font-size:13px;color:var(--muted);margin-bottom:4px;">Optional message</label>
                    <textarea name="share_message" id="shareMessage" rows="3" maxlength="255" placeholder="Add a short note…" style="width:100%;padding:12px;border-radius:12px;border:1px solid var(--border);background:rgba(255,255,255,0.02);color:var(--text);font-size:15px;margin-bottom:16px;"><?php echo htmlspecialchars($share_form_state['message']); ?></textarea>
                    <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;">Send Deck</button>
                </form>
            <?php endif; ?>
        </div>
    </div>

    <!-- Deck Picker Modal -->
    <div class="modal-overlay" id="deckPickerModal">
        <div class="modal">
            <div class="modal-header">
                <h2 class="modal-title">Choose a Deck</h2>
                <button class="modal-close" id="closeDeckPickerModal">✕</button>
            </div>
            <div class="deck-option-grid">
                <?php foreach ($user_decks as $deck): ?>
                    <button type="button"
                            class="deck-option"
                            data-deck-id="<?php echo (int)$deck['id']; ?>"
                            data-deck-title="<?php echo htmlspecialchars($deck['title'] ?: 'Untitled Deck', ENT_QUOTES); ?>"
                            style="--deck-color: <?php echo htmlspecialchars($deck['color'] ?: $user_theme_color); ?>;">
                        <div class="deck-option-accent"></div>
                        <div class="deck-option-body">
                            <div class="deck-option-title"><?php echo htmlspecialchars($deck['title'] ?: 'Untitled Deck'); ?></div>
                            <?php if (!empty($deck['description'])): ?>
                                <div class="deck-option-desc"><?php echo htmlspecialchars($deck['description']); ?></div>
                            <?php else: ?>
                                <div class="deck-option-desc">Updated <?php echo htmlspecialchars($deck['updated_at'] ? date('M j', strtotime($deck['updated_at'])) : 'recently'); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="deck-option-check">
                            <span>✔</span>
                        </div>
                    </button>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <script>
        const userMenu = document.getElementById('userMenu');
        const userDropdown = document.getElementById('userDropdown');

        if (userMenu && userDropdown) {
            userMenu.addEventListener('click', function (e) {
                e.stopPropagation();
                const isVisible = userDropdown.style.display === 'block';
                userDropdown.style.display = isVisible ? 'none' : 'block';
            });

            document.addEventListener('click', function (e) {
                if (!userMenu.contains(e.target)) {
                    userDropdown.style.display = 'none';
                }
            });
        }

        // Find Friends Modal
        const findFriendsBtn = document.getElementById('findFriendsBtn');
        const findFriendsModal = document.getElementById('findFriendsModal');
        const closeFindFriendsModal = document.getElementById('closeFindFriendsModal');

        if (findFriendsBtn && findFriendsModal) {
            findFriendsBtn.addEventListener('click', function() {
                findFriendsModal.classList.add('show');
                document.getElementById('searchQuery')?.focus();
            });

            if (closeFindFriendsModal) {
                closeFindFriendsModal.addEventListener('click', function() {
                    findFriendsModal.classList.remove('show');
                });
            }

            findFriendsModal.addEventListener('click', function(e) {
                if (e.target === findFriendsModal) {
                    findFriendsModal.classList.remove('show');
                }
            });
        }

        // Auto-open modal if there are search results or errors
        <?php if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['search_friends'])): ?>
        window.addEventListener('DOMContentLoaded', function() {
            if (findFriendsModal) {
                findFriendsModal.classList.add('show');
            }
        });
        <?php endif; ?>

        // Search friends functionality
        const searchFriendsInput = document.getElementById('searchFriendsInput');
        const friendsList = document.getElementById('friendsList');
        
        if (searchFriendsInput && friendsList) {
            searchFriendsInput.addEventListener('input', function(e) {
                const searchTerm = e.target.value.toLowerCase().trim();
                const friendItems = friendsList.querySelectorAll('.friend-item');
                
                friendItems.forEach(function(item) {
                    const searchData = item.getAttribute('data-name') || '';
                    if (searchData.includes(searchTerm)) {
                        item.style.display = '';
                    } else {
                        item.style.display = 'none';
                    }
                });
                
                // Show empty state if no results
                const visibleItems = Array.from(friendItems).filter(item => item.style.display !== 'none');
                let emptyState = friendsList.querySelector('.empty-state');
                
                if (visibleItems.length === 0 && searchTerm !== '') {
                    if (!emptyState) {
                        emptyState = document.createElement('div');
                        emptyState.className = 'empty-state';
                        emptyState.innerHTML = '<div class="empty-icon">🔍</div><p>No friends found matching your search.</p>';
                        friendsList.appendChild(emptyState);
                    }
                } else if (emptyState && searchTerm === '') {
                    emptyState.remove();
                }
            });
        }

        // Share Deck Modal
        const shareDeckModal = document.getElementById('shareDeckModal');
        const closeShareDeckModalBtn = document.getElementById('closeShareDeckModal');
        const shareDeckButtons = document.querySelectorAll('.share-deck-btn');
        const shareFriendNameEl = document.getElementById('shareFriendName');
        const shareRecipientInput = document.getElementById('shareRecipientId');
        const shareFriendLabelInput = document.getElementById('shareFriendLabelInput');

        function openShareDeckModal(friendId, friendName) {
            if (!shareDeckModal) return;
            shareDeckModal.classList.add('show');
            document.body.style.overflow = 'hidden';
            if (shareFriendNameEl) {
                shareFriendNameEl.textContent = friendName || 'your friend';
            }
            if (shareRecipientInput) {
                shareRecipientInput.value = friendId || '';
            }
            if (shareFriendLabelInput) {
                shareFriendLabelInput.value = friendName || 'your friend';
            }
            setActiveDeckById(shareDeckInput?.value || null);
        }

        function closeShareDeckModal() {
            if (!shareDeckModal) return;
            shareDeckModal.classList.remove('show');
            document.body.style.overflow = '';
        }

        if (shareDeckButtons.length && shareDeckModal) {
            shareDeckButtons.forEach((btn) => {
                btn.addEventListener('click', () => {
                    const friendId = btn.getAttribute('data-friend-id');
                    const friendName = btn.getAttribute('data-friend-name') || 'your friend';
                    openShareDeckModal(friendId, friendName);
                });
            });
        }

        if (closeShareDeckModalBtn) {
            closeShareDeckModalBtn.addEventListener('click', () => {
                closeShareDeckModal();
            });
        }

        if (shareDeckModal) {
            shareDeckModal.addEventListener('click', (e) => {
                if (e.target === shareDeckModal) {
                    closeShareDeckModal();
                }
            });
        }

        const deckPickerModal = document.getElementById('deckPickerModal');
        const closeDeckPickerModalBtn = document.getElementById('closeDeckPickerModal');
        const openDeckPickerBtn = document.getElementById('openDeckPickerBtn');
        const deckPickerOptions = deckPickerModal ? deckPickerModal.querySelectorAll('.deck-option') : [];
        const shareDeckInput = document.getElementById('shareDeckInput');
        const selectedDeckTitleEl = document.getElementById('selectedDeckTitle');

        function updateSelectedDeckLabel(title) {
            if (selectedDeckTitleEl) {
                selectedDeckTitleEl.textContent = title || 'No deck selected';
            }
        }

        function setActiveDeckById(deckId) {
            if (!deckPickerOptions.length || !shareDeckInput) {
                return;
            }

            let matched = false;
            deckPickerOptions.forEach((option) => {
                const optionId = option.getAttribute('data-deck-id');
                const isMatch = deckId && optionId === String(deckId);
                option.classList.toggle('active', !!isMatch);
                if (isMatch) {
                    matched = true;
                }
            });

            if (!matched && deckPickerOptions[0]) {
                deckPickerOptions.forEach((btn) => btn.classList.remove('active'));
            }
        }

        function openDeckPickerModalFlow() {
            if (!deckPickerModal) return;
            deckPickerModal.classList.add('show');
            document.body.style.overflow = 'hidden';
            setActiveDeckById(shareDeckInput?.value || null);
        }

        function closeDeckPickerModalFlow() {
            if (!deckPickerModal) return;
            deckPickerModal.classList.remove('show');
            if (!shareDeckModal || !shareDeckModal.classList.contains('show')) {
                document.body.style.overflow = '';
            }
        }

        if (openDeckPickerBtn) {
            openDeckPickerBtn.addEventListener('click', openDeckPickerModalFlow);
        }

        if (closeDeckPickerModalBtn) {
            closeDeckPickerModalBtn.addEventListener('click', closeDeckPickerModalFlow);
        }

        if (deckPickerModal) {
            deckPickerModal.addEventListener('click', (e) => {
                if (e.target === deckPickerModal) {
                    closeDeckPickerModalFlow();
                }
            });
        }

        if (deckPickerOptions.length && shareDeckInput) {
            deckPickerOptions.forEach((option) => {
                option.addEventListener('click', () => {
                    const deckId = option.getAttribute('data-deck-id');
                    const deckTitle = option.getAttribute('data-deck-title') || 'Untitled Deck';
                    shareDeckInput.value = deckId;
                    deckPickerOptions.forEach((btn) => btn.classList.remove('active'));
                    option.classList.add('active');
                    updateSelectedDeckLabel(deckTitle);
                    closeDeckPickerModalFlow();
                });
            });
        }

        const shouldReopenShareModal = <?php echo (isset($_POST['share_deck']) && $share_error) ? 'true' : 'false'; ?>;
        window.addEventListener('DOMContentLoaded', () => {
            if (shouldReopenShareModal) {
                const previousFriendId = <?php echo (int)$share_form_state['recipient_id']; ?>;
                const previousFriendName = <?php echo json_encode($share_form_state['friend_name']); ?>;
                if (previousFriendId) {
                    openShareDeckModal(previousFriendId, previousFriendName);
                }
            }
        });

        // View Profile Modal
        (function() {
            const profileModalOverlay = document.createElement('div');
            profileModalOverlay.className = 'profile-modal-overlay';
            profileModalOverlay.id = 'profileModalOverlay';

            const profileModal = document.createElement('div');
            profileModal.className = 'profile-modal';

            profileModal.innerHTML = `
                <div class="profile-modal-header">
                    <h2 class="profile-modal-title">Profile</h2>
                    <button class="profile-modal-close" id="closeProfileModal">✕</button>
                </div>
                <div class="profile-content" id="profileContent">
                    <!-- Content will be populated dynamically -->
                </div>
            `;

            profileModalOverlay.appendChild(profileModal);
            document.body.appendChild(profileModalOverlay);

            function openProfileModal(friendData) {
                const avatar = friendData.profile && friendData.profile.trim() !== '' ? 
                    `<div class="profile-avatar-large"><img src="${friendData.profile}" alt="${friendData.name}'s avatar" /></div>` :
                    `<div class="profile-avatar-large">${friendData.initials}</div>`;
                
                const joinedDate = friendData.joined ? new Date(friendData.joined).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }) : 'Unknown';
                
                document.getElementById('profileContent').innerHTML = `
                    ${avatar}
                    <div>
                        <h3 class="profile-name">${friendData.name}</h3>
                        <p class="profile-username">@${friendData.username}</p>
                        <p class="profile-email">${friendData.email}</p>
                    </div>
                    <div class="profile-stats">
                        <div class="profile-stat">
                            <div class="profile-stat-value">${friendData.decks}</div>
                            <p class="profile-stat-label">Decks</p>
                        </div>
                        <div class="profile-stat">
                            <div class="profile-stat-value">${friendData.cards}</div>
                            <p class="profile-stat-label">Cards</p>
                        </div>
                    </div>
                    <p class="profile-joined">Friends since ${joinedDate}</p>
                `;
                profileModalOverlay.classList.add('show');
            }

            function closeProfileModal() {
                profileModalOverlay.classList.remove('show');
            }

            // Handle View Profile button clicks
            document.addEventListener('click', function(e) {
                const viewProfileBtn = e.target.closest('.view-profile-btn');
                if (viewProfileBtn) {
                    e.preventDefault();
                    const friendData = {
                        id: viewProfileBtn.getAttribute('data-friend-id'),
                        name: viewProfileBtn.getAttribute('data-friend-name'),
                        username: viewProfileBtn.getAttribute('data-friend-username'),
                        email: viewProfileBtn.getAttribute('data-friend-email'),
                        initials: viewProfileBtn.getAttribute('data-friend-initials'),
                        profile: viewProfileBtn.getAttribute('data-friend-profile'),
                        decks: viewProfileBtn.getAttribute('data-friend-decks'),
                        cards: viewProfileBtn.getAttribute('data-friend-cards'),
                        joined: viewProfileBtn.getAttribute('data-friend-joined')
                    };
                    openProfileModal(friendData);
                }
            });

            // Close modal handlers
            document.getElementById('closeProfileModal').addEventListener('click', closeProfileModal);
            profileModalOverlay.addEventListener('click', function(e) {
                if (e.target === profileModalOverlay) {
                    closeProfileModal();
                }
            });
        })();

        // Notifications dropdown
        const notifBtn = document.getElementById('notifBtn');
        const notifDropdown = document.getElementById('notifDropdown');

        if (notifBtn && notifDropdown) {
            notifBtn.addEventListener('click', function (e) {
                e.stopPropagation();
                notifDropdown.classList.toggle('show');
            });

            document.addEventListener('click', function (e) {
                if (!notifDropdown.contains(e.target) && e.target !== notifBtn) {
                    notifDropdown.classList.remove('show');
                }
            });
        }

        // Clear all notifications function
        function clearAllNotifications(event) {
            event.preventDefault();
            event.stopPropagation();
            
            if (!confirm('Clear all notifications?')) {
                return;
            }
            
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            
            const inputAction = document.createElement('input');
            inputAction.type = 'hidden';
            inputAction.name = 'clear_all_notifications';
            inputAction.value = '1';
            
            const inputAjax = document.createElement('input');
            inputAjax.type = 'hidden';
            inputAjax.name = 'ajax';
            inputAjax.value = '1';
            
            form.appendChild(inputAction);
            form.appendChild(inputAjax);
            document.body.appendChild(form);
            
            fetch(window.location.href, {
                method: 'POST',
                body: new FormData(form)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const notifList = document.querySelector('.notif-list');
                    if (notifList) {
                        const items = notifList.querySelectorAll('.notif-item');
                        items.forEach((item, index) => {
                            setTimeout(() => {
                                item.style.opacity = '0';
                                item.style.transform = 'translateX(-10px)';
                                setTimeout(() => item.remove(), 200);
                            }, index * 50);
                        });
                        
                        setTimeout(() => {
                            const notifDropdown = document.getElementById('notifDropdown');
                            if (notifDropdown) {
                                notifDropdown.innerHTML = '<h4><span>Notifications</span></h4><div class="notif-empty"><p>You\'re all caught up</p><span>We\'ll let you know when something new happens.</span></div>';
                            }
                            const notifBtn = document.getElementById('notifBtn');
                            if (notifBtn) {
                                notifBtn.classList.remove('has-alert');
                            }
                        }, items.length * 50 + 200);
                    }
                }
            })
            .catch(error => {
                console.error('Error clearing notifications:', error);
                form.submit();
            });
            
            document.body.removeChild(form);
        }

        // Dismiss notification function
        function dismissNotification(event, notifId) {
            event.preventDefault();
            event.stopPropagation();
            
            if (!notifId) return;
            
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            
            const inputAction = document.createElement('input');
            inputAction.type = 'hidden';
            inputAction.name = 'dismiss_notification';
            inputAction.value = '1';
            
            const inputId = document.createElement('input');
            inputId.type = 'hidden';
            inputId.name = 'notif_id';
            inputId.value = notifId;
            
            const inputAjax = document.createElement('input');
            inputAjax.type = 'hidden';
            inputAjax.name = 'ajax';
            inputAjax.value = '1';
            
            form.appendChild(inputAction);
            form.appendChild(inputId);
            form.appendChild(inputAjax);
            document.body.appendChild(form);
            
            fetch(window.location.href, {
                method: 'POST',
                body: new FormData(form)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const notifItem = document.querySelector(`[data-notif-id="${notifId}"]`);
                    if (notifItem) {
                        notifItem.style.opacity = '0';
                        notifItem.style.transform = 'translateX(-10px)';
                        setTimeout(() => {
                            notifItem.remove();
                            const notifList = document.querySelector('.notif-list');
                            if (notifList && notifList.children.length === 0) {
                                const notifDropdown = document.getElementById('notifDropdown');
                                if (notifDropdown) {
                                    notifDropdown.innerHTML = '<h4>Notifications</h4><div class="notif-empty"><p>You\'re all caught up</p><span>We\'ll let you know when something new happens.</span></div>';
                                }
                                const notifBtn = document.getElementById('notifBtn');
                                if (notifBtn) {
                                    notifBtn.classList.remove('has-alert');
                                }
                            }
                        }, 200);
                    }
                }
            })
            .catch(error => {
                console.error('Error dismissing notification:', error);
                form.submit();
            });
            
            document.body.removeChild(form);
        }
    </script>

    <!-- Logout Confirmation Modal -->
    <div class="logout-modal-overlay" id="logoutModal">
        <div class="logout-modal">
            <div class="logout-modal-icon">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
                </svg>
            </div>
            <div class="logout-modal-header">
                <h3 class="logout-modal-title">Confirm Logout</h3>
                <p class="logout-modal-message">Are you sure you want to logout? You will need to login again to access your account.</p>
            </div>
            <div class="logout-modal-actions">
                <button class="btn-modal btn-modal-cancel" id="logoutCancelBtn">Cancel</button>
                <button class="btn-modal btn-modal-logout" id="logoutConfirmBtn">Logout</button>
            </div>
        </div>
    </div>

    <script>
        // Logout Modal - Initialize after modal HTML is in DOM
        document.addEventListener('DOMContentLoaded', function() {
            const logoutBtn = document.getElementById('logoutBtn');
            const logoutModal = document.getElementById('logoutModal');
            const logoutConfirmBtn = document.getElementById('logoutConfirmBtn');
            const logoutCancelBtn = document.getElementById('logoutCancelBtn');

            if (logoutBtn) {
                logoutBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    if (logoutModal) {
                        logoutModal.classList.add('active');
                    }
                    // Close user dropdown when opening logout modal
                    const userDropdown = document.getElementById('userDropdown');
                    if (userDropdown) {
                        userDropdown.style.display = 'none';
                    }
                });
            }

            if (logoutCancelBtn) {
                logoutCancelBtn.addEventListener('click', function() {
                    if (logoutModal) {
                        logoutModal.classList.remove('active');
                    }
                });
            }

            if (logoutConfirmBtn) {
                logoutConfirmBtn.addEventListener('click', function() {
                    window.location.href = 'dashboard.php?logout=1';
                });
            }

            if (logoutModal) {
                logoutModal.addEventListener('click', function(e) {
                    if (e.target === logoutModal) {
                        logoutModal.classList.remove('active');
                    }
                });
            }

            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && logoutModal && logoutModal.classList.contains('active')) {
                    logoutModal.classList.remove('active');
                }
            });
        });
    </script>
</body>
</html>


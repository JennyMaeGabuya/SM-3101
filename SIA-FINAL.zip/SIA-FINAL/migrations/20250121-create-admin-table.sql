-- Admin table definition
-- Stores administrator accounts for the system

CREATE TABLE IF NOT EXISTS `admin` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `username` VARCHAR(50) NOT NULL UNIQUE,
    `email` VARCHAR(100) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `full_name` VARCHAR(100) NOT NULL,
    `status` ENUM('active','inactive') NOT NULL DEFAULT 'active',
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_admin_username` (`username`),
    KEY `idx_admin_email` (`email`),
    KEY `idx_admin_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default admin account
-- Username: admin
-- Email: admin@bizmo.com
-- Password: admin123
-- 
-- NOTE: The password hash below is a placeholder. 
-- For security, run admin/setup_admin.php to generate a proper password hash,
-- or manually generate one using: password_hash('admin123', PASSWORD_DEFAULT)
-- 
-- To set up the admin account properly, you can either:
-- 1. Run admin/setup_admin.php (recommended)
-- 2. Or manually update the password hash after running this migration
INSERT INTO `admin` (`username`, `email`, `password`, `full_name`, `status`) 
VALUES (
    'admin',
    'admin@bizmo.com',
    '$2y$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', -- Placeholder hash - run setup_admin.php to generate proper hash
    'Administrator',
    'active'
) ON DUPLICATE KEY UPDATE `username`=`username`;


-- Add reply_to_email_id column to incoming_emails table
-- This links incoming emails (replies) to sent emails

ALTER TABLE `incoming_emails` 
ADD COLUMN `reply_to_email_id` INT UNSIGNED DEFAULT NULL AFTER `message_html`,
ADD KEY `idx_incoming_emails_reply_to` (`reply_to_email_id`),
ADD CONSTRAINT `fk_incoming_emails_reply_to`
    FOREIGN KEY (`reply_to_email_id`) REFERENCES `emails` (`id`)
    ON DELETE SET NULL ON UPDATE CASCADE;







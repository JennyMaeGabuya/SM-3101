-- Add deleted column to incoming_emails table for soft delete functionality
ALTER TABLE `incoming_emails` 
ADD COLUMN `deleted` TINYINT(1) NOT NULL DEFAULT 0 AFTER `updated_at`,
ADD INDEX `idx_incoming_emails_deleted` (`deleted`);





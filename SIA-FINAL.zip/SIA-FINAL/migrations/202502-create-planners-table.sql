-- Planners table definition
-- Stores study plans/notes for users on specific dates

CREATE TABLE IF NOT EXISTS `planners` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` INT NOT NULL,
    `plan_date` DATE NOT NULL,
    `subject` VARCHAR(255) NOT NULL,
    `notes` TEXT DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_planners_user` (`user_id`),
    KEY `idx_planners_date` (`plan_date`),
    KEY `idx_planners_user_date` (`user_id`, `plan_date`),
    CONSTRAINT `fk_planners_user`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



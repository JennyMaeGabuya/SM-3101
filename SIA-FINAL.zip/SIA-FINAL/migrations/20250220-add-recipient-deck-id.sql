-- Add recipient_deck_id to deck_shares so we can track created copies
ALTER TABLE `deck_shares`
    ADD COLUMN `recipient_deck_id` INT UNSIGNED DEFAULT NULL AFTER `deck_id`;

-- Optional: if you need to run this twice, guard manually in MySQL:
-- ALTER TABLE ... ADD COLUMN ... only if it doesn't exist.




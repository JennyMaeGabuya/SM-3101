-- Emails table definition
-- Stores emails sent by admin to users

CREATE TABLE IF NOT EXISTS `emails` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `admin_id` INT UNSIGNED NOT NULL,
    `recipient_email` VARCHAR(255) NOT NULL,
    `recipient_name` VARCHAR(255) NOT NULL,
    `subject` VARCHAR(500) NOT NULL,
    `message` TEXT NOT NULL,
    `status` ENUM('sent','failed','pending') NOT NULL DEFAULT 'pending',
    `sent_at` DATETIME DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_emails_admin` (`admin_id`),
    KEY `idx_emails_recipient` (`recipient_email`),
    KEY `idx_emails_status` (`status`),
    KEY `idx_emails_created` (`created_at`),
    CONSTRAINT `fk_emails_admin`
        FOREIGN KEY (`admin_id`) REFERENCES `admin` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


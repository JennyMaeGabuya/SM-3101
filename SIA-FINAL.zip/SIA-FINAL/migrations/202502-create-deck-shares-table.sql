-- Deck shares table definition
-- Allows users to send decks to their friends

CREATE TABLE IF NOT EXISTS `deck_shares` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `sender_id` INT NOT NULL,
    `recipient_id` INT NOT NULL,
    `deck_id` INT UNSIGNED NOT NULL,
    `message` VARCHAR(255) DEFAULT NULL,
    `status` ENUM('pending','accepted','declined','cancelled') NOT NULL DEFAULT 'pending',
    `expires_at` DATETIME DEFAULT NULL,
    `responded_at` DATETIME DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `unique_deck_share` (`sender_id`, `recipient_id`, `deck_id`),
    KEY `idx_deck_shares_sender` (`sender_id`),
    KEY `idx_deck_shares_recipient` (`recipient_id`),
    KEY `idx_deck_shares_deck` (`deck_id`),
    KEY `idx_deck_shares_status` (`status`),
    CONSTRAINT `fk_deck_shares_sender`
        FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_deck_shares_recipient`
        FOREIGN KEY (`recipient_id`) REFERENCES `users` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_deck_shares_deck`
        FOREIGN KEY (`deck_id`) REFERENCES `decks` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CHECK (`sender_id` <> `recipient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;




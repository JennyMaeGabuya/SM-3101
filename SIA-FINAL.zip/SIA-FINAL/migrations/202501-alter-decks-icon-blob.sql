-- Ensure you're running this migration with appropriate backups in place.
-- 1. Convert the `icon` column to a BLOB so deck icons can store binary image data.

ALTER TABLE `decks`
    MODIFY `icon` LONGBLOB NULL;

-- Optional: If you previously stored file paths or data URIs in `icon`,
-- you can keep them as-is; they'll still be readable as blobs. Future
-- uploads will write raw binary data directly into this column.






CREATE TABLE IF NOT EXISTS `incoming_emails` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `from_email` VARCHAR(255) NOT NULL,
    `from_name` VARCHAR(255) DEFAULT NULL,
    `subject` VARCHAR(255) NOT NULL,
    `message` TEXT NOT NULL,
    `message_html` TEXT DEFAULT NULL,
    `read_status` ENUM('read','unread') NOT NULL DEFAULT 'unread',
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_incoming_emails_from_email` (`from_email`),
    KEY `idx_incoming_emails_read_status` (`read_status`),
    KEY `idx_incoming_emails_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


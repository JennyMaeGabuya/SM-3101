<?php
require_once 'config.php';

session_start();

$verify_error = '';
$verify_success = '';
$token = $_GET['token'] ?? '';

// Handle email verification
if (!empty($token)) {
    // Check if email_verification_token column exists
    $columns_check = $conn->query("SHOW COLUMNS FROM users LIKE 'email_verification_token'");
    if ($columns_check->num_rows == 0) {
        $verify_error = "Verification system not properly configured.";
    } else {
        // Verify token
        $stmt = $conn->prepare("SELECT id, email, email_verification_expiry FROM users WHERE email_verification_token = ?");
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            
            // Check if token is expired
            if (time() > $user['email_verification_expiry']) {
                $verify_error = "This verification link has expired. Please request a new one by updating your email in settings.";
            } else {
                // Verify email
                $status = 'verified';
                $update_stmt = $conn->prepare("UPDATE users SET status = ?, email_verification_token = NULL, email_verification_expiry = NULL WHERE id = ?");
                $update_stmt->bind_param("si", $status, $user['id']);
                
                if ($update_stmt->execute()) {
                    $verify_success = "Email verified successfully! You can now log in with your verified email address.";
                    
                    // If user is logged in, update session
                    if (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $user['id']) {
                        $_SESSION['user_email'] = $user['email'];
                    }
                } else {
                    $verify_error = "Error verifying email. Please try again.";
                }
                $update_stmt->close();
            }
        } else {
            $verify_error = "Invalid or expired verification token. Please request a new verification link by updating your email in settings.";
        }
        $stmt->close();
    }
} else {
    $verify_error = "No verification token provided.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bizmo – Verify Email</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #0b0b12;
            --text: #ffffff;
            --muted: #a2a3ad;
            --accent: #dc2626;
            --surface: #111118;
            --border: rgba(255,255,255,0.08);
        }

        * { box-sizing: border-box; }
        html, body { height: 100%; }
        body {
            margin: 0;
            font-family: 'Inter', ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial;
            background: linear-gradient(180deg, #0c0c14 0%, #0c0c14 55%, #0c0c14 100%);
            color: var(--text);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .verification-card {
            max-width: 500px;
            width: 100%;
            background: linear-gradient(135deg, rgba(255,255,255,0.05), rgba(255,255,255,0.02));
            border: 1px solid var(--border);
            border-radius: 20px;
            padding: 40px;
            text-align: center;
        }

        .verification-title {
            font-size: 28px;
            font-weight: 900;
            margin: 0 0 16px;
            background: linear-gradient(135deg, #fff, rgba(255,255,255,0.8));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .alert {
            padding: 16px 20px;
            border-radius: 12px;
            margin-bottom: 24px;
            font-size: 14px;
            font-weight: 600;
        }

        .alert-success {
            background: rgba(34,197,94,0.15);
            border: 1px solid rgba(34,197,94,0.3);
            color: #4ade80;
        }

        .alert-error {
            background: rgba(239,68,68,0.15);
            border: 1px solid rgba(239,68,68,0.3);
            color: #f87171;
        }

        .btn {
            display: inline-block;
            padding: 12px 24px;
            border-radius: 12px;
            background: linear-gradient(135deg, var(--accent), #b91c1c);
            color: #fff;
            font-weight: 700;
            font-size: 14px;
            text-decoration: none;
            transition: all .25s ease;
            margin-top: 16px;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(220,38,38,0.4);
        }
    </style>
</head>
<body>
    <div class="verification-card">
        <h1 class="verification-title">Email Verification</h1>
        
        <?php if ($verify_success): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($verify_success); ?>
            </div>
            <a href="login.php" class="btn">Go to Login</a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="settings.php" class="btn" style="margin-left: 12px;">Go to Settings</a>
            <?php endif; ?>
        <?php elseif ($verify_error): ?>
            <div class="alert alert-error">
                <?php echo htmlspecialchars($verify_error); ?>
            </div>
            <a href="login.php" class="btn">Go to Login</a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="settings.php" class="btn" style="margin-left: 12px;">Go to Settings</a>
            <?php endif; ?>
        <?php else: ?>
            <div class="alert alert-error">
                No verification token provided.
            </div>
            <a href="login.php" class="btn">Go to Login</a>
        <?php endif; ?>
    </div>
</body>
</html>


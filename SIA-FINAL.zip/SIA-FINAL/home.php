<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bizmo – Transform Your Learning Journey</title>
    <meta name="description" content="Modern Learning Management System that makes education accessible and engaging.">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #0b0b12;
            --text: #ffffff;
            --muted: #a2a3ad;
            --accent: #dc2626;
            --accent-700: #b91c1c;
            --surface: #111118;
            --border: rgba(255,255,255,0.08);
            --soft-red: rgba(220,38,38,0.15);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        html, body {
            height: 100%;
            overflow-x: hidden;
        }

        body {
            font-family: 'Inter', ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial;
            color: var(--text);
            position: relative;
            background: var(--bg);
        }

        /* Video Background */
        .video-background {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            overflow: hidden;
        }

        .video-background video {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .video-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(
                180deg,
                rgba(11, 11, 18, 0.95) 0%,
                rgba(11, 11, 18, 0.92) 50%,
                rgba(11, 11, 18, 0.95) 100%
            );
            z-index: 1;
        }

        /* Header */
        .header {
            position: sticky;
            top: 0;
            z-index: 30;
            backdrop-filter: saturate(140%) blur(12px);
            background: rgba(10, 10, 15, 0.75);
            border-bottom: 1px solid var(--border);
            transition: all 0.3s ease;
        }

        .header.scrolled {
            background: rgba(10, 10, 15, 0.9);
            box-shadow: 0 4px 24px rgba(0, 0, 0, 0.3);
        }

        .container {
            max-width: 1180px;
            margin: 0 auto;
            padding: 0 20px;
        }

        .nav {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 16px 0;
        }

        .brand {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            font-weight: 800;
            font-size: 18px;
            color: var(--text);
            text-decoration: none;
            transition: transform 0.2s ease;
        }

        .brand:hover {
            transform: scale(1.02);
        }

        .logo {
            background: transparent;
            box-shadow: none;
            border: 1px solid var(--border);
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: grid;
            place-items: center;
        }

        .logo svg, .logo img {
            width: 50px;
            height: 50px;
            display: block;
        }

        .links {
            display: flex;
            align-items: center;
            gap: 18px;
        }

        .link {
            color: var(--muted);
            text-decoration: none;
            font-weight: 600;
            transition: color 0.2s ease;
        }

        .link:hover {
            color: var(--text);
        }

        .cta {
            text-decoration: none;
            font-weight: 700;
            color: #fff;
            background: var(--accent);
            padding: 10px 14px;
            border-radius: 999px;
            border: 1px solid var(--accent-700);
            transition: all 0.2s ease;
        }

        .cta:hover {
            background: var(--accent-700);
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(220, 38, 38, 0.4);
        }

        /* Hero Section */
        .hero {
            position: relative;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px 20px 80px;
            text-align: center;
        }

        .hero-content {
            max-width: 900px;
            z-index: 2;
            position: relative;
        }

        .hero-title {
            font-size: clamp(36px, 6vw, 72px);
            font-weight: 900;
            margin-bottom: 24px;
            line-height: 1.1;
            background: linear-gradient(135deg, #fff, rgba(255, 255, 255, 0.8));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            animation: fadeInUp 0.8s ease;
        }

        .hero-subtitle {
            font-size: clamp(18px, 2.5vw, 24px);
            color: var(--muted);
            margin-bottom: 40px;
            line-height: 1.6;
            animation: fadeInUp 0.8s ease 0.2s both;
        }

        .hero-actions {
            display: flex;
            gap: 16px;
            justify-content: center;
            flex-wrap: wrap;
            animation: fadeInUp 0.8s ease 0.4s both;
        }

        .btn-primary {
            padding: 16px 32px;
            background: linear-gradient(135deg, var(--accent), var(--accent-700));
            color: #fff;
            font-weight: 700;
            font-size: 16px;
            border-radius: 12px;
            border: none;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s ease;
            box-shadow: 0 4px 16px rgba(220, 38, 38, 0.3);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(220, 38, 38, 0.4);
        }

        .btn-secondary {
            padding: 16px 32px;
            background: rgba(255, 255, 255, 0.05);
            color: var(--text);
            font-weight: 600;
            font-size: 16px;
            border-radius: 12px;
            border: 1px solid var(--border);
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s ease;
        }

        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.1);
            border-color: rgba(255, 255, 255, 0.2);
        }

        /* Features Section */
        .features {
            position: relative;
            padding: 100px 20px;
            z-index: 2;
        }

        .section-title {
            text-align: center;
            font-size: clamp(32px, 4vw, 48px);
            font-weight: 900;
            margin-bottom: 16px;
            background: linear-gradient(135deg, #fff, rgba(255, 255, 255, 0.8));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .section-subtitle {
            text-align: center;
            font-size: 18px;
            color: var(--muted);
            margin-bottom: 60px;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }

        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 32px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .feature-card {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid var(--border);
            border-radius: 20px;
            padding: 40px;
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
        }

        .feature-card:hover {
            transform: translateY(-8px);
            background: rgba(255, 255, 255, 0.05);
            border-color: rgba(220, 38, 38, 0.3);
            box-shadow: 0 20px 60px rgba(220, 38, 38, 0.2);
        }

        .feature-icon {
            width: 64px;
            height: 64px;
            border-radius: 16px;
            background: var(--soft-red);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 24px;
        }

        .feature-icon svg {
            width: 32px;
            height: 32px;
            color: var(--accent);
        }

        .feature-title {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 12px;
            color: var(--text);
        }

        .feature-description {
            font-size: 16px;
            color: var(--muted);
            line-height: 1.6;
        }

        /* Stats Section */
        .stats {
            position: relative;
            padding: 80px 20px;
            z-index: 2;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 32px;
            max-width: 1000px;
            margin: 0 auto;
        }

        .stat-card {
            text-align: center;
            padding: 32px;
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid var(--border);
            border-radius: 16px;
            backdrop-filter: blur(10px);
        }

        .stat-value {
            font-size: 48px;
            font-weight: 900;
            color: var(--accent);
            margin-bottom: 8px;
        }

        .stat-label {
            font-size: 16px;
            color: var(--muted);
            font-weight: 600;
        }

        /* CTA Section */
        .cta-section {
            position: relative;
            padding: 100px 20px;
            z-index: 2;
            text-align: center;
        }

        .cta-card {
            max-width: 800px;
            margin: 0 auto;
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid var(--border);
            border-radius: 24px;
            padding: 60px 40px;
            backdrop-filter: blur(10px);
        }

        .cta-title {
            font-size: clamp(32px, 4vw, 42px);
            font-weight: 900;
            margin-bottom: 16px;
            background: linear-gradient(135deg, #fff, rgba(255, 255, 255, 0.8));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .cta-description {
            font-size: 18px;
            color: var(--muted);
            margin-bottom: 32px;
            line-height: 1.6;
        }

        /* Footer */
        footer {
            position: relative;
            padding: 40px 20px;
            text-align: center;
            color: var(--muted);
            border-top: 1px solid var(--border);
            z-index: 2;
            background: rgba(11, 11, 18, 0.95);
        }

        /* Animations */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Custom Scrollbar Styles */
        /* Webkit browsers (Chrome, Safari, Edge) */
        ::-webkit-scrollbar {
            width: 12px;
            height: 12px;
        }

        ::-webkit-scrollbar-track {
            background: var(--bg);
            border-radius: 6px;
        }

        ::-webkit-scrollbar-thumb {
            background: var(--border);
            border-radius: 6px;
            border: 2px solid var(--bg);
            transition: background 0.2s ease;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: var(--accent);
        }

        /* Firefox */
        * {
            scrollbar-width: thin;
            scrollbar-color: var(--border) var(--bg);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .hero {
                padding: 100px 20px 60px;
            }

            .hero-actions {
                flex-direction: column;
            }

            .btn-primary, .btn-secondary {
                width: 100%;
            }

            .features-grid {
                grid-template-columns: 1fr;
            }

            .feature-card {
                padding: 32px;
            }

            .cta-card {
                padding: 40px 24px;
            }
        }

        @media (max-width: 480px) {
            .links {
                gap: 12px;
            }

            .link {
                font-size: 14px;
            }

            .cta {
                padding: 8px 12px;
                font-size: 14px;
            }
        }
    </style>
</head>
<body>
    <!-- Video Background -->
    <div class="video-background">
        <video autoplay muted loop playsinline>
            <source src="videos/video.mp4" type="video/mp4">
        </video>
        <div class="video-overlay"></div>
    </div>

    <!-- Header -->
    <header class="header" id="header">
        <div class="container">
            <nav class="nav">
                <a href="home.php" class="brand">
                    <div class="logo" aria-label="Bizmo logo">
                        <img src="icons/bizmo.png" alt="" width="50" height="50" />
                    </div>
                    <span>Bizmo</span>
                </a>
                <div class="links">
                    <a class="link" href="home.php">Home</a>
                    <a class="link" href="#features">Features</a>
                
                    <a class="cta" href="login.php">Get started</a>
                </div>
            </nav>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-content">
            <h1 class="hero-title">Transform Your Learning Journey</h1>
            <p class="hero-subtitle">
                Experience a modern Learning Management System designed to make education accessible, 
                engaging, and effective. Join thousands of learners achieving their goals.
            </p>
            <div class="hero-actions">
                <a href="login.php" class="btn-primary">Start Learning Now</a>
                <a href="#features" class="btn-secondary">Explore Features</a>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features" id="features">
        <div class="container">
            <h2 class="section-title">Why Choose Bizmo?</h2>
            <p class="section-subtitle">
                Discover the features that make learning easier, faster, and more enjoyable
            </p>
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                    </div>
                    <h3 class="feature-title">Interactive Learning</h3>
                    <p class="feature-description">
                        Engage with interactive quizzes, flashcards, and practice sessions that adapt to your learning pace.
                    </p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>
                        </svg>
                    </div>
                    <h3 class="feature-title">Track Progress</h3>
                    <p class="feature-description">
                        Monitor your learning journey with detailed analytics and progress tracking to stay motivated.
                    </p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/>
                        </svg>
                    </div>
                    <h3 class="feature-title">Collaborate & Share</h3>
                    <p class="feature-description">
                        Connect with friends, share study decks, and learn together in a supportive community.
                    </p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/>
                        </svg>
                    </div>
                    <h3 class="feature-title">Custom Decks</h3>
                    <p class="feature-description">
                        Create personalized study decks tailored to your needs and learning objectives.
                    </p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/>
                        </svg>
                    </div>
                    <h3 class="feature-title">Fast & Efficient</h3>
                    <p class="feature-description">
                        Optimized performance ensures smooth learning experience across all devices.
                    </p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
                        </svg>
                    </div>
                    <h3 class="feature-title">Secure & Private</h3>
                    <p class="feature-description">
                        Your data is protected with industry-standard security measures and privacy controls.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="stats">
        <div class="container">
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-value">10K+</div>
                    <div class="stat-label">Active Learners</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">50K+</div>
                    <div class="stat-label">Study Decks</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">1M+</div>
                    <div class="stat-label">Cards Studied</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">98%</div>
                    <div class="stat-label">Satisfaction Rate</div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta-section">
        <div class="container">
            <div class="cta-card">
                <h2 class="cta-title">Ready to Start Learning?</h2>
                <p class="cta-description">
                    Join thousands of learners who are already transforming their education with Bizmo. 
                    Get started today and unlock your full learning potential.
                </p>
                <a href="login.php" class="btn-primary">Get Started Free</a>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="container">
            <p>&copy; 2025 Bizmo. All rights reserved.</p>
        </div>
    </footer>

    <script>
        // Header scroll effect
        const header = document.getElementById('header');
        let lastScroll = 0;

        window.addEventListener('scroll', () => {
            const currentScroll = window.pageYOffset;
            
            if (currentScroll > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
            
            lastScroll = currentScroll;
        });

        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Ensure video plays on mobile
        const video = document.querySelector('.video-background video');
        if (video) {
            video.play().catch(err => {
                console.log('Video autoplay prevented:', err);
            });
        }
    </script>
</body>
</html>

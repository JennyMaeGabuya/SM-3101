# How to Enable IMAP Extension in XAMPP

## Step-by-Step Instructions

### Step 1: Locate your php.ini file
1. Open XAMPP Control Panel
2. Click on the **"Config"** button next to Apache
3. Select **"PHP (php.ini)"** from the dropdown menu
4. This will open the `php.ini` file in Notepad

**OR** manually navigate to:
```
C:\xampp\php\php.ini
```

### Step 2: Enable IMAP Extension
1. In the `php.ini` file, press **Ctrl + F** to open Find dialog
2. Search for: `extension=imap`
3. You should find a line that looks like:
   ```ini
   ;extension=imap
   ```
4. Remove the semicolon (`;`) at the beginning to uncomment it:
   ```ini
   extension=imap
   ```

### Step 3: Check if IMAP DLL exists
1. Navigate to: `C:\xampp\php\ext\`
2. Look for the file: `php_imap.dll`
3. If the file **does NOT exist**, you need to download it (see Step 4)

### Step 4: Download IMAP DLL (if needed)
If `php_imap.dll` is missing:

1. **Option A: Download from PHP official site**
   - Go to: https://windows.php.net/download/
   - Download the **Thread Safe (TS)** version matching your PHP version
   - Extract `php_imap.dll` from the ZIP file
   - Copy it to: `C:\xampp\php\ext\`

2. **Option B: Use XAMPP's built-in DLL**
   - The DLL should already be in `C:\xampp\php\ext\`
   - If not, reinstall XAMPP or update to the latest version

### Step 5: Verify IMAP dependencies
IMAP extension requires additional DLL files. Make sure these exist in `C:\xampp\php\`:
- `libeay32.dll`
- `ssleay32.dll`
- `libssh2.dll`

If missing, copy them from `C:\xampp\php\ext\` or download from PHP official site.

### Step 6: Restart Apache
1. In XAMPP Control Panel, click **"Stop"** for Apache
2. Wait a few seconds
3. Click **"Start"** for Apache

### Step 7: Verify IMAP is enabled
Create a test file `test_imap.php` in your `htdocs` folder:

```php
<?php
if (function_exists('imap_open')) {
    echo "IMAP extension is ENABLED! ✓";
} else {
    echo "IMAP extension is NOT enabled ✗";
}
phpinfo();
?>
```

Visit: `http://localhost/test_imap.php` in your browser.

## Troubleshooting

### Error: "Call to undefined function imap_open()"
- Make sure you removed the semicolon (`;`) from `extension=imap` in php.ini
- Restart Apache after making changes
- Check that `php_imap.dll` exists in `C:\xampp\php\ext\`

### Error: "Unable to load dynamic library"
- Check that all required DLL files are present
- Verify PHP version matches the DLL version
- Check Apache error logs: `C:\xampp\apache\logs\error.log`

### Still not working?
1. Check PHP version: Create `phpinfo.php` with `<?php phpinfo(); ?>`
2. Download matching IMAP DLL for your PHP version
3. Ensure you're editing the correct `php.ini` file (the one used by Apache)

## Alternative: Use Manual Email Entry
If you can't enable IMAP, you can still use the system by:
1. Clicking **"Add Incoming Email"** button in admin_email.php
2. Manually entering email details from your Gmail inbox

This works without requiring IMAP extension!


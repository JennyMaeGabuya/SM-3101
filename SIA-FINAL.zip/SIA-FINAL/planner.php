<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'] ?? 'Learner';
$user_email = $_SESSION['user_email'] ?? '';

$upload_dir = 'uploads/profiles/';
$profile_picture_path = null;

$stmt = $conn->prepare("SELECT profile_picture FROM profiles WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    $profile_filename = $row['profile_picture'] ?? null;
    if (!empty($profile_filename)) {
        $candidate_path = $upload_dir . $profile_filename;
        $filesystem_path = __DIR__ . '/' . $candidate_path;
        if (file_exists($filesystem_path)) {
            $profile_picture_path = $candidate_path;
        }
    }
}
$stmt->close();

$user_theme_color = '#dc2626';
$stmt = $conn->prepare("SELECT theme_color FROM themes WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    $user_theme_color = $row['theme_color'];
}
$stmt->close();

function hexToRgb($hex) {
    $hex = str_replace('#', '', $hex);
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    return [$r, $g, $b];
}

$theme_rgb = hexToRgb($user_theme_color);
$theme_rgba_15 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.15)";
$theme_rgba_10 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.1)";
$theme_rgba_05 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.05)";
$theme_rgba_20 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.2)";
$theme_rgba_25 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.25)";
$theme_rgba_30 = "rgba({$theme_rgb[0]},{$theme_rgb[1]},{$theme_rgb[2]},0.3)";
$theme_darker = sprintf("#%02x%02x%02x", max(0, min(255, $theme_rgb[0] - ($theme_rgb[0] * 15 / 100))), max(0, min(255, $theme_rgb[1] - ($theme_rgb[1] * 15 / 100))), max(0, min(255, $theme_rgb[2] - ($theme_rgb[2] * 15 / 100))));

function getInitials($name) {
    $words = explode(' ', trim($name));
    if (count($words) >= 2) {
        return strtoupper(substr($words[0], 0, 1) . substr($words[count($words) - 1], 0, 1));
    }
    return strtoupper(substr($name, 0, 2));
}
$user_initials = getInitials($user_name);

// Create planners table if it doesn't exist
$table_check = $conn->query("SHOW TABLES LIKE 'planners'");
if ($table_check->num_rows == 0) {
    $conn->query("CREATE TABLE IF NOT EXISTS `planners` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `user_id` INT NOT NULL,
        `plan_date` DATE NOT NULL,
        `subject` VARCHAR(255) NOT NULL,
        `notes` TEXT DEFAULT NULL,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `idx_planners_user` (`user_id`),
        KEY `idx_planners_date` (`plan_date`),
        KEY `idx_planners_user_date` (`user_id`, `plan_date`),
        CONSTRAINT `fk_planners_user`
            FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
            ON DELETE CASCADE ON UPDATE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

// Planner management
$planner_error = null;
$planner_success = null;
$planner_delete_error = null;
$planner_delete_success = null;

// Handle planner operations
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_planner'])) {
    $plan_date = trim($_POST['plan_date'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $notes = trim($_POST['notes'] ?? '');
    $planner_id = isset($_POST['planner_id']) ? (int)$_POST['planner_id'] : 0;

    if (empty($plan_date) || empty($subject)) {
        $planner_error = 'Date and subject are required.';
    } else {
        if ($planner_id > 0) {
            // Update existing planner
            $stmt = $conn->prepare("UPDATE planners SET plan_date = ?, subject = ?, notes = ? WHERE id = ? AND user_id = ?");
            $stmt->bind_param("sssii", $plan_date, $subject, $notes, $planner_id, $user_id);
        } else {
            // Create new planner
            $stmt = $conn->prepare("INSERT INTO planners (user_id, plan_date, subject, notes) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("isss", $user_id, $plan_date, $subject, $notes);
        }
        
        if ($stmt->execute()) {
            $planner_success = $planner_id > 0 ? 'Plan updated successfully.' : 'Plan created successfully.';
            $redirect_month = date('Y-m', strtotime($plan_date));
            header("Location: planner.php?month=" . $redirect_month);
            exit();
        } else {
            $planner_error = 'Failed to save plan. Please try again.';
        }
        $stmt->close();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_planner'])) {
    $delete_planner_id = isset($_POST['planner_id']) ? (int)$_POST['planner_id'] : 0;

    if ($delete_planner_id <= 0) {
        $planner_delete_error = 'Invalid plan selected.';
    } else {
        // Get the plan date before deleting
        $stmt = $conn->prepare("SELECT plan_date FROM planners WHERE id = ? AND user_id = ?");
        $stmt->bind_param("ii", $delete_planner_id, $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $plan_data = $result->fetch_assoc();
        $stmt->close();

        if ($plan_data) {
            $stmt = $conn->prepare("DELETE FROM planners WHERE id = ? AND user_id = ?");
            $stmt->bind_param("ii", $delete_planner_id, $user_id);
            if ($stmt->execute()) {
                $planner_delete_success = 'Plan deleted successfully.';
                $redirect_month = date('Y-m', strtotime($plan_data['plan_date']));
                header("Location: planner.php?month=" . $redirect_month);
                exit();
            } else {
                $planner_delete_error = 'Failed to delete plan. Please try again.';
            }
            $stmt->close();
        } else {
            $planner_delete_error = 'Plan not found or you do not have permission to delete it.';
        }
    }
}

// Fetch planners for the current month (for calendar display)
$current_month = isset($_GET['month']) ? $_GET['month'] : date('Y-m');
$planners = [];
$stmt = $conn->prepare("SELECT id, plan_date, subject, notes FROM planners WHERE user_id = ? AND DATE_FORMAT(plan_date, '%Y-%m') = ? ORDER BY plan_date ASC");
$stmt->bind_param("is", $user_id, $current_month);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $planners[$row['plan_date']][] = $row;
}
$stmt->close();

// Notification system (simplified - can be expanded if needed)
$notifications = [];
$has_notifications = !empty($notifications);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bizmo – Study Planner</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #0b0b12;
            --text: #ffffff;
            --muted: #a2a3ad;
            --accent: <?php echo $user_theme_color; ?>;
            --accent-700: <?php echo $theme_darker; ?>;
            --surface: #111118;
            --border: rgba(255,255,255,0.08);
            --soft-accent: <?php echo $theme_rgba_15; ?>;
        }
        * { box-sizing: border-box; }
        html, body { height: 100%; }
        body {
            margin: 0;
            font-family: 'Inter', ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial;
            background: linear-gradient(180deg, #0c0c14 0%, #0c0c14 55%, #0c0c14 100%);
            color: var(--text);
        }
        .header {
            position: sticky; top: 0; z-index: 30;
            backdrop-filter: saturate(180%) blur(20px);
            background: rgba(10,10,15,0.8);
            border-bottom: 1px solid var(--border);
            box-shadow: 0 4px 24px rgba(0,0,0,0.2);
        }
        .header-content {
            max-width: 1400px; margin: 0 auto; padding: 0 24px;
            display: flex; align-items: center; justify-content: space-between;
            padding-top: 18px; padding-bottom: 18px;
        }
        .brand {
            display: inline-flex; align-items: center; gap: 12px;
            font-weight: 800; font-size: 18px; color: var(--text);
            text-decoration: none; transition: transform .2s ease;
        }
        .brand:hover { transform: scale(1.02); }
        .logo {
            background: linear-gradient(135deg, <?php echo $theme_rgba_10; ?>, <?php echo $theme_rgba_05; ?>);
            box-shadow: 0 4px 12px <?php echo $theme_rgba_15; ?>;
            border: 1px solid <?php echo $theme_rgba_20; ?>;
            width: 50px; height: 50px; border-radius: 12px;
            display: grid; place-items: center;
            transition: all .3s ease;
        }
        .logo:hover { transform: rotate(5deg) scale(1.05); }
        .logo img { width: 50px; height: 50px; display: block; }
        .header-right { display: flex; align-items: center; gap: 12px; position: relative; }
        .user-menu {
            display: flex; align-items: center; gap: 12px; cursor: pointer;
            padding: 8px 14px 8px 8px; border-radius: 999px;
            background: rgba(255,255,255,0.04);
            border: 1px solid var(--border);
            transition: all .25s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
        }
        .user-menu:hover {
            background: rgba(255,255,255,0.08);
            border-color: var(--accent);
            transform: translateY(-1px);
        }
        .user-avatar {
            width: 36px; height: 36px; border-radius: 999px;
            background: linear-gradient(135deg, var(--accent), var(--accent-700));
            display: grid; place-items: center;
            font-weight: 700; font-size: 14px;
            box-shadow: 0 4px 12px <?php echo $theme_rgba_30; ?>;
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            overflow: hidden;
        }
        .dashboard-layout {
            display: grid; grid-template-columns: 280px 1fr;
            max-width: 1400px; margin: 0 auto;
            min-height: calc(100vh - 74px);
        }
        .sidebar {
            padding: 28px 20px; border-right: 1px solid var(--border);
            background: rgba(10,10,15,0.6);
            backdrop-filter: blur(10px);
        }
        .sidebar-nav { display: flex; flex-direction: column; gap: 4px; }
        .nav-item {
            display: flex; align-items: center; gap: 14px;
            padding: 14px 16px; border-radius: 14px;
            color: var(--muted); text-decoration: none;
            font-weight: 600; font-size: 15px;
            transition: all .25s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
        }
        .nav-item:hover {
            background: rgba(255,255,255,0.05);
            color: var(--text);
            transform: translateX(4px);
        }
        .nav-item.active {
            background: linear-gradient(135deg, <?php echo $theme_rgba_20; ?>, <?php echo $theme_rgba_10; ?>);
            color: var(--text);
            border: 1px solid <?php echo $theme_rgba_30; ?>;
            box-shadow: 0 4px 12px <?php echo $theme_rgba_15; ?>;
        }
        .nav-item.active::before {
            content: ''; position: absolute; left: 0; top: 50%;
            transform: translateY(-50%);
            width: 3px; height: 60%; border-radius: 0 4px 4px 0;
            background: var(--accent);
        }
        .nav-icon {
            width: 22px; height: 22px; display: grid; place-items: center;
            font-size: 20px;
        }
        .nav-icon img,
        .nav-icon svg {
            width: 20px;
            height: 20px;
            display: block;
            object-fit: contain;
            filter: brightness(0) invert(1);
            opacity: 0.75;
            transition: opacity 0.2s ease, filter 0.2s ease;
        }
        .nav-item:hover .nav-icon img,
        .nav-item:hover .nav-icon svg,
        .nav-item.active .nav-icon img,
        .nav-item.active .nav-icon svg {
            opacity: 1;
        }
        .nav-item.active .nav-icon img,
        .nav-item.active .nav-icon svg {
            filter: brightness(0) invert(1) drop-shadow(0 0 6px <?php echo $theme_rgba_25; ?>);
        }
        .main-content { padding: 40px; }
        .page-header { margin-bottom: 32px; }
        .page-title {
            font-size: 36px; font-weight: 900; margin: 0 0 10px;
            background: linear-gradient(135deg, #fff, rgba(255,255,255,0.8));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .page-subtitle {
            color: var(--muted); font-size: 17px; margin: 0;
            font-weight: 500;
        }
        .alert {
            margin-bottom: 16px;
            padding: 12px 16px;
            border-radius: 12px;
            border: 1px solid var(--border);
            font-size: 14px;
        }
        .alert-error {
            color: #fecaca;
            background: rgba(239,68,68,0.08);
            border-color: rgba(239,68,68,0.4);
        }
        .alert-success {
            color: #bbf7d0;
            background: rgba(34,197,94,0.08);
            border-color: rgba(34,197,94,0.4);
        }
        .btn {
            border: none;
            border-radius: 12px;
            padding: 12px 20px;
            font-weight: 600;
            cursor: pointer;
            transition: all .25s ease;
            font-size: 14px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .btn-primary {
            background: linear-gradient(135deg, var(--accent), var(--accent-700));
            color: #0b0b12;
            border: 1px solid <?php echo $theme_rgba_30; ?>;
            box-shadow: 0 10px 24px <?php echo $theme_rgba_20; ?>;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 14px 32px <?php echo $theme_rgba_25; ?>;
        }
        .btn-secondary {
            background: rgba(255,255,255,0.05);
            color: var(--text);
            border: 1px solid var(--border);
        }
        .btn-secondary:hover {
            border-color: var(--accent);
            transform: translateY(-2px);
        }
        /* Study Planner Styles */
        .calendar-day-header {
            text-align: center;
            font-weight: 700;
            font-size: 13px;
            color: var(--muted);
            padding: 12px 8px;
            text-transform: uppercase;
        }
        .calendar-day {
            aspect-ratio: 1;
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 8px;
            background: rgba(255,255,255,0.02);
            cursor: pointer;
            transition: all 0.2s ease;
            position: relative;
            min-height: 80px;
            display: flex;
            flex-direction: column;
        }
        .calendar-day:hover {
            background: rgba(255,255,255,0.06);
            border-color: var(--accent);
            transform: translateY(-2px);
        }
        .calendar-day.other-month {
            opacity: 0.3;
        }
        .calendar-day.today {
            border-color: var(--accent);
            background: <?php echo $theme_rgba_10; ?>;
            box-shadow: 0 0 0 2px <?php echo $theme_rgba_20; ?>;
        }
        .calendar-day-number {
            font-weight: 700;
            font-size: 14px;
            margin-bottom: 4px;
        }
        .calendar-day-plans {
            flex: 1;
            display: flex;
            flex-direction: column;
            gap: 4px;
            overflow: hidden;
        }
        .calendar-plan-item {
            font-size: 10px;
            padding: 4px 6px;
            border-radius: 6px;
            background: <?php echo $theme_rgba_20; ?>;
            color: var(--text);
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            border: 1px solid <?php echo $theme_rgba_30; ?>;
        }
        .calendar-plan-count {
            position: absolute;
            top: 4px;
            right: 4px;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background: var(--accent);
            color: #0b0b12;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 11px;
            font-weight: 700;
        }
        .planner-modal-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.75);
            backdrop-filter: blur(4px);
            z-index: 10000;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .planner-modal-overlay.active {
            display: flex;
        }
        .planner-modal {
            background: rgba(10,10,15,0.98);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 24px;
            width: min(500px, 92vw);
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 40px 120px rgba(0,0,0,0.5);
        }
        .planner-modal h3 {
            margin: 0 0 20px;
            font-size: 22px;
            font-weight: 800;
        }
        .planner-form-group {
            margin-bottom: 16px;
        }
        .planner-form-group label {
            display: block;
            font-size: 13px;
            color: var(--muted);
            margin-bottom: 6px;
            font-weight: 600;
        }
        .planner-form-group input,
        .planner-form-group textarea {
            width: 100%;
            padding: 12px 14px;
            border-radius: 12px;
            border: 1px solid var(--border);
            background: rgba(10,10,15,0.9);
            color: var(--text);
            font-family: inherit;
            font-size: 14px;
        }
        .planner-form-group textarea {
            min-height: 120px;
            resize: vertical;
            white-space: pre-wrap;
        }
        .planner-notes-list {
            margin: 8px 0 0 0;
            padding-left: 20px;
            list-style-type: disc;
            color: var(--muted);
            font-size: 12px;
            line-height: 1.6;
        }
        .planner-notes-list li {
            margin-bottom: 4px;
        }
        .planner-modal-actions {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            margin-top: 24px;
        }
        .planner-modal-actions button {
            padding: 10px 20px;
            border-radius: 10px;
            font-weight: 600;
            cursor: pointer;
            border: 1px solid var(--border);
            transition: all 0.2s ease;
        }
        .planner-btn-cancel {
            background: rgba(255,255,255,0.05);
            color: var(--text);
        }
        .planner-btn-cancel:hover {
            background: rgba(255,255,255,0.08);
        }
        .planner-btn-save {
            background: linear-gradient(135deg, var(--accent), var(--accent-700));
            color: #0b0b12;
            border: 1px solid <?php echo $theme_rgba_30; ?>;
        }
        .planner-btn-save:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px <?php echo $theme_rgba_25; ?>;
        }
        .planner-btn-delete {
            background: rgba(239,68,68,0.15);
            color: #fee2e2;
            border-color: rgba(239,68,68,0.5);
        }
        .planner-btn-delete:hover {
            background: rgba(239,68,68,0.25);
        }
        .confirm-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.65);
            backdrop-filter: blur(2px);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 20000;
            padding: 20px;
        }
        .confirm-overlay.show {
            display: flex;
        }
        .confirm-modal {
            background: rgba(10,10,15,0.98);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 24px;
            width: min(360px, 92vw);
            box-shadow: 0 16px 40px rgba(0,0,0,0.45);
        }
        .confirm-modal h4 {
            margin: 0 0 8px;
            font-size: 18px;
            font-weight: 700;
        }
        .confirm-modal p {
            margin: 0 0 18px;
            color: var(--muted);
            font-size: 14px;
            line-height: 1.6;
        }
        .confirm-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }
        .confirm-actions button {
            border-radius: 10px;
            padding: 10px 16px;
            font-weight: 600;
            cursor: pointer;
            border: 1px solid var(--border);
            background: rgba(255,255,255,0.05);
            color: var(--text);
            transition: all 0.2s ease;
        }
        .confirm-actions button:hover {
            background: rgba(255,255,255,0.08);
        }
        .confirm-actions .danger {
            border-color: rgba(239,68,68,0.5);
            background: rgba(239,68,68,0.15);
            color: #fee2e2;
        }
        .confirm-actions .danger:hover {
            background: rgba(239,68,68,0.25);
        }
        .planner-container {
            background: linear-gradient(135deg, rgba(255,255,255,0.05), rgba(255,255,255,0.02));
            border: 1px solid var(--border);
            border-radius: 20px;
            padding: 24px;
        }
        .planner-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 24px;
            flex-wrap: wrap;
            gap: 12px;
        }

        @media (max-width: 1024px) {
            .dashboard-layout { grid-template-columns: 1fr; }
            .sidebar { display: none; }
        }
        @media (max-width: 720px) {
            .main-content { padding: 24px; }
            .page-title { font-size: 28px; }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-content">
            <a href="dashboard.php" class="brand">
                <div class="logo" aria-label="Bizmo logo">
                    <img src="icons/bizmo.png" alt="" width="50" height="50" />
                </div>
                <span>Bizmo</span>
            </a>
            <div class="header-right">
                <div class="user-menu" id="userMenu">
                    <div class="user-avatar" style="<?php if ($profile_picture_path): ?>background-image: url('<?php echo htmlspecialchars($profile_picture_path); ?>');<?php endif; ?>">
                        <?php if (!$profile_picture_path): ?>
                            <?php echo htmlspecialchars($user_initials); ?>
                        <?php endif; ?>
                    </div>
                    <span style="font-weight: 600; font-size: 14px;"><?php echo htmlspecialchars($user_name); ?></span>
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                    </svg>
                    <div class="user-dropdown" id="userDropdown" style="display: none; position: absolute; top: calc(100% + 8px); right: 0; background: rgba(10,10,15,0.95); border: 1px solid var(--border); border-radius: 12px; padding: 8px; min-width: 200px; box-shadow: 0 8px 24px rgba(0,0,0,0.4); z-index: 1000;">
                        <div style="padding: 12px; border-bottom: 1px solid var(--border);">
                            <div style="font-weight: 600; font-size: 14px; margin-bottom: 4px;"><?php echo htmlspecialchars($user_name); ?></div>
                            <div style="font-size: 12px; color: var(--muted);"><?php echo htmlspecialchars($user_email); ?></div>
                        </div>
                        <a href="#" id="logoutBtn" style="display: block; padding: 12px; color: var(--text); text-decoration: none; border-radius: 8px; transition: background 0.2s ease; font-size: 14px; font-weight: 600;" onmouseover="this.style.background='rgba(255,255,255,0.05)'" onmouseout="this.style.background='transparent'">
                            <span style="margin-right: 8px;">🚪</span> Logout
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <div class="dashboard-layout">
        <aside class="sidebar">
            <nav class="sidebar-nav">
                <a href="dashboard.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/dashboard.png" alt="" loading="lazy">
                    </span>
                    <span>Dashboard</span>
                </a>
                <a href="decks.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/cards.png" alt="" loading="lazy">
                    </span>
                    <span>My Decks</span>
                </a>
                <a href="progress.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/progress.png" alt="" loading="lazy">
                    </span>
                    <span>Progress</span>
                </a>
                <a href="favorites.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/favorite.png" alt="" loading="lazy">
                    </span>
                    <span>Favorites</span>
                </a>
                <a href="friends.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/friends.png" alt="" loading="lazy">
                    </span>
                    <span>Friends</span>
                </a>
                <a href="reports.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                        </svg>
                    </span>
                    <span>Reports</span>
                </a>
                <a href="planner.php" class="nav-item active">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/planner.png" alt="" loading="lazy">
                    </span>
                    <span>Study Planner</span>
                </a>
                <a href="settings.php" class="nav-item">
                    <span class="nav-icon" aria-hidden="true">
                        <img src="icons/settings.png" alt="" loading="lazy">
                    </span>
                    <span>Settings</span>
                </a>
            </nav>
        </aside>

        <main class="main-content">
            <div class="page-header">
                <h1 class="page-title">Study Planner</h1>
                <p class="page-subtitle">Plan your study schedule and review sessions.</p>
            </div>

            <?php if (!empty($planner_error)): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($planner_error); ?></div>
            <?php elseif (!empty($planner_success)): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($planner_success); ?></div>
            <?php endif; ?>
            <?php if (!empty($planner_delete_error)): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($planner_delete_error); ?></div>
            <?php elseif (!empty($planner_delete_success)): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($planner_delete_success); ?></div>
            <?php endif; ?>

            <div class="planner-container">
                <div class="planner-header">
                    <div style="display: flex; align-items: center; gap: 16px;">
                        <button class="btn btn-secondary" id="prevMonth" style="padding: 8px 12px; font-size: 18px;">‹</button>
                        <h2 id="currentMonthDisplay" style="margin: 0; font-size: 20px; font-weight: 700; min-width: 200px; text-align: center;">
                            <?php echo date('F Y', strtotime($current_month . '-01')); ?>
                        </h2>
                        <button class="btn btn-secondary" id="nextMonth" style="padding: 8px 12px; font-size: 18px;">›</button>
                    </div>
                    <button class="btn btn-primary" id="addPlanBtn" style="padding: 10px 20px;">+ Add Plan</button>
                </div>

                <div id="calendarContainer" style="display: grid; grid-template-columns: repeat(7, 1fr); gap: 8px;">
                    <!-- Calendar will be generated by JavaScript -->
                </div>
            </div>
        </main>
    </div>

    <div id="deletePlanOverlay" class="confirm-overlay">
        <div class="confirm-modal">
            <h4>Delete Plan?</h4>
            <p>You're about to delete this study plan. This action cannot be undone.</p>
            <div class="confirm-actions">
                <button type="button" id="cancelDeletePlan">Cancel</button>
                <button type="button" id="confirmDeletePlan" class="danger">Delete</button>
            </div>
        </div>
    </div>

    <script>
        // Study Planner functionality
        (function() {
            const addPlanBtn = document.getElementById('addPlanBtn');
            const prevMonthBtn = document.getElementById('prevMonth');
            const nextMonthBtn = document.getElementById('nextMonth');
            const currentMonthDisplay = document.getElementById('currentMonthDisplay');
            const calendarContainer = document.getElementById('calendarContainer');
            
            let currentMonth = '<?php echo $current_month; ?>';
            const plannersData = <?php echo json_encode($planners); ?>;

            // Helper function to format notes as bulleted list
            function formatNotesAsBullets(notes) {
                if (!notes || notes.trim() === '') return '';
                const lines = notes.split('\n').filter(line => line.trim() !== '');
                if (lines.length === 0) return '';
                return '<ul style="margin: 8px 0 0 0; padding-left: 20px; list-style-type: disc; color: var(--muted); font-size: 12px; line-height: 1.6;">' +
                    lines.map(line => `<li style="margin-bottom: 4px;">${line.trim()}</li>`).join('') +
                    '</ul>';
            }

            // Render calendar
            function renderCalendar() {
                const [year, month] = currentMonth.split('-').map(Number);
                const firstDay = new Date(year, month - 1, 1);
                const lastDay = new Date(year, month, 0);
                const daysInMonth = lastDay.getDate();
                const startingDayOfWeek = firstDay.getDay();

                const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 
                    'July', 'August', 'September', 'October', 'November', 'December'];
                currentMonthDisplay.textContent = `${monthNames[month - 1]} ${year}`;

                // Clear container
                calendarContainer.innerHTML = '';

                // Day headers
                const dayHeaders = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
                dayHeaders.forEach(day => {
                    const header = document.createElement('div');
                    header.className = 'calendar-day-header';
                    header.textContent = day;
                    calendarContainer.appendChild(header);
                });

                // Previous month days
                const prevMonthLastDay = new Date(year, month - 1, 0).getDate();
                for (let i = startingDayOfWeek - 1; i >= 0; i--) {
                    const day = prevMonthLastDay - i;
                    const dayEl = createCalendarDay(day, true, year, month - 1);
                    calendarContainer.appendChild(dayEl);
                }

                // Current month days
                for (let day = 1; day <= daysInMonth; day++) {
                    const dayEl = createCalendarDay(day, false, year, month);
                    calendarContainer.appendChild(dayEl);
                }

                // Next month days to fill the grid
                const totalCells = calendarContainer.children.length;
                const remainingCells = 42 - totalCells; // 6 rows * 7 days
                for (let day = 1; day <= remainingCells; day++) {
                    const dayEl = createCalendarDay(day, true, year, month + 1);
                    calendarContainer.appendChild(dayEl);
                }
            }

            function createCalendarDay(day, isOtherMonth, year, month) {
                const dayEl = document.createElement('div');
                dayEl.className = 'calendar-day';
                if (isOtherMonth) {
                    dayEl.classList.add('other-month');
                }

                const dateStr = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                const today = new Date();
                const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
                
                if (dateStr === todayStr) {
                    dayEl.classList.add('today');
                }

                const dayNumber = document.createElement('div');
                dayNumber.className = 'calendar-day-number';
                dayNumber.textContent = day;
                dayEl.appendChild(dayNumber);

                const plansContainer = document.createElement('div');
                plansContainer.className = 'calendar-day-plans';
                
                if (plannersData[dateStr] && plannersData[dateStr].length > 0) {
                    const plans = plannersData[dateStr];
                    if (plans.length > 3) {
                        const countBadge = document.createElement('div');
                        countBadge.className = 'calendar-plan-count';
                        countBadge.textContent = plans.length;
                        dayEl.appendChild(countBadge);
                    }
                    plans.slice(0, 3).forEach(plan => {
                        const planItem = document.createElement('div');
                        planItem.className = 'calendar-plan-item';
                        planItem.textContent = plan.subject;
                        // Format notes for tooltip
                        let tooltipText = plan.subject;
                        if (plan.notes) {
                            const noteLines = plan.notes.split('\n').filter(line => line.trim() !== '').map(line => '• ' + line.trim()).join('\n');
                            tooltipText += ':\n' + noteLines;
                        }
                        planItem.title = tooltipText;
                        plansContainer.appendChild(planItem);
                    });
                }
                dayEl.appendChild(plansContainer);

                dayEl.addEventListener('click', function(e) {
                    e.stopPropagation();
                    if (plannersData[dateStr] && plannersData[dateStr].length > 0) {
                        // If multiple plans, show list; otherwise edit the single plan
                        if (plannersData[dateStr].length === 1) {
                            window.openPlannerModal(dateStr, plannersData[dateStr][0].id);
                        } else {
                            showPlansList(dateStr, plannersData[dateStr]);
                        }
                    } else {
                        window.openPlannerModal(dateStr);
                    }
                });

                return dayEl;
            }

            // Month navigation
            if (prevMonthBtn) {
                prevMonthBtn.addEventListener('click', function() {
                    const [year, month] = currentMonth.split('-').map(Number);
                    const newDate = new Date(year, month - 2, 1);
                    currentMonth = `${newDate.getFullYear()}-${String(newDate.getMonth() + 1).padStart(2, '0')}`;
                    window.location.href = `planner.php?month=${currentMonth}`;
                });
            }

            if (nextMonthBtn) {
                nextMonthBtn.addEventListener('click', function() {
                    const [year, month] = currentMonth.split('-').map(Number);
                    const newDate = new Date(year, month, 1);
                    currentMonth = `${newDate.getFullYear()}-${String(newDate.getMonth() + 1).padStart(2, '0')}`;
                    window.location.href = `planner.php?month=${currentMonth}`;
                });
            }

            // Planner modal
            const plannerModalOverlay = document.createElement('div');
            plannerModalOverlay.className = 'planner-modal-overlay';
            plannerModalOverlay.id = 'plannerModalOverlay';

            const plannerModal = document.createElement('div');
            plannerModal.className = 'planner-modal';

            // Make functions accessible globally
            window.openPlannerModal = function(dateStr = null, plannerId = null) {
                const form = document.createElement('form');
                form.method = 'POST';
                const currentUrl = new URL(window.location.href);
                const monthParam = currentUrl.searchParams.get('month') || currentMonth;
                form.action = 'planner.php?month=' + monthParam;
                form.innerHTML = `
                    <h3>${plannerId ? 'Edit Plan' : 'Add Plan'}</h3>
                    ${plannerId ? '<input type="hidden" name="planner_id" value="' + plannerId + '">' : ''}
                    <input type="hidden" name="save_planner" value="1">
                    <div class="planner-form-group">
                        <label for="plan_date">Date</label>
                        <input type="date" id="plan_date" name="plan_date" value="${dateStr || ''}" required>
                    </div>
                    <div class="planner-form-group">
                        <label for="subject">Subject</label>
                        <input type="text" id="subject" name="subject" placeholder="e.g. Mathematics, History" required>
                    </div>
                    <div class="planner-form-group">
                        <label for="notes">Notes</label>
                        <textarea id="notes" name="notes" placeholder="Add your study plan or review notes...&#10;Each line will be displayed as a bullet point"></textarea>
                    </div>
                    <div class="planner-modal-actions">
                        ${plannerId ? '<button type="button" class="planner-btn-delete" id="deletePlanBtn">Delete</button>' : ''}
                        <button type="button" class="planner-btn-cancel" id="cancelPlanBtn">Cancel</button>
                        <button type="submit" class="planner-btn-save">Save</button>
                    </div>
                `;

                // Load existing data if editing
                if (plannerId && plannersData) {
                    Object.values(plannersData).flat().forEach(plan => {
                        if (plan.id == plannerId) {
                            form.querySelector('#plan_date').value = plan.plan_date;
                            form.querySelector('#subject').value = plan.subject;
                            form.querySelector('#notes').value = plan.notes || '';
                        }
                    });
                }

                plannerModal.innerHTML = '';
                plannerModal.appendChild(form);
                plannerModalOverlay.appendChild(plannerModal);
                document.body.appendChild(plannerModalOverlay);
                plannerModalOverlay.classList.add('active');

                // Delete button handler
                const deleteBtn = form.querySelector('#deletePlanBtn');
                if (deleteBtn) {
                    deleteBtn.addEventListener('click', function() {
                        // Close the planner modal first
                        closePlannerModal();
                        // Show delete confirmation modal
                        showDeleteConfirmation(plannerId);
                    });
                }

                // Cancel button
                form.querySelector('#cancelPlanBtn').addEventListener('click', closePlannerModal);

                // Close on overlay click
                plannerModalOverlay.addEventListener('click', function(e) {
                    if (e.target === plannerModalOverlay) {
                        closePlannerModal();
                    }
                });
            }

            window.closePlannerModal = function() {
                plannerModalOverlay.classList.remove('active');
                setTimeout(() => {
                    if (plannerModalOverlay.parentNode) {
                        plannerModalOverlay.parentNode.removeChild(plannerModalOverlay);
                    }
                }, 300);
            };

            function showPlansList(dateStr, plans) {
                const dateObj = new Date(dateStr + 'T00:00:00');
                const dateFormatted = dateObj.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
                
                const listContainer = document.createElement('div');
                listContainer.innerHTML = `
                    <h3>Plans for ${dateFormatted}</h3>
                    <div id="plansListContainer" style="margin-bottom: 20px; max-height: 400px; overflow-y: auto;"></div>
                    <div class="planner-modal-actions">
                        <button type="button" class="planner-btn-cancel" id="closePlansListBtn">Close</button>
                        <button type="button" class="planner-btn-save" id="addNewPlanBtn">+ Add New Plan</button>
                    </div>
                `;
                
                const plansListContainer = listContainer.querySelector('#plansListContainer');
                plans.forEach(plan => {
                    const planDiv = document.createElement('div');
                    planDiv.style.cssText = 'padding: 12px; border: 1px solid var(--border); border-radius: 10px; margin-bottom: 8px; cursor: pointer; transition: all 0.2s ease;';
                    const notesDisplay = plan.notes ? formatNotesAsBullets(plan.notes) : '';
                    planDiv.innerHTML = `
                        <div style="font-weight: 700; margin-bottom: 4px;">${plan.subject}</div>
                        ${notesDisplay}
                    `;
                    planDiv.addEventListener('mouseenter', function() {
                        this.style.background = 'rgba(255,255,255,0.05)';
                    });
                    planDiv.addEventListener('mouseleave', function() {
                        this.style.background = 'transparent';
                    });
                    planDiv.addEventListener('click', function() {
                        closePlannerModal();
                        setTimeout(() => {
                            window.openPlannerModal(dateStr, plan.id);
                        }, 300);
                    });
                    plansListContainer.appendChild(planDiv);
                });

                plannerModal.innerHTML = '';
                plannerModal.appendChild(listContainer);
                plannerModalOverlay.appendChild(plannerModal);
                document.body.appendChild(plannerModalOverlay);
                plannerModalOverlay.classList.add('active');

                listContainer.querySelector('#closePlansListBtn').addEventListener('click', closePlannerModal);
                listContainer.querySelector('#addNewPlanBtn').addEventListener('click', function() {
                    closePlannerModal();
                    setTimeout(() => {
                        window.openPlannerModal(dateStr);
                    }, 300);
                });

                plannerModalOverlay.addEventListener('click', function(e) {
                    if (e.target === plannerModalOverlay) {
                        closePlannerModal();
                    }
                });
            }

            // Add plan button
            if (addPlanBtn) {
                addPlanBtn.addEventListener('click', function() {
                    const today = new Date();
                    const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
                    window.openPlannerModal(todayStr);
                });
            }

            // Initial render
            renderCalendar();

            // Delete confirmation modal
            const deletePlanOverlay = document.getElementById('deletePlanOverlay');
            const cancelDeleteBtn = document.getElementById('cancelDeletePlan');
            const confirmDeleteBtn = document.getElementById('confirmDeletePlan');
            let pendingDeletePlanId = null;

            function showDeleteConfirmation(planId) {
                pendingDeletePlanId = planId;
                if (deletePlanOverlay) {
                    deletePlanOverlay.classList.add('show');
                }
            }

            function closeDeleteModal() {
                pendingDeletePlanId = null;
                if (deletePlanOverlay) {
                    deletePlanOverlay.classList.remove('show');
                }
            }

            if (cancelDeleteBtn) {
                cancelDeleteBtn.addEventListener('click', closeDeleteModal);
            }

            if (confirmDeleteBtn) {
                confirmDeleteBtn.addEventListener('click', function() {
                    if (!pendingDeletePlanId) return;
                    const deleteForm = document.createElement('form');
                    deleteForm.method = 'POST';
                    deleteForm.style.display = 'none';
                    const currentUrl = new URL(window.location.href);
                    const monthParam = currentUrl.searchParams.get('month') || currentMonth;
                    deleteForm.action = 'planner.php?month=' + monthParam;
                    deleteForm.innerHTML = `
                        <input type="hidden" name="delete_planner" value="1">
                        <input type="hidden" name="planner_id" value="${pendingDeletePlanId}">
                    `;
                    document.body.appendChild(deleteForm);
                    deleteForm.submit();
                    closeDeleteModal();
                });
            }

            if (deletePlanOverlay) {
                deletePlanOverlay.addEventListener('click', function(e) {
                    if (e.target === deletePlanOverlay) {
                        closeDeleteModal();
                    }
                });
            }

            // Close modal on Escape key
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && deletePlanOverlay && deletePlanOverlay.classList.contains('show')) {
                    closeDeleteModal();
                }
            });

            // User menu dropdown
            const userMenu = document.getElementById('userMenu');
            const userDropdown = document.getElementById('userDropdown');

            if (userMenu && userDropdown) {
                userMenu.addEventListener('click', function (e) {
                    e.stopPropagation();
                    const isVisible = userDropdown.style.display === 'block';
                    userDropdown.style.display = isVisible ? 'none' : 'block';
                });

                document.addEventListener('click', function (e) {
                    if (!userMenu.contains(e.target) && e.target.id !== 'logoutBtn' && !e.target.closest('#logoutBtn')) {
                        userDropdown.style.display = 'none';
                    }
                });
            }

            // Logout functionality
            const logoutBtn = document.getElementById('logoutBtn');
            if (logoutBtn) {
                logoutBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    if (confirm('Are you sure you want to logout?')) {
                        window.location.href = 'dashboard.php?logout=1';
                    }
                });
            }
        })();
    </script>
</body>
</html>
